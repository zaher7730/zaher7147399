/* بطاقة العرض المشتركة
   يعرّف: card، cards، SERVICE_IMG، rp، fb، pin */
function card(o, mid) {
  const i = OFF.push(o) - 1,
    q = TQ(o)[o.tier || 0],
    pr = tp(o, o.tier || 0) || o.pr,
    t = ['bus', 'local', 'air', 'pass', 'visa'].includes(o.k),
    per = o.per || 'السعر للشخص',
    price = t
      ? `<div class="pr"><small>${per}</small>${o.old ? `<s>${curOf(o)}${o.old}</s>` : ''}${curOf(o)}${pr}</div>`
      : `<div class="pr">${curOf(o)}${pr}<small>${per}</small></div>`;
  return `<div class="o ${t ? 'o-t' : 'o-c'} o-${o.k}"><div class="inf"><div class="nm"><span class="officeName">${o.n}</span>${o.verified ? '<i class="ck" aria-label="مكتب موثّق">✓</i>' : ''}</div>${o.cr ? `<div class="cr2">${crl(o)}</div>` : ''}<div class="tags"><span class="tg">مكتب مسجل</span><span class="tg tr${o.tier || 0}">${q.t || 'باقة ' + q.n}</span></div>${mid}<div class="inc">${q.i
    .slice(0, 3)
    .map((x) => `<span>${x}</span>`)
    .join(
      '',
    )}</div><div class="bt"><button class="gb" onclick="det(${i})">ابدأ الحجز ‹</button>${price}</div></div><div class="pic ${o.model ? 'cr' : ''}"><img src="${rp(o)}" loading="lazy" onerror="fb(this,'${o.ph}')">${o.bd ? `<span class="bd ${o.br ? 'r' : ''}">${o.bd}</span>` : ''}<span class="vp">${['عادية', 'متوسطة', 'VIP'][o.tier || 0]}</span>${o.model ? `<div class="cm">${o.model}</div>` : ''}</div></div>`;
}
const cards = (o, mid) => card({ ...o }, mid);
const SERVICE_IMG = { bus: 'p_bus1', local: 'p_van1', air: 'p_air_a', pass: 'p_ps1', visa: 'p_v1', cars: 'p_car1' };
const rp = (o) => {
  if (o.k == 'local' && o.li != null && typeof LCP != 'undefined') return LCP[o.li];
  if (o.k == 'cars') return IM[o.ty == 'دفع رباعي' ? 'p_car2' : o.ty == 'بيك أب' ? 'p_car3' : 'p_car1'];
  if (o.k == 'visa' && o.svc == 'زيارة عائلية') return IM.hero_fam;
  if (o.k == 'visa' && /حج|عمرة/.test(o.svc || '')) return IM.p_v2;
  return IM[SERVICE_IMG[o.k]] || IM.p_bus1;
};
const fb = (e, k) => {
  e.onerror = null;
  e.src = IM[k] || IM.p_bus1;
};
const pin = (t) => `<span>${ic('c_pin')}${t}</span>`;
const nx = (k, D) => {
  const F = S.F[k],
    n = DATES.find((x) => D.some((r) => (!F.f || r[1] == F.f) && (!F.t || r[2] == F.t) && r[3].includes(x.n)));
  return n
    ? `<div class="chips" style="justify-content:center"><button onclick="S.d['${k}']=${n.n};render()">أقرب موعد متاح: ${n.w} ${n.d} ${n.m}</button></div>`
    : '';
};
