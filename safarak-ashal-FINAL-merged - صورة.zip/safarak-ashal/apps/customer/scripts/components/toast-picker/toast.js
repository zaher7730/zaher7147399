/* مكونات الواجهة: التنبيه المنبثق، القوائم، الأيقونات — الجزء 1/2
   يعرّف: toast، pick، setF، PKAL، sel، swap */
function toast(t) {
  const e = document.createElement('div');
  e.className = 'toast';
  e.textContent = t;
  $('#app').append(e);
  setTimeout(() => e.remove(), 2200);
}
function pick(t, opts, cur, cb) {
  document.querySelectorAll('.sheet.pk').forEach((e) => e.remove());
  const s = document.createElement('div');
  s.className = 'sheet pk';
  s.innerHTML =
    '<div><div class="pkh"><h3>' +
    t +
    '</h3><button class="pkx" type="button" aria-label="إغلاق">×</button></div>' +
    (opts.length >= 8
      ? '<div class="pks"><input type="search" class="pksi" placeholder="ابحث عن مدينة..." autocomplete="off"></div>'
      : '') +
    '<div class="pkl">' +
    opts
      .map((o) => `<div class="opt ${o == cur ? 'on' : ''}" data-v="${o}"><span>${o}</span><i>${o == cur ? '✓' : ''}</i></div>`)
      .join('') +
    '</div></div>';
  const si = s.querySelector('.pksi');
  if (si)
    si.oninput = () => {
      const N = (x) =>
          String(x)
            .replace(/[\u064B-\u0652\u0640]/g, '')
            .replace(/[أإآ]/g, 'ا')
            .replace(/ة/g, 'ه')
            .replace(/ى/g, 'ي')
            .trim()
            .toLowerCase(),
        q = N(si.value);
      let n = 0;
      s.querySelectorAll('.opt').forEach((o) => {
        const ok = !q || N(o.dataset.v + ' ' + (PKAL[o.dataset.v] || '')).includes(q);
        o.style.display = ok ? '' : 'none';
        if (ok) n++;
      });
      let e = s.querySelector('.pkn');
      if (!n) {
        if (!e) {
          e = document.createElement('div');
          e.className = 'pkn';
          e.textContent = 'لا توجد نتائج، جرّب اسماً آخر';
          s.querySelector('.pkl').append(e);
        }
      } else if (e) e.remove();
    };
  s.onclick = (e) => {
    if (e.target.closest('.pkx')) {
      s.remove();
      return;
    }
    const v = e.target.closest('.opt');
    if (v) {
      cb(v.dataset.v);
      s.remove();
      render();
    } else if (e.target === s) s.remove();
  };
  $('#app').append(s);
}
function setF(k, f, t, o, all) {
  pick(t, all ? ['الكل', ...o] : o, S.F[k][f] || (all ? 'الكل' : ''), (v) => {
    S.F[k][f] = v == 'الكل' ? '' : v;
  });
}
const PKAL = {
  المكلا: 'حضرموت',
  سيئون: 'حضرموت وادي',
  شبوة: 'عتق',
  لحج: 'الحوطة',
  أبين: 'زنجبار',
  الجوف: 'الحزم',
  المهرة: 'الغيضة',
  صنعاء: 'امانة العاصمة',
  الحديدة: 'تهامة',
  ريمة: 'الجبين',
  الضالع: 'الضالع',
  البيضاء: 'البيضاء رداع',
  مأرب: 'مارب',
  ذمار: 'ذمار',
};
const sel = (l, v, ph, fn, p) =>
  `<button class="sel ${v ? 'set' : ''}" onclick="${fn}"><span>▾</span><span style="flex:1;padding:0 8px"><small>${l}</small>${v || ph}</span>${p ? '<span>📍</span>' : ''}</button>`;
const swap = (k) => {
  const f = S.F[k];
  [f.f, f.t] = [f.t, f.f];
  render();
};
const route = (k) => {
  const f = S.F[k];
  return `<div class="r2">${sel('من', f.f, 'اختر المدينة', `setF('${k}','f','من',CT['${k}'])`, 1)}<button class="sw" onclick="swap('${k}')">⇄</button>${sel('إلى', f.t, 'اختر المدينة', `setF('${k}','t','إلى',CT['${k}'])`, 1)}</div>`;
};
const dates = (k) =>
  `<div class="dates">${DATES.map((x) => `<div class="dy ${S.d[k] == x.n ? 'on' : ''}" onclick="S.d['${k}']=${x.n};render()">${x.w}<b>${x.d}</b>${x.m}</div>`).join('')}</div><div class="hint">اسحب للأسفل لعرض المزيد من العروض ←</div>`;
