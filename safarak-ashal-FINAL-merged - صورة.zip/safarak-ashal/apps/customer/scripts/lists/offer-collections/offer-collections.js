/* مجموعات العروض (تُملأ من الخادم) والمدة والمسارات
   يعرّف: BUS، bi، cts، PRIV، priv، PRIVKM */
const BUS = [],
  LOC = [],
  AIR = [],
  CARS = [];
const bi = (D) => D.flatMap((r) => [r, Object.assign([r[0], r[2], r[1], ...r.slice(3)], { rv: 1 })]),
  BUS2 = bi(BUS),
  LOC2 = bi(LOC),
  AIR2 = bi(AIR);
const cts = (D) => [...new Set(D.flatMap((r) => [r[1], r[2]]))],
  CT = { bus: cts(BUS), local: cts(LOC), air: cts(AIR) };
/* رحلات خاصة: نقل بسيارات متنوعة من اليمن إلى عُمان والسعودية (نفس نظام النقل الدولي) */
const PRIV = [],
  PRIV2 = bi(PRIV);
CT.priv = [];
const PRIVKM = [],
  PRIVD = [],
  PRIVD2 = bi(PRIVD);
CT.privd = [];
const DURS = {};
const dur = (o) => (o.from ? DURS[o.from + '-' + o.to] || DURS[o.to + '-' + o.from] || '' : '');
const via = (o) => {
  const v = VIA[o.from + '-' + o.to] || (VIA[o.to + '-' + o.from] || []).slice().reverse();
  return v.length ? v : o.from ? [o.from, o.to] : 0;
};
