/* الرسائل والمحادثات — الجزء 2/2
   يعرّف: chat، imgSmall */
const chat = () => {
  const c = cvFor(S.cur);
  S.cur = c.id;
  if (!c.loaded && !c.busy) SA_openConv(c);
  else if (c.un) {
    c.un = 0;
    c.sid && window.SA_API.markRead(c.sid).catch(() => {});
  }
  let pd = '';
  return `<div class="chh"><button class="bk" onclick="bk('msgs')">‹</button><span class="av2">${ini(c.office)}</span><div><b>${c.office} <i class="ck">✓</i></b><small>محادثة المكتب</small></div><button class="bk" onclick="callO()" style="margin-inline-start:auto">📞</button></div>${c.oids.length ? `<div class="ctx"><span>طلباتك لدى المكتب: ${c.oids.length}</span><b class="cd">${c.oids[c.oids.length - 1]}</b></div>` : ''}<div class="ml">${c.msgs
    .map((m) => {
      const d = day(m.t),
        s = d != pd ? `<div class="day"><span>${d}</span></div>` : '';
      pd = d;
      return (
        s +
        `<div class="mr ${m.me ? 'me' : ''}"><div class="bub">${m.img ? `<img src="${m.img}" onclick="zoom(this.src)">` : m.img === '' ? `<div class="fc"><i>🖼</i><div><b>${ht(m.nm || 'صورة')}</b></div></div>` : ''}${m.doc ? `<div class="fc"${m.url ? ` onclick="window.open('${m.url}','_blank')" style="cursor:pointer"` : ''}><i>${fi(m.doc)}</i><div><b>${ht(m.doc)}</b><small>${ext(m.doc).toUpperCase()} · ${m.sz || ''}</small></div></div>` : ''}${m.m ? `<p>${ht(m.m)}</p>` : ''}<small>${hm(m.t)}${m.me ? (m.pending ? ' …' : m.rd ? ' ✓✓' : ' ✓') : ''}</small></div></div>`
      );
    })
    .join(
      '',
    )}</div><div class="msgb2"><button class="at" onclick="atsh()">＋</button><input id="cm" class="f" placeholder="اكتب رسالة..." value="${(() => {
    const v = S.pre || '';
    S.pre = '';
    return ht(v);
  })()}" onkeydown="if(event.key=='Enter')sm()"><button class="gb" onclick="sm()">إرسال</button></div>`;
};
const imgSmall = (f) =>
  new Promise((r) => {
    const R = new FileReader();
    R.onerror = () => r('');
    R.onload = () => {
      const u = R.result;
      if (/gif|svg/.test(f.type)) return r(u);
      const im = new Image();
      im.onerror = () => r(u);
      im.onload = () => {
        try {
          const k = Math.min(1, 1800 / Math.max(im.width, im.height)),
            c = document.createElement('canvas');
          c.width = Math.round(im.width * k);
          c.height = Math.round(im.height * k);
          c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
          r(c.toDataURL('image/jpeg', 0.9));
        } catch (e) {
          r(u);
        }
      };
      im.src = u;
    };
    R.readAsDataURL(f);
  });
