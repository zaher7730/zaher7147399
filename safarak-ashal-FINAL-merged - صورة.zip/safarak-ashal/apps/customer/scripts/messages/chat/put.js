/* الرسائل والمحادثات — الجزء 1/2
   يعرّف: put، sm، atsh، att، zoom، chats */
function put(m) {
  S.cv[S.cur].msgs.push({ ...m, me: 1, t: Date.now() });
  render();
}
async function sm() {
  const i = $('#cm'),
    v = i.value.trim();
  if (!v) return;
  if (!window.SA_API || !S.u.in) return toast('سجّل الدخول لإرسال الرسائل');
  const c = S.cv[S.cur];
  if (!c) return;
  i.value = '';
  try {
    await SA_sendText(c, v);
  } catch (e) {
    toast(e.message || 'تعذّر إرسال الرسالة');
    const n = $('#cm');
    if (n) n.value = v;
  }
}
function atsh() {
  const s = document.createElement('div');
  s.className = 'sheet';
  s.onclick = (e) => e.target == s && s.remove();
  s.innerHTML =
    '<div><h3>إرفاق ملف</h3>' +
    [
      ['🖼', 'صورة من المعرض', 'image/*', ''],
      ['📷', 'التقاط صورة بالكاميرا', 'image/*', 'capture'],
      ['📄', 'مستند (PDF / Word / Excel)', '.pdf,.doc,.docx,.xls,.xlsx,.txt', ''],
    ]
      .map(
        (a) =>
          `<label class="opt"><span>${a[0]} ${a[1]}</span><input type="file" hidden multiple accept="${a[2]}" ${a[3]} onchange="att(this)"></label>`,
      )
      .join('') +
    '</div>';
  $('#app').append(s);
}
async function att(inp) {
  const fs = [...inp.files],
    c = S.cv[S.cur];
  document.querySelectorAll('.sheet').forEach((e) => e.remove());
  if (!window.SA_API || !S.u.in || !c) return toast('سجّل الدخول لإرسال المرفقات');
  for (const f of fs) {
    if (f.size > 1e7) {
      toast('الحجم الأقصى 10 ميجابايت');
      continue;
    }
    try {
      toast('جارٍ إرسال ' + f.name);
      await SA_sendFile(c, f);
    } catch (e) {
      toast(e.message || 'تعذّر إرسال الملف');
    }
  }
  inp.value = '';
}
function zoom(u) {
  const s = document.createElement('div');
  s.className = 'sheet';
  s.style.alignItems = 'center';
  s.onclick = () => s.remove();
  s.innerHTML = '<img src="' + u + '" style="max-height:90%;object-fit:contain">';
  $('#app').append(s);
}
const chats = () => {
    const L = Object.values(S.cv)
    .filter((c) => c.msgs.length)
    .sort((a, b) => b.msgs.slice(-1)[0].t - a.msgs.slice(-1)[0].t);
  return (
    `<div class="kk">محادثاتك مع المكاتب</div><h1 class="h1">الرسائل</h1><p class="sub">محادثة واحدة لكل مكتب.</p>` +
    (L.map((c) => {
      const l = c.msgs.slice(-1)[0];
      return `<div class="cvr" onclick="S.cur='${c.id}';go('chat')"><span class="av2">${ini(c.office)}</span><div class="cb"><b>${c.office}</b><small>${l.img != null && l.img !== undefined && l.img !== false && !l.m && !l.doc ? '📷 صورة' : l.doc ? '📄 ' + ht(l.doc) : ht(l.m || '')}</small></div><div class="cm2"><small>${ago(l.t)}</small>${c.un ? `<i class="ub">${c.un}</i>` : ''}</div></div>`;
    }).join('') || '<div class="empty"><b>💬</b>لا توجد محادثات بعد</div>')
  );
};
const ago = (t) => {
  const d = (Date.now() - t) / 6e4;
  return d < 1
    ? 'الآن'
    : d < 60
      ? 'قبل ' + Math.floor(d) + ' د'
      : d < 1440
        ? 'قبل ' + Math.floor(d / 60) + ' ساعة'
        : 'قبل ' + Math.floor(d / 1440) + ' يوم';
};
const ext = (n) => (n.split('.').pop() || '').toLowerCase(),
  fi = (n) => ({ pdf: '📕', doc: '📘', docx: '📘', xls: '📗', xlsx: '📗' })[ext(n)] || '📄';
