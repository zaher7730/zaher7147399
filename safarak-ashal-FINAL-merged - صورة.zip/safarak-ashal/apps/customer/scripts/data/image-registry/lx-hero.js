/* سجل الصور: يربط مفاتيح الصور بملفات حقيقية داخل assets/images — الجزء 2/2
   يعرّف: lx_hero */
Object.assign(IM, {
  p_bus1: '/apps/customer/assets/images/p_bus1.jpg',
  p_bus2: '/apps/customer/assets/images/p_bus2.jpg',
  hero_bus: '',
  p_van1: '/apps/customer/assets/images/p_van1.jpg',
  p_van2: '/apps/customer/assets/images/p_van2.jpg',
  p_van3: '/apps/customer/assets/images/p_van3.jpg',
  p_air: '/apps/customer/assets/images/p_air.jpg',
  p_car1: '/apps/customer/assets/images/p_car1.jpg',
  p_car2: '/apps/customer/assets/images/p_car2.jpg',
  p_car3: '/apps/customer/assets/images/p_car3.jpg',
  p_ps1: '/apps/customer/assets/images/p_ps1.jpg',
  p_ps2: '/apps/customer/assets/images/p_ps2.jpg',
  p_v1: '/apps/customer/assets/images/p_v1.jpg',
  p_v2: '/apps/customer/assets/images/p_v2.jpg',
  hero_fam: '/apps/customer/assets/images/hero_fam.jpg',
  hdr: '/apps/customer/assets/images/hdr.jpg',
  ban: '/apps/customer/assets/images/ban.jpg',
  note: '/apps/customer/assets/images/note.jpg',
  t_van: '/apps/customer/assets/images/t_van.jpg',
  t_car: '/apps/customer/assets/images/t_car.jpg',
  t_bus: '/apps/customer/assets/images/t_bus.jpg',
  t_air: '/apps/customer/assets/images/t_air.jpg',
  t_trv: '/apps/customer/assets/images/t_trv.jpg',
  t_pass: '/apps/customer/assets/images/t_pass.jpg',
  t_send: '/apps/customer/assets/images/t_send.jpg',
  t_help: '/apps/customer/assets/images/t_help.jpg',
  h_bus: '/apps/customer/assets/images/h_bus.png',
  h_van: '/apps/customer/assets/images/h_van.png',
  h_air: '/apps/customer/assets/images/h_air.png',
  h_car: '/apps/customer/assets/images/h_car.png',
  h_pass: '/apps/customer/assets/images/h_pass.png',
  h_trv: '/apps/customer/assets/images/h_trv.png',
});
/* لاستبدال أي صورة بصورة حقيقية: window.SAFARAK_PHOTOS={p_bus1:'رابط أو base64',...} */
Object.assign(IM, {
  p_prado: '/apps/customer/assets/images/p_prado.jpg',
  p_innova: '/apps/customer/assets/images/p_innova.jpg',
  p_hero: '/apps/customer/assets/images/p_hero.webp',
});
Object.assign(IM, { p_air_a: '/apps/customer/assets/images/p_air_a.jpg', p_air_b: '/apps/customer/assets/images/p_air_b.jpg' });
Object.assign(IM, { p_bus3: '/apps/customer/assets/images/p_bus3.jpg' });
Object.assign(IM, { cr_lc_0: '/apps/customer/assets/images/cr_lc_0.jpg' });
Object.assign(IM, { hm_logo: '/shared/assets/brand/logo.png' });
IM.lx_hero = '/apps/customer/assets/images/lx_hero.jpg';
Object.assign(IM, window.SAFARAK_PHOTOS || {});
Object.assign(IM, {
  hm_cars: '/apps/customer/assets/images/hm_cars.jpg',
  hm_priv: '/apps/customer/assets/images/hm_priv.jpg',
  hm_local: '/apps/customer/assets/images/hm_local.jpg',
  hm_visa: '/apps/customer/assets/images/hm_visa.jpg',
  hm_air: '/apps/customer/assets/images/hm_air.jpg',
  hm_bus: '/apps/customer/assets/images/hm_bus.jpg',
  hm_send: '/apps/customer/assets/images/hm_send.jpg',
  hm_pass: '/apps/customer/assets/images/hm_pass.jpg',
});
