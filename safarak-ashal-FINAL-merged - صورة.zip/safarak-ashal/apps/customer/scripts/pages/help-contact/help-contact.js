/* التواصل مع خدمة العملاء
   يعرّف: ST_، CFG، callO، back، help */
const ST_ = ['قيد المراجعة', 'قيد التنفيذ', 'مكتمل', 'مرفوض', 'بانتظار الوثائق', 'بانتظار الدفع', 'ملغي'],
  HT = [
    'تم استلام الطلب وبانتظار المراجعة',
    'تم تأكيد الحوالة والمكتب يجهّز طلبك',
    'اكتمل الطلب - نتمنى لك رحلة سعيدة',
    'تم رفض الطلب من المكتب',
    'يرجى إرسال المستندات المطلوبة عبر الرسائل',
    'بانتظار إتمام الدفع لتأكيد الطلب',
    'تم إلغاء الطلب',
  ];
const CFG = { phone: '', wa: '', cs: '', hours: '', email: '', cur: 'YER', rate: 0 };
const callO = () => (CFG.phone ? (location.href = 'tel:' + CFG.phone) : toast('رقم الاتصال غير مضبوط من الإدارة بعد')),
  waO = () =>
    CFG.wa
      ? window.open(
          'https://wa.me/' +
            String(CFG.wa).replace(/\D/g, '') +
            '?text=' +
            encodeURIComponent('مرحباً، أرغب بالاستفسار' + (S.o && S.scr == 'detail' ? ' عن: ' + S.o.n + ' - ' + S.o.t : '')),
          '_blank',
        )
      : toast('رقم واتساب غير مضبوط من الإدارة بعد');
const back = (t, to) => `<div class="tt"><button class="bk" onclick="bk('${to}')">‹</button><h1>${t}</h1></div>`;
const help = () =>
  `<div class="ph"><h1>تواصل معنا</h1><img src="${IM.t_help}" style="width:90px"></div><div class="sec" onclick="waO()" style="cursor:pointer">💬 واتساب</div><div class="sec" onclick="callO()" style="cursor:pointer">📞 اتصال مباشر</div><div class="sec"><p class="pp">${CFG.hours ? 'ساعات الدعم: ' + ht(CFG.hours) : 'لم تُضبط ساعات الدعم بعد'}</p>${CFG.email ? `<p class="pp">${ht(CFG.email)}</p>` : ''}</div>`;
