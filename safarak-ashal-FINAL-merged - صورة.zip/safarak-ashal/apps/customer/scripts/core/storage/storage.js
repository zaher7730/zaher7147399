/* التخزين: كل بيانات العميل (طلبات، محادثات، مفضلة، ملف شخصي) تعيش في الخادم
   يعرّف: APP_VER، sv، sync */
const APP_VER = '4.0-server-backed';
/* تنظيف لمرة واحدة: حذف أي بيانات شخصية قديمة كانت محفوظة في هذا المتصفح */
(() => {
  try {
    if (localStorage.getItem('safarak_app_ver') !== APP_VER) {
      Object.keys(localStorage).forEach((k) => {
        if (/^safarak/i.test(k) && k !== 'safarak_app_ver') localStorage.removeItem(k);
      });
      localStorage.setItem('safarak_app_ver', APP_VER);
    }
  } catch (e) {}
})();
S.sd = 1;
S.ord = [];
S.fav = [];
S.bk = {};
S.cv = {};
S.fo = [];
S.foIds = [];
S.rv = {};
S.rvl = {};
S.myRv = [];
S.nts = [];
S.sb = {};
/* لا حفظ محلي للبيانات؛ كل تغيير يُرسل للخادم عند حدوثه */
const sv = () => {};
const sync = () => {};
