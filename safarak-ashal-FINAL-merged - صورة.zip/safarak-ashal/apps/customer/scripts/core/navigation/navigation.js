/* التنقل بين الشاشات
   يعرّف: go، bk */
function go(s, b) {
  if (s == 'help') return waCS();
  if (s == 'offices' && !b && S.scr != 'offices') S.oo = null;
  if (!b && S.scr != s) S.hist.push(S.scr);
  if (!['detail', 'book', 'pay'].includes(s)) S.ofm = null;
  S.scr = s;
  render();
  $('#m').scrollTop = 0;
}
const bk = (d) => go(S.hist.pop() || d || 'home', 1);
