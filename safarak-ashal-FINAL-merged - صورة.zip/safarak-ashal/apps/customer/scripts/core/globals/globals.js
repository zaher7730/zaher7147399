/* دوال مساعدة عامة
   يعرّف: $، curOf، hero_bus */
const $ = (s) => document.querySelector(s),
  TODAY = new Date();
/* رمز عملة العرض: من العرض نفسه (cur أو details.currency) ثم إعداد المنصة؛ لا رمز دولار ثابت */
function curOf(x) {
  return (x && (x.cur || (x.details && x.details.currency))) || (typeof CFG !== 'undefined' && CFG.cur) || 'YER';
}
/* dedupe */ IM.hero_bus = IM.p_bus1;
