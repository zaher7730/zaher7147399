/* العرض الرئيسي وشريط التنقل
   يعرّف: render، setNav، NI، NT */
function render() {
  sync();
  sv();
  const s = S.scr,
    P = { priv: privPage, bus: busPage, local: localPage, air: airPage, cars: carsPage, pass: passPage, visa: visaPage };
  let h;
  if (P[s]) {
    h = P[s]();
  } else
    h = {
      home,
      detail,
      book,
      pay,
      done,
      odetail,
      login,
      otp,
      send: sendPage,
      sendf: sendForm,
      xreq: xreqPage,
      orders,
      offices,
      ofdet,
      msgs: chats,
      chat,
      more,
      help,
      acct,
      fav,
      notif,
      policy,
      verified,
      about,
      settings,
      terms,
      tickets,
      tkdet,
      devices,
    }[s]();
  const sc = $('#m').scrollTop;
  $('#m').innerHTML = h;
  $('#m').scrollTop = ['home'].includes(s) ? 0 : sc;
  $('#m').classList.toggle('chatm', s == 'chat');
  if (s == 'chat') $('#m').scrollTop = 1e6;

  setNav(s);
}
function setNav(s) {
  if (s == 'login' || s == 'otp') {
    $('#nav').style.display = 'none';
    return;
  }
  $('#nav').style.display = '';
  const tab = S.ofm && ['detail', 'book', 'pay'].includes(s) ? 'offices' : NT[s] || 'home',
    un = Object.values(S.cv).reduce((a, c) => a + (c.un || 0), 0);
  $('#nav').innerHTML = [
    ['home', 'الرئيسية'],
    ['offices', 'المكاتب'],
    ['msgs', 'الرسائل'],
    ['orders', 'طلباتي'],
    ['more', 'المزيد'],
  ]
    .map(
      (n) =>
        `<button class="${n[0] == tab ? 'on' : ''}" onclick="S.hist=[];S.q='';go('${n[0]}')"><svg viewBox="0 0 24 24">${NI[n[0]]}</svg>${n[1]}${n[0] == 'msgs' && un ? '<i class="nbd"></i>' : ''}</button>`,
    )
    .join('');
}
const NI = {
  more: '<circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/>',
  orders: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4h6v3H9zM9 12h6M9 16h6"/>',
  msgs: '<path d="M4 5h16v11H9l-5 4z"/><path d="M8 10h8M8 13h5"/>',
  offices: '<path d="M4 21V5l9-2v18M13 8h7v13M7 8h2M7 12h2M7 16h2M16 12h1M16 16h1M2 21h20"/>',
  home: '<path d="M3 11l9-8 9 8M5 10v11h5v-6h4v6h5V10"/>',
};
const NT = {
  send: 'home',
  sendf: 'home',
  xreq: 'home',
  ofdet: 'offices',
  done: 'orders',
  odetail: 'orders',
  home: 'home',
  offices: 'offices',
  msgs: 'msgs',
  chat: 'msgs',
  orders: 'orders',
  more: 'more',
  acct: 'more',
  fav: 'more',
  notif: 'more',
  policy: 'more',
  verified: 'more',
  about: 'more',
  settings: 'more',
  terms: 'more',
  tickets: 'more',
  tkdet: 'more',
  devices: 'more',
};
