/* الإقلاع وتحميل البيانات الأولي
   يعرّف: cvFor، payT، scr، ofn */
function cvFor(id) {
  /* محادثة واحدة لكل مكتب؛ الرسائل والمرفقات حقيقية من الخادم (services/server-sync/chat.js) */
  const x = S.ord.find((o) => o.id == id);
  let nm, oid = null;
  if (x) {
    nm = x.o.n;
    oid = x.o.serverOfficeId || null;
  } else if (/^O\d+$/.test(id)) {
    const o = OFFS[+id.slice(1)] || {};
    nm = o.n || id;
    oid = o.id || null;
  } else if (S.cv[id]) return S.cv[id];
  else {
    nm = id;
    const o = OFFS.find((q) => q.n === id);
    oid = o ? o.id : null;
  }
  const off = ofn(nm),
    k = 'C:' + off;
  let c = S.cv[k];
  if (!c) c = S.cv[k] = { id: k, office: off, oids: [], un: 0, msgs: [] };
  if (oid && !c.oid) c.oid = oid;
  return c;
}
function payT(t) {
  keep();
  if (t != 'm' && !(t == 'e' && SA_online.on)) {
    toast('هذه الطريقة غير مفعّلة حالياً');
    return;
  }
  S.pt = t;
  render();
}
S.scr = S.u.in ? 'home' : 'login';
const ofn = (n) => n.replace(/\s+ل\S*.*$/, '');
(async () => {
  if (window.SA_API) {
    try {
      const params = new URLSearchParams(location.search),
        adminMode = params.get('access') === 'admin';
      const r = await window.SA_API.me();
      if (adminMode && r.user.role === 'admin') {
        location.href = '/apps/admin/';
        return;
      }
      if (r.user.role === 'customer' && !adminMode) {
        S.u.id = r.user.id;
        S.u.name = r.user.name;
        S.u.ph = r.user.phone;
        S.u.in = 1;
        S.scr = 'home';
      } else {
        S.u.in = 0;
        S.scr = 'login';
      }
    } catch {
      S.u.in = 0;
      S.scr = 'login';
    }
    try {
      const [live, offices, points, config] = await Promise.all([
        window.SA_API.services(),
        window.SA_API.offices(),
        window.SA_API.points(),
        window.SA_API.publicConfig(),
      ]);
      window.SA_applyPublicOffices(offices.offices);
      window.SA_applyPublicServices(live.services);
      window.SA_applyPublicPoints(points.points);
      Object.assign(CFG, {
        phone: config.config.phone || '',
        wa: config.config.wa || '',
        cs: config.config.wa || '',
        hours: config.config.hours || '',
        email: config.config.email || '',
        cur: config.config.cur || 'YER',
        rate: Number(config.config.rate || 0),
      });
      SA_loadOnline();
    } catch (e) {
      console.warn('Unable to load published services or public settings:', e.message);
    }
    await SA_loadPublicDocs();
    if (S.u.in) await SA_startSession({ id: S.u.id, name: S.u.name, phone: S.u.ph });
  } else if (typeof window.SA_applyPublicServices === 'function') {
    window.SA_applyPublicServices([]);
  }
  render();
})();
setInterval(() => {
  if (S.scr != 'home') return;
  const a = document.querySelectorAll('.hmSl');
  if (!a.length) return;
  S.ad = (S.ad + 1) % ADS.length;
  a.forEach((e, i) => e.classList.toggle('on', i == S.ad));
  document.querySelectorAll('.hmDots i').forEach((e, i) => e.classList.toggle('on', i == S.ad));
}, 3500);
