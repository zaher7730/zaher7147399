/* تسجيل الدخول ورمز التحقق — الجزء 3/3
   يعرّف: lgNum، FLG، LXI */
const lgNum = () => {
  const s = lgS();
  return (
    CCS[s.c][1] +
    ' ' +
    String(s.p || '')
      .replace(/\D/g, '')
      .replace(/^0+/, '')
  );
};
const FLG = {
  ye: '<svg viewBox="0 0 30 21"><rect width="30" height="7" fill="#ce1126"/><rect y="7" width="30" height="7" fill="#fff"/><rect y="14" width="30" height="7" fill="#000"/></svg>',
  sa: '<svg viewBox="0 0 30 21"><rect width="30" height="21" fill="#0a6b3a"/><rect x="7" y="6" width="16" height="2.2" rx="1" fill="#fff"/><rect x="8" y="12.6" width="14" height="1.6" rx=".8" fill="#fff"/></svg>',
};
const LXI = {
  user: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4.2"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7z"/></svg>',
  userO: '<svg viewBox="0 0 24 24" class="lo"><circle cx="12" cy="8.5" r="3.8"/><path d="M5 20.5c0-3.8 3.1-6 7-6s7 2.2 7 6"/></svg>',
  build: '<svg viewBox="0 0 24 24" class="lo"><path d="M5 21V6l7-3.5L19 6v15M3 21h18M9 9h2M13 9h2M9 13h2M13 13h2M10.5 21v-4h3v4"/></svg>',
  phone:
    '<svg viewBox="0 0 24 24"><path d="M6.6 3.5l2.6.6c.5.1.8.5.8 1l-.1 2.7c0 .5-.2.9-.6 1.2l-1.3 1c1.2 2.4 3.2 4.4 5.6 5.6l1-1.3c.3-.4.7-.6 1.2-.6l2.7-.1c.5 0 .9.3 1 .8l.6 2.6c.1.5-.1 1-.6 1.3-1.2.7-2.6 1-4 .8C9.8 19.200 4.800 14.200 3.300 8.100 3 6.700 3.300 5.300 4 4.100c.3-.5.8-.7 1.300-.6z"/></svg>',
  phoneO:
    '<svg viewBox="0 0 24 24" class="lo"><path d="M6.6 3.5l2.6.6c.5.1.8.5.8 1l-.1 2.7c0 .5-.2.9-.6 1.2l-1.3 1c1.2 2.4 3.2 4.4 5.6 5.6l1-1.3c.3-.4.7-.6 1.2-.6l2.7-.1c.5 0 .9.3 1 .8l.6 2.6c.1.5-.1 1-.6 1.3-1.2.7-2.6 1-4 .8C9.800 19.200 4.800 14.200 3.300 8.100 3 6.700 3.300 5.300 4 4.100c.3-.5.8-.7 1.300-.6z"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" class="lo"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>',
  shield:
    '<svg viewBox="0 0 24 24"><path d="M12 2.200l8 3v6.300c0 5-3.400 8.700-8 10.300-4.600-1.600-8-5.300-8-10.300V5.200z" fill="#0f2a6b"/><rect x="8.700" y="10.600" width="6.600" height="5.200" rx="1.100" fill="#fff"/><path d="M10 10.600V9a2 2 0 014 0v1.600" fill="none" stroke="#fff" stroke-width="1.500"/></svg>',
  head: '<svg viewBox="0 0 24 24" class="lo"><path d="M4 14v-2a8 8 0 0116 0v2M4 14h2.500v4H5a1 1 0 01-1-1zM20 14h-2.500v4H19a1 1 0 001-1zM18 18c0 1.700-2 2.500-5 2.500"/></svg>',
  plane:
    '<svg viewBox="0 0 24 24"><path d="M21 16v-2l-8-5V3.500a1.500 1.500 0 00-3 0V9l-8 5v2l8-2.500V19l-2 1.500V22l3.500-1 3.500 1v-1.500L13 19v-5.500z"/></svg>',
};
