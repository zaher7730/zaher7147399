/* تسجيل الدخول ورمز التحقق — الجزء 2/3
   يعرّف: otp، lgOtpIn، lgOtpKey، lgResend، lgVerify، logout */
function otp() {
  return `<div class="lgp"><div class="lgTop"><img class="lxBrandLogo" src="${IM.hm_logo}" alt="شعار سفرك أسهل"><h1>رمز التحقق</h1><p>${S.previewOtp ? 'معاينة شكلية فقط — لا يتم إرسال رمز من هذا الملف' : 'أرسلنا رمزاً من 4 أرقام إلى واتساب'}</p></div>
<div class="lgCard" style="text-align:center"><span class="lgWa">${WAI}واتساب</span><p class="lgs" style="margin-bottom:0">أدخل الرمز المرسل إلى الرقم<br><b dir="ltr" style="color:#0f2250;font-size:14px">${lgNum()}</b></p>
<div class="lgOtp">${[0, 1, 2, 3].map((i) => `<input id="lgo${i}" maxlength="1" inputmode="numeric" autocomplete="one-time-code" oninput="lgOtpIn(${i},this)" onkeydown="lgOtpKey(${i},event)">`).join('')}</div>
<button class="lgBtn" onclick="lgVerify()">تأكيد</button>
<div class="lgLinks"><button onclick="lgResend()">إعادة إرسال الرمز</button><button onclick="S.scr='login';S.previewOtp=false;render()">تغيير الرقم</button></div></div></div>`;
}
function lgOtpIn(i, e) {
  e.value = e.value.replace(/\D/g, '').slice(-1);
  if (e.value && i < 3) $('#lgo' + (i + 1)).focus();
  if (e.value && i == 3) lgVerify();
}
function lgOtpKey(i, e) {
  if (e.key == 'Backspace' && !e.target.value && i > 0) {
    const p = $('#lgo' + (i - 1));
    p.focus();
    p.value = '';
  }
}
async function lgResend() {
  const s = lgS();
  if (!window.SA_API) return toast('هذه معاينة شكلية فقط؛ لا يمكن إرسال رمز منها');
  try {
    const loginRole = new URLSearchParams(location.search).get('access') === 'admin' ? 'admin' : 'customer';
    const r = await window.SA_API.requestOtp({ phone: lgNum(), name: (s.n || '').trim(), role: loginRole });
    s.challengeId = r.challengeId;
    toast('تم طلب إرسال رمز جديد');
  } catch (e) {
    toast(e.message || 'تعذر إرسال الرمز');
  }
}
async function lgVerify() {
  const c = [0, 1, 2, 3].map((i) => ($('#lgo' + i) || {}).value || '').join('');
  if (c.length < 4) return toast('اكتب الرمز المكوّن من 4 أرقام');
  const s = lgS();
  if (!window.SA_API && window.SAFARAK_PREVIEW_MODE) {
    if (window.SAFARAK_PREVIEW_ROLE === 'admin' && window.parent !== window && typeof window.parent.openAdminPanel === 'function') {
      window.parent.openAdminPanel();
      return;
    }
    S.u.name = (s.n || '').trim();
    S.u.ph = lgNum();
    S.u.in = 1;
    S.lg = null;
    S.previewOtp = false;
    S.hist = [];
    S.scr = 'home';
    render();
    toast('وضع معاينة فقط: لا يوجد حساب أو حجز محفوظ');
    return;
  }
  if (!window.SA_API || !s.challengeId) return toast('هذه معاينة شكلية فقط؛ شغّل الخادم لتسجيل الدخول الحقيقي');
  try {
    const r = await window.SA_API.verifyOtp({ challengeId: s.challengeId, code: c });
    const adminMode = new URLSearchParams(location.search).get('access') === 'admin';
    if (adminMode && r.user.role === 'admin') {
      location.href = '/apps/admin/';
      return;
    }
    if (r.user.role !== 'customer') return toast('الحساب ليس حساب عميل');
    S.lg = null;
    S.previewOtp = false;
    S.hist = [];
    S.scr = 'home';
    await SA_startSession(r.user);
    render();
    toast('أهلاً بك ' + S.u.name.split(/\s+/)[0]);
  } catch (e) {
    toast(e.message || 'رمز التحقق غير صحيح');
  }
}
async function logout() {
  if (window.SA_API) await window.SA_API.logout().catch(() => {});
  SA_endSession();
  S.u.in = 0;
  S.lg = null;
  S.hist = [];
  S.scr = 'login';
  render();
}
/* ===== تسجيل الدخول الأصلي: الاسم + رقم يمني/سعودي + رمز تحقق من مزود الإرسال ===== */
const CCS = { ye: ['🇾🇪', '+967', 'اليمن'], sa: ['🇸🇦', '+966', 'السعودية'] },
  WAI = '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 00-8.6 15.1L2 22l5-1.3A10 10 0 1012 2z"/></svg>';
const lgS = () => S.lg || (S.lg = { c: 'ye', n: S.u.name || '', p: '' });
