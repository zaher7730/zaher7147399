/* تسجيل الدخول ورمز التحقق — الجزء 1/3
   يعرّف: lgRead، lgCountry، lgTab، login، lgSend */
function lgRead() {
  const n = $('#lgn'),
    p = $('#lgp'),
    s = lgS();
  n && (s.n = n.value);
  p && (s.p = p.value);
}
function lgCountry() {
  lgRead();
  const s = lgS(),
    o = ['🇾🇪 اليمن (+967)', '🇸🇦 السعودية (+966)'];
  pick('اختر الدولة', o, s.c == 'ye' ? o[0] : o[1], (v) => {
    s.c = v.includes('966') ? 'sa' : 'ye';
  });
}
function lgTab(t) {
  if (window.parent !== window && typeof window.parent.openRole === 'function') {
    window.parent.openRole('office');
    return;
  }
  location.href = '/apps/office/';
}
function login() {
  const s = lgS(),
    c = CCS[s.c];
  return `<div class="lxp"><div class="lxHero"><img src="${IM.lx_hero}" alt="سفرك أسهل"></div>
<h2 class="lxTag">جميع مكاتب السفريات في مكان واحد</h2>
<div class="lxCard">
<div class="lxTabs"><button type="button" class="lxTab on">${LXI.user}<span>عميل</span></button><button type="button" class="lxTab off" onclick="lgTab()">${LXI.build}<span>صاحب مكتب</span></button></div>
<label class="lxF"><span class="lxL">${LXI.user}الاسم الكامل</span><div class="lxIn"><input id="lgn" value="${ht(s.n || '')}" placeholder="أدخل اسمك بالكامل" autocomplete="name">${LXI.userO}</div></label>
<label class="lxF"><span class="lxL">${LXI.phone}رقم الهاتف</span><div class="lxPh"><button type="button" class="lxCc" onclick="lgCountry()"><span class="fg">${FLG[s.c]}</span><b>${c[1]}</b><svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg></button><div class="lxIn"><input id="lgp" type="tel" inputmode="numeric" dir="ltr" maxlength="10" oninput="this.value=this.value.replace(/\\D/g,'')" value="${ht(s.p || '')}" placeholder="أدخل رقم هاتفك" autocomplete="tel-national">${LXI.phoneO}</div></div></label>
<button type="button" class="lxBtn" onclick="lgSend()"><span>موافق</span>${LXI.arrow}</button>
<div class="lxSec">${LXI.shield}<p><b>سجل دخولك وسيتم إرسال الكود إلى الواتساب</b>المنصة مجرد وسيط بينك وبين المكتب وجميع المكاتب موثقة لدينا بحضور ميداني وجميع مستخدمات وبياناتك في أمان</p></div>
<div class="lxBye"><i></i><span>نتمنى لكم رحلة سعيدة</span><i></i></div>
</div>
<button type="button" class="lxCs" onclick="waCS()">${LXI.head}<span>التواصل مع خدمة العملاء</span></button>
<div class="lxNote">بالمتابعة أنت توافق على شروط الاستخدام وسياسة الخصوصية.</div>
<div class="lxPl">${LXI.plane}</div></div>`;
}
async function lgSend() {
  lgRead();
  const s = lgS();
  if (!(s.n || '').trim()) return toast('اكتب اسمك');
  const d = String(s.p || '')
    .replace(/\D/g, '')
    .replace(/^0+/, '');
  if (!d) return toast('اكتب رقم الهاتف');
  if (d.length != 9 || d[0] != (s.c == 'ye' ? '7' : '5'))
    return toast(s.c == 'ye' ? 'رقم يمني غير صحيح (9 أرقام يبدأ بـ 7)' : 'رقم سعودي غير صحيح (9 أرقام يبدأ بـ 5)');
  s.p = d;
  if (!window.SA_API) {
    S.previewOtp = true;
    S.scr = 'otp';
    render();
    return toast('معاينة شكلية فقط؛ لتلقي رمز حقيقي شغّل الخادم المتصل');
  }
  try {
    const loginRole = new URLSearchParams(location.search).get('access') === 'admin' ? 'admin' : 'customer';
    const r = await window.SA_API.requestOtp({ phone: lgNum(), name: s.n.trim(), role: loginRole });
    s.challengeId = r.challengeId;
    S.previewOtp = false;
    S.scr = 'otp';
    render();
    setTimeout(() => {
      const i = $('#lgo0');
      i && i.focus();
    }, 50);
  } catch (e) {
    toast(e.message || 'تعذر إرسال رمز التحقق');
  }
}
