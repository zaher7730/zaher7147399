/* صفحة الإشعارات (إشعارات حقيقية من الخادم)
   يعرّف: notif */
const NK = { booking: '📦', payment: '💳', message: '💬', review: '⭐', review_reply: '💬', broadcast: '📣', ticket: '🎫', invoice: '🧾' };
const notif = () => {
  const L = S.nts || [];
  setTimeout(SA_readNotifications, 1500);
  return (
    back('الإشعارات', 'more') +
    (S.u.nt === 0 ? '<div class="empty"><b>🔕</b>الإشعارات متوقفة من الإعدادات</div>' : '') +
    (S.u.nt === 0
      ? ''
      : L.length
        ? L.map(
            (n) =>
              `<div class="sec"${n.read ? '' : ' style="border-inline-start:3px solid var(--g,#e0b341)"'}>${NK[n.kind] || '🔔'} <b>${ht(n.title)}</b>${n.body ? `<div style="font-size:12.5px;margin-top:4px">${ht(n.body)}</div>` : ''}<small style="display:block;margin-top:6px;opacity:.7">${ago(SA_ts(n.createdAt))}</small></div>`,
          ).join('')
        : '<div class="empty"><b>🔔</b>لا توجد إشعارات بعد</div>')
  );
};
