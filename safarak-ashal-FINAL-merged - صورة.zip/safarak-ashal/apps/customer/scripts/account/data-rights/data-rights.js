/* حقوق البيانات: تنزيل نسخة من بيانات الحساب وطلب حذفه
   يعرّف: SA_exportData، SA_requestDeletion */
async function SA_exportData() {
  if (!window.SA_API || !S.u.in) return toast('سجّل الدخول لتنزيل بياناتك');
  try {
    toast('جارٍ تجهيز بياناتك…');
    const data = await window.SA_API.exportMyData();
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'safarak-my-data.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    toast('تم تنزيل ملف بياناتك');
  } catch (e) {
    toast(e.message || 'تعذّر تنزيل البيانات');
  }
}
async function SA_requestDeletion() {
  if (!window.SA_API || !S.u.in) return toast('سجّل الدخول أولاً');
  if (SA_deletionPending()) return toast('طلب حذف حسابك قيد المراجعة لدى الإدارة');
  if (!confirm('سيصل طلب حذف حسابك وبياناتك إلى الإدارة لمراجعته، وقد تبقى سجلات الحجوزات والدفع التي يلزم الاحتفاظ بها نظاماً. هل تريد المتابعة؟')) return;
  try {
    await window.SA_API.requestAccountDeletion();
    toast('تم إرسال طلب الحذف؛ ستراجعه الإدارة');
    SA_tk.busy = 0;
    await SA_loadTickets();
    render();
  } catch (e) {
    toast(e.message || 'تعذّر إرسال طلب الحذف');
  }
}
