/* المفضلة والبحث
   يعرّف: fv، hs، fav */
function fv(i, e) {
  e.stopPropagation();
  if (!S.u.in) return toast('سجّل الدخول لاستخدام المفضلة');
  const o = OFF[i],
    k = o.k + o.n + o.t,
    j = S.fav.findIndex((f) => f.k + f.n + f.t == k);
  j < 0 ? S.fav.push(o) : S.fav.splice(j, 1);
  toast(j < 0 ? 'أُضيف إلى المفضلة' : 'أُزيل من المفضلة');
  render();
  SA_saveOfferFavs(o, j < 0);
}
function hs(v) {
  v = (v || '').trim();
  if (!v) return;
  const M = [
    ['priv', 'خاصة خاص رحلات_خاصة عمان صلالة مسقط'],
    ['bus', 'نقل دولي نقل بري باص حافلة'],
    ['cars', 'سيارة سيارات تأجير'],
    ['local', 'محلية'],
    ['pass', 'جواز جوازات'],
    ['visa', 'تأشيرة تأشيرات عمرة حج زيارة سياحية'],
    ['air', 'طيران تذكرة طائرة'],
  ];
  const c = CITIES.find((x) => x == v);
  if (c) {
    S.F.bus.t = c;
    return go('bus');
  }
  const m = M.find((x) => x[1].split(' ').some((w) => w.includes(v) || v.includes(w)));
  if (m) return go(m[0]);
  S.q = v;
  go('offices');
}
const fav = () =>
  back('المفضلة', 'more') +
  (S.fav.length
    ? S.fav
        .map(
          (o, i) =>
            `<div class="sec"><b>${o.n}</b><div style="font-size:12.5px;margin:4px 0 8px">${o.t} · ${curOf(o)}${o.pr}</div><div class="chips"><button onclick="S.o=S.fav[${i}];S.v=nv();S.fl={};S.fu={};S.tab='z';go('detail')">ابدأ الحجز</button><button onclick="S.fav.splice(${i},1);render()">إزالة</button></div></div>`,
        )
        .join('')
    : '<div class="empty"><b>⭐</b>اضغط على ♡ في أي عرض لإضافته هنا</div>');
