/* الحساب والملف الشخصي — الجزء 2/2
   يعرّف: acct */
const acct = () => {
  const u = S.u,
    vf = u.idn && u.idi,
    t = u.idt || 'هوية شخصية';
  return (
    back('الملف الشخصي', 'more') +
    `<div class="cmp"><div class="hd2"><span class="av2" style="width:36px;height:36px;font-size:14px">${ht((u.name || '؟').trim()[0])}</span><div><b>${ht(u.name || '-')}</b><small dir="ltr">${ht(u.ph || '')}</small></div><span class="pl ${vf ? 'ok' : 'wr'}">${vf ? 'تم إدخال البيانات' : 'لم تُدخل البيانات'}</span></div><div class="pill">البيانات الشخصية</div><div class="g2"><div class="full"><label>الاسم كما في الهوية أو الجواز</label><div class="fi"><input id="un" class="f" value="${ht(u.name || '')}"></div></div><div class="full"><label>رقم الجوال</label><div class="fi"><input id="up" class="f" inputmode="tel" dir="ltr" style="text-align:right" value="${ht(u.ph || '')}" placeholder="رقم الجوال"></div></div><div class="full"><label>تاريخ الميلاد</label><div class="fi"><input id="udob" class="f" type="date" value="${ht(u.dob || '')}"></div></div></div><div class="pill">توثيق الحساب</div><div class="tgb">${['هوية شخصية', 'جواز سفر'].map((x) => `<button class="${x == t ? 'on' : ''}" onclick="acT('${x}')">${x}</button>`).join('')}</div><div class="g2"><div class="full"><label>رقم ${t}</label><div class="fi"><input id="ui" class="f" dir="ltr" style="text-align:right" value="${ht(u.idn || '')}" placeholder="اكتب الرقم"></div></div><div class="full"><label>صورة ${t}</label><label class="up ${u.idi ? 'ok' : ''}">${u.idi ? `<img class="pv" src="${u.idi}">` : ic('f_cloud', 'big')}<div><b>${u.idi ? 'تم الرفع ✔ (اضغط للتغيير)' : 'اضغط لرفع الصورة'}</b><small>JPG / PNG</small></div><input type="file" accept="image/*" onchange="acImg(this)"></label></div></div><div style="height:10px"></div><button class="gb w" onclick="acSave()">حفظ</button><p class="tn">تُعبّأ بياناتك تلقائياً في نماذج الحجز، ولا تُعرض إلا للمكتب المعني بطلبك.</p></div>`
  );
};
