/* الحساب والملف الشخصي — الجزء 1/2
   يعرّف: acImg، acSave، more، acK، acT */
function acImg(inp) {
  acK();
  const f = inp.files[0];
  if (!f) return;
  if (!f.type.startsWith('image/')) {
    toast('ارفع صورة (JPG / PNG)');
    return;
  }
  /* الصورة تُحفظ في الخادم كملف خاص عند الضغط على حفظ؛ هنا معاينة محلية فقط */
  S.u.idiFile = f;
  const r = new FileReader();
  r.onload = () => {
    S.u.idi = r.result;
    render();
    toast('تم اختيار الصورة؛ اضغط حفظ لرفعها');
  };
  r.readAsDataURL(f);
}
async function acSave() {
  acK();
  if (!window.SA_API || !S.u.in) return toast('سجّل الدخول لحفظ بياناتك');
  if (S.u.idn && String(S.u.idn).trim().length < 6) return toast('رقم الهوية / الجواز قصير جداً');
  if (await SA_saveProfile()) {
    toast(S.u.idn && S.u.idi ? 'تم حفظ بياناتك ووثيقة الهوية بشكل آمن' : 'تم حفظ البيانات');
    go('more');
  }
}
const more = () => {
  const u = S.u,
    vf = u.idn && u.idi,
    R = (f, i, t, s) =>
      `<div onclick="${f}"><span>${i}</span><span style="flex:1">${t}${s ? `<small>${s}</small>` : ''}</span><em>‹</em></div>`;
  return `<div class="ph"><h1>المزيد</h1></div><div class="ml2">${R("go('acct')", '👤', 'الملف الشخصي', vf ? 'تم إدخال بيانات الهوية' : 'أكمل بيانات الهوية أو الجواز')}${R("go('fav')", '⭐', 'المفضلة')}${R("go('about')", 'ℹ️', 'عن سفرك أسهل', 'الترخيص · الخصوصية · الشروط')}${R("go('settings')", '⚙️', 'الإعدادات')}${R("go('tickets')", '🎫', 'تذاكر الدعم', 'استفسارات وشكاوى ومتابعة الردود')}${R("go('help')", '🎧', 'المساعدة والدعم', 'تواصل مع خدمة العملاء عبر واتساب')}</div>`;
};
const acK = () => {
  const a = $('#un'),
    b = $('#up'),
    c = $('#ui'),
    d = $('#udob');
  a && (S.u.name = a.value);
  b && (S.u.ph = b.value);
  c && (S.u.idn = c.value);
  d && (S.u.dob = d.value);
};
const acT = (t) => {
  acK();
  S.u.idt = t;
  render();
};
