/* أجهزتي المتصلة: عرض الجلسات النشطة وإنهاء أي جلسة (حماية عند فقدان جهاز)
   يعرّف: devices، SA_dv، SA_loadDevices، SA_revokeDevice، SA_revokeOthers، SA_deviceName */
const SA_dv = { list: [], loaded: 0, busy: 0 };
function SA_deviceName(ua) {
  ua = String(ua || '');
  const os = /Android/i.test(ua) ? 'أندرويد' : /iPhone|iPad|iPod/i.test(ua) ? 'آيفون / آيباد' : /Windows/i.test(ua) ? 'ويندوز' : /Mac OS X|Macintosh/i.test(ua) ? 'ماك' : /Linux/i.test(ua) ? 'لينكس' : 'جهاز غير معروف',
    br = /Edg\//i.test(ua) ? 'إيدج' : /OPR\/|Opera/i.test(ua) ? 'أوبرا' : /Firefox/i.test(ua) ? 'فايرفوكس' : /Chrome|CriOS/i.test(ua) ? 'كروم' : /Safari/i.test(ua) ? 'سفاري' : '';
  return os + (br ? ' · ' + br : '');
}
async function SA_loadDevices() {
  if (!window.SA_API || !S.u.in || SA_dv.busy) return;
  SA_dv.busy = 1;
  try {
    SA_dv.list = (await window.SA_API.sessions()).sessions || [];
  } catch (e) {
    toast(e.message || 'تعذّر تحميل الأجهزة');
  }
  SA_dv.loaded = 1;
  SA_dv.busy = 0;
  if (S.scr === 'devices') SA_rerender();
}
async function SA_revokeDevice(id) {
  try {
    await window.SA_API.revokeSession(id);
    toast('تم إنهاء جلسة الجهاز');
    await SA_loadDevices();
  } catch (e) {
    toast(e.message || 'تعذّر إنهاء الجلسة');
  }
}
async function SA_revokeOthers() {
  if (!confirm('سيُسجَّل خروجك من كل الأجهزة الأخرى وتبقى هذه الجلسة. هل تريد المتابعة؟')) return;
  try {
    const r = await window.SA_API.revokeOtherSessions();
    toast(r.revoked ? 'تم إنهاء ' + r.revoked + ' جلسة' : 'لا توجد جلسات أخرى');
    await SA_loadDevices();
  } catch (e) {
    toast(e.message || 'تعذّر إنهاء الجلسات');
  }
}
const devices = () => {
  if (!S.u.in) return back('أجهزتي المتصلة', 'settings') + '<div class="sec"><p class="pp">سجّل الدخول لعرض أجهزتك.</p></div>';
  if (!SA_dv.loaded && !SA_dv.busy) SA_loadDevices();
  const others = (SA_dv.list || []).filter((s) => !s.current).length;
  return (
    back('أجهزتي المتصلة', 'settings') +
    `<div class="sec"><p class="pp">هذه الأجهزة مسجّل دخولها إلى حسابك الآن. إذا لم تتعرّف على جهاز فأنهِ جلسته فوراً.</p>${others ? '<button class="gb w" onclick="SA_revokeOthers()">إنهاء كل الجلسات الأخرى</button>' : ''}</div>` +
    ((SA_dv.list || [])
      .map(
        (s) =>
          `<div class="sec"><div style="display:flex;align-items:center;gap:8px"><b style="flex:1">${ht(SA_deviceName(s.userAgent))}</b>${s.current ? '<span class="pl ok">هذا الجهاز</span>' : ''}</div><small class="pp">آخر نشاط: ${fmt(s.lastSeen || Date.now())}${s.ip ? ' · العنوان: <span dir="ltr">' + ht(s.ip) + '</span>' : ''}</small>${s.current ? '' : `<div style="height:8px"></div><button class="gb w" style="padding:8px;font-size:13px" onclick="SA_revokeDevice('${ht(s.id)}')">إنهاء هذه الجلسة</button>`}</div>`,
      )
      .join('') || (SA_dv.loaded ? '<div class="sec"><p class="pp">لا توجد جلسات.</p></div>' : '<div class="sec"><p class="pp">جارٍ التحميل…</p></div>'))
  );
};
