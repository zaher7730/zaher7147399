/* محتوى تديره الإدارة ويقرؤه تطبيق العميل من الخادم: إعلانات، خدمات التطبيق، صفحات وسياسات
   يعرّف: SA_loadPublicDocs، SA_pageOverride، SA_svHidden، SA_svImage، SA_shareOffice، SA_refreshCities، SA_withAdminDocs */
const SA_AD_TARGET = { طيران: 'air', جوازات: 'pass', 'تأجير سيارات': 'cars', تأشيرات: 'visa', 'نقل دولي': 'bus', 'رحلات محلية': 'local', 'مكتب معيّن': 'offices' };
const SA_PAGE_TITLES = { about: 'من نحن', terms: 'الشروط والأحكام', policy: 'سياسة الخصوصية', verified: 'ما معنى المكتب الموثّق', help: 'تواصل معنا' };
window.SA_PAGES = {};
const SA_SV_HIDDEN = new Set();
const SA_SV_IMG = {};
/* مدن ومستندات تديرها الإدارة (مجموعتا ct وrq): تتبعها قوائم المدن ونماذج الحجز عند العميل */
const SA_CITY_RULES = {};
const SA_REQ_DOCS = {};
const SA_CITY_SVC = { bus: ['نقل دولي'], local: ['رحلات محلية'], air: ['طيران'], priv: ['رحلات خاصة (انطلاق)', 'رحلات خاصة (وجهة)', 'رحلات خاصة'] };
const SA_REQ_SVC = { bus: 'نقل دولي', air: 'طيران', local: 'رحلات محلية', priv: 'رحلات خاصة', cars: 'تأجير سيارات', visa: 'تأشيرات', pass: 'جوازات' };
const SA_escHtml = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
function SA_svHidden(key) {
  return SA_SV_HIDDEN.has(key);
}
function SA_svImage(key) {
  return SA_SV_IMG[key] || '';
}
/* صفحة نصها من الإدارة بدل النص الافتراضي (فقط إن عدّلته الإدارة) */
function SA_pageOverride(key, title, to) {
  const body = window.SA_PAGES[key];
  if (!body) return '';
  const paras = String(body)
    .split(/\n+/)
    .map((x) => x.trim())
    .filter(Boolean)
    .map((x) => `<p class="ch">${SA_escHtml(x)}</p>`)
    .join('');
  return back(title, to || 'more') + `<div class="sec">${paras}</div>`;
}
function SA_applyPublicDocs(docs) {
  docs = docs || {};
  /* الإعلانات: البطاقة الأصلية أولاً ثم إعلانات الإدارة المفعّلة وضمن مدتها */
  const today = new Date().toISOString().slice(0, 10);
  ADS.splice(1, ADS.length);
  for (const a of docs.ads || []) {
    const on = a.on === undefined || a.on === 1 || a.on === true || a.on === '1';
    if (!on || !a.h || !a.im) continue;
    if (a.from && /^\d{4}-/.test(a.from) && a.from > today) continue;
    if (a.to && /^\d{4}-/.test(a.to) && a.to < today) continue;
    ADS.push({ src: String(a.im), h: String(a.h), p: String(a.p || ''), t: SA_AD_TARGET[a.tg] || '' });
  }
  /* خدمات التطبيق: عنوان/وصف/صورة/إظهار */
  SA_SV_HIDDEN.clear();
  for (const k of Object.keys(SA_SV_IMG)) delete SA_SV_IMG[k];
  const nameToKey = {};
  for (const k of Object.keys(HD)) nameToKey[HD[k][0]] = k;
  for (const s of docs.sv || []) {
    const key = nameToKey[s.n] || (s.n === 'رحلات خاصة' ? 'priv' : s.n === 'التأشيرات' ? 'visa' : s.n === 'إرسال جوازك للمكتب' ? 'send' : '');
    if (!key) continue;
    if (s.on === 0 || s.on === false || s.on === '0') SA_SV_HIDDEN.add(key);
    if (s.p && HD[key]) HD[key][1] = String(s.p);
    if (s.im && /^(\/|https?:)/.test(String(s.im))) SA_SV_IMG[key] = String(s.im);
  }
  /* المدن: المدينة المعطّلة في الإدارة أو غير المفعّلة لهذه الخدمة لا تظهر في قوائم العميل */
  for (const k of Object.keys(SA_CITY_RULES)) delete SA_CITY_RULES[k];
  for (const c of docs.ct || []) if (c && c.n) SA_CITY_RULES[String(c.n)] = { on: !(c.on === 0 || c.on === false || c.on === '0'), svs: Array.isArray(c.svs) ? c.svs : null, intl: c.ty === 'خارجية' };
  /* المستندات المطلوبة لكل خدمة */
  for (const k of Object.keys(SA_REQ_DOCS)) delete SA_REQ_DOCS[k];
  for (const r of docs.rq || []) if (r && r.sv && Array.isArray(r.req)) SA_REQ_DOCS[String(r.sv)] = r.req.map((x) => String(x).trim()).filter(Boolean);
  SA_refreshCities();
  /* الصفحات والسياسات: تُستبدل فقط إن عدّلتها الإدارة (لها تاريخ تحديث) */
  window.SA_PAGES = {};
  const byTitle = Object.fromEntries(Object.entries(SA_PAGE_TITLES).map(([k, v]) => [v, k]));
  for (const pg of docs.pg || []) {
    const key = byTitle[pg.n];
    if (key && pg.body && pg.upd) window.SA_PAGES[key] = pg.body;
  }
}
async function SA_loadPublicDocs() {
  if (!window.SA_API) return;
  try {
    const r = await window.SA_API.publicDocs(['ads', 'sv', 'pg', 'ct', 'rq']);
    SA_applyPublicDocs(r.docs);
  } catch (e) {
    console.warn('تعذر تحميل محتوى المنصة:', e.message);
  }
}

/* هل المدينة مسموحة لهذه الخدمة حسب قائمة مدن الإدارة؟ المدينة غير المعرّفة في الإدارة لا تُخفى حتى لا يضيع عرض حقيقي */
function SA_cityOk(city, kind) {
  const r = SA_CITY_RULES[city];
  if (!r) return true;
  if (!r.on) return false;
  const want = SA_CITY_SVC[kind];
  return !r.svs || !r.svs.length || !want || want.some((x) => r.svs.includes(x));
}
/* قوائم المدن من العروض الحقيقية مصفّاة بقائمة الإدارة، وشريط مدن التأشيرات هو مدن الإدارة الداخلية المفعّلة */
function SA_refreshCities() {
  const ok = (kind) => (c) => SA_cityOk(c, kind);
  CT.bus = cts(BUS).filter(ok('bus'));
  CT.local = cts(LOC).filter(ok('local'));
  CT.air = cts(AIR).filter(ok('air'));
  CT.priv = cts(PRIV).filter(ok('priv'));
  const managed = Object.keys(SA_CITY_RULES).filter((n) => !SA_CITY_RULES[n].intl),
    inland = managed.filter((n) => SA_CITY_RULES[n].on);
  /* إن عرّفت الإدارة مدناً داخلية ثم عطّلتها كلها فالشريط يفرغ ولا يرجع للقائمة الافتراضية */
  if (managed.length) {
    VCT.splice(0, VCT.length, ...inland);
    for (const f of Object.values(S.F || {})) if (f && f.c && !VCT.includes(f.c)) f.c = '';
  }
}
/* مستندات الإدارة المطلوبة للخدمة تُضاف حقول رفع إلزامية في نموذج الحجز إن لم يكن في النموذج حقل يقابلها */
const SA_DOC_ALIAS = { 'جواز سفر': ['جواز'], 'صورة شخصية': ['صورة شخصية', 'صورتين شخصية', 'صورتان شخصيتان', 'صور شخصية'], 'هوية وطنية': ['هوية', 'بطاقة'], 'شهادة ميلاد': ['ميلاد'], 'رخصة قيادة': ['رخصة'], 'شهادة تطعيم': ['تطعيم'], 'تذكرة سفر': ['تذكرة'], 'حجز فندقي': ['فندق', 'سكن'], 'كشف حساب بنكي': ['كشف حساب'], 'عقد عمل': ['عقد'], 'خطاب دعوة': ['دعوة'], 'شهادة زواج': ['زواج'], 'تأشيرة سابقة': ['تأشيرة'] };
function SA_withAdminDocs(o, r) {
  const docs = SA_REQ_DOCS[SA_REQ_SVC[o && o.k]] || [];
  if (!docs.length) return r;
  const labels = r.filter((x) => x[0] == 'f' && x[1] != 'rc').map((x) => String(x[2] || ''));
  const out = [...r];
  docs.forEach((d) => {
    const keys = SA_DOC_ALIAS[d] || [d];
    if (labels.some((l) => keys.some((k) => l.includes(k)))) return;
    out.push(['f', 'doc_' + d.replace(/\s+/g, '_'), d, 1]);
  });
  return out;
}

/* مشاركة ملف مكتب (رابط التطبيق + اسم المكتب) */
async function SA_shareOffice(i) {
  const o = OFFS[i];
  if (!o) return;
  const r = await window.SA_SHARE.share({ title: o.n, text: 'مكتب ' + oPlain(o.n) + ' على سفرك أسهل' + (o.c ? ' — ' + o.c : ''), url: location.origin + '/' });
  const m = { copied: 'تم نسخ الرابط', failed: 'تعذّرت المشاركة', shared: 'تمت المشاركة' }[r];
  if (m) toast(m);
}
