/* جلسة العميل مع الخادم: بدء/إنهاء المزامنة وتوزيع الأحداث اللحظية
   يعرّف: SA_ts، SA_size، SA_rerender، SA_startSession، SA_endSession */
/* يحوّل وقت الخادم (UTC بصيغة SQLite) إلى طابع زمني بالميلي ثانية */
const SA_ts = (v) => {
  if (!v) return Date.now();
  const s = String(v);
  const t = Date.parse(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : s.replace(' ', 'T') + 'Z');
  return Number.isFinite(t) ? t : Date.now();
};
const SA_size = (b) => (b > 1048576 ? (b / 1048576).toFixed(1) + ' ميجابايت' : Math.max(1, Math.round((b || 0) / 1024)) + ' كيلوبايت');
/* إعادة رسم مع الحفاظ على ما كتبه العميل في حقل الرسالة */
function SA_rerender() {
  const i = document.getElementById('cm'),
    v = i ? i.value : null,
    f = !!i && document.activeElement === i;
  render();
  if (v != null) {
    const n = document.getElementById('cm');
    if (n) {
      n.value = v;
      if (f) n.focus();
    }
  }
}
let SA_sessionOn = false;
/* يُستدعى بعد نجاح الدخول أو عند العثور على جلسة قائمة */
async function SA_startSession(user) {
  if (!window.SA_API || !user) return;
  S.u.id = user.id;
  S.u.name = user.name || S.u.name;
  S.u.ph = user.phone || S.u.ph;
  S.u.in = 1;
  SA_sessionOn = true;
  await Promise.allSettled([
    SA_loadBookings(),
    SA_loadConversations(),
    SA_loadFavorites(),
    SA_loadNotifications(),
    SA_loadMyReviews(),
    SA_loadProfile(),
    SA_loadTickets(),
  ]);
  if (window.SA_RT) window.SA_RT.start();
  SA_rerender();
}
/* يُستدعى عند الخروج أو انتهاء الجلسة: يمسح بيانات المستخدم من الذاكرة */
function SA_endSession() {
  SA_sessionOn = false;
  if (window.SA_RT) window.SA_RT.stop();
  S.ord = [];
  S.cv = {};
  S.fav = [];
  S.fo = [];
  S.foIds = [];
  S.rv = {};
  S.rvl = {};
  S.myRv = [];
  S.nts = [];
  S.bk = {};
  S.sb = {};
  S.cur = null;
  S.u = { name: '', ph: '', in: 0 };
  SA_tk.list = [];
  SA_tk.loaded = 0;
  SA_tk.cur = null;
  SA_tk.msgs = [];
  SA_tk.form = 0;
  SA_dv.list = [];
  SA_dv.loaded = 0;
}
/* انتهت الجلسة من الخادم: نعيد المستخدم لشاشة الدخول */
window.SA_ON_UNAUTHORIZED = (err, url) => {
  if (!SA_sessionOn || /\/api\/auth\//.test(String(url || ''))) return;
  SA_endSession();
  S.hist = [];
  S.scr = 'login';
  render();
  toast('انتهت الجلسة؛ سجّل الدخول من جديد');
};
if (window.SA_RT) {
  window.SA_RT.on('message', (m) => SA_onMessage(m));
  window.SA_RT.on('read', (d) => SA_onRead(d));
  window.SA_RT.on('notification', (n) => SA_onNotification(n));
  window.SA_RT.on('booking', () => SA_loadBookings());
}
