/* تذاكر الدعم: تحميلها من الخادم وفتح تذكرة جديدة والرد داخل التذكرة
   يعرّف: SA_tk، SA_loadTickets، SA_showTicket، SA_newTicket، SA_createTicket، SA_replyTicket، SA_deletionPending */
const SA_tk = { list: [], loaded: 0, busy: 0, cur: null, msgs: [], form: 0, draft: {}, sending: 0 };
async function SA_loadTickets() {
  if (!window.SA_API || !S.u.in || SA_tk.busy) return;
  SA_tk.busy = 1;
  try {
    const r = await window.SA_API.tickets();
    SA_tk.list = r.tickets || [];
  } catch (e) {
    console.warn('تعذر تحميل التذاكر:', e.message);
  }
  SA_tk.loaded = 1;
  SA_tk.busy = 0;
  if (['tickets', 'tkdet', 'settings'].includes(S.scr)) SA_rerender();
}
const SA_deletionPending = () => (SA_tk.list || []).some((t) => t.kind === 'data_deletion' && ['open', 'pending'].includes(t.status));
async function SA_showTicket(id) {
  try {
    const r = await window.SA_API.ticket(id);
    SA_tk.cur = r.ticket;
    SA_tk.msgs = r.messages || [];
    SA_tk.draft = {};
    if (S.scr !== 'tkdet') go('tkdet');
    else SA_rerender();
  } catch (e) {
    toast(e.message || 'تعذّر فتح التذكرة');
  }
}
function SA_newTicket() {
  SA_tk.form = 1;
  SA_tk.draft = {};
  SA_rerender();
}
async function SA_createTicket() {
  const v = (id) => String(($('#' + id) || {}).value || '').trim();
  const subject = v('tk_s'),
    body = v('tk_b');
  if (subject.length < 3) return toast('اكتب موضوعاً واضحاً (3 أحرف على الأقل)');
  if (!body) return toast('اكتب تفاصيل المشكلة أو الاستفسار');
  if (SA_tk.sending) return;
  SA_tk.sending = 1;
  try {
    const r = await window.SA_API.createTicket({ subject, body, kind: v('tk_k') || 'support', bookingId: v('tk_o') || undefined });
    SA_tk.form = 0;
    SA_tk.draft = {};
    toast('تم إرسال تذكرتك؛ سيصلك الرد هنا وفي الإشعارات');
    SA_tk.busy = 0;
    await SA_loadTickets();
    await SA_showTicket(r.ticket.id);
  } catch (e) {
    toast(e.message || 'تعذّر إرسال التذكرة');
  } finally {
    SA_tk.sending = 0;
  }
}
async function SA_replyTicket() {
  const t = SA_tk.cur,
    text = String(($('#tk_r') || {}).value || '').trim();
  if (!t || !text) return toast('اكتب ردّك أولاً');
  if (SA_tk.sending) return;
  SA_tk.sending = 1;
  try {
    await window.SA_API.ticketMessage(t.id, { body: text });
    SA_tk.draft = {};
    await SA_showTicket(t.id);
    SA_tk.busy = 0;
    SA_loadTickets();
  } catch (e) {
    toast(e.message || 'تعذّر إرسال الرد');
  } finally {
    SA_tk.sending = 0;
  }
}
