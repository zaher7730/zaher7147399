/* الملف الشخصي وتوثيق الهوية (حفظ حقيقي في الخادم + رفع صورة الهوية الخاصة)
   يعرّف: SA_loadProfile، SA_saveProfile */
async function SA_loadProfile() {
  if (!window.SA_API || !S.u.in) return;
  try {
    const r = await window.SA_API.me();
    const p = r.profile || {};
    S.u.name = r.user.name || S.u.name;
    S.u.email = r.user.email || '';
    if (p.idNumber) S.u.idn = p.idNumber;
    if (p.idType) S.u.idt = p.idType;
    if (p.idFileUrl) S.u.idi = p.idFileUrl;
    S.u.idFileId = p.idFileId || null;
    const x = p.extra || {};
    if (x.dob) S.u.dob = x.dob;
  } catch (e) {
    console.warn('Unable to load profile:', e.message);
  }
}
async function SA_saveProfile() {
  const u = S.u;
  try {
    if (u.name && String(u.name).trim().length >= 2) await window.SA_API.send('PATCH', '/api/me', { name: String(u.name).trim() });
    let fileId = u.idFileId || undefined;
    if (u.idiFile) {
      const up = await window.SA_FILES.upload(u.idiFile);
      fileId = up.id;
    }
    await window.SA_API.send('PUT', '/api/me/profile', {
      idType: u.idt || '',
      idNumber: u.idn || '',
      idFileId: fileId,
      extra: { dob: u.dob || '' },
    });
    u.idiFile = null;
    await SA_loadProfile();
    return true;
  } catch (e) {
    toast(e.message || 'تعذّر حفظ البيانات');
    return false;
  }
}
