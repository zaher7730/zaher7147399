/* تقييمات المكاتب الحقيقية (قراءة وإضافة)
   يعرّف: SA_loadMyReviews، SA_loadOfficeReviews، SA_officeIdx، SA_reviewableBooking، SA_submitReview */
const SA_officeIdx = (idOrName) => OFFS.findIndex((o) => o.id == idOrName || o.n === idOrName);
async function SA_loadMyReviews() {
  if (!window.SA_API || !S.u.in) return;
  try {
    S.myRv = (await window.SA_API.reviews()).reviews;
  } catch (e) {
    console.warn('Unable to load my reviews:', e.message);
  }
}
/* يحمّل آراء المكتب العامة مرة واحدة ثم يعيد الرسم؛ يُستدعى من ratingStats وصفحة المكتب */
function SA_loadOfficeReviews(officeId, force) {
  if (!window.SA_API || !officeId) return;
  S.rvl = S.rvl || {};
  const i = SA_officeIdx(officeId);
  if (i < 0 || (S.rvl[i] && !force)) return;
  S.rvl[i] = 'loading';
  window.SA_API.officeReviews(officeId)
    .then((r) => {
      S.rv[i] = r.reviews.map((x) => ({ n: x.customer_first_name || 'عميل', s: x.rating, t: x.comment || '', ts: SA_ts(x.created_at), reply: x.office_reply || '' }));
      S.rvsum = S.rvsum || {};
      S.rvsum[i] = r.summary;
      S.rvl[i] = 1;
      if (['ofdet', 'detail'].includes(S.scr)) SA_rerender();
    })
    .catch((e) => {
      S.rvl[i] = 0;
      console.warn('Unable to load office reviews:', e.message);
    });
}
/* أول حجز مكتمل لهذا المكتب لم يُقيَّم بعد */
function SA_reviewableBooking(officeId) {
  const done = new Set((S.myRv || []).map((r) => r.bookingId));
  return S.ord.find((x) => x.st == 2 && x.o.serverOfficeId == officeId && !done.has(x.id));
}
async function SA_submitReview(officeId, rating, comment) {
  if (!window.SA_API || !S.u.in) return toast('سجّل الدخول لتقييم المكتب');
  const bk = SA_reviewableBooking(officeId);
  if (!bk) return toast('يمكنك تقييم المكتب بعد اكتمال حجز لديه');
  try {
    await window.SA_API.createReview({ bookingId: bk.id, rating, comment: comment || '' });
    toast('شكراً لتقييمك');
    await SA_loadMyReviews();
    SA_loadOfficeReviews(officeId, true);
    return true;
  } catch (e) {
    toast(e.message || 'تعذّر حفظ التقييم');
  }
}
