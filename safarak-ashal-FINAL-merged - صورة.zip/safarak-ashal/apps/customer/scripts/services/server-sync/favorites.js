/* المفضلة: المكاتب (علاقات في الخادم) والعروض (لقطة محفوظة في حالة المستخدم)
   يعرّف: SA_loadFavorites، SA_syncFavIdx، SA_saveOfferFavs، SA_toggleOfficeFav */
let SA_favVersion = null;
function SA_syncFavIdx() {
  S.fo = (S.foIds || []).map((id) => OFFS.findIndex((o) => o.id == id)).filter((i) => i >= 0);
}
async function SA_loadFavorites() {
  if (!window.SA_API || !S.u.in) return;
  try {
    const [f, st] = await Promise.all([window.SA_API.favorites(), window.SA_API.getState('customer-favorites')]);
    S.foIds = f.favorites.filter((x) => x.kind === 'office').map((x) => x.id);
    SA_syncFavIdx();
    S.fav = Array.isArray(st.value) ? st.value : [];
    SA_favVersion = st.version;
  } catch (e) {
    console.warn('Unable to load favorites:', e.message);
  }
}
/* حفظ لقطة العروض المفضلة (بدون صور ثقيلة) + علاقة الخدمة في الخادم */
async function SA_saveOfferFavs(offer, on) {
  if (!window.SA_API || !S.u.in) return;
  try {
    const snap = S.fav.map((o) => JSON.parse(JSON.stringify(o, (k, v) => (k === 'img' && typeof v === 'string' && v.length > 2000 ? undefined : v))));
    const r = await window.SA_API.putState('customer-favorites', snap, SA_favVersion);
    SA_favVersion = r.version;
    if (offer && offer.serviceId) window.SA_API.setFavorite('service', offer.serviceId, on).catch(() => {});
  } catch (e) {
    if (e.status === 409 || e.status === 428) {
      await SA_loadFavorites();
      return render();
    }
    toast(e.message || 'تعذّر حفظ المفضلة');
  }
}
async function SA_toggleOfficeFav(i, on) {
  const o = OFFS[i];
  if (!window.SA_API || !S.u.in || !o) return;
  S.foIds = S.foIds || [];
  const had = S.foIds.includes(o.id);
  if (on && !had) S.foIds.push(o.id);
  if (!on) S.foIds = S.foIds.filter((x) => x !== o.id);
  try {
    await window.SA_API.setFavorite('office', o.id, on);
  } catch (e) {
    S.foIds = had ? [...new Set([...S.foIds, o.id])] : S.foIds.filter((x) => x !== o.id);
    SA_syncFavIdx();
    toast(e.message || 'تعذّر حفظ المفضلة');
    render();
  }
}
/* مؤشرات المكاتب تتغير كلما أُعيد بناء قائمة المكاتب */
(() => {
  const base = window.SA_applyPublicServices;
  if (typeof base === 'function')
    window.SA_applyPublicServices = function (services) {
      const r = base.call(this, services);
      SA_syncFavIdx();
      return r;
    };
})();
