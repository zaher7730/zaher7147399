/* إشعارات العميل الحقيقية (قائمة، قراءة، لحظي، إشعار الجهاز)
   يعرّف: SA_loadNotifications، SA_onNotification، SA_readNotifications، SA_enablePush */
async function SA_loadNotifications() {
  if (!window.SA_API || !S.u.in) return;
  try {
    const r = await window.SA_API.notifications(100);
    S.nts = r.notifications;
  } catch (e) {
    console.warn('Unable to load notifications:', e.message);
  }
}
function SA_onNotification(n) {
  S.nts = [n, ...(S.nts || []).filter((x) => x.id !== n.id)].slice(0, 100);
  if (S.u.nt !== 0 && n.kind !== 'message') toast(n.title);
  if (/^ticket/.test(n.kind)) {
    SA_tk.busy = 0;
    SA_loadTickets();
    if (S.scr == 'tkdet' && SA_tk.cur && n.data && n.data.ticketId == SA_tk.cur.id) SA_showTicket(SA_tk.cur.id);
  }
  if (S.scr == 'notif') SA_rerender();
}
async function SA_readNotifications() {
  const ids = (S.nts || []).filter((n) => !n.read).map((n) => n.id);
  if (!ids.length || !window.SA_API) return;
  S.nts.forEach((n) => (n.read = true));
  window.SA_API.markNotificationsRead(ids).catch(() => {});
}
const SA_b64u = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), (c) => c.charCodeAt(0));
/* جاهزية عامل الخدمة مع مهلة: بدون تسجيل ناجح كان الانتظار يبقى إلى الأبد */
async function SA_swReady() {
  const existing = await navigator.serviceWorker.getRegistration('/');
  if (!existing) throw new Error('خدمة الإشعارات غير مفعّلة في هذا المتصفح (تتطلب HTTPS أو localhost)');
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('انتهت مهلة تجهيز خدمة الإشعارات؛ أعد تحميل الصفحة')), 10000); });
  try { return await Promise.race([navigator.serviceWorker.ready, timeout]); } finally { clearTimeout(timer); }
}
/* تفعيل إشعارات الجهاز (Web Push). يحتاج مفاتيح VAPID في الخادم؛ بدونها يخبر المستخدم بوضوح */
async function SA_enablePush() {
  try {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return toast('المتصفح لا يدعم إشعارات الجهاز');
    const cfg = await window.SA_API.get('/api/push/public-key').catch(() => null);
    if (!cfg || !cfg.publicKey) return toast('إشعارات الجهاز غير مفعّلة في الخادم بعد');
    if ((await Notification.requestPermission()) !== 'granted') return toast('لم تُمنح صلاحية الإشعارات');
    const reg = await SA_swReady();
    const sub = (await reg.pushManager.getSubscription()) || (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: SA_b64u(cfg.publicKey) }));
    await window.SA_API.send('POST', '/api/push/subscribe', sub.toJSON());
    toast('تم تفعيل إشعارات الجهاز');
  } catch (e) {
    toast(e.message || 'تعذّر تفعيل إشعارات الجهاز');
  }
}
