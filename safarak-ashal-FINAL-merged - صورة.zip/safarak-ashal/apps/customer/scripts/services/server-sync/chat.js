/* المحادثات الحقيقية مع المكاتب (تحميل، إرسال، قراءة، مرفقات، لحظي)
   يعرّف: SA_mapMsg، SA_loadConversations، SA_openConv، SA_sendText، SA_sendFile، SA_onMessage، SA_onRead */
const SA_cvKey = (name) => 'C:' + ofn(String(name || ''));
function SA_mapMsg(m) {
  const o = { id: m.id, me: m.senderId === S.u.id ? 1 : 0, t: SA_ts(m.createdAt), rd: m.readAt ? 1 : 0 };
  if (m.body) o.m = m.body;
  if (m.fileId) {
    if (m.kind === 'image') {
      o.img = m.fileUrl + '?inline=1';
      o.nm = m.fileName || 'صورة';
    } else {
      o.doc = m.fileName || 'ملف';
      o.sz = SA_size(m.fileSize);
      o.url = m.fileUrl;
    }
  }
  return o;
}
function SA_cvOf(conv) {
  const k = SA_cvKey(conv.office.name);
  const c = S.cv[k] || (S.cv[k] = { id: k, office: ofn(conv.office.name), oids: [], un: 0, msgs: [] });
  c.sid = conv.id;
  c.oid = conv.office.id;
  c.un = conv.unread || 0;
  return c;
}
async function SA_loadConversations() {
  if (!window.SA_API || !S.u.in) return;
  try {
    const r = await window.SA_API.conversations();
    r.conversations.forEach((cv) => {
      const c = SA_cvOf(cv);
      if (cv.lastBody && !c.msgs.length) c.msgs.push({ m: cv.lastBody, t: SA_ts(cv.lastMessageAt || cv.createdAt), me: 0, preview: 1 });
    });
  } catch (e) {
    console.warn('Unable to load conversations:', e.message);
  }
}
/* يفتح محادثة المكتب: ينشئها إن لزم ثم يحمّل الرسائل ويعلّمها مقروءة */
async function SA_openConv(c) {
  if (!window.SA_API || !c || c.busy) return;
  c.busy = true;
  try {
    if (!c.sid) {
      if (!c.oid) return;
      const r = await window.SA_API.openConversation({ officeId: c.oid });
      SA_cvOf(r.conversation);
    }
    const after = (c.msgs.filter((m) => m.id).slice(-1)[0] || {}).id || 0;
    const r = await window.SA_API.messages(c.sid, after);
    const fresh = r.messages.map(SA_mapMsg);
    c.msgs = c.msgs.filter((m) => m.id || m.pending);
    const have = new Set(c.msgs.map((m) => m.id));
    fresh.forEach((m) => !have.has(m.id) && c.msgs.push(m));
    c.msgs.sort((a, b) => a.t - b.t);
    c.loaded = true;
    if (c.un) {
      c.un = 0;
      window.SA_API.markRead(c.sid).catch(() => {});
    }
    if (S.scr == 'chat' || S.scr == 'msgs') SA_rerender();
  } catch (e) {
    toast(e.message || 'تعذّر تحميل المحادثة');
  } finally {
    c.busy = false;
  }
}
async function SA_sendText(c, text) {
  if (!c.sid) await SA_openConv(c);
  if (!c.sid) throw new Error('تعذّر فتح المحادثة مع المكتب');
  const tmp = { m: text, me: 1, t: Date.now(), pending: 1 };
  c.msgs.push(tmp);
  SA_rerender();
  try {
    const r = await window.SA_API.sendMessage(c.sid, { body: text });
    Object.assign(tmp, SA_mapMsg(r.message), { pending: 0 });
  } catch (e) {
    c.msgs.splice(c.msgs.indexOf(tmp), 1);
    throw e;
  } finally {
    SA_rerender();
  }
}
async function SA_sendFile(c, file) {
  if (!c.sid) await SA_openConv(c);
  if (!c.sid) throw new Error('تعذّر فتح المحادثة مع المكتب');
  const up = await window.SA_FILES.upload(file);
  const r = await window.SA_API.sendMessage(c.sid, { fileId: up.id });
  c.msgs.push(SA_mapMsg(r.message));
  SA_rerender();
}
function SA_onMessage(m, reloaded) {
  const c = Object.values(S.cv).find((x) => x.sid === m.conversationId);
  if (!c) {
    SA_loadConversations().then(() => {
      const n = Object.values(S.cv).find((x) => x.sid === m.conversationId);
      if (n) SA_onMessage(m, true);
    });
    return;
  }
  if (c.msgs.some((x) => x.id === m.id)) return;
  const mine = m.senderId === S.u.id;
  c.msgs = c.msgs.filter((x) => !x.preview && !(x.pending && mine && x.m === m.body));
  c.msgs.push(SA_mapMsg(m));
  c.msgs.sort((a, b) => a.t - b.t);
  if (mine) return SA_rerender();
  const open = S.scr == 'chat' && S.cur === c.id && document.visibilityState === 'visible';
  if (open) window.SA_API.markRead(c.sid).catch(() => {});
  else {
    if (!reloaded) c.un = (c.un || 0) + 1;
    toast('رسالة جديدة من ' + c.office);
  }
  SA_rerender();
}
function SA_onRead(d) {
  const c = Object.values(S.cv).find((x) => x.sid === d.conversationId);
  if (!c) return;
  c.msgs.forEach((m) => m.me && (m.rd = 1));
  if (S.scr == 'chat' && S.cur === c.id) SA_rerender();
}
