/* حساب حقول الحجز والسعر الكامل — الجزء 2/2
   يعرّف: isFullC، fullPrice */
const isFullC = (o) => !!(o && o.dom && String(S.v.fc || '').indexOf('السيارة كاملة') == 0);
const fullPrice = (o) => Number(o.details && o.details.fullVehiclePrice) || (+o.pr || 0) * (+o.tot || 1);
