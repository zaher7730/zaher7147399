/* تطبيق العروض والمكاتب القادمة من الخادم
   يعرّف: SA_days، SA_applyPublicOffices، SA_DAY_NAMES، SA_applyPublicServices */
/* أيام الرحلة (فهارس الأيام الـ14 القادمة) من حقلي المكتب «أيام الرحلة» و«تاريخ الرحلة».
   يومياً = كل الأيام · أسماء أيام = تلك الأيام · نهاية الأسبوع = الخميس والجمعة · تاريخ محدد (YYYY-MM-DD) = ذلك اليوم فقط */
function SA_days(value, date) {
  if (Array.isArray(value)) return value.map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n < 14);
  const text = String(value || '');
  if (text.includes('يومي')) return DATES.map((x) => x.n);
  const out = new Set();
  const names = SA_DAY_NAMES.filter((n) => text.includes(n));
  if (text.includes('نهاية الأسبوع')) names.push('الخميس', 'الجمعة');
  DATES.filter((d) => names.includes(d.w)).forEach((d) => out.add(d.n));
  const iso = String(date || '').slice(0, 10);
  if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) {
    DATES.forEach((x) => {
      const dt = new Date(TODAY);
      dt.setDate(dt.getDate() + x.n);
      const key = dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0');
      if (key === iso) out.add(x.n);
    });
  }
  return [...out].sort((a, b) => a - b);
}
window.SA_applyPublicOffices = function (offices) {
  window.SA_PUBLIC_OFFICES = Array.isArray(offices) ? offices : [];
  window.SA_applyPublicServices(window.SA_PUBLIC_SERVICES || []);
};
const SA_DAY_NAMES = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
window.SA_applyPublicServices = function (services) {
  window.SA_PUBLIC_SERVICES = Array.isArray(services) ? services : [];
  [BUS, LOC, AIR, CARS, PASS, VISA, PRIV].forEach((a) => a.splice(0, a.length));
  [BUS2, LOC2, AIR2, PRIV2].forEach((a) => a.splice(0, a.length));
  OFFS.splice(0, OFFS.length);
  Object.keys(OWN).forEach((k) => delete OWN[k]);
  const officeIndex = new Map();
  for (const office of window.SA_PUBLIC_OFFICES || []) {
    const idx = OFFS.length;
    officeIndex.set(Number(office.id), idx);
    OFFS.push({
      id: Number(office.id),
      n: String(office.office_name || office.name || ''),
      ph: String(office.phone || ''),
      c: String((office.profile && office.profile.city) || ''),
      y: '',
      r: Number((office.rating && office.rating.count) || 0),
      s: Number((office.rating && office.rating.avg) || 0),
      b: '',
      tg: [],
      im: 'p_air',
    });
    OWN[idx] = {};
  }
  for (const svc of Array.isArray(services) ? services : []) {
    const k = String(svc.service_type || '').toLowerCase(),
      d = svc.details && typeof svc.details === 'object' ? svc.details : {},
      oi = Number(svc.office_id);
    if (!['bus', 'local', 'air', 'cars', 'pass', 'visa', 'priv'].includes(k)) continue;
    const name = String(svc.office_name || svc.office_user_name || '').trim();
    if (!name) continue;
    let idx = officeIndex.get(oi);
    if (idx == null) {
      idx = OFFS.length;
      officeIndex.set(oi, idx);
      OFFS.push({
        id: oi,
        n: name,
        c: String(d.city || ''),
        y: '',
        r: 0,
        s: 0,
        b: '',
        tg: [],
        im:
          k === 'air'
            ? 'p_air'
            : k === 'cars'
              ? 'p_car2'
              : k === 'pass'
                ? 'p_pass'
                : k === 'visa'
                  ? 'p_v1'
                  : k === 'local'
                    ? 'h_van'
                    : 'p_bus1',
      });
      OWN[idx] = {};
    }
    if (d.city && !OFFS[idx].c) OFFS[idx].c = String(d.city);
    const rowTitle = String(d.title || svc.title || d.svc || '').trim(),
      from = String(d.from || ''),
      to = String(d.to || '');
    let row, target;
    if (k === 'bus' || k === 'air' || k === 'local' || k === 'priv') {
      target = k === 'bus' ? BUS : k === 'air' ? AIR : k === 'local' ? LOC : PRIV;
      const day = SA_days(d.days, d.date);
      row =
        k === 'air'
          ? [
              name,
              from,
              to,
              day,
              String(d.time || ''),
              String(d.kind || d.type || ''),
              Number(d.seats || 0),
              Number(d.price || 0),
              d.old == null ? 0 : Number(d.old),
              String(d.carrier || ''),
              Number(d.tier || 0),
            ]
          : k === 'local'
            ? [
                name,
                from,
                to,
                day,
                String(d.kind || d.vehicle || ''),
                Number(d.seats || 0),
                Number(d.price || 0),
                d.old == null ? 0 : Number(d.old),
                Number(d.tier || 0),
                String(d.time || ''),
                0,
              ]
            : [
                name,
                from,
                to,
                day,
                String(d.time || ''),
                String(d.kind || d.type || rowTitle),
                Number(d.seats || 0),
                Number(d.price || 0),
                d.old == null ? 0 : Number(d.old),
                0,
                String(d.carrier || ''),
                Number(d.tier || 0),
              ];
    } else if (k === 'cars') {
      target = CARS;
      row = [
        name,
        String(d.city || ''),
        String(d.make || ''),
        String(d.model || rowTitle),
        String(d.kind || d.type || ''),
        Number(d.year || 0),
        Number(d.seats || 0),
        Number(d.price || 0),
        Number(d.deposit || d.dep || 0),
        Number(d.tier || 0),
      ];
    } else if (k === 'pass') {
      target = PASS;
      row = [name, String(d.svc || rowTitle), String(d.dur || ''), Number(d.price || 0), Number(d.tier || 0)];
    } else {
      target = VISA;
      row = [name, String(d.svc || rowTitle), Number(d.price || 0), d.old == null ? 0 : Number(d.old), Number(d.tier || 0)];
    }
    row.serviceId = svc.id;
    row.serverOfficeId = oi;
    row.reserved = !!svc.reserved; /* سيارة محجوزة من عميل آخر: يحسبها الخادم */
    row.details = d;
    if (d.imageUrl) {
      const imageKey = 'sa_asset_' + svc.id;
      IM[imageKey] = d.imageUrl;
      row.imageKey = imageKey;
      if (!OFFS[idx].hasImage) {
        OFFS[idx].im = imageKey;
        OFFS[idx].hasImage = true;
      }
    }
    const ri = target.length;
    target.push(row);
    OWN[idx][k] = OWN[idx][k] || [];
    OWN[idx][k].push(ri);
    if (!OFFS[idx].tg.includes(k)) OFFS[idx].tg.push(k);
  }
  BUS2.push(...bi(BUS));
  LOC2.push(...bi(LOC));
  AIR2.push(...bi(AIR));
  PRIV2.push(...bi(PRIV));
  SA_refreshCities();
  if (typeof render === 'function') render();
};
