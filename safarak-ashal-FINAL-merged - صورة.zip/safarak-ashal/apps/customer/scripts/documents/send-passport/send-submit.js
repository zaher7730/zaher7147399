/* إرسال الجواز للمكتب (الأمانات) — الجزء 3/3
   يعرّف: sendSubmit، SDO، SA_applyPublicPoints، sdS، SDPIN */
async function sendSubmit() {
  const g = (i) => (($('#' + i) || {}).value || '').trim(),
    n = g('sdn'),
    recipient = g('sdo'),
    phone = g('sdp'),
    point = SDO[sdS().i];
  if (!n) return toast('اكتب اسم المرسل');
  if (!recipient) return toast('اكتب اسم المكتب المستلم');
  if (!/\d/.test(phone)) return toast('اكتب رقم الهاتف');
  if (!point) return toast('لا توجد نقطة أمانات مسجلة حالياً؛ لن يتم إنشاء طلب وهمي');
  if (!window.SA_API) return toast('هذه معاينة شكلية فقط؛ شغّل الخادم لتسجيل الطلب الحقيقي');
  const office = (window.SA_PUBLIC_OFFICES || []).find((o) => String(o.office_name || o.name).trim() === recipient);
  if (!office) return toast('اختر اسم مكتب مسجلاً من القائمة');
  try {
    const title = 'إرسال جواز عبر ' + point[0];
    const r = await window.SA_API.createBooking({
      officeId: office.id,
      serviceType: 'pass',
      title,
      passengerCount: 1,
      totalAmount: Number(SDP || 0),
      currency: CFG.cur || 'YER',
      details: {
        pointId: point[4],
        pointName: point[0],
        pointCity: point[1],
        pointAddress: point[2],
        senderName: n,
        senderPhone: phone,
        recipientOffice: recipient,
      },
    });
    const b = {
      ...r.booking,
      details: { pointId: point[4], pointName: point[0], pointCity: point[1], pointAddress: point[2] },
      office_name: office.office_name || office.name,
      customer_name: S.u.name,
      customer_phone: S.u.ph,
    };
    const x = SA_mapBooking(b);
    S.ord.unshift(x);
    S.cur = x.id;
    S.hist = [];
    S.scr = 'done';
    render();
    toast('تم تسجيل طلب إرسال الجواز في قاعدة البيانات');
  } catch (e) {
    toast(e.message || 'تعذر حفظ طلب الإرسال');
  }
}
/* ===== إرسال جوازك للمكتب: مكاتب أمانات (بقالات) يسلّم لها العميل جوازه ومستنداته وتوصلها لمكتب السفر ===== */
const SDO = [],
  SDC = [],
  SDP = 0;
window.SA_applyPublicPoints = function (points) {
  SDO.splice(0, SDO.length, ...(Array.isArray(points) ? points : []).map((p) => [p.name, p.city, p.address, p.phone, p.id]));
  SDC.splice(0, SDC.length, ...[...new Set(SDO.map((x) => x[1]).filter(Boolean))]);
  if (typeof render === 'function') render();
};
const sdS = () => S.sn || (S.sn = { c: '', i: 0 });
const SDPIN =
  '<svg viewBox="0 0 24 24"><path d="M12 2a7 7 0 00-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 00-7-7zm0 9.5A2.5 2.5 0 1112 6.500a2.5 2.5 0 010 5z"/></svg>';
