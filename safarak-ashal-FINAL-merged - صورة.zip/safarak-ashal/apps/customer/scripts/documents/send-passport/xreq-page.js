/* إرسال الجواز للمكتب (الأمانات) — الجزء 2/3
   يعرّف: xreqPage، xreqSubmit */
function xreqPage() {
  const o = S.o || {},
    ap = o.svc == 'الموافقات الأمنية',
    E = (v) => ht(v).replace(/"/g, '&quot;');
  const ph = ap
    ? 'اكتب سؤالك أو أي ملاحظة تريد أن يعرفها المكتب...'
    : 'اكتب ملاحظتك بوضوح، مثال: هذا رقم جوازي، كنت في السعودية وحصل لي حادث قبل أربع سنوات...';
  return `<div class="sdPg">${sdHead(o.svc || 'طلب خدمة', o.n || '', 'detail')}<div class="sdBan">${ap ? 'أرسل اسمك ورقم جوازك مع ملاحظتك، ويراجع المكتب طلبك ويرد عليك في الرسائل' : 'سجّل رقم جوازك واكتب ملاحظتك، ويصل الرقم والملاحظة إلى المكتب ويرد عليك في الرسائل'}</div>
<div class="sdForm"><div class="sdGrid" style="grid-template-columns:${ap ? '1fr 1fr' : '1fr'}">${ap ? `<label class="lgF"><span>الاسم الكامل</span><input id="xrn1" class="lgIn" value="${E(S.u.name || '')}"></label>` : ''}<label class="lgF"><span>رقم الجواز</span><input id="xrp" class="lgIn" dir="ltr" style="text-align:right" maxlength="12" autocomplete="off"></label></div>
<label class="lgF"><span>${ap ? 'ملاحظة مفتوحة (اختياري)' : 'الملاحظة'}</span><textarea id="xrn" class="lgIn xrTa" rows="5" placeholder="${ph}"></textarea></label>
<div class="sdInfo"><svg viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg><span>يصل رقم جوازك وملاحظتك إلى المكتب فقط وتبقى بياناتك محفوظة.</span></div>
<button class="lgBtn" style="max-width:260px;display:block;margin:0 auto" onclick="xreqSubmit()">إرسال إلى المكتب</button></div></div>`;
}
async function xreqSubmit() {
  const o = S.o || {},
    ap = o.svc === 'الموافقات الأمنية',
    g = (i) => (($('#' + i) || {}).value || '').trim(),
    nm = ap ? g('xrn1') : (S.u.name || '').trim(),
    pp = g('xrp'),
    nt = g('xrn');
  if (ap && !nm) return toast('اكتب اسمك الكامل');
  if (!/^[A-Za-z0-9]{5,12}$/.test(pp)) return toast('اكتب رقم جواز صحيح');
  if (!ap && !nt) return toast('اكتب ملاحظتك للمكتب');
  if (!window.SA_API) return toast('هذه معاينة شكلية فقط؛ شغّل الخادم لتسجيل الطلب الحقيقي');
  if (!o.serviceId) return toast('لا يمكن إرسال الطلب قبل نشر المكتب هذه الخدمة وربطها بعرض حقيقي');
  const title = (ap ? 'طلب موافقة أمنية — ' : 'طلب برنت بصمة — ') + (o.t || o.svc || 'خدمة');
  try {
    const r = await window.SA_API.createBooking({
      serviceId: o.serviceId,
      serviceType: o.k || 'pass',
      title,
      passengerCount: 1,
      totalAmount: Number(o.pr || 0),
      currency:
        String(o.cur || CFG.cur || 'YER')
          .replace(/[^A-Za-z]/g, '')
          .slice(0, 8) || 'YER',
      details: {
        serviceId: o.serviceId,
        officeName: o.n,
        requestType: ap ? 'موافقة أمنية' : 'برنت بصمة',
        passportNumber: pp,
        customerName: nm,
        note: nt,
      },
    });
    const b = {
      ...r.booking,
      details: { serviceId: o.serviceId, officeName: o.n, passportNumber: pp, note: nt },
      office_name: o.n,
      customer_name: S.u.name,
      customer_phone: S.u.ph,
    };
    await SA_uploadFormAttachments(b.public_id, S.v);
    const x = SA_mapBooking(b);
    S.ord.unshift(x);
    S.cur = x.id;
    S.hist = [];
    S.scr = 'done';
    render();
    toast('تم إرسال طلب الخدمة إلى المكتب في قاعدة البيانات');
  } catch (e) {
    toast(e.message || 'تعذر حفظ الطلب على الخادم');
  }
}
