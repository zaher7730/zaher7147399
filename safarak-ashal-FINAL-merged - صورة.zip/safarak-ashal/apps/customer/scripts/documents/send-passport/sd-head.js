/* إرسال الجواز للمكتب (الأمانات) — الجزء 1/3
   يعرّف: sdHead، sendCity، sendPage، sendGo، sendForm */
function sdHead(t, p, to) {
  return `<div class="sdHd"><div class="sdHt"><h1>${t}</h1>${p ? `<p>${p}</p>` : ''}</div><button class="sdBk" onclick="bk('${to}')" aria-label="رجوع"><svg viewBox="0 0 24 24"><path d="M15 6l-6 6 6 6"/></svg></button></div>`;
}
function sendCity() {
  pick('اختر مدينتك', ['الكل', ...SDC], sdS().c || 'الكل', (v) => {
    sdS().c = v == 'الكل' ? '' : v;
  });
}
function sendPage() {
  const s = sdS(),
    L = SDO.map((o, i) => [o, i]).filter(([o]) => !s.c || o[1] == s.c);
  return `<div class="sdPg">${sdHead('إرسال جوازك للمكتب', 'أرسل جوازك بسهولة عبر مكاتب الأمانات ويتم توصيلهم لمكتب السفر بكل أمان', 'home')}<div class="sdBan">إرسال جوازك وبياناتك إلى مكتب السفر الذي ينجز معاملاتك، عبر مكاتب الأمانات المعتمدة لدينا، بكل سهولة وأمان ونضمن خصوصياتك</div>
<div class="sdCity"><button class="lcCity" style="width:190px" onclick="sendCity()"><span class="tx"><small>المدينة</small><b class="${s.c ? '' : 'lcph'}">${s.c || 'اختر مدينتك'}</b></span>${ARI.chev}</button></div>
<div class="sdList">${L.map(([o, i]) => `<div class="sdCard"><div class="sdNm">${o[0]}<i></i></div><div class="sdAd">${SDPIN}${o[1]} - ${o[2]}</div><button class="sdGo" onclick="sendGo(${i})">ابدأ الإرسال</button></div>`).join('') || '<div class="empty"><b>📍</b>لا توجد مكاتب أمانات في هذه المدينة بعد</div>'}</div></div>`;
}
function sendGo(i) {
  sdS().i = i;
  go('sendf');
}
function sendForm() {
  const o = SDO[sdS().i] || SDO[0];
  return `<div class="sdPg">${sdHead(o[0], '', 'send')}<div class="sdForm"><div class="sdAd">${SDPIN}${o[1]} - ${o[2]}</div><p class="sdHint">يرجى الحضور إلى موقع مكتب الأمانات لكي يتم تسليمنا جوازك ومستنداتك ويتم إرساله.</p>
<div class="sdGrid"><label class="lgF"><span>اسم المرسل</span><input id="sdn" class="lgIn" value="${ht(S.u.name || '')}"></label><label class="lgF"><span>اسم المكتب المستلم</span><input id="sdo" class="lgIn" list="sdl" placeholder="مكتب السفر المستلم"><datalist id="sdl">${OFFS.map((x) => `<option value="${x.n}">`).join('')}</datalist></label>
<label class="lgF"><span>رقم الهاتف</span><input id="sdp" class="lgIn" type="tel" inputmode="numeric" dir="ltr" style="text-align:right" value="${ht(S.u.ph || '')}"></label><label class="lgF"><span>مبلغ الإرسال</span><input class="lgIn" readonly value="${SDP > 0 ? SDP + ' ريال' : 'يحدد بعد مراجعة المكتب'}"></label></div>
<div class="sdInfo"><svg viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg><span>يتم توصيل جوازك ومستنداتك إلى المكتب المحدد بكل أمان وحفظ خصوصياتك ومعلوماتك.</span></div>
<button class="lgBtn" style="max-width:260px;display:block;margin:0 auto" onclick="sendSubmit()">أبدأ الإرسال</button></div></div>`;
}
