/* صفحة الجواز اليمني
   يعرّف: serviceOfferCard، passPage، SP */
function serviceOfferCard(o, details) {
  const tier = Math.max(0, Math.min(2, Number(o.tier) || 0)),
    info = (TQ(o) || TR[o.k] || [])[tier] || {},
    idx = OFF.push({ ...o, left: 1, tot: 1 }) - 1;
  const price = Number(o.pr) || 0,
    old = Number(o.old) || 0,
    level = ARL[tier] || 'عادي';
  const feats = (o.xf || info.i || []).slice(0, 3),
    icons = [ARI.thumb, ARI.bag, ARI.food];
  return `<div class="arCard serviceOfferCard"><div class="arDet"><div class="arName"><span class="t">${o.n}</span><span class="v"></span></div><div class="arChips"><span class="c1">مكتب مسجل</span><span class="c2">${o.svc || o.t}</span></div><div class="arSpec serviceOfferSpec">${details}</div><div class="arFeat">${feats.map((x, j) => `<span>${icons[j] || ARI.thumb}${x}</span>`).join('')}</div><div class="arBot"><button class="arBook" onclick="det(${idx})">ابدأ الحجز${ARI.left}</button><div class="arPrice"><small>السعر للخدمة</small>${old ? `<s>${curOf(o)}${old}</s>` : ''}<b>${price ? curOf(o) + price : o.pl || 'حسب الباقة'}</b></div></div></div><div class="arPic serviceOfferPic"><img class="bg" src="${ari(o.ph)}" alt="" aria-hidden="true"><img class="fg" src="${ari(o.ph)}" loading="lazy" alt="${o.t}" onerror="fb(this,'${o.k === 'pass' ? 'p_ps1' : /زيارة عائلية|حج|عمرة/.test(o.svc || '') ? 'p_v2' : 'p_v1'}')"><span class="arVip ${tier === 2 ? '' : 'n'}">${level}</span></div></div>`;
}
function passPage(sk, rows, nm, city) {
  sk = sk || 'pass';
  rows = rows || PASS;
  const F = S.F[sk] || (S.F[sk] = {});
  OFF = [];
  OPT[sk] = nm ? PSV.filter((s) => rows.some((p) => p[1] === s)) : PSV;
  const offers = rows
    .filter((p) => !F.s || p[1] === F.s)
    .map((p, j) => {
      const o = {
        k: 'pass',
        tier: p[4] || 0,
        n: nm || '',
        t: p[1],
        svc: p[1],
        pr: p[3],
        cur: CFG.cur || 'YER',
        ph: SP[j % SP.length],
        dur: p[2],
      };
      return serviceOfferCard(
        o,
        `<div><p><small>نوع الخدمة</small>${p[1]}</p></div><div><p><small>المدة</small>${p[2]}</p></div><div><p><small>التوصيل</small>${h((p.details && p.details.delivery) || 'يحدده المكتب')}</p></div>`,
      );
    })
    .join('');
  return `<div class="arp serviceCategoryPage passPageWrap"><div class="arHead"><div class="arTit"><h1>${HD[sk][0]}</h1><p>${HD[sk][1]}</p></div><button class="arBack" onclick="bk('home')" aria-label="رجوع">${ARI.back}</button></div><div class="serviceOffersBody">${sel('', F.s, 'اختر نوع الخدمة', `setF('${sk}','s','اختر نوع الخدمة',OPT['${sk}'],1)`)}<div class="crSep serviceOfferSep"><b>اختر من بين العروض</b></div><div class="crSub">اسحب للأسفل لعرض المزيد من العروض</div><div class="arList">${offers || '<div class="empty"><b>🔍</b>لا توجد عروض مطابقة للخدمة المحددة</div>'}</div></div></div>`;
}
const SP = ['p_ps1', 'p_ps2'];
