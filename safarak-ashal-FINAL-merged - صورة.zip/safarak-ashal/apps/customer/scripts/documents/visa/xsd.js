/* صفحة التأشيرات — الجزء 2/2
   يعرّف: XSD، VCOUNTRIES، vFil */
const XSD = {
  'برنت بصمة': { ph: 'p_ps1', xf: ['سجّل رقم جوازك واكتب ملاحظتك', 'يصل الرقم والملاحظة للمكتب مباشرة'] },
  'الموافقات الأمنية': { ph: 'p_v1', xf: ['أرسل اسمك ورقم جوازك', 'اكتب أي ملاحظة أو سؤال تريده'] },
};
const VCOUNTRIES = ['السعودية', 'عُمان', 'مصر', 'إثيوبيا', 'الإمارات', 'قطر', 'الكويت', 'الأردن', 'البحرين', 'تركيا'];
const vFil = (sk, F, nm) => {
  const b = (f, l, v) =>
    `<button class="lcCity" onclick="vF('${sk}','${f}')"><span class="tx"><small>${l}</small><b>${v || 'الكل'}</b></span>${ARI.chev}</button>`;
  if (nm) return `<div class="vFil singleVisaFilter">${b('v', 'نوع التأشيرة', F.v)}</div>`;
  return `<div class="vCityTitle">اختر مدينتك</div><div class="vCityStrip" role="group" aria-label="اختر المحافظة">${VCT.map((c) => `<button type="button" class="vCityChip ${F.c === c ? 'on' : ''}" onclick="S.F['${sk}'].c='${c}';render()">${c}</button>`).join('')}</div><div class="vFil">${b('v', 'نوع التأشيرة', F.v)}${b('d', 'اختيار الدولة', F.d)}${b('x', 'خدمات أخرى', F.x)}</div>`;
};
