/* صفحة التأشيرات — الجزء 1/2
   يعرّف: officeLoc، officeCity، xsProps، vF، visaPage، VCT، XSN */
function officeLoc(o) {
  const c = o.custom || {};
  if (c.loc) return c.loc;
  if (o.k == 'local') return o.from || '';
  if (o.city) return o.city;
  const k = oShort(o.n),
    f = OFFS.find((x) => oShort(x.n) === k);
  return (f && f.c) || '';
}
/* مدينة المكتب من بياناته المسجلة في المنصة (ملف المكتب أو خدمته) */
function officeCity(name) {
  const k = oShort(name),
    f = OFFS.find((x) => oShort(x.n) === k);
  return f && f.c ? String(f.c).split(' - ')[0] : '';
}
/* الخدمات الأخرى (برنت بصمة / الموافقات الأمنية): تُطلب عبر نموذج الطلب لا نموذج الحجز */
function xsProps(svc) {
  const d = XSD[svc];
  return d ? { xs: 1, pl: 'حسب المكتب', ph: d.ph, xf: d.xf } : {};
}
function vF(sk, f) {
  const F = S.F[sk] || (S.F[sk] = {}),
    T = { c: ['اختر مدينتك', VCT], d: ['اختر الدولة', VCOUNTRIES], v: ['اختر نوع التأشيرة', OPT[sk] || VT], x: ['اختر خدمة أخرى', XSN] };
  pick(T[f][0], ['الكل', ...T[f][1]], F[f] || 'الكل', (v) => {
    F[f] = v == 'الكل' ? '' : v;
    if (v != 'الكل') {
      if (f == 'v') F.x = '';
      if (f == 'x') F.v = '';
    }
  });
}
function visaPage(sk, rows, nm, city) {
  sk = sk || 'visa';
  rows = rows || VISA;
  const F = S.F[sk] || (S.F[sk] = {});
  if (!nm && !F.c) F.c = VCT.includes('تعز') ? 'تعز' : VCT[0] || '';
  OFF = [];
  OPT[sk] = nm ? VT.filter((s) => rows.some((v) => v[1] === s)) : VT;
  const pub = !nm,
    cityOk = (v) => !pub || !F.c || officeCity(v[0]) === F.c;
  const offers = rows
    .filter((v) => (F.x ? v[1] === F.x : !F.v || v[1] === F.v))
    .filter(cityOk)
    .map((v) => {
      const x = XSN.includes(v[1]),
        o = {
          k: 'visa',
          tier: x ? 0 : v[4] || 0,
          n: nm || '',
          t: v[1],
          svc: v[1],
          pr: x ? v[2] || 0 : v[2] || 'حسب الباقة',
          old: v[3] || 0,
          ph: /زيارة عائلية|حج|عمرة/.test(v[1]) ? 'p_v2' : 'p_v1',
          serviceId: v.serviceId || null,
          serverOfficeId: v.serverOfficeId || null,
          details: v.details || {},
          ...xsProps(v[1]),
        };
      if (v.imageKey) o.ph = v.imageKey;
      return serviceOfferCard(
        o,
        x
          ? `<div><p><small>نوع الخدمة</small>${v[1]}</p></div><div><p><small>طريقة الطلب</small>عبر التطبيق</p></div>`
          : `<div><p><small>نوع التأشيرة</small>${v[1]}</p></div><div><p><small>يشمل العرض</small>${h((v.details && v.details.includes) || 'راجع تفاصيل العرض المنشورة من المكتب')}</p></div>`,
      );
    })
    .join('');
  return `<div class="arp serviceCategoryPage visaPageWrap"><div class="arHead"><div class="arTit"><h1>${HD[sk][0]}</h1><p>${HD[sk][1]}</p></div><button class="arBack" onclick="bk('home')" aria-label="رجوع">${ARI.back}</button></div>${vFil(sk, F, nm)}<div class="serviceOffersBody"><div class="crSep serviceOfferSep"><b>اختر من بين العروض</b></div><div class="crSub">اسحب للأسفل لعرض المزيد من العروض</div><div class="arList">${offers || '<div class="empty"><b>🔍</b>لا توجد عروض مطابقة للاختيار المحدد</div>'}</div></div></div>`;
}
/* خدمات المسافر: ثلاث قوائم (المدينة · نوع التأشيرة · خدمات أخرى). مدن المكاتب من بياناتها المسجلة */
const oShort = (n) =>
    String(n || '')
      .replace(/^مكتب\s+/, '')
      .replace(/\s+ل\S*.*$/, '');
const VCT = ['تعز', 'عدن', 'صنعاء', 'مأرب', 'حجة', 'المكلا', 'سيئون', 'شبوة', 'الحديدة', 'إب'],
  XSN = ['برنت بصمة', 'الموافقات الأمنية'];
