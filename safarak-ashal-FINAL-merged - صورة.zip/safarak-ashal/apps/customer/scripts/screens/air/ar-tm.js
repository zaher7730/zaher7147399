/* صفحة الطيران — الجزء 3/3
   يعرّف: arTm */
/* يحوّل نص وقت الانطلاق إلى دقائق من منتصف الليل. يقبل «8:30 م» و«08:30 ص» و«20:30» والأرقام العربية */
const arTm = (t) => {
  const s = String(t == null ? '' : t).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)),
    m = s.match(/(\d{1,2})(?::(\d{2}))?/);
  if (!m) return 0;
  let h = Number(m[1]);
  const mi = Number(m[2] || 0);
  if (/م|PM|pm/.test(s)) h = (h % 12) + 12;
  else if (/ص|AM|am/.test(s)) h = h % 12;
  return h * 60 + mi;
};
