/* نموذج الحجز — الجزء 2/3
   يعرّف: book، bad */
function book() {
  const o = S.o,
    k = o.k;
  if (k == 'air' && !S.v.tt) S.v.tt = 'ذهاب';
  if (k == 'cars' && !S.v.rcv) S.v.rcv = 'استلام من المكتب';
  if (o.dom && !S.v.fc) S.v.fc = 'حجز مقاعد';
  const F = fields(o).filter((x) => !(x[0] == 'c' && /طفل|الأطفال/.test(x[2] || ''))),
    fam = o.svc == 'زيارة عائلية',
    sh = (fam ? F.filter((x) => x[5] == S.tab) : F).filter((x) => !x[7]),
    EX = F.filter((x) => x[7]),
    X = ['c', 'f', 'ta'];
  const sec = (t, a, full) =>
    a.length ? `<div class="pill">${t}</div><div class="g2">${a.map((x) => fld(x, full || x[0] == 'ta')).join('')}</div>` : '';
  const SE1 = sh.filter((x) => x[1] == 'seat'),
    TT = sh.filter((x) => x[1] == 'tt'),
    P = sh.filter((x) => !X.includes(x[0]) && x[1] != 'seat' && x[1] != 'tt'),
    C = sh.filter((x) => x[0] == 'c'),
    A = sh.filter((x) => x[0] == 'f'),
    N = sh.filter((x) => x[0] == 'ta');
  const vn = Math.min(5, Math.max(1, +S.v.vn || 1)),
    vb = (j) =>
      sec(
        'بيانات الزائر ' + j,
        P.filter((x) => (x[6] || 1) == j),
        1,
      ) +
      sec(
        'مرفقات الزائر ' + j,
        A.filter((x) => (x[6] || 1) == j),
        1,
      ),
    VS =
      fam && S.tab == 'z'
        ? vb(1) + sec('عدد الزائرين', [['c', 'vn', 'عدد الزائرين', 1]]) + [...Array(vn - 1)].map((_, j) => vb(j + 2)).join('')
        : '';
  const ex = !fam && ['bus', 'air', 'local', 'visa'].includes(k),
    CT = sec(k == 'cars' ? 'مدة الإيجار' : k == 'visa' ? 'عدد الأفراد' : 'عدد المسافرين', C),
    AT = VS ? '' : sec('المرفقات والمستندات المطلوبة', A, 1),
    EXH = [...new Set(EX.map((x) => x[7]))]
      .map(
        (j) =>
          sec(
            'بيانات الفرد ' + j,
            EX.filter((x) => x[7] == j && x[0] != 'f'),
            0,
          ) +
          sec(
            'مرفقات الفرد ' + j,
            EX.filter((x) => x[7] == j && x[0] == 'f'),
            1,
          ),
      )
      .join('');
  const pt = fam
    ? S.tab == 'z'
      ? 'بيانات الزائر'
      : 'بيانات المقيم'
    : k == 'cars'
      ? 'بيانات المستأجر'
      : k == 'pass' || k == 'visa'
        ? 'بيانات مقدم الطلب'
        : 'معلومات المسافرين';
  return `<div class="cmp"><div class="tt"><button class="bk" onclick="keep();bk('detail')">‹</button><h1>${fam ? 'البيانات ومتطلبات الزيارة' : 'بيانات العميل'}</h1></div>${bar(2)}${fam ? `<div class="tabs"><div class="${S.tab == 'm' ? 'on' : ''}" onclick="keep();S.tab='m';render()">بيانات المقيم</div><div class="${S.tab == 'z' ? 'on' : ''}" onclick="keep();S.tab='z';render()">بيانات الزائر</div></div>` : ''}
 ${VS || sec(pt, P, fam)}${sec('نوع الرحلة', TT, 1)}${ex ? '' : CT}${sec('تفاصيل المقعد', SE1, 1)}${AT}${ex ? CT + EXH : ''}${sec('ملاحظات خاصة', N)}
 <div class="stk"><div class="tot"><span>${curOf(o)} ${total()}</span><span>${ic('y_dollar')} ${k == 'cars' ? 'الإجمالي (إيجار + ضمان)' : 'السعر الإجمالي'}</span></div><button class="gb w" onclick="toPay()">← متابعة إلى الدفع</button></div></div>`;
}
function bad() {
  const v = S.v,
    t = new Date().toISOString().slice(0, 10),
    ph = (x) => /^\+?\d{7,15}$/.test(String(x).replace(/[\s-]/g, ''));
  if (v.ph && !ph(v.ph)) return 'رقم الجوال غير صحيح';
  if (v.rph && !ph(v.rph)) return 'جوال المقيم غير صحيح';
  if (v.em && !/^\S+@\S+\.\S+$/.test(v.em)) return 'البريد الإلكتروني غير صحيح';
  if (v.dob && v.dob > t) return 'تاريخ الميلاد غير صحيح';
  if (v.pd && v.pd < t) return 'تاريخ الاستلام يجب أن يكون اليوم أو بعده';
  if (v.pp && String(v.pp).trim().length < 6) return 'رقم الجواز / الهوية قصير جداً';
  return '';
}
