/* نموذج الحجز — الجزء 1/3
   يعرّف: keep، cc، fld، PX، total */
function keep() {
  document.querySelectorAll('[data-k]').forEach((e) => (S.v[e.dataset.k] = e.value));
}
function cc(k, d) {
  keep();
  const passengerService = ['bus', 'local', 'air'].includes(S.o && S.o.k);
  const countKeys = passengerService && ['a', 'y', 'c'].includes(k);
  const t = (+S.v.a || 0) + (+S.v.y || 0) + (+S.v.c || 0);
  if (countKeys && d > 0 && S.o.left != null && Number(S.o.left) > 0 && t >= Number(S.o.left)) {
    toast('المقاعد المتاحة ' + S.o.left + ' فقط');
    return;
  }
  S.v[k] = Math.min(k == 'vn' ? 5 : 99, Math.max(k == 'a' || k == 'vn' ? 1 : 0, (S.v[k] || 0) + d));
  render();
}
function fld(x, full) {
  const [t, k, l, r, o] = x,
    v = S.v[k] || '',
    I = ic(FI[k.replace(/_\d+$/, '')] || 'f_user'),
    L = `<label>${l}${r ? ' <b>*</b>' : ''}</label>`,
    W = full ? 'full' : '';
  if (t == 'sd') {
    const sm = seatMap(S.o).filter((a) => a[1] > 0),
      cu = sm.find((a) => a[0] == v);
    FP[k] = { l, L: sm.map((a) => [a[0] + ' — متاح ' + a[1], a[0]]) };
    return `<div class="${W}">${L}<div class="fi"><button type="button" class="fsel ${v ? '' : 'ph'}" onclick="pickF('${k}')"><span>${cu ? cu[0] + ' — متاح ' + cu[1] : v || 'اختر'}</span><span>▾</span></button>${I}</div></div>`;
  }
  if (t == 'tg')
    return `<div class="full">${L}<div class="tgb">${o.map((a) => `<button type="button" class="${a == v ? 'on' : ''}" onclick="keep();S.v['${k}']='${a}';render()">${a}</button>`).join('')}</div></div>`;
  if (t == 'c')
    return `<div class="${W}"><label class="cntLabel">${l}${r ? ' <b>*</b>' : ''}</label><div class="cn compactCn">${k == 'c' ? '' : I}<button type="button" onclick="cc('${k}',1)">+</button><b>${S.v[k] || 0}</b><button type="button" onclick="cc('${k}',-1)">−</button></div></div>`;
  if (t == 'f') {
    const ok = S.fl[k];
    return `<div class="full">${L}<label class="up ${ok ? 'ok' : ''}">${S.fu && /^data:image\//.test(S.fu[k] || '') ? `<img class="pv" src="${S.fu[k]}">` : ic('f_cloud', 'big')}<div><b>${ok ? 'تم الإرفاق ✔' : 'اضغط لرفع الصورة'}</b><small>${ok || 'JPG / PNG / PDF · 5 ميجابايت'}</small></div><input type="file" accept="image/*,.pdf" onchange="keep();const f=this.files[0];S.fl['${k}']=f?f.name:'';S.fu['${k}']='';if(f&&f.size>5242880){S.fl['${k}']='';toast('الحجم الأقصى 5 ميجابايت');render();return}if(f&&['image/jpeg','image/png','image/webp','application/pdf'].indexOf(f.type)<0){S.fl['${k}']='';toast('نوع الملف غير مدعوم؛ JPG أو PNG أو WEBP أو PDF');render();return}if(f&&(f.type.indexOf('image')==0||f.type=='application/pdf')){const r=new FileReader();r.onload=()=>{S.fu['${k}']=r.result;render()};r.readAsDataURL(f)}render()"></label></div>`;
  }
  if (t == 's') {
    FP[k] = { l, L: o.map((a) => [a, a]) };
    return `<div class="${W || k == 'drv' || k == 'rcv' ? 'full' : ''}">${L}<div class="fi"><button type="button" class="fsel ${v ? '' : 'ph'}" onclick="pickF('${k}')"><span>${v || 'اختر'}</span><span>▾</span></button>${I}</div></div>`;
  }
  if (t == 'ta')
    return `<div class="full">${L}<div class="fi"><textarea class="f" data-k="${k}" rows="2" placeholder="أي ملاحظات إضافية...">${ht(v)}</textarea>${ic('f_pen')}</div></div>`;
  return `<div class="${W}">${L}<div class="fi"><input class="f" data-k="${k}" value="${ht(v)}" type="${t == 'd' ? 'date' : t == 'e' ? 'email' : 'text'}" ${t == 'p' ? 'inputmode="tel" placeholder="+967 7XXXXXXXX"' : ''}>${I}</div></div>`;
}
function PX() {
  const o = S.o;
  if (isFullC(o)) return +o.tot || 1;
  return o.svc == 'زيارة عائلية' ? Math.max(1, +S.v.vn || 1) : o.k == 'cars' ? +S.v.a || 1 : (+S.v.a || 1) + (+S.v.y || 0) + (+S.v.c || 0);
}
function total() {
  const o = S.o,
    k = o.k;
  if (isFullC(o)) return fullPrice(o) + dep(o);
  const n = k == 'cars' ? +S.v.a || 1 : PX();
  return tp(o, S.tier || 0) * n * (k == 'air' && S.v.tt == 'ذهاب وإياب' ? 2 : 1) + dep(o);
}
