/* نموذج الحجز — الجزء 3/3
   يعرّف: missing، toPay، FI */
function missing(F) {
  return F.filter((x) => x[3] && !(x[0] == 'f' ? S.fl[x[1]] && S.fu && S.fu[x[1]] : x[0] == 'c' ? x[1] != 'a' || +S.v.a > 0 : S.v[x[1]]));
}
function toPay() {
  keep();
  if (tripGoneGuard(S.o)) return;
  const m = missing(fields(S.o));
  if (m.length) {
    const x = m[0];
    if (x[5]) S.tab = x[5];
    render();
    toast('مطلوب: ' + x[2] + (x[7] ? ' (الفرد ' + x[7] + ')' : ''));
    return;
  }
  const e = bad() || seatBad();
  if (e) {
    toast(e);
    return;
  }
  S.pm = '';
  S.pmo = 0;
  S.pt = 'm';
  go('pay');
}
const FI = {
  seat: 'c_seat',
  name: 'f_user',
  pp: 'f_pp',
  nid: 'f_pp',
  rid: 'f_pp',
  em: 'f_mail',
  ph: 'f_phone',
  rph: 'f_phone',
  dob: 'f_cal',
  pd: 'f_cal',
  td: 'f_cal',
  a: 'f_adult',
  y: 'f_youth',
  c: '',
  bg: 'f_bag',
  nt: 'f_pen',
  tn: 'f_user',
  tr: 'f_pp',
};
