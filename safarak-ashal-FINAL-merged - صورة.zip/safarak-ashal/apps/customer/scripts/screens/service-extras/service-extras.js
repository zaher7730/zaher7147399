/* مساعدات الخدمات والرفع
   يعرّف: nv، XP، pickF، waCS، vfm، FP */
function nv() {
  return { a: 1, vn: 1, y: 0, c: 0, bg: 0, name: S.u.name, ph: S.u.ph, pp: S.u.idn || '', nid: S.u.idn || '' };
}
function XP(o) {
  const k = o.k;
  if (k == 'cars' || k == 'pass' || o.svc == 'زيارة عائلية' || isFullC(o)) return [];
  const n = Math.min(15, PX());
  if (n < 2) return [];
  const NT = ['يمني', 'سعودي', 'مصري', 'سوداني', 'أخرى'],
    T =
      k == 'visa'
        ? [
            ['t', 'name', 'الاسم كما في الجواز', 1],
            ['s', 'sex', 'الجنس', 1, SEX],
            ['s', 'nat', 'الجنسية', 1, NT],
            ['t', 'pp', 'رقم الجواز', 1],
            ['d', 'dob', 'تاريخ الميلاد', 1],
            ...vfm(o),
          ]
        : k == 'air'
          ? [
              ['t', 'name', 'الاسم كما في الجواز', 1],
              ['s', 'sex', 'الجنس', 1, SEX],
              ['t', 'pp', 'رقم الجواز', 1],
              ['d', 'dob', 'تاريخ الميلاد', 1],
              ['f', 'f1', 'صورة جواز السفر', 1],
            ]
          : k == 'bus'
            ? [
                ['t', 'name', 'الاسم الكامل', 1],
                ['t', 'pp', 'رقم الجواز / الهوية', 1],
                ['f', 'f1', 'صورة الجواز / الهوية', 1],
              ]
            : [['t', 'name', 'الاسم الكامل', 1]];
  const r = [];
  for (let j = 2; j <= n; j++)
    T.forEach((x) => {
      const y = [...x];
      y[1] = x[1] + '_' + j;
      y[7] = j;
      r.push(y);
    });
  return r;
}
function pickF(k) {
  keep();
  const P = FP[k];
  if (!P) return;
  const cu = (P.L.find((x) => x[1] == S.v[k]) || [])[0];
  pick(
    P.l,
    P.L.map((x) => x[0]),
    cu,
    (val) => {
      const a = P.L.find((x) => x[0] == val);
      S.v[k] = a ? a[1] : '';
    },
  );
}
/* ===== النسخة الحالية: دخول + حساب + لوحة المكتب + تفاصيل الخدمات الموحدة ===== */
const waCS = () =>
  CFG.cs
    ? window.open(
        'https://wa.me/' + String(CFG.cs).replace(/\D/g, '') + '?text=' + encodeURIComponent('مرحباً خدمة عملاء سفرك أسهل، أحتاج مساعدة'),
        '_blank',
      )
    : toast('لم تضف الإدارة رقم واتساب خدمة العملاء بعد');
const vfm = (o) => (VF[o.svc] || []).map((x, i) => (x[0] == 't' ? ['t', 'x' + i, x[1], x[2]] : ['f', 'x' + i, x[1], x[2]]));
const FP = {};
const trust = () =>
  `<p class="tn">سفرك أسهل وسيط بينك وبين المكتب الذي تختاره. تُستخدم بيانات الطلب لتنفيذه لدى المكتب المعني وفق سياسة الخصوصية.</p>`;
