/* تفاصيل سيارة التأجير — الجزء 1/2
   يعرّف: carSpec، carRating، dpHead، dpContact، dpSl، carPics */
function carSpec(o) {
  const d = o && o.details && typeof o.details === 'object' ? o.details : {};
  return {
    key: '',
    name: (o && o.t) || '',
    y: Number(d.year || o.year) || null,
    s: Number(d.seats || o.se) || null,
    pr: Number(d.price ?? o.pr) || 0,
    old: Number(d.old ?? o.old) || 0,
    wk: Number(d.week) || 0,
    mo: Number(d.month) || 0,
    office: (o && o.n) || '',
    yrs: null,
    tr: d.transmission || '',
    dr: d.drive || '',
    sp: d.spec || '',
    fu: d.fuel || '',
    en: d.engine || '',
    pw: d.power || '',
    dep: Number(d.dep || o.dep) || 0,
    km: Number(d.km) || 0,
    kx: Number(d.kx) || 0,
    age: Number(d.minAge) || 0,
    cn: Number(d.insurance) || 0,
    tk: Number(d.tax) || 0,
    bg: d.baggage || '',
    rt: null,
    eq: Array.isArray(d.features) ? d.features : [],
  };
}
function carRating(o, s) {
  return { avg: '—', n: 0 };
}
function dpHead(back, name, sub, loc) {
  return `<div class="dpHead"><button class="dpBack" onclick="bk('${back}')" aria-label="رجوع">${DPI.back}</button><div class="dpTtl"><h1><span>${ht(name || '')}</span><i>${DPI.chk}</i></h1>${sub ? `<p>${ht(sub)}</p>` : ''}${loc ? `<p class="loc">${DPI.pin}${ht(loc)}</p>` : ''}</div></div>`;
}
function dpContact(wa) {
  return `<div class="dpCt"><button type="button" onclick="detailChat('app')">${DPI.chat}محادثة داخل التطبيق</button><button type="button" class="wa" onclick="detailChat('wa')">${wa ? DPI.wa : DPI.chat}تواصل عبر واتساب</button></div>`;
}
function dpSl(e) {
  const i = Math.round(Math.abs(e.scrollLeft) / Math.max(1, e.clientWidth));
  e.parentNode.querySelectorAll('.dpDots i').forEach((d, j) => d.classList.toggle('on', j == i));
}
function carPics(o, s) {
  const a = [IM['cr_' + s.id + '_0'] || IM[o.ph] || rp(o)],
    cap = ['أمامية', 'خلفية', 'داخلية', 'جانبية'];
  [1, 2, 3].forEach((i) => {
    const x = IM['cr_' + s.id + '_' + i];
    if (x) a.push(x);
  });
  return a.map(
    (src, i) =>
      `<div><img src="${src}" alt="" onclick="zoom(this.src)">${a.length > 1 ? `<span class="dpCap">${cap[i]}</span>` : ''}</div>`,
  );
}
function carDetail(o) {
  const s = carSpec(o),
    R = carRating(o, s),
    pics = carPics(o, s),
    $$ = (n) => curOf(o) + n,
    em = /V\d+/.exec(s.en) || /(\d+)\s*سلندر/.exec(s.en),
    eng = em ? (em[0][0] == 'V' ? em[0] : em[1] + ' سلندر') : s.en;
  const c = (l, v, x) => `<div><span>${l}</span> <b class="${x || ''}">${v}</b></div>`;
  return `<div class="dp">${dpHead('cars', s.office, '', officeLoc(o))}${ofBar()}
<div class="dpHero car"><div class="dpSl" onscroll="dpSl(this)">${pics.join('')}</div><span class="dpRate">تقييم العملاء ★ ${R.avg} (${R.n})</span><button class="dpRateBtn" type="button" onclick="openRateOffice()">قيّم بالنجوم</button>${pics.length > 1 ? `<div class="dpDots">${pics.map((_, i) => `<i class="${i ? '' : 'on'}"></i>`).join('')}</div>` : ''}</div>
${dpContact(1)}
<div class="dpTbl"><div class="dpH" style="margin-inline:4px">تفاصيل السيارة</div>
<div class="dpR">${c('نوع السيارة', ht(s.name))}${c('الموديل', s.y)}${c('الوقود', ht(s.fu))}</div>
<div class="dpR">${c('ناقل الحركة', ht(s.tr))}${c('نظام الدفع', ht(s.dr))}${c('المحرك', ht(eng))}</div>
<div class="dpR">${c('السعر اليومي', $$(s.pr) + ' <s>' + $$(s.old) + '</s>', 'or')}${c('السعر الأسبوعي', $$(s.wk), 'or')}${c('الضمان المالي', $$(s.dep), 'or')}</div>
<div class="dpR"><div><b>ضمان ذهب 10 جرام</b></div><div><b>احضار ضمان تجاري</b></div></div></div>
${dpTW(DPT.car)}
<div class="dpCta"><button type="button" onclick="if(!tripGoneGuard(S.o))go('book')">ابدأ الحجز الآن</button></div></div>`;
}
function pickupOf(o, C) {
  const p = String((C && C.pickup) || o.loc || o.pickup || o.startLocation || '').trim();
  return p || (o.from ? o.from + ' — مقر المكتب (يؤكد لك المكتب نقطة التجمع بعد الحجز)' : '');
}
const dep = (o) => (o && o.k == 'cars' ? carSpec(o).dep : 0);
