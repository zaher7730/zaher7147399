/* تفاصيل سيارة التأجير — الجزء 2/2
   يعرّف: CSPEC، CBODY، DPI، DPFINE، DPT، dpTW */
/* ===== بيانات السيارات (تستخدمها صفحة التفاصيل والحجز) ===== */
/* بيانات كل سيارة: يعدّلها المكتب لاحقاً. صور السيارة: window.SAFARAK_PHOTOS={cr_<id>_0:'رابط',cr_<id>_1:..,cr_<id>_2:'الخلف',cr_<id>_3:'الداخل'} */
const CSPEC = {},
  CSG = {};
const CBODY = (o) => {
  const t = (o.ty || '') + ' ' + (o.t || '');
  return /باص/.test(t) ? 'van' : /بيك/.test(t) ? 'pickup' : /سيدان/.test(t) ? 'sedan' : 'suv';
};
const DPI = {
  back: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>',
  chk: '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h16v11H9l-5 4z"/></svg>',
  wa: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21l1.6-4.7A8.5 8.5 0 1 1 8 19.5z"/><path d="M9 8.5c.4 3 3.5 6 6.5 6.5" /></svg>',
  pin: '<svg viewBox="0 0 24 24"><path d="M12 22s-7-6.2-7-12a7 7 0 1 1 14 0c0 5.8-7 12-7 12z"/><circle cx="12" cy="10" r="2.5"/></svg>',
  req: '<svg viewBox="0 0 24 24"><rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4h6v3H9zM9 12h6M9 16h4"/></svg>',
  no: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M6.5 6.5l11 11"/></svg>',
  shield: '<svg viewBox="0 0 24 24"><path d="M12 3l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10V6z"/><path d="M9 12l2.2 2.2L15.5 10"/></svg>',
  star: '<svg viewBox="0 0 24 24"><path d="M12 3l2.7 5.6 6.1.8-4.5 4.3 1.1 6.1L12 16.9l-5.4 2.9 1.1-6.1-4.5-4.3 6.1-.8z"/></svg>',
};
const DPFINE =
  'أسعار الخدمات قابلة للتغيير بناءً على التحديثات والتعليمات الصادرة من الجهات المختصة. المنصة وسيط بينك وبين المكتب، والمكتب هو الذي ينفذ طلبك ومعاملتك، والرسوم تُدفع إلى الحساب الخاص بالمكتب.';
const DPT = {
  car: {
    rq: ['هوية شخصية أو جواز سفر ساري', 'رخصة قيادة سارية المفعول', 'ضمانة تجارية'],
    wn: [
      'يمنع خروج خارج المحافظة دون علم المكتب',
      'يمنع نقل أي مواد ممنوعة أو غير قانونية بالمركبة',
      'أي مخالفة مرورية أو ضرر بالمركبة يُخصم من مبلغ الضمان.',
    ],
  },
  bus: {
    rq: ['جواز سفر ساري المفعول', 'الالتزام بموعد الرحلة والحضور قبل الانطلاق بنصف ساعة.'],
    wn: ['يمنع جلب أي أغراض غير أغراضك الشخصية.'],
  },
  local: { rq: ['صورة بطاقة شخصية أو جواز سفر', 'الحضور قبل موعد انطلاق الرحلة بنصف ساعة', 'الالتزام بموقع وموعد التجمع المحدد'], wn: [] },
  air: { rq: ['جواز سفر ساري المفعول', 'تأشيرة الوجهة إن كانت مطلوبة', 'أسماء المسافرين مطابقة للوثائق'], wn: [] },
};
const dpTW = (d) =>
  `<div class="dpTW ${d.wn && d.wn.length ? '' : 'one'}"><div><div class="ic2">${DPI.req}</div><h5>المتطلبات</h5>${d.rq.map((x) => `<p>${ht(x)}</p>`).join('')}</div>${d.wn && d.wn.length ? `<div class="w"><div class="ic2">${DPI.no}</div><h5>${d.wt || 'تحذير'}</h5>${d.wn.map((x) => `<p>${ht(x)}</p>`).join('')}</div>` : ''}</div>`;
const dpSup = () =>
  `<div class="dpSup"><span class="sh">${DPI.shield}</span><div><b>معك طوال الرحلة</b><small>للدعم أو الاستفسار، تواصل مع المكتب في أي وقت.</small></div></div>`;
