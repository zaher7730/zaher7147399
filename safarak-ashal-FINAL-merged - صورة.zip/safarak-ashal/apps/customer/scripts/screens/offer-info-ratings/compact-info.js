/* معلومات العرض والتقييم — الجزء 2/2
   يعرّف: compactInfo، ratingKey، ratingStats، getMyRating، openRateOffice، rateOffice */
function compactInfo(o) {
  const I = info(o),
    C = customMeta(o, I),
    st = I.st || [];
  return { I, C, st };
}
function ratingKey(o) {
  return 'office-' + String((o && (o.officeId || o.serverOfficeId)) || (o && o.n) || '');
}
/* إحصاءات التقييم: من الخادم (آراء منشورة فقط) */
function ratingStats(o) {
  const i = SA_officeIdx((o && (o.serverOfficeId || o.officeId)) || (o && o.n));
  if (i < 0) return { count: 0, avg: '—', dist: [0, 0, 0, 0, 0] };
  SA_loadOfficeReviews(OFFS[i].id);
  const m = (S.rvsum || {})[i];
  if (!m) return { count: 0, avg: '—', dist: [0, 0, 0, 0, 0] };
  return { count: m.count || 0, avg: m.avg == null ? '—' : Number(m.avg).toFixed(1), dist: m.dist || [0, 0, 0, 0, 0] };
}
function getMyRating(o) {
  const i = SA_officeIdx((o && (o.serverOfficeId || o.officeId)) || (o && o.n));
  const id = i >= 0 ? OFFS[i].id : null;
  const r = (S.myRv || []).find((x) => x.officeId == id);
  return r ? r.rating : 0;
}
function openRateOffice() {
  const o = S.o;
  if (!o) return;
  const current = getMyRating(o);
  const box = document.createElement('div');
  box.className = 'rateOverlay';
  box.innerHTML = `<div class="rateDialog"><button class="rateClose" aria-label="إغلاق">×</button><b>قيّم المكتب بالنجوم</b><p>اختر عدد النجوم فقط</p><div class="rateStars">${[1, 2, 3, 4, 5].map((n) => `<button type="button" class="${n <= current ? 'selected' : ''}" data-rate="${n}">★</button>`).join('')}</div></div>`;
  box.onclick = (e) => {
    if (e.target === box || e.target.closest('.rateClose')) box.remove();
    const b = e.target.closest('[data-rate]');
    if (b) {
      rateOffice(o.n, +b.dataset.rate);
      box.remove();
    }
  };
  document.body.append(box);
}
async function rateOffice(name, n) {
  const i = SA_officeIdx(name);
  if (i < 0) return toast('المكتب غير موجود');
  if (await SA_submitReview(OFFS[i].id, n, '')) render();
}
function detailChat(type) {
  const o = S.o || {};
  if (type === 'wa') {
    const num = String(o.officePhone || CFG.wa || CFG.cs || '').replace(/\D/g, '');
    if (!num) {
      toast('رقم واتساب المكتب غير متوفر حالياً');
      return;
    }
    const tn = ['bus', 'local', 'air'].includes(o.k) && o.key ? ' (رقم الرحلة ' + tripNo(o.key) + ')' : '';
    window.open(
      'https://wa.me/' +
        num +
        '?text=' +
        encodeURIComponent('مرحباً، أستفسر عن ' + (o.t || o.svc || 'الخدمة') + tn + ' لدى ' + (o.n || 'المكتب')),
      '_blank',
    );
    return;
  }
  S.hist.push(S.scr);
  if (['bus', 'local', 'air'].includes(o.k) && o.key) {
    S.pre = 'مرحباً، أستفسر عن الرحلة رقم ' + tripNo(o.key) + ' (' + (o.t || '') + ')';
    S.cur = S.ord.find((x) => x.o && x.o.n === o.n)?.id || o.n;
    go('chat');
    return;
  }
  S.cur = S.ord.find((x) => x.o && x.o.n === o.n)?.id || '';
  go('msgs');
}
function detail() {
  const o = S.o;
  if (o.k == 'cars') return carDetail(o);
  if (['bus', 'local', 'air'].includes(o.k)) return tripDetail(o);
  return svcDetail(o);
}
