/* قائمة المكاتب وصفحة المكتب — الجزء 1/2
   يعرّف: shuffleOffs، otab، setRs، addRv، rateGo، ini */
/* ترتيب المكاتب يتجدد مع كل دخول للصفحة (مثل تطبيقات التواصل): كل المكاتب تبقى، والمكاتب التي ظهرت أولاً آخر مرة تتأخر ليظهر غيرها */
function shuffleOffs() {
  const a = ofListed(),
    n = a.length;
  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  const top = new Set(S.ot4 || []);
  const o = a.filter((i) => !top.has(i)).concat(a.filter((i) => top.has(i)));
  S.ot4 = o.slice(0, 4);
  return o;
}
function otab(t) {
  S.ot = t;
  render();
}
function setRs(n) {
  S.rs = n;
  document.querySelectorAll('.rsr b').forEach((b, j) => (b.className = j < n ? 'on' : ''));
}
async function addRv(i) {
  const t = $('#rvt').value.trim();
  if (!t) return toast('اكتب رأيك أولاً');
  if (await SA_submitReview(OFFS[i].id, S.rs || 5, t)) {
    S.rs = 5;
    render();
  }
}
function rateGo() {
  S.ot = 'about';
  render();
  setTimeout(() => {
    const e = $('#rvbox');
    e && e.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 50);
}
const ini = (n) => n.replace('مكتب ', '')[0],
  tfo = (i) => {
    if (!S.u.in) return toast('سجّل الدخول لاستخدام المفضلة');
    const j = S.fo.indexOf(i);
    j < 0 ? S.fo.push(i) : S.fo.splice(j, 1);
    toast(j < 0 ? 'أُضيف للمفضلة' : 'أُزيل من المفضلة');
    render();
    SA_toggleOfficeFav(i, j < 0);
  };
const ofc = (o, i) =>
  `<div class="oc" onclick="S.oi=${i};S.ot='about';go('ofdet')"><div class="cv">${IM[o.im] ? `<img src="${IM[o.im]}" alt="${ht(o.n)}">` : '<div class="cvPh" aria-label="لا توجد صورة للمكتب">🏢</div>'}${o.r ? `<span class="rtg">⭐ ${OS(i).s}</span>` : ''}<button class="hb" onclick="event.stopPropagation();tfo(${i})">${S.fo.includes(i) ? '♥' : '♡'}</button><div class="tgs">${o.tg.map((t) => `<span>${{ air: 'الطيران', bus: 'النقل الدولي', local: 'رحلات محلية', cars: 'تأجير السيارات', pass: 'الجوازات', visa: 'التأشيرات', priv: 'رحلات خاصة' }[t] || t}</span>`).join('')}</div></div><div class="ob"><b><span class="av3">${ini(o.n)}</span>${o.n}</b><small>${[o.c, o.y ? o.y + ' سنة خبرة' : ''].filter(Boolean).join(' · ')}</small>${o.b ? `<span class="tg tr2">${o.b}</span>` : ''}</div></div>`;
const pcity = () =>
  pick('المدينة', ['الكل', ...new Set(ofListed().map((i) => OFFS[i].c))], S.oc || 'الكل', (v) => {
    S.oc = v == 'الكل' ? '' : v;
  });
const offices = () => {
  if (!S.oo || S.oo.length != ofListed().length) S.oo = shuffleOffs();
  const q = S.q || '',
    c = S.oc || '',
    s = S.os || '',
    L = S.oo.map((i) => [OFFS[i], i]).filter(([o]) => (!c || o.c == c) && (!q || o.n.includes(q) || o.tg.some((t) => t.includes(q))));
  return `<div class="kk">سوق مكاتب السفر</div><h1 class="h1">مكاتب السفر</h1><p class="sub">${ofCountLine(S.oo.length)}</p><div class="srch"><span>🔎</span><input placeholder="ابحث عن مكتب أو خدمة" value="${ht(q)}" oninput="S.q=this.value;render();const i=$('input');i.focus();i.setSelectionRange(99,99)"></div><div style="max-width:200px;margin-bottom:12px">${sel('من', c, 'اختر المدينة', 'pcity()', 1)}</div><div class="og">${L.map(([o, i]) => ofc(o, i)).join('') || '<div class="empty" style="grid-column:1/-1"><b>🏢</b>لا توجد مكاتب مطابقة</div>'}</div>`;
};
const stars = (n) => '★'.repeat(n) + '☆'.repeat(5 - n);
