/* قائمة المكاتب وصفحة المكتب — الجزء 2/2
   يعرّف: ofdet */
const ofdet = () => {
  const i = S.oi,
    o = OFFS[i],
    T = S.ot || 'about',
    mine = (SA_loadOfficeReviews(o.id), S.rv[i] || []),
    rv = mine.map((x) => [x.n, x.s, x.t, fmt(x.ts)]),
    fv = S.fo.includes(i),
    offs = o.tg.filter((t) => OWN[i] && OWN[i][t] && OWN[i][t].length),
    ph = [o.im].filter((k) => IM[k]);
  let body = '';
  if (T == 'about')
    body = `<div class="sec"><h4>بيانات المكتب</h4><p class="pp" style="line-height:1.9">${o.n} — بيانات المكتب والخدمات المنشورة كما سجلها المكتب في المنصة. لا تظهر أرقام توثيق أو تقييمات إلا بعد ربطها بمصدر موثوق.</p></div><div class="sec"><h4>خدمات المكتب</h4><div class="svg2">${osv(
      i,
    )
      .map((k) => `<div onclick="oSvc(${i},'${k}')"><i>${SVI[k][1]}</i>${svcTitle(i, k)}</div>`)
      .join(
        '',
      )}</div></div><div class="sec" id="rvbox"><h4>آراء وتقييم العملاء</h4><div class="rsr">${[1, 2, 3, 4, 5].map((n) => `<b class="${n <= (S.rs || 5) ? 'on' : ''}" onclick="setRs(${n})">★</b>`).join('')}</div><textarea id="rvt" class="f" rows="2" placeholder="اكتب رأيك في المكتب..." style="width:100%;margin:8px 0"></textarea><button class="gb w" onclick="addRv(${i})">إرسال التقييم</button></div>${rv.map((x) => `<div class="rvc"><div><b>${x[0]}</b><span class="rs">${stars(x[1])}</span></div><p>${x[2]}</p><small>${x[3]}</small></div>`).join('')}`;
  else if (T == 'offers')
    body = offs.length
      ? offs
          .map((t) => {
            const rows = (OWN[i][t] || []).map((j) => BASE[t][j]),
              label = SVI[t]?.[0] || t,
              first = rows[0] || [],
              details = first.details && typeof first.details === 'object' ? first.details : {},
              price =
                details.price ??
                (t === 'air' || t === 'bus' || t === 'priv'
                  ? first[7]
                  : t === 'local'
                    ? first[6]
                    : t === 'cars'
                      ? first[7]
                      : t === 'pass'
                        ? first[3]
                        : first[2]),
              old =
                details.old ??
                (t === 'air' || t === 'bus' || t === 'priv'
                  ? first[8]
                  : t === 'local'
                    ? first[7]
                    : t === 'cars'
                      ? first[8]
                      : t === 'pass'
                        ? first[4]
                        : first[3]),
              currency = details.currency || CFG.cur || 'YER';
            return `<div class="ofr"><div class="ofh"><span class="oi">${SVI[t]?.[1] || '🧳'}</span><div><b>${ht(label)}</b><small>${rows.length} عرض منشور من المكتب</small></div><div class="opr">${price !== undefined && price !== null && price !== '' ? `<b>${currency}${price}</b>` : '<b>السعر حسب تفاصيل العرض</b>'}${old ? `<small>السعر السابق ${currency}${old}</small>` : ''}</div></div><div class="ofb"><button class="gb" onclick="oSvc(${i},'${t}')">عرض العروض</button></div></div>`;
          })
          .join('')
      : '<div class="empty"><b>🏷</b>لا توجد عروض منشورة حالياً</div>';
  else
    body = `<div class="sec"><h4>صور المكتب</h4><p class="hint" style="text-align:right;margin:0 0 8px">الصور يرفعها المكتب نفسه</p><div class="gal">${ph.map((k) => `<img src="${IM[k]}" onclick="zoom(this.src)">`).join('')}</div></div>`;
  return (
    back('ملف المكتب', 'offices') +
    `<div class="ocv">${IM[o.im] ? `<img src="${IM[o.im]}" alt="${ht(o.n)}">` : '<div class="cvPh" style="height:100%" aria-label="لا توجد صورة للمكتب">🏢</div>'}${OS(i).s !== '—' ? `<span class="star">⭐ ${OS(i).s}</span>` : ''}<button class="hb" onclick="tfo(${i})">${fv ? '♥' : '♡'}</button></div><div class="oid"><span class="lg">${ini(o.n)}</span><div><h2>${o.n}</h2><small>${[o.c, o.y ? o.y + ' سنة خبرة' : '', OS(i).s !== '—' ? '⭐ ' + OS(i).s : '', OS(i).n !== '—' ? OS(i).n + ' تقييم' : ''].filter(Boolean).join(' · ')}</small><span class="tg tr2">${o.b}</span></div></div><div class="acts"><button onclick="callO()"><i>📞</i>اتصال</button><button onclick="oco(${i})"><i>💬</i>مراسلة</button><button onclick="rateGo()"><i>⭐</i>تقييم</button><button onclick="tfo(${i})"><i>${fv ? '♥' : '♡'}</i>مفضلة</button><button onclick="SA_shareOffice(${i})"><i>↗</i>مشاركة</button></div><div class="loc" onclick="window.open('https://www.google.com/maps/search/'+encodeURIComponent('${o.n} ${o.c}'),'_blank')"><span>🗺</span><div><b>موقع المكتب في الخريطة</b><small>اضغط لعرض الموقع على الخريطة</small></div><em>‹</em></div><div class="os3"><div><b>${o.y || '—'}</b>سنوات خبرة</div><div><b>${OS(i).dn || 0}</b>طلبات مكتملة</div><div><b>${OS(i).n === '—' ? '—' : OS(i).n}</b>تقييم</div></div><p class="hint">الطلبات المكتملة والتقييمات والآراء يحتسبها نظام سفرك أسهل تلقائياً</p><div class="otb">${[
      ['about', 'نبذة'],
      ['offers', 'العروض (' + offs.length + ')'],
      ['photos', 'الصور'],
    ]
      .map((t) => `<div class="${T == t[0] ? 'on' : ''}" onclick="otab('${t[0]}')">${t[1]}</div>`)
      .join('')}</div>${body}`
  );
};
