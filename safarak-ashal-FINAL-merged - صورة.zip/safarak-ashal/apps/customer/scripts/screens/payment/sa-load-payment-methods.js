/* صفحة الدفع — الجزء 1/2
   يعرّف: SA_loadPaymentMethods، pmBank، pmTog، pmSet، pay، BANKS */
async function SA_loadPaymentMethods(officeId) {
  if (!window.SA_API) return;
  try {
    const r = await window.SA_API.paymentMethods(officeId);
    const methods = r.methods || [];
    BANKS.splice(
      0,
      BANKS.length,
      ...methods.filter((m) => m.type === 'بنك').map((m) => [m.name, m.account_no, m.holder || '', m.currency || 'YER', m.id]),
    );
    PMS.splice(
      0,
      PMS.length,
      ...methods.filter((m) => m.type !== 'بنك').map((m) => [m.name, m.account_no, m.type, m.currency || 'YER', m.id]),
    );
    if (S.scr === 'pay') render();
  } catch (e) {
    console.warn('تعذر تحميل وسائل الدفع:', e.message);
  }
}
function pmBank(i) {
  const m = BANKS[i];
  if (!m) return;
  S.pm = m[0];
  S.pmId = m[4];
  S.pmo = 0;
  render();
}
function pmTog() {
  keep();
  S.pmo = !S.pmo;
  render();
}
function pmSet(i) {
  keep();
  S.pm = S.pm == PMS[i][0] ? '' : PMS[i][0];
  S.pmId = S.pm ? PMS[i][4] || null : null;
  S.pmo = 0;
  render();
}
function pay() {
  if (!SA_online.loaded) SA_loadOnline();
  const o = S.o,
    c = o.cur || o.details?.currency || CFG.cur || 'YER',
    k = o.k,
    cars = k == 'cars',
    days = +S.v.a || 1,
    dp = dep(o),
    day = tp(o, S.tier || 0);
  const pm = PMS.find((x) => x[0] == S.pm) || BANKS.find((x) => x[0] == S.pm);
  return `<div class="cmp"><div class="tt"><button class="bk" onclick="keep();bk('book')">‹</button><h1>الدفع</h1></div>
${payOpts()}<div ${S.pt && S.pt != 'm' ? 'style="display:none"' : ''}>${BANKS.length ? `<div class="sec"><h4>حسابات التحويل</h4>${BANKS.map((b, i) => `<div class="bnk"><b>${b[0]}</b><span class="cd">${b[1]}</span><button class="gb" onclick="cpy('${b[1]}')">نسخ</button><button class="gb" onclick="pmBank(${i})">اختيار</button></div>`).join('')}` : PMS.length ? `<div class="sec"><h4>وسائل الدفع</h4><p class="pp">اختر المحفظة أو وسيلة الدفع التي أضافها المكتب من قائمة وسائل الدفع أدناه.</p></div>` : `<div class="sec"><h4>الدفع</h4><p class="pp">لم يضف المكتب بيانات دفع بعد. يمكنك إرسال طلبك الآن، وسيظهر للمكتب ليتواصل معك لتأكيد السعر وطريقة الدفع.</p></div>`}
<button class="sel ${S.pm ? 'set' : ''}" style="padding:8px 12px;font-size:13px;box-shadow:none" onclick="pmTog()"><span>${S.pmo ? '▴' : '▾'}</span><span style="flex:1;padding:0 8px">${S.pm || 'وسائل دفع أخرى'}</span></button>
${S.pmo ? `<div class="dd">${PMS.map((x, i) => `<div class="${x[0] == S.pm ? 'on' : ''}" onclick="pmSet(${i})"><span>${x[0]}</span>${x[0] == S.pm ? '✓' : ''}</div>`).join('')}</div>` : ''}
${pm ? `<div class="bnk" style="margin-top:6px"><b>${pm[0]}</b><span class="cd">${pm[1]}</span><button class="gb" onclick="cpy('${pm[1]}')">نسخ</button></div>` : ''}</div>
${S.pt == 'e' ? '' : `<div class="pill">إرفاق سند التحويل</div><div class="g2">${fld(['f', 'rc', 'صورة الحوالة', 1])}${fld(['t', 'tn', 'اسم المرسل أو رقم حسابه', 1])}${fld(['t', 'tr', 'رقم الحوالة', 1])}</div>`}</div>${soon()}
<div class="stk"><div class="tot"><span>${c}${total()}</span><span>${cars ? 'المطلوب دفعه (إيجار + ضمان)' : 'السعر الإجمالي'}</span></div><button class="gb w" onclick="send()">${ic('y_send')} ${S.pt == 'e' ? 'إرسال الطلب والانتقال للدفع' : 'إرسال الطلب للمكتب'}</button></div></div>`;
}
const BANKS = [],
  PMS = [];
const cpy = (n) => {
  navigator.clipboard && navigator.clipboard.writeText(n);
  toast('تم نسخ الرقم');
};
