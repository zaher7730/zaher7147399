/* صفحة الدفع — الجزء 2/2
   يعرّف: PT */
const PT = [
    ['m', '<span style="font-size:22px">🏦</span>', 'دفع يدوي (تحويل)'],
    [
      'e',
      '<span style="display:inline-flex;align-items:center;gap:6px"><svg width="38" height="24" viewBox="0 0 38 24"><circle cx="14" cy="12" r="10" fill="#eb001b"/><circle cx="24" cy="12" r="10" fill="#f79e1b" fill-opacity=".9"/></svg><svg width="48" height="24" viewBox="0 0 48 24"><text x="24" y="19" text-anchor="middle" font-family="Arial" font-weight="900" font-style="italic" font-size="19" fill="#0f2a6b">VISA</text></svg></span>',
      'دفع إلكتروني بالبطاقة',
    ],
  ],
  /* خيارات الدفع لا تظهر إلا عند تفعيل الدفع الإلكتروني في الخادم؛ بدونه يبقى الدفع اليدوي وحده */
  payOpts = () =>
    SA_online.on
      ? `<div class="pill" style="margin:0 auto 6px">خيارات الدفع</div><div class="pto">${PT.map((x) => `<button class="${(S.pt || 'm') == x[0] ? 'on' : ''}" onclick="payT('${x[0]}')">${x[1]}<span>${x[2]}</span></button>`).join('')}</div>`
      : '',
  soon = () =>
    S.pt == 'e'
      ? `<div class="sec" style="text-align:center;padding:16px"><div style="font-size:34px">💳</div><b>الدفع بالبطاقة</b><p class="pp" style="margin-top:6px">بعد إرسال الطلب تنتقل إلى صفحة دفع آمنة لإتمام الدفع، ويصل تأكيد الدفع تلقائياً.</p></div>`
      : '';
