/* الدفع الإلكتروني: يظهر زره وخياره فقط عندما يكون مزوّد الدفع مفعّلاً في الخادم
   يعرّف: SA_online، SA_loadOnline، SA_startCheckout، onlinePayBox */
const SA_online = { on: false, loaded: 0, busy: 0 };
async function SA_loadOnline() {
  if (!window.SA_API || SA_online.busy) return;
  SA_online.busy = 1;
  try {
    SA_online.on = !!(await window.SA_API.paymentsConfig()).online;
  } catch (e) {
    SA_online.on = false;
  }
  SA_online.loaded = 1;
  SA_online.busy = 0;
  if (!SA_online.on && S.pt === 'e') S.pt = 'm';
  if (['done', 'odetail', 'pay'].includes(S.scr)) SA_rerender();
}
/* ينشئ عملية دفع على الخادم ثم ينقل العميل إلى صفحة الدفع الآمنة */
async function SA_startCheckout(bookingId) {
  if (!window.SA_API || !SA_online.on) return toast('الدفع الإلكتروني غير متاح حالياً');
  if (SA_online.working) return;
  SA_online.working = 1;
  try {
    const r = await window.SA_API.checkout(bookingId);
    if (!r.checkoutUrl) throw new Error('تعذّر الحصول على صفحة الدفع');
    location.href = r.checkoutUrl;
  } catch (e) {
    toast((e.message || 'تعذّر بدء الدفع الإلكتروني') + '؛ يمكنك الدفع بالتحويل أو مراسلة المكتب');
  } finally {
    SA_online.working = 0;
  }
}
/* زر الدفع الإلكتروني لطلب لم يُدفع بعد */
const onlinePayBox = (x) =>
  SA_online.on && x && x.paymentStatus === 'pending' && !x.pendingPayment && !['cancelled', 'rejected', 'completed'].includes(x.serverStatus)
    ? `<div class="sec"><h4>الدفع الإلكتروني</h4><p class="pp">ادفع قيمة الطلب بالبطاقة عبر صفحة دفع آمنة، ويتأكد دفعك تلقائياً.</p><button class="gb w" onclick="SA_startCheckout('${ht(x.id)}')">💳 ادفع الآن إلكترونياً</button></div>`
    : '';
