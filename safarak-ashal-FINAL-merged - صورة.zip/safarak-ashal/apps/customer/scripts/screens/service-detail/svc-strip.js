/* تفاصيل الخدمة — الجزء 1/2
   يعرّف: svcStrip، svcDetail، SVX */
function svcStrip(c, def) {
  const a = String(c.strip || '')
    .split('\n')
    .map((x) => x.trim())
    .filter(Boolean)
    .map((x) => {
      const i = x.search(/[:：]/);
      return i < 0 ? [x, '—'] : [x.slice(0, i).trim(), x.slice(i + 1).trim() || '—'];
    });
  return a.length ? a.slice(0, 4) : def;
}
function svcDetail(o) {
  const k = o.k,
    { I } = compactInfo(o),
    c = o.custom || {},
    cur = curOf(o),
    pr = tp(o, o.tier || 0) || o.pr,
    rs = ratingStats(o),
    tier = Math.max(0, Math.min(2, +o.tier || 0)),
    X = SVX[o.svc] || {};
  const num = !!pr && !isNaN(+pr),
    priceTxt = num ? cur + pr + (+o.old > 0 ? ' <s>' + cur + o.old + '</s>' : '') : ht(pr || 'حسب الباقة');
  const title = c.title || (o.svc || o.t || '') + (tier == 2 ? ' VIP' : ''),
    src = rp(o);
  const loc = officeLoc(o);
  const def =
    X.st ||
    (k == 'pass'
      ? [
          ['مدة التنفيذ', c.schedule || o.dur || '—'],
          ['الاستلام', 'حسب الاختيار'],
        ]
      : [['مدة التنفيذ', c.schedule || 'خلال 14 يوم']]);
  const cells = svcStrip(c, def),
    rq = customList(c, 'req', X.rq || I.req || []),
    ft = customList(c, 'features', X.ft || (k == 'pass' ? ['توصيل مجاني'] : ['مواصلات مجانية'])),
    wn = customList(c, 'warn', X.wn || []);
  return `<div class="dp svcp">${dpHead(k, o.n, '', loc)}${ofBar()}
<div class="dpHero svc"><img src="${src}" alt="" onerror="fb(this,'${SERVICE_IMG[k] || 'p_bus1'}')"><span class="dpRate">تقييم العملاء (${rs.count}) ★</span><button class="dpRateBtn" type="button" onclick="openRateOffice()">★ قيّم بالنجوم</button></div>
${dpContact(0)}
<div class="dpRoute">${DPI.shield}<span>${ht(title)}</span></div>
<div class="dpInfo wr one" style="grid-template-columns:1.25fr repeat(${cells.length},1fr)"><div class="pr"><small>السعر للشخص</small><b>${priceTxt}</b></div>${cells.map((x) => `<div><small>${ht(x[0])}</small><b>${ht(x[1])}</b></div>`).join('')}</div>
${dpSX(rq, ft, k == 'pass' ? 'مميزات الخدمة' : 'مميزات الرحلة', wn)}
<div class="dpFine">${DPFINE}</div>
<div class="dpCta"><button type="button" onclick="if(!tripGoneGuard(S.o))go('${o.xs ? 'xreq' : 'book'}')">${o.xs ? 'ابدأ الطلب الآن' : 'ابدأ الحجز الآن'}</button></div></div>`;
}
/* صفحة الخدمات (الجوازات والتأشيرات): نسخة واحدة، شكل المرجع، كل أجزائها قابلة للتعديل من المكتب */
const SVX = {
  'استخراج جواز جديد': { rq: ['صورتين شخصية خلفية بيضاء 6×4', 'شهادة ميلاد'] },
  عمرة: {
    rq: ['جواز سفر ساري المفعول', 'صورتين شخصية خلفية بيضاء 6×4', 'صورة بيانات التأشيرة الصادرة من المملكة'],
    ft: ['إقامة فندقية بجوار الحرم لمدة 20 يوم', 'مواصلات مجانية داخل الحرم', 'وجبات الطعام مجانية'],
  },
  'زيارة عائلية': {
    rq: ['جواز سفر ساري المفعول', 'صورتين شخصية خلفية بيضاء 6×4', 'صورة بيانات التأشيرة الصادرة من المملكة'],
    wn: ['يلزم إذن سفر للشخص الذي عمره تحت 18', 'اثبات عزوبية للنساء أو إذا كانت متزوجة إذن سفر'],
  },
};
Object.assign(SVX, {
  'برنت بصمة': {
    rq: ['رقم الجواز', 'ملاحظة توضح حالتك مثل: كنت في السعودية وحصل لي حادث قبل سنوات'],
    ft: [],
    st: [
      ['طريقة الطلب', 'عبر التطبيق'],
      ['الرد', 'في الرسائل'],
    ],
  },
  'الموافقات الأمنية': {
    rq: ['الاسم الكامل', 'رقم الجواز', 'ملاحظة أو سؤال إن وجد'],
    ft: [],
    st: [
      ['طريقة الطلب', 'عبر التطبيق'],
      ['الرد', 'في الرسائل'],
    ],
  },
});
