/* تفاصيل الخدمة — الجزء 2/2
   يعرّف: VISA_PHOTO_REQ، dpSX */
// متطلب التأشيرات الموحد حسب طلب التصميم: صورتان شخصيتان بخلفية بيضاء مقاس 4×6 فقط
const VISA_PHOTO_REQ = ['صورتان شخصيتان بخلفية بيضاء مقاس 4×6'];
[
  'حج',
  'عمرة',
  'زيارة عائلية',
  'زيارة عمل',
  'إقامة',
  'تأشيرة دراسية (طالبية)',
  'تأشيرة علاجية',
  'تأشيرة سياحية',
  'تأشيرة تجارية',
  'زيارة تجارية',
  'سياحية فاخرة',
  'سياحية متوسطة',
].forEach((n) => {
  SVX[n] = Object.assign({}, SVX[n] || {}, { rq: VISA_PHOTO_REQ.slice() });
});
const dpSX = (rq, ft, ftt, wn) => {
  const left =
    (ft.length
      ? `<div class="g"><div class="ic2">${DPI.star}</div><h5>${ht(ftt)}</h5>${ft.map((x) => `<p>${ht(x)}</p>`).join('')}</div>`
      : '') +
    (wn.length ? `<div class="w"><div class="ic2">${DPI.no}</div><h5>تنويه</h5>${wn.map((x) => `<p>${ht(x)}</p>`).join('')}</div>` : '');
  return `<div class="dpTW sx ${left ? '' : 'one'}"><div><div class="ic2">${DPI.req}</div><h5>المتطلبات</h5>${rq.map((x) => `<p>${ht(x)}</p>`).join('')}</div>${left ? `<div class="lc">${left}</div>` : ''}</div>`;
};
