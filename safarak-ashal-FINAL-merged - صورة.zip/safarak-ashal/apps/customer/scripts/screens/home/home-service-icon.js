/* الصفحة الرئيسية — الجزء 1/2
   يعرّف: homeServiceIcon */
function homeServiceIcon(k) {
  const paths = {
    cars: '<path d="M4 13l1.5-5A2 2 0 0 1 7.4 6.5h9.2A2 2 0 0 1 18.5 8l1.5 5v5h-3v-2H7v2H4z"/><path d="M7 10h10M7 13h.01M17 13h.01" stroke="#fff" stroke-width="1.7" fill="none" stroke-linecap="round"/>',
    priv: '<path d="M3 15l2-5 5-2 3-4 3 1-1 4 4 2 2 4-6 1-3-2-4 2z"/><circle cx="8" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
    local: '<path d="M4 6h16v12H4z"/><path d="M7 6V4h10v2M7 10h10M7 14h3m3 0h4" stroke="#fff" stroke-width="1.6" fill="none"/>',
    visa: '<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v5h4M9 12h7M9 16h7" stroke="#fff" stroke-width="1.6" fill="none"/>',
    air: '<path d="M3 13l7-2 3-7 2 1-1 7 6 3-1 2-7-2-4 4-2-1 2-5-5-1z"/>',
    bus: '<path d="M5 4h14a2 2 0 0 1 2 2v12H3V6a2 2 0 0 1 2-2z"/><path d="M5 8h14M6 11h4v4H6zm8 0h4v4h-4zM7 18v2m10-2v2" stroke="#fff" stroke-width="1.5" fill="none"/>',
    send: '<path d="M3 11l18-8-6 18-3-7z"/><path d="M12 14L21 3" stroke="#fff" stroke-width="1.5" fill="none"/>',
    pass: '<path d="M6 3h12v18H6z"/><circle cx="12" cy="9" r="2.5" fill="#fff"/><path d="M8 16h8" stroke="#fff" stroke-width="1.5"/>',
  };
  const fill =
    k === 'visa'
      ? '#d6a32c'
      : k === 'air'
        ? '#1d5ca8'
        : k === 'bus'
          ? '#168a8a'
          : k === 'cars'
            ? '#bd8a1c'
            : k === 'send'
              ? '#2b7cbd'
              : k === 'pass'
                ? '#2e5d9e'
                : k === 'local'
                  ? '#31836f'
                  : '#7855b7';
  return `<svg class="hmServiceSvg" viewBox="0 0 24 24" role="img" aria-label="خدمة"><circle cx="12" cy="12" r="11" fill="${fill}"/><g fill="#fff" stroke="#fff" stroke-width=".7" stroke-linejoin="round">${paths[k] || paths.bus}</g></svg>`;
}
