/* الصفحة الرئيسية — الجزء 2/2
   يعرّف: home */
function home() {
  const T = [
      ['cars', 'hm_cars', 'تأجير السيارات'],
      ['priv', 'hm_priv', 'رحلات خاصة'],
      ['local', 'hm_local', 'رحلات محلية'],
      ['visa', 'hm_visa', 'التأشيرات'],
      ['air', 'hm_air', 'الطيران'],
      ['bus', 'hm_bus', 'النقل الدولي'],
      null,
      ['send', 'hm_send', 'إرسال جوازك للمكتب'],
      ['pass', 'hm_pass', 'الجواز اليمني'],
    ],
    nm = (S.u.name || '').trim(),
    first = nm.split(/\s+/)[0] || 'ضيفنا',
    ini = nm ? nm[0].toUpperCase() : 'A';
  S.ord.forEach((x) => S.cv[x.id] || mkc(x.id));
  const GO = '<span class="hmGo"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg></span>';
  return `<div class="hm"><div class="hmTop"><div class="hmAv" onclick="go('acct')"><svg viewBox="0 0 22 16"><path d="M1 5l4.2 4L8 2l3 6 3-6 2.8 7L21 5l-2 9.5H3z" fill="#e3ae46"/></svg><b>${ini}</b><i></i></div><div class="hmHi" onclick="go('acct')"><b>مرحباً ${first}</b><small>نحن نسهلك خدمات سفرك</small></div><img class="hmLogo" src="${IM.hm_logo}" alt="سفرك أسهل"><button class="hmBell" onclick="go('notif')" aria-label="الإشعارات"><svg viewBox="0 0 24 24"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>${S.u.nt === 0 ? '' : '<i></i>'}</button></div>
<div class="hmSrch"><svg viewBox="0 0 24 24" onclick="hs(this.parentNode.querySelector('input').value)"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg><input placeholder="ابحث عن خدمة أو مكتب أو وجهة..." onkeydown="if(event.key=='Enter')hs(this.value)"></div>
<div class="hmBan">${ADS.map((a, i) => (a.i ? `<div class="hmSl ${i == S.ad ? 'on' : ''}" onclick="go('bus')"><img src="${IM.ban}" alt=""></div>` : `<div class="hmSl c ${i == S.ad ? 'on' : ''}"><img class="pi" src="${a.src || IM[a.im]}" alt=""><h2 style="max-width:58%">${SA_escHtml(a.h)}</h2><p>${SA_escHtml(a.p)}</p>${a.t ? `<button class="gb" onclick="go('${a.t}')">احجز الآن</button>` : ''}</div>`)).join('')}<div class="hmDots">${ADS.map((_, i) => `<i class="${i == S.ad ? 'on' : ''}"></i>`).join('')}</div></div>
<div class="hmNote" onclick="go('verified')">جميع خدمات السفر من مكاتب مسجلة نوفر عنائك وبحثك ونضمن حقوقك وعدم تسريب بياناتك</div>
<div class="hmGrid">${T.filter((x) => !x || !SA_svHidden(x[0])).map((x) => (x ? `<div class="hmCard ${x[0] == 'send' ? 'wrap' : ''}" onclick="go('${x[0]}')"><div class="hmPh"><img src="${SA_svImage(x[0]) || IM[x[1]]}" alt="${x[2]}" loading="eager"></div><div class="hmCap"><b>${x[2]}</b>${GO}</div></div>` : '<div></div>')).join('')}</div></div>`;
}
