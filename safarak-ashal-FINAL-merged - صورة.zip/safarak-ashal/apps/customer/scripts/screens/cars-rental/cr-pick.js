/* صفحة تأجير السيارات — الجزء 1/2
   يعرّف: crPick، carsPage */
function crPick(k) {
  const F = S.F[CX.sk] || (S.F[CX.sk] = {});
  const ix = { c: 1, b: 2, t: 4, m: 3 },
    vals = k === 'a' ? ['المتاحة فقط'] : [...new Set(CARS.map((c) => String(c[ix[k]] || '')).filter(Boolean))];
  if (!vals.length) return toast('لا توجد سيارات منشورة لتصفية النتائج');
  pick(CRTTL[k], ['الكل', ...vals], F[k] || 'الكل', (v) => {
    F[k] = v == 'الكل' ? '' : v;
  });
}
function carsPage(sk, rows, nm) {
  CX = { sk: sk || 'cars', rows: rows || CARS, nm: nm || '', off: nm ? 1 : 0 };
  OFF = [];
  const F = S.F[CX.sk] || {};
  const list = CARS.filter((c) => !F.c || String(c[1] || '') === F.c)
    .filter((c) => !F.b || String(c[2] || '') === F.b)
    .filter((c) => !F.t || String(c[4] || c[3] || '') === F.t)
    .filter((c) => !F.m || String(c[3] || '') === String(F.m))
    .filter((c) => !F.a || !c.reserved);

  const I = {
    pin: '<svg viewBox="0 0 24 24"><path d="M12 22s-7.5-6.4-7.5-12a7.5 7.5 0 0 1 15 0c0 5.6-7.5 12-7.5 12z"/><circle cx="12" cy="10" r="2.8" fill="#fff"/></svg>',
    car: '<svg viewBox="0 0 24 24"><path d="M5.2 10.5l1.5-4A2.2 2.2 0 0 1 8.8 5h6.4a2.2 2.2 0 0 1 2.1 1.5l1.5 4h.2A1.5 1.5 0 0 1 20.5 12v5a1 1 0 0 1-1 1H19v1.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5V18H8v1.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5V18h-.5a1 1 0 0 1-1-1v-5A1.5 1.5 0 0 1 5 10.5z"/><path d="M8 7.2h8l1 3H7z" fill="#fff"/><circle cx="7.5" cy="14.3" r="1.3" fill="#fff"/><circle cx="16.5" cy="14.3" r="1.3" fill="#fff"/></svg>',
    cal: '<svg viewBox="0 0 24 24"><path d="M4 8.5h16v10.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 19z"/><path d="M4 8.5V6.5A1.5 1.5 0 0 1 5.5 5h13A1.5 1.5 0 0 1 20 6.5v2M8 3v4M16 3v4M8 12.5h.01M12 12.5h.01M16 12.5h.01M8 16.5h.01M12 16.5h.01M16 16.5h.01"/></svg>',
    cplus: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7.5v9M7.5 12h9"/></svg>',
    seat: '<svg class="fl" viewBox="0 0 24 24"><path d="M8.5 2.5a2.4 2.4 0 0 1 2.3 1.8l1.5 6.4h4a2.5 2.5 0 0 1 2.4 1.9l.8 3.4a1.5 1.5 0 0 1-1.5 1.9H9.4a3 3 0 0 1-2.9-2.2L4.6 7A3.3 3.3 0 0 1 7.8 2.6z"/><rect x="8.5" y="19.2" width="9" height="2" rx="1"/></svg>',
    cal2: '<svg viewBox="0 0 24 24"><path d="M3 9.5h18v9.5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM3 9.5V7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2.5M8 3v4M16 3v4" stroke="#16397f" stroke-width="2" fill="none" stroke-linecap="round"/><path d="M7.5 13.5h2v2h-2zM11 13.5h2v2h-2zM14.5 13.5h2v2h-2zM7.5 17h2v1.5h-2zM11 17h2v1.5h-2z" fill="#16397f" stroke="none"/></svg>',
    chev: '<svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg>',
    back: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>',
    left: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>',
    chk: '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    menu: '<svg viewBox="0 0 24 24"><path d="M5 7h14M5 12h14M5 17h14"/></svg>',
    srch: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg>',
    tag: '<svg class="tgi" viewBox="0 0 24 24"><path d="M3 12.2V4.5A1.5 1.5 0 0 1 4.5 3h7.7a1.5 1.5 0 0 1 1 .44l8 8a1.5 1.5 0 0 1 0 2.1l-7.7 7.7a1.5 1.5 0 0 1-2.1 0l-8-8a1.5 1.5 0 0 1-.4-1.04z"/><circle cx="8" cy="8" r="1.8" fill="#fff"/></svg>',
    toy: '<svg viewBox="0 0 48 32"><g fill="none" stroke="#fff" stroke-width="2.7"><ellipse cx="24" cy="16" rx="21" ry="13"/><ellipse cx="24" cy="17.5" rx="7.2" ry="10.5"/><ellipse cx="24" cy="10.5" rx="13.5" ry="4.6"/></g></svg>',
    ok: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#fff"/><path d="M7 12.5l3.3 3.3L17 9" stroke="#12964a" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    no: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#fff"/><path d="M12 6.5v11M6.5 12h11" stroke="#d71f35" stroke-width="3" fill="none" stroke-linecap="round"/></svg>',
  };
  const val = (k) => F[k];
  const field = (k, label, ph, icon, fn) =>
    `<button class="crField field-${k}" onclick="${fn}"><b><span>${label}</span>${icon}</b><small class="${val(k) ? 'set' : ''}"><span>${val(k) || ph}</span>${I.chev}</small></button>`;
  const cards =
    list
      .map((c) => {
        const d = c.details || {},
          imageKey = c.imageKey || 'p_car1';
        const o = {
          k: 'cars',
          tier: Number(c[9] || 0),
          n: String(c[0] || ''),
          t: [c[2], c[3]].filter(Boolean).join(' '),
          pr: Number(c[7] || 0),
          per: 'في اليوم',
          ty: String(c[4] || ''),
          se: c[6],
          model: String(c[3] || ''),
          year: String(c[5] || ''),
          city: String(c[1] || ''),
          ph: imageKey,
          dep: Number(c[8] || 0),
          serviceId: c.serviceId,
          serverOfficeId: c.serverOfficeId,
          details: d,
          cur: d.currency || CFG.cur || 'YER',
          reserved: !!c.reserved,
        };
        const idx = OFF.push(o) - 1,
          src = IM[imageKey] || IM.p_car1,
          price = Number(c[7] || 0),
          specs = [String(c[5] || '—'), String(c[4] || '—'), String(c[6] || '—')];
        return `<div class="crCard"><div class="crDet"><div class="crName"><span class="t">${ht(c[0] || 'مكتب سيارات')}</span>${c[0] ? `<span class="v">${I.chk}</span>` : ''}</div><div class="crCity">${I.pin}<span>${ht(c[1] || '')}</span></div><div class="crSpecs"><div>${I.car.replace('<svg', '<svg class="fl"')}<p>السيارة</p></div><div>${I.cplus}<p><small>الموديل</small>${ht(specs[0])}</p></div><div>${I.cal}<p><small>الفئة</small>${ht(specs[1])}</p></div><div>${I.seat}<p><small>عدد المقاعد</small>${ht(specs[2])}</p></div></div><div class="crBot"><button class="crBook" onclick="det(${idx})">ابدأ الحجز${I.left}</button><div class="crPrice">${ht(c[7] == null ? 'حسب العرض' : String(price))}<small>${ht(c[7] == null ? 'السعر حسب المكتب' : c[7] + ' في اليوم')}</small></div></div></div><div class="crPic"><img class="bg" src="${src}" alt="" onerror="fb(this,'p_car1')"><img class="fg" src="${src}" loading="lazy" alt="${ht([c[2], c[3]].filter(Boolean).join(' '))}" onerror="fb(this,'p_car1')"><span class="crSt ${c.reserved ? 'bad' : 'ok'}">${c.reserved ? 'غير متاح' : 'متاح'}${c.reserved ? I.no : I.ok}</span><div class="crBtm"><div class="nm">${I.toy}<span>${ht(c[3] || 'سيارة')}</span></div></div></div></div>`;
      })
      .join('') ||
    '<div class="empty"><b>🚗</b><strong>لا توجد سيارات منشورة حالياً</strong><p>ستظهر هنا سيارات المكاتب بعد نشر عروض حقيقية من لوحة المكتب.</p></div>';
  const searchBox = CARS.length
    ? `<div class="crBox"><div class="crPill">ابحث عن السيارة المناسبة</div><div class="crFields">${field('c', 'المدينة', 'اختر المدينة', I.pin, "crPick('c')")}${field('b', 'الشركة المصنعة', 'اختر الشركة', I.car, "crPick('b')")}${field('t', 'نوع السيارة', 'اختر النوع', I.car, "crPick('t')")}${field('m', 'الموديل', 'اختر الموديل', I.cal2, "crPick('m')")}</div><div class="crRow"><button class="crOffers" onclick="crPick('a')">${I.tag}<span>${F.a ? F.a : 'العروض المتاحة'}</span>${I.chev.replace('<svg', '<svg class="ch"')}</button><button class="crFollow" onclick="document.getElementById('crResults').scrollIntoView({behavior:'smooth'})">متابعة الحجز${I.srch}</button></div></div><div class="crSep" id="crResults"><b>العروض المنشورة من المكاتب</b></div><div class="crSub">اسحب للأسفل لعرض المزيد من العروض</div>`
    : `<div class="crEmptyIntro"><b>تأجير السيارات</b><p>لا توجد عروض سيارات منشورة حالياً. ستظهر السيارات هنا بعد أن ينشرها مكتب من داخل لوحة المكتب.</p></div>`;
  return `<div class="crp"><div class="crHead"><button class="crBack" onclick="bk('home')" aria-label="رجوع">${I.back}</button><div class="crTitle"><h1>تأجير السيارات</h1><p>احجز السيارة التي تناسبك من مكاتب مسجلة</p></div></div>${searchBox}<div class="crList">${cards}</div></div>`;
}
