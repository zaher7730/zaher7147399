/* صفحة الرحلات الخاصة — الجزء 1/2
   يعرّف: privPage */
function privPage() {
  const dm = S.pgt == 'd',
    K = dm ? 'privd' : 'priv',
    DATA = dm ? PRIVD2 : PRIV2,
    F = S.F[K] || (S.F[K] = {}),
    d = S.d[K] || 0;
  OFF = [];
  const L = DATA.filter(
    (r) =>
      (!r.rv || (F.f && F.t)) &&
      (!F.f || r[1] == F.f) &&
      (!F.t || r[2] == F.t) &&
      r[3].includes(d),
  ).sort((a, b) => arTm(a[4]) - arTm(b[4]));
  const dts = DATES.map(
    (x) => `<button class="arDy ${d == x.n ? 'on' : ''}" onclick="S.d['${K}']=${x.n};render()">${x.w}<b>${x.d}</b>${x.m}</button>`,
  ).join('');
  const cards = L.map((r) => {
    const key = [K, r[0], r[1], r[2], d, r[4]].join(),
      se = r[6] - (S.bk[key] || 0),
      tier = r[11] || 0,
      full = se <= 0;
    const st = tripStatus(d, r[4]),
      gone = st.gone,
      red = gone || full,
      bd = full ? 'المقاعد مكتملة' : st.label;
    const ph = r[9],
      o = {
        key,
        left: se,
        tot: r[6],
        tier,
        n: ofTitle(r[0], 'للرحلات الخاصة'),
        k: 'bus',
        priv: 1,
        dom: dm ? 1 : 0,
        pickup: dm ? r[1] + ' — مقر مكتب ' + r[0] + ' (نقطة التجمع الرئيسية)' : '',
        cr: '',
        t: r[1] + ' ← ' + r[2],
        from: r[1],
        to: r[2],
        pr: r[7],
        old: r[8],
        date: DATES[d].full,
        time: r[4],
        ty: r[5],
        se,
        ph,
        bd,
        br: red,
        vip: tier == 2,
        gone,
      };
    const i = OFF.push(o) - 1,
      src = ari(ph),
      ft = PRF[tier] || PRF[0];
    return `<div class="arCard"><div class="arDet"><div class="arName"><span class="t">${ofTitle(r[0], 'للرحلات الخاصة')}</span><span class="v"></span></div><div class="arChips"><span class="c1">مكتب مسجل</span><span class="c2">${PRC[tier]}</span></div><div class="arRoute"><span class="pn">${ARI.pin}<span>${r[1]}</span></span><span class="ln"></span><span class="pn r">${ARI.pin}<span>${r[2]}</span></span></div><div class="arSpec"><div>${ARI.carS}<p><small>نوع السيارة</small>${r[5]}</p></div><div>${ARI.clock}<p><small>الانطلاق</small>${r[4]}</p></div><div>${ARI.cal}<p><small>التاريخ</small>${DATES[d].full}</p></div><div>${ARI.seat}<p><small>المقاعد المتاحة</small>${full ? 'مكتمل' : se + ' مقعد'}</p></div></div><div class="arFeat">${ft.map((x) => `<span>${ARI[x[0]]}${x[1]}</span>`).join('')}</div><div class="arBot"><button class="arBook ${full ? 'dis' : ''}" onclick="det(${i})">ابدأ الحجز${ARI.left}</button><div class="arPrice"><small>السعر للشخص</small>${r[8] ? `<s>${curOf(r)}${r[8]}</s>` : ''}<b>${curOf(r)}${r[7]}</b></div></div></div><div class="arPic bus"><img class="bg" src="${src}" alt="" aria-hidden="true"><img class="fg" src="${src}" loading="lazy" alt="${r[1]} ${r[2]}" onerror="fb(this,'p_car1')"><span class="arSt ${red ? 'bad' : 'ok'}">${bd}</span><span class="arVip ${tier == 2 ? '' : 'n'}">${String(r[5]).split(' ')[0]}</span></div></div>`;
  }).join('');
  return `<div class="arp"><div class="arHead"><div class="arTit"><h1>رحلات خاصة</h1><p>${dm ? 'سافر بسيارتك المفضلة بين المحافظات اليمنية' : 'سافر بسيارتك المفضلة من اليمن إلى عُمان والسعودية'}</p></div><button class="arBack" onclick="bk('home')" aria-label="رجوع">${ARI.back}</button></div>${lcSel(K)}<div class="arDates">${dts}</div><div class="pvRow"><button class="pvTab ${dm ? '' : 'on'}" onclick="S.pgt='i';render()">رحلات دولية</button><b>اختر من بين العروض</b><button class="pvTab ${dm ? 'on' : ''}" onclick="S.pgt='d';render()">رحلات داخلية</button></div><div class="crSub">اسحب للأسفل لعرض المزيد من العروض</div><div class="arList">${cards || `<div class="empty"><b>🔍</b>لا توجد رحلات في هذا التاريخ${F.f || F.t ? ' لهذا المسار' : ''}<br>جرّب تاريخاً أو مدينة أخرى${nx(K, DATA)}</div>`}</div></div>`;
}
