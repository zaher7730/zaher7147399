/* إرسال الحجز ومزامنة الطلبات — الجزء 1/3
   يعرّف: send، retryPayment، pendingPayBox، pickRetryReceipt، SA_findReceiptFile */
async function send() {
  keep();
  const online = S.pt == 'e';
  if (online && !SA_online.on) {
    toast('الدفع الإلكتروني غير متاح حالياً');
    return;
  }
  if (S.pt && S.pt != 'm' && !online) {
    toast('طريقة الدفع هذه غير مفعّلة بعد');
    return;
  }
  if (!window.SA_API) return toast('هذه معاينة شكلية فقط؛ لتسجيل حجز حقيقي شغّل الخادم المتصل');
  const sb_ = seatBad();
  if (sb_) {
    toast(sb_);
    return;
  }
  const o = S.o;
  if (tripGoneGuard(o)) return;
  if (!o || !o.serviceId) return toast('هذا العرض غير مربوط بخدمة منشورة من مكتب؛ لا يمكن إنشاء حجز وهمي');
  const needsReceipt = !online && (BANKS.length > 0 || PMS.length > 0);
  if (needsReceipt && !S.pm) return toast('اختر وسيلة الدفع من الحسابات التي أضافها المكتب');
  if (needsReceipt) {
    const m = missing([
      ['f', 'rc', 'صورة الحوالة', 1],
      ['t', 'tn', 'اسم المرسل أو رقم حسابه', 1],
      ['t', 'tr', 'رقم الحوالة', 1],
    ]);
    if (m.length) {
      toast('مطلوب: ' + m[0][2]);
      return;
    }
  }
  const pax = o.k == 'cars' ? +S.v.a || 1 : PX();
  if (isFullC(o) && o.left < o.tot) {
    toast('لم تعد السيارة كاملة متاحة، اختر حجز مقاعد');
    return;
  }
  const cleanForm = {};
  for (const [key, value] of Object.entries(S.v || {})) {
    if (typeof value === 'string' && value.length < 1000 && !/^data:/i.test(value) && !/(password|token|secret)/i.test(key))
      cleanForm[key] = value;
    else if (typeof value === 'number' || typeof value === 'boolean') cleanForm[key] = value;
  }
  const payMethod = needsReceipt
    ? { methodId: S.pmId || [...BANKS, ...PMS].find((m) => m[0] === S.pm)?.[4], methodName: S.pm }
    : null;
  const payload = {
    serviceId: o.serviceId,
    serviceType: o.k,
    title: o.t || o.details?.title || 'طلب خدمة',
    passengerCount: pax,
    totalAmount: Number(total()) || 0,
    currency:
      String(o.cur || o.details?.currency || 'YER')
        .replace(/[^A-Za-z]/g, '')
        .slice(0, 8) || 'YER',
    details: {
      serviceId: o.serviceId,
      officeName: o.n,
      from: o.from || '',
      to: o.to || '',
      date: o.date || '',
      departDate: tripDepartDate(o),
      time: o.time || '',
      serviceTitle: o.t,
      form: cleanForm,
      paymentSubmitted: needsReceipt ? true : false,
      ...(payMethod ? { payment: payMethod } : {}),
    },
  };
  try {
    const result = await window.SA_API.createBooking(payload),
      b = result.booking;
    const attachments = await SA_uploadFormAttachments(b.public_id, { ...(S.v || {}), ...(S.fu || {}) });
    let paymentStatus = b.payment_status || 'pending',
      paymentError = false,
      pendingPayment = null;
    if (needsReceipt) {
      const fields = {
        reference: String(S.v.tr || ''),
        sender: String(S.v.tn || ''),
        methodId: payMethod.methodId,
        methodName: payMethod.methodName,
        currency: payload.currency,
      };
      const receipt = attachments.files.find((f) => f.key === 'rc');
      if (!receipt) {
        paymentError = true;
        pendingPayment = { bookingPublicId: b.public_id, fields, receiptData: S.fu.rc || null, receiptId: null };
      } else {
        try {
          await window.SA_API.submitPayment(b.public_id, { ...fields, receiptFileId: receipt.id });
          paymentStatus = 'submitted';
        } catch (e) {
          paymentError = true;
          pendingPayment = { bookingPublicId: b.public_id, fields, receiptData: null, receiptId: receipt.id };
          console.warn('Payment submission failed:', e.message);
        }
      }
    }
    const st =
      { pending: 0, reviewing: 0, in_progress: 1, completed: 2, rejected: 3, waiting_documents: 4, waiting_payment: 5, cancelled: 6 }[
        b.status
      ] ?? 0;
    const x = {
      o: { ...o, n: o.n, t: b.title, cur: b.currency || payload.currency, pr: b.total_amount },
      id: b.public_id,
      inv: b.public_id,
      n: S.v.name || S.u.name,
      ph: S.v.ph || S.u.ph,
      pax: b.passenger_count,
      t: b.total_amount,
      st,
      ts: Date.parse(b.created_at) || Date.now(),
      dt: new Date().toLocaleDateString('ar'),
      serverStatus: b.status,
      paymentStatus,
    };
    S.ord.unshift(x);
    if (pendingPayment) x.pendingPayment = pendingPayment;
    S.hist = [];
    S.cur = x.id;
    S.scr = 'done';
    render();
    if (online) return SA_startCheckout(b.public_id);
    toast(
      paymentError
        ? 'تم حفظ الحجز، لكن لم تُسجَّل الحوالة بعد؛ أعد إرسالها من شاشة الإتمام'
        : 'تم إرسال الحجز إلى قاعدة البيانات المشتركة' + (paymentStatus === 'submitted' ? '؛ الحوالة بانتظار مراجعة المكتب' : '') +
            (attachments.failed ? '؛ تعذّر رفع ' + attachments.failed + ' مرفق، أرسلها للمكتب من المحادثة' : ''),
    );
  } catch (e) {
    toast(e.message || 'تعذر حفظ الحجز على الخادم');
  }
}

/* ابحث عن سند التحويل المرفوع فعلاً على الخادم لهذا الحجز (المفتاح rc فقط، ومن رفع العميل نفسه) لتفادي رفعه مرتين */
async function SA_findReceiptFile(bk) {
  const r = await window.SA_API.files();
  return (r.files || []).find((f) => f.booking_id === bk.id && f.owner_id === bk.customer_id && /^rc\./i.test(f.original_name || '')) || null;
}

/* قراءة سند جديد يختاره العميل عندما لا يوجد سند محفوظ على الخادم (فشل رفعه قبل إعادة التحميل) */
function pickRetryReceipt(bookingId, input) {
  const x = S.ord.find((o) => o.id === bookingId),
    p = x && x.pendingPayment,
    f = input && input.files && input.files[0];
  if (!p || !f) return;
  if (f.size > 5242880) return toast('الحجم الأقصى 5 ميجابايت');
  if (['image/jpeg', 'image/png', 'image/webp', 'application/pdf'].indexOf(f.type) < 0)
    return toast('نوع الملف غير مدعوم؛ JPG أو PNG أو WEBP أو PDF');
  const r = new FileReader();
  r.onload = () => {
    p.receiptData = r.result;
    render();
  };
  r.onerror = () => toast('تعذّرت قراءة الملف');
  r.readAsDataURL(f);
}

/* صندوق الحوالة المعلّقة: يظهر في شاشة الإتمام وتفاصيل الطلب، ويُبنى من حالة الخادم (انظر SA_mapBooking) */
function pendingPayBox(x) {
  const p = x && x.pendingPayment;
  if (!p) return '';
  const f = p.fields || {},
    complete = f.methodName && f.reference && f.sender,
    ready = p.receiptId || p.receiptData;
  const action = !complete
    ? '<p class="ch">بيانات الحوالة غير مكتملة في الطلب؛ راسل المكتب لتسجيلها.</p>'
    : ready
      ? `<button class="gb w" onclick="retryPayment('${x.id}')">إعادة إرسال الحوالة</button>`
      : `<label class="up"><div><b>أرفق سند التحويل مجدداً</b><small>JPG / PNG / PDF · 5 ميجابايت</small></div><input type="file" accept="image/*,.pdf" onchange="pickRetryReceipt('${x.id}',this)"></label>`;
  return `<div class="sec"><h4>الحوالة لم تُسجَّل بعد</h4><p class="ch">الطلب محفوظ، لكن الحوالة لم تصل للمكتب. أعد إرسالها دون إعادة إدخال بياناتها.</p>${action}</div>`;
}

/* إعادة إرسال الحوالة لطلب حُفظ بدون تسجيلها. تقرأ حالة الخادم أولاً فلا تُكرّر حوالة مسجّلة، وتعيد استخدام السند المرفوع إن وُجد */
async function retryPayment(bookingId) {
  const x = S.ord.find((o) => o.id === bookingId);
  const p = x && x.pendingPayment;
  if (!p || !window.SA_API) return toast('لا توجد حوالة معلّقة لهذا الطلب');
  if (p.busy) return;
  p.busy = true;
  try {
    const bk = (await window.SA_API.booking(bookingId)).booking;
    if (bk.payment_status !== 'pending') {
      await SA_loadBookings();
      return toast('الحوالة مسجّلة مسبقاً لهذا الطلب');
    }
    if (['cancelled', 'rejected'].includes(bk.status)) {
      await SA_loadBookings();
      return toast('لا يمكن تسجيل حوالة لطلب ملغي أو مرفوض');
    }
    if (!p.receiptId) {
      const found = await SA_findReceiptFile(bk);
      if (found) p.receiptId = found.id;
    }
    if (!p.receiptId) {
      const data = String(p.receiptData || ''),
        m = data.match(/^data:(application\/pdf|image\/(?:jpeg|png|webp));base64,/i);
      if (!m) return toast('أرفق سند التحويل أولاً');
      const mimeType = m[1].toLowerCase(),
        ext = mimeType === 'application/pdf' ? 'pdf' : mimeType === 'image/png' ? 'png' : mimeType === 'image/webp' ? 'webp' : 'jpg';
      const up = await window.SA_API.uploadFile({ bookingId, filename: 'rc.' + ext, mimeType, base64: data });
      p.receiptId = up.file.id;
      p.receiptData = null;
    }
    await window.SA_API.submitPayment(bookingId, { ...p.fields, receiptFileId: p.receiptId });
    x.paymentStatus = 'submitted';
    delete x.pendingPayment;
    await SA_loadBookings();
    render();
    toast('تم تسجيل الحوالة؛ بانتظار مراجعة المكتب');
  } catch (e) {
    toast(e.message || 'تعذّر إرسال الحوالة، حاول مرة أخرى');
  } finally {
    p.busy = false;
  }
}
