/* إرسال الحجز ومزامنة الطلبات — الجزء 2/3
   يعرّف: SA_uploadFormAttachments، SA_mapBooking، SA_pendingPaymentOf، SA_loadBookings، cancelO، sumr */
async function SA_uploadFormAttachments(bookingId, form) {
  if (!window.SA_API || !bookingId || !form) return { uploaded: 0, failed: 0, files: [] };
  let uploaded = 0,
    failed = 0;
  const files = [];
  for (const [key, value] of Object.entries(form)) {
    if (typeof value !== 'string' || !/^data:(application\/pdf|image\/(?:jpeg|png|webp));base64,/i.test(value)) continue;
    const match = value.match(/^data:(application\/pdf|image\/(?:jpeg|png|webp));base64,/i);
    if (!match) continue;
    const mimeType = match[1].toLowerCase(),
      ext = mimeType === 'application/pdf' ? 'pdf' : mimeType === 'image/png' ? 'png' : mimeType === 'image/webp' ? 'webp' : 'jpg';
    try {
      const result = await window.SA_API.uploadFile({
        bookingId,
        filename: String(key).replace(/[^\w\u0600-\u06FF-]/g, '_') + '.' + ext,
        mimeType,
        base64: value,
      });
      files.push({ key, id: result.file.id, mimeType, filename: result.file.filename });
      uploaded++;
    } catch (e) {
      failed++;
      console.warn('Attachment upload failed for', key, e.message);
    }
  }
  return { uploaded, failed, files };
}
/* الحوالة المعلّقة تُشتق من الخادم: حجز ينتظر سنداً (details.paymentSubmitted) وحالة دفعه ما زالت pending ولم يُلغَ أو يُرفض.
   بيانات الحوالة من details.form وdetails.payment المحفوظتين مع الحجز، فتبقى بعد التحديث وبعد الخروج والدخول. */
function SA_pendingPaymentOf(b, details) {
  if (details.paymentSubmitted !== true || b.payment_status !== 'pending' || ['cancelled', 'rejected'].includes(b.status)) return null;
  const form = details.form && typeof details.form === 'object' ? details.form : {},
    pay = details.payment && typeof details.payment === 'object' ? details.payment : {};
  return {
    bookingPublicId: b.public_id,
    fields: {
      reference: String(form.tr || ''),
      sender: String(form.tn || ''),
      methodId: pay.methodId,
      methodName: pay.methodName,
      currency: b.currency || 'YER',
    },
    receiptData: null,
    receiptId: null,
  };
}
function SA_mapBooking(b) {
  const details = b.details && typeof b.details === 'object' ? b.details : {},
    k = String(b.service_type || 'bus'),
    st =
      { pending: 0, reviewing: 0, in_progress: 1, completed: 2, rejected: 3, waiting_documents: 4, waiting_payment: 5, cancelled: 6 }[
        b.status
      ] ?? 0;
  return {
    o: {
      k,
      n: b.office_name || b.office_user_name || details.officeName || 'المكتب',
      t: b.title,
      cur: b.currency || 'YER',
      pr: Number(b.total_amount || 0),
      serviceId: details.serviceId || null,
      serverOfficeId: b.office_id,
      details,
      from: details.from || '',
      to: details.to || '',
      date: details.date || '',
      time: details.time || '',
    },
    id: b.public_id,
    inv: b.public_id,
    n: b.customer_name || S.u.name,
    ph: b.customer_phone || S.u.ph,
    pax: b.passenger_count || 1,
    t: Number(b.total_amount || 0),
    st,
    ts: SA_ts(b.created_at),
    dt: b.created_at || '',
    serverStatus: b.status,
    paymentStatus: b.payment_status,
    serverBookingId: b.id,
    customerId: b.customer_id,
    pendingPayment: SA_pendingPaymentOf(b, details),
  };
}
async function SA_loadBookings() {
  if (!window.SA_API || !S.u.in) return;
  try {
    const r = await window.SA_API.bookings();
    const prev = new Map(S.ord.map((o) => [o.id, o.pendingPayment])),
      next = r.bookings.map(SA_mapBooking),
      pending = next.filter((o) => o.pendingPayment);
    for (const o of pending) {
      const old = prev.get(o.id);
      if (old) {
        o.pendingPayment.receiptData = old.receiptData || null;
        o.pendingPayment.receiptId = old.receiptId || null;
      }
    }
    if (pending.some((o) => !o.pendingPayment.receiptId && !o.pendingPayment.receiptData)) {
      try {
        const files = (await window.SA_API.files()).files || [];
        for (const o of pending) {
          const f = files.find((x) => x.booking_id === o.serverBookingId && x.owner_id === o.customerId && /^rc\./i.test(x.original_name || ''));
          if (f && !o.pendingPayment.receiptData) o.pendingPayment.receiptId = f.id;
        }
      } catch (e) {
        console.warn('Unable to look up stored receipts:', e.message);
      }
    }
    S.ord = next;
    render();
  } catch (e) {
    console.warn('Unable to load customer bookings:', e.message);
  }
}
async function cancelO(i) {
  const x = S.ord[i];
  if (!x) return;
  try {
    await window.SA_API.cancelBooking(x.id, 'إلغاء من العميل');
    toast('تم إلغاء الطلب');
    await SA_loadBookings();
  } catch (e) {
    toast(e.message || 'تعذّر إلغاء الطلب');
  }
}
const sumr = (x) =>
  x.xr
    ? `<p class="pp">المكتب: <b>${x.o.n}</b><br>الخدمة: ${x.o.t}<br>الاسم: ${ht(x.n)}<br>رقم الجواز: <b class="cd">${ht(x.pp)}</b>${x.nt ? '<br>الملاحظة: ' + ht(x.nt) : ''}<br>رقم الطلب: <b class="cd">${x.id}</b><br>تاريخ العملية: ${fmt(x.ts)}<br>الحالة: <span class="tg">${ST_[x.st]}</span></p>`
    : `<p class="pp">المكتب: <b>${x.o.n}</b><br>الخدمة: ${x.o.t}<br>الباقة: ${TQ(x.o)[x.tier || 0].n}${x.o.date ? '<br>التاريخ: ' + x.o.date + (x.o.time ? ' · ' + x.o.time : '') : ''}<br>${x.o.k == 'cars' ? 'عدد الأيام: ' : 'عدد الأفراد: '}${x.pax}${x.tt ? '<br>نوع الرحلة: ' + x.tt : ''}${x.rcv ? '<br>الاستلام: ' + x.rcv + (x.dl ? ' — ' + x.dl : '') : ''}${x.o.cr ? '<br>' + crl(x.o) : ''}${x.dep ? '<br>مبلغ الضمان (يُعاد): ' + curOf(x.o) + x.dep : ''}<br>رقم الفاتورة: <b class=\"cd\">${x.inv}</b><br>تاريخ العملية: ${fmt(x.ts)}<br>الإجمالي: <b>${curOf(x.o)}${x.t}</b><br>الحالة: <span class="tg">${ST_[x.st]}</span></p>`;
