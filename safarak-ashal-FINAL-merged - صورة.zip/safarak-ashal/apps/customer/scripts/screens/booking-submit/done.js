/* إرسال الحجز ومزامنة الطلبات — الجزء 3/3
   يعرّف: done */
const done = () => {
  const x = S.ord[0];
  if (!x) return home();
  return `<div class="empty"><b style="color:#15803d">✔</b><h2 style="color:var(--tx);margin:8px 0">تم إرسال طلبك بنجاح</h2>رقم الطلب<div class="rp">${x.id}</div></div><div class="sec"><h4>ملخص الطلب</h4>${sumr(x)}</div><div class="sec"><h4>الخطوات التالية</h4>${x.xr ? '<p class="ch">وصل رقم جوازك وملاحظتك إلى المكتب</p><p class="ch">يرد عليك المكتب في الرسائل</p><p class="ch">احتفظ برقم الطلب للمتابعة</p>' : x.snd ? '<p class="ch">احضر جوازك ومستنداتك إلى مكتب الأمانات المحدد</p><p class="ch">يوصّلها المكتب إلى مكتب السفر المستلم</p><p class="ch">احتفظ برقم الطلب للمتابعة</p>' : `<p class="ch">يراجع المكتب سند التحويل خلال ساعات العمل</p><p class="ch">يصلك التأكيد في الرسائل والإشعارات</p><p class="ch">احتفظ برقم الطلب للتواصل مع المكتب</p>`}</div>${pendingPayBox(x)}${onlinePayBox(x)}<button class="gb w" onclick="S.cur='${x.id}';S.hist=[];go('orders')">متابعة الطلب</button><button class="gb w" style="margin-top:8px;background:#13306b;color:var(--gold);border:1.5px solid var(--gold)" onclick="S.hist=[];go('home')">الرجوع للقائمة الرئيسية</button><div class="chips" style="justify-content:center"><button onclick="S.cur='${x.id}';go('chat')">💬 راسل المكتب</button></div>`;
};
