/* إعدادات المكتب وتحريره — الجزء 4/4
   يعرّف: ofBar، TS، SVI، OWN، osv، OC، oPlain، ofTitle، ofListed، ofCountLine */
function ofBar() {
  const m = S.ofm;
  if (!m) return '';
  const k = m.k,
    r = m.rows[m.ri],
    tr = ['bus', 'air', 'local', 'priv'].includes(k),
    hasDates = tr && Array.isArray(r[3]) && r[3].length > 0;
  return `<div class="box" style="padding:8px;margin:0 0 8px"><div class="g" style="grid-template-columns:${hasDates ? '1.4fr 1fr' : '1fr'};margin:0">${sel({ bus: 'الرحلة', air: 'الرحلة', local: 'الرحلة المحلية', priv: 'الرحلة الخاصة', cars: 'السيارة', pass: 'نوع الخدمة', visa: 'نوع التأشيرة' }[k], ofLb(k, r), '', "ofPick('r')")}${hasDates ? sel('التاريخ', m.d == null ? 'اختر التاريخ' : dLb(DATES[m.d]), '', "ofPick('d')") : ''}</div></div>`;
}
const TS = {
  العمرة: 'visa',
  الحج: 'visa',
  التأشيرات: 'visa',
  'تذاكر الطيران': 'air',
  الطيران: 'air',
  الجوازات: 'pass',
  'تأجير السيارات': 'cars',
  'النقل الدولي': 'bus',
  'النقل البري': 'bus',
};
const SVI = {
    air: ['الطيران', '✈️'],
    bus: ['النقل الدولي', '🚌'],
    pass: ['الجوازات', '🛂'],
    visa: ['التأشيرات', '📄'],
    cars: ['تأجير السيارات', '🚗'],
    local: ['رحلات محلية', '🚌'],
    priv: ['رحلات خاصة', '🚘'],
  },
  SVO = ['air', 'bus', 'pass', 'visa', 'cars', 'local', 'priv'],
  BASE = { bus: BUS, air: AIR, cars: CARS, pass: PASS, visa: VISA, local: LOC, priv: PRIV };
/* خدمات كل مكتب: أرقام الصفوف من بيانات الخدمة التي يملكها المكتب (الرحلات المحلية مستقلة وغير مرتبطة بالمكاتب) */
const OWN = {};
const osv = (i) => SVO.filter((k) => OWN[i] && OWN[i][k]);
const OC = {};
const svcTitle = (i, k) => (OC[i] && OC[i][k] && OC[i][k].title) || SVI[k][0];
const svcCfg = (i, k) => ({ ...((OC[i] && OC[i][k]) || {}) });
const ht = (v) =>
  String(v ?? '').replace(/[&<>\"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&#39;' })[m]);
const ofLb = (k, r) =>
  ['bus', 'air', 'priv', 'local'].includes(k)
    ? r[1] + ' ← ' + r[2] + (r[4] ? ' · ' + r[4] : '') + (r[5] ? ' · ' + r[5] : '')
    : k == 'cars'
      ? [r[2], r[3], r[5], r[4]].filter(Boolean).join(' ')
      : r[1];
const dLb = (x) => x.w + ' ' + x.d + ' ' + x.m;
const OFFS = [];
/* اسم المكتب بدون كلمة «مكتب» في أوله، حتى لا يظهر «مكتب مكتب ...» */
const oPlain = (n) => String(n || '').replace(/^\s*مكتب\s+/, '').trim();
const ofTitle = (n, suffix) => 'مكتب ' + oPlain(n) + (suffix ? ' ' + suffix : '');
/* المكاتب التي لديها خدمة منشورة واحدة على الأقل (المكتب بلا خدمات لا يظهر في السوق) */
const ofListed = () => OFFS.map((o, i) => i).filter((i) => OFFS[i].tg.length);
const ofCountLine = (n) =>
  !n
    ? 'لا توجد مكاتب لديها خدمات منشورة حاليًا'
    : n === 1
      ? 'مكتب واحد مسجل لديه خدمات منشورة'
      : n === 2
        ? 'مكتبان مسجلان لديهما خدمات منشورة'
        : n <= 10
          ? n + ' مكاتب مسجلة لديها خدمات منشورة'
          : n + ' مكتبًا مسجلًا لديه خدمات منشورة';
window.SA_PUBLIC_OFFICES = [];
window.SA_PUBLIC_SERVICES = [];
