/* إعدادات المكتب وتحريره — الجزء 2/4
   يعرّف: ofRow، ofFix */
function ofRow(k, j) {
  return BASE[k][j];
}
function ofFix() {
  const m = S.ofm;
  if (m.k == 'bus' || m.k == 'air' || m.k == 'local' || m.k == 'priv') {
    const r = m.rows[m.ri];
    if (!Array.isArray(r[3]) || !r[3].length) {
      m.d = null;
      return;
    }
    if (m.d == null || !r[3].includes(m.d)) m.d = (DATES.find((x) => r[3].includes(x.n)) || {}).n ?? null;
  }
}
