/* إعدادات المكتب وتحريره — الجزء 1/4
   يعرّف: cfgFor، applyOC، customList، customMeta */
function cfgFor(o) {
  return o && o.officeId != null ? svcCfg(o.officeId, o.k) : {};
}
function applyOC(o) {
  const c = cfgFor(o);
  if (!c || !Object.keys(c).length) return o;
  o.custom = c;
  o.t = c.title || o.t;
  o.pr = c.price !== '' && c.price != null ? +c.price || 0 : o.pr;
  o.cur = c.cur || o.cur;
  if (c.schedule) o.dateLabel = c.schedule;
  if (c.description) o.description = c.description;
  if (c.package) o.package = c.package;
  return o;
}
function customList(c, key, fallback) {
  const a = String(c[key] ?? '')
    .split(/\n|،|,/)
    .map((x) => x.trim())
    .filter(Boolean);
  return a.length ? a : fallback;
}
function customMeta(o, I) {
  const c = o.custom || {},
    q = (TQ(o) || [])[o.tier || 0] || {},
    allFeatures = [...(q.i || []), ...(q.f || [])];
  return {
    desc: c.description || '',
    package: c.package || q.n || '',
    features: customList(c, 'features', allFeatures),
    req: customList(c, 'req', I.req || []),
    warn: customList(c, 'warn', []),
    det: customList(c, 'det', I.det || []),
    notes: customList(c, 'notes', I.notes || []),
    route: customList(c, 'route', via(o) || []),
    extraTitle: c.extraTitle || '',
    extra: customList(c, 'extra', []),
    schedule: c.schedule || '',
    pickup: c.pickup || '',
  };
}
