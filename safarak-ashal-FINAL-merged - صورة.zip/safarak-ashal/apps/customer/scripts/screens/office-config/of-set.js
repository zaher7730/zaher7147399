/* إعدادات المكتب وتحريره — الجزء 3/4
   يعرّف: ofSet، oSvc، ofPick */
function ofSet() {
  const m = S.ofm,
    o = OFFS[m.i],
    r = m.rows[m.ri],
    k = m.k;
  if (!o || !r) return;
  ofFix();
  if (k == 'bus' || k == 'air' || k == 'priv') {
    const key = [k, r[0], r[1], r[2], m.d, r[4]].join(),
      se = r[6] - (S.bk[key] || 0);
    S.o = applyOC({
      key,
      left: se,
      tot: r[6],
      tier: r[k == 'air' ? 10 : 11],
      k,
      n: o.n,
      officeId: m.i,
      cr: r[k == 'air' ? 9 : 10],
      t: r[1] + ' ← ' + r[2],
      from: r[1],
      to: r[2],
      pr: r[7],
      old: r[8],
      date: m.d == null ? '' : DATES[m.d].full,
      time: r[4],
      ty: r[5],
      se,
      ph: k == 'air' ? 'p_air' : ['p_bus1', 'p_bus2'][r[9] || 0],
      bd: '',
      br: 0,
      vip: /VIP/.test(r[5]),
    });
  } else if (k == 'local') {
    const key = [k, r[0], r[1], r[2], m.d, r[9]].join(),
      se = r[5] - (S.bk[key] || 0);
    S.o = applyOC({
      key,
      left: se,
      tot: r[5],
      tier: r[8] || 0,
      k,
      n: o.n,
      officeId: m.i,
      t: r[1] + ' ← ' + r[2],
      from: r[1],
      to: r[2],
      pr: r[6],
      old: r[7],
      date: m.d == null ? '' : DATES[m.d].full,
      time: r[9] || '',
      ty: r[4],
      se,
      ph: 'h_van',
    });
  } else if (k == 'cars')
    S.o = applyOC({
      k: 'cars',
      tier: r[9],
      n: o.n,
      officeId: m.i,
      t: r[2] + ' ' + r[3],
      pr: r[7],
      per: 'في اليوم',
      ty: r[4],
      se: r[6],
      model: r[3],
      year: r[5],
      city: r[1],
      ph: r[4] == 'دفع رباعي' ? 'p_car1' : r[4] == 'سيدان' ? 'p_car2' : 'p_car3',
    });
  else if (k == 'pass')
    S.o = applyOC({
      k: 'pass',
      tier: r[4],
      n: o.n,
      officeId: m.i,
      t: r[1],
      svc: r[1],
      pr: r[3],
      cur: r.details?.currency || CFG.cur || 'YER',
      ph: SP[m.ri % 2],
      dur: r[2],
    });
  else
    S.o = applyOC({
      k: 'visa',
      tier: r[4],
      n: o.n,
      officeId: m.i,
      t: r[1],
      svc: r[1],
      pr: r[2] || 'حسب الباقة',
      old: r[3] || 0,
      ph: /عائلية|حج|عمرة/.test(r[1]) ? 'p_v2' : 'p_v1',
      ...xsProps(r[1]),
    });
  if (S.o) {
    S.o.serviceId = r.serviceId || null;
    S.o.serverOfficeId = r.serverOfficeId || null;
    S.o.officeId = r.serverOfficeId ?? m.i;
    S.o.officePhone = o.ph || '';
    S.o.details = r.details || {};
    if (r.imageKey) S.o.ph = r.imageKey;
  }
}
async function oSvc(i, k, pre) {
  const ix = OWN[i] && OWN[i][k];
  if (!ix) return toast('الخدمة غير متاحة لدى هذا المكتب');
  let rows = ix.map((j) => ofRow(k, j));
  if (k == 'bus' || k == 'air' || k == 'priv') rows = bi(rows);
  let ri = 0;
  if (pre && pre.v) {
    const x = rows.findIndex((r) => r[1] == pre.v);
    if (x >= 0) ri = x;
  }
  S.oi = i;
  S.ofm = { i, k, rows, ri, d: null };
  ofSet();
  S.tier = S.o.tier || 0;
  S.v = nv();
  S.fl = {};
  S.fu = {};
  S.pm = '';
  S.pmId = null;
  S.tab = 'z';
  if (window.SA_API) await SA_loadPaymentMethods(S.o.serverOfficeId || S.o.officeId);
  go('detail');
}
function ofPick(w) {
  const m = S.ofm,
    k = m.k;
  if (w == 'd') {
    const r = m.rows[m.ri],
      L = DATES.filter((x) => Array.isArray(r[3]) && r[3].includes(x.n));
    if (!L.length) return toast('لم يحدد المكتب مواعيد متاحة لهذا العرض');
    pick('التاريخ', L.map(dLb), m.d == null ? '' : dLb(DATES[m.d]), (v) => {
      m.d = L.find((x) => dLb(x) == v).n;
      ofSet();
    });
    return;
  }
  const L = m.rows.map((r) => ofLb(k, r));
  pick(
    {
      bus: 'الرحلة',
      air: 'الرحلة',
      local: 'الرحلة المحلية',
      priv: 'الرحلة الخاصة',
      cars: 'السيارة',
      pass: 'نوع الخدمة',
      visa: 'نوع التأشيرة',
    }[k],
    L,
    L[m.ri],
    (v) => {
      m.ri = Math.max(0, L.indexOf(v));
      ofSet();
    },
  );
}
