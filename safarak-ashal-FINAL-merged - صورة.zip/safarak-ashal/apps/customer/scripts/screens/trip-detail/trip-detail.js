/* تفاصيل الرحلة
   يعرّف: tripNo، tripDetail، det، TRN */
function tripNo(key) {
  if (!key) return '';
  const p = String(key).split(','),
    q = [p[0], p[1], p[2], p[3], p[5]].join(',');
  if (!TRN.m) {
    TRN.m = {};
    const add = (kind, rows, ti) =>
      (rows || []).forEach((r) => {
        const x = [kind, r[0], r[1], r[2], r[ti]].join(',');
        if (!(x in TRN.m)) TRN.m[x] = TRN.c++;
      });
    add('bus', BUS2, 4);
    add('local', LOC2, 9);
    add('air', AIR2, 4);
  }
  if (!(q in TRN.m)) TRN.m[q] = TRN.c++;
  return TRN.m[q];
}
/* صفحة الرحلة الموحّدة: النقل الدولي + الرحلات المحلية (نسخة واحدة فقط، شكل المرجع) */
function tripDetail(o) {
  const k = o.k,
    { C } = compactInfo(o),
    c = o.custom || {},
    cur = curOf(o),
    pr = tp(o, o.tier || 0) || o.pr,
    rs = ratingStats(o);
  const stops =
    k == 'air'
      ? c.route && String(c.route).trim()
        ? C.route
        : []
      : C.route && C.route.length
        ? C.route
        : via(o) || [o.from, o.to].filter(Boolean);
  const src = o.ph && IM[o.ph] ? ari(o.ph) : rp(o),
    pickup = k == 'air' ? String(C.pickup || '').trim() : pickupOf(o, C);
  const D = DPT[k] || DPT.bus,
    rq = customList(c, 'req', o.dom ? ['بطاقة هوية أو جواز سفر ساري', 'الالتزام بموعد الرحلة والحضور قبل الانطلاق بنصف ساعة'] : D.rq),
    wn = customList(c, 'warn', D.wn);
  const sub = o.cr ? crl(o) : '';
  const cell = (l, v, x) => `<div class="${x || ''}"><small>${l}</small><b>${v}</b></div>`;
  return `<div class="dp trip">${dpHead(k, o.n, sub, officeLoc(o))}${ofBar()}
<div class="dpHero bus"><img src="${src}" alt="" onerror="fb(this,'${k == 'local' ? 'p_van1' : k == 'air' ? 'p_air_a' : 'p_bus1'}')"><span class="dpRate">تقييم العملاء (${rs.count}) ★</span><button class="dpRateBtn" type="button" onclick="openRateOffice()">★ قيّم بالنجوم</button></div>
${dpContact(0)}
<div class="dpRoute">${DPI.pin}<span>${ht(o.from || '')}</span><em>←</em><span>${ht(o.to || '')}</span><small class="tno">رقم الرحلة ${tripNo(o.key)}</small></div>
<div class="dpInfo wr one">${cell(k == 'air' ? 'سعر التذكرة' : 'سعر المقعد', cur + pr + (o.old ? ' <s>' + cur + o.old + '</s>' : ''), 'pr')}${k == 'air' ? cell('شركة الطيران', ht(o.cr || 'حسب الحجز')) : cell(o.priv ? 'نوع السيارة' : 'نوع الباص', ht(o.ty || '—'))}${cell(k == 'air' ? 'موعد الإقلاع' : 'موعد الانطلاق', ht(o.time || '—'))}${cell('تاريخ الرحلة', ht(o.date || '—'))}${cell('المقاعد المتاحة', ht(String(o.left ?? o.se ?? '—')))}</div>
${dpTW({ rq, wn })}
${k == 'bus' || k == 'air' ? dpSup() : ''}
${pickup ? `<div class="dpH sm">موقع التجمع للمغادرة</div><div class="dpLoc">${DPI.pin}<span>${ht(pickup)}</span></div>` : ''}${o.dom ? `<div class="dpH sm">مرونة وقت الانطلاق</div><div class="dpLoc"><span>⏱ يمكن تقديم أو تأخير الانطلاق حتى 30 دقيقة، ويؤكد لك المكتب الموعد النهائي بعد الحجز.</span></div>` : ''}
${stops.length ? `<div class="dpH sm">مسار الرحلة</div><div class="dpPath"><div class="dpTl">${stops.map((x, i) => `<div><i>${i + 1}</i><b>${ht(x)}</b></div>`).join('')}</div><small>المحطات توضيحية وقد تختلف حسب مسار المكتب.</small></div>` : ''}
<div class="dpFine">${DPFINE}</div>
<div class="dpCta"><button type="button" onclick="if(!tripGoneGuard(S.o))go('book')">ابدأ الحجز الآن</button></div></div>`;
}
function det(i) {
  if (OFF[i].left === 0) return toast('المقاعد مكتملة لهذه الرحلة');
  if (OFF[i].reserved) return toast('هذه السيارة غير متاحة حالياً — محجوزة من عميل آخر');
  if (OFF[i].gone) return toast(TRIP_GONE_MSG);
  S.ofm = null;
  S.o = OFF[i];
  S.tier = S.o.tier || 0;
  S.v = nv();
  S.fl = {};
  S.fu = {};
  S.tab = 'z';
  go('detail');
}
/* رقم الرحلة التسلسلي: يبدأ من 10 ويزيد واحدًا لكل رحلة، ثابت لكل المستخدمين ويُستخدم للتواصل مع المكتب */
const TRN = { m: null, c: 10 };
