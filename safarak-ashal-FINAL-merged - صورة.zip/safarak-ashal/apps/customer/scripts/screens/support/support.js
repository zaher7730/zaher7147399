/* شاشات تذاكر الدعم: القائمة، النموذج الجديد، والمحادثة داخل التذكرة
   يعرّف: tickets، tkdet، tkForm، TKS، TKK، tkDraft */
const TKS = { open: ['مفتوحة', 'wr'], pending: ['تم الرد عليك', 'bu'], resolved: ['تم الحل', 'ok'], closed: ['مغلقة', 'bu'] },
  TKK = { support: 'استفسار', dispute: 'نزاع أو شكوى', data_deletion: 'طلب حذف الحساب' };
const tkDraft = (id) => ht(SA_tk.draft[id] || '');
const tickets = () => {
  if (!S.u.in) return back('تذاكر الدعم', 'more') + '<div class="sec"><p class="pp">سجّل الدخول لفتح تذكرة دعم ومتابعة الردود عليها.</p></div>';
  if (!SA_tk.loaded && !SA_tk.busy) SA_loadTickets();
  if (SA_tk.form) return tkForm();
  return (
    back('تذاكر الدعم', 'more') +
    `<div class="sec"><p class="pp">افتح تذكرة لأي استفسار أو شكوى، وتابع ردود فريق الدعم هنا.</p><button class="gb w" onclick="SA_newTicket()">+ تذكرة جديدة</button></div>` +
    ((SA_tk.list || [])
      .map((t) => {
        const s = TKS[t.status] || [t.status, 'wr'];
        return `<div class="sec" style="cursor:pointer" onclick="SA_showTicket(${t.id})"><div style="display:flex;align-items:center;gap:8px"><b style="flex:1">${ht(t.subject)}</b><span class="pl ${s[1]}">${s[0]}</span></div><small class="pp">${TKK[t.kind] || ''}${t.booking_public_id ? ' · طلب ' + ht(t.booking_public_id) : ''} · ${fmt(SA_ts(t.updated_at))}</small></div>`;
      })
      .join('') || (SA_tk.loaded ? '<div class="sec"><p class="pp">لا توجد تذاكر بعد.</p></div>' : '<div class="sec"><p class="pp">جارٍ التحميل…</p></div>'))
  );
};
const tkForm = () =>
  `<div class="cmp"><div class="tt"><button class="bk" onclick="SA_tk.form=0;render()">‹</button><h1>تذكرة جديدة</h1></div><div class="g2"><div class="full"><label>نوع التذكرة</label><div class="fi"><select id="tk_k" class="f"><option value="support">استفسار أو مساعدة</option><option value="dispute">نزاع أو شكوى على طلب</option></select></div></div><div class="full"><label>الطلب المرتبط (اختياري)</label><div class="fi"><select id="tk_o" class="f"><option value="">بدون طلب محدد</option>${(S.ord || []).map((o) => `<option value="${ht(o.id)}">${ht(o.id)} · ${ht(ttl(o))}</option>`).join('')}</select></div></div><div class="full"><label>الموضوع</label><div class="fi"><input id="tk_s" class="f" maxlength="200" value="${tkDraft('tk_s')}" oninput="SA_tk.draft.tk_s=this.value"></div></div><div class="full"><label>التفاصيل</label><div class="fi"><textarea id="tk_b" class="f" rows="5" maxlength="4000" oninput="SA_tk.draft.tk_b=this.value">${tkDraft('tk_b')}</textarea></div></div></div><div style="height:10px"></div><button class="gb w" onclick="SA_createTicket()">إرسال التذكرة</button></div>`;
const tkdet = () => {
  const t = SA_tk.cur;
  if (!t) return back('التذكرة', 'tickets') + '<div class="sec"><p class="pp">لم يتم اختيار تذكرة.</p></div>';
  const s = TKS[t.status] || [t.status, 'wr'],
    closed = t.status === 'closed';
  return (
    back('التذكرة', 'tickets') +
    `<div class="sec"><div style="display:flex;align-items:center;gap:8px"><b style="flex:1">${ht(t.subject)}</b><span class="pl ${s[1]}">${s[0]}</span></div><small class="pp">${TKK[t.kind] || ''}${t.booking_public_id ? ' · طلب ' + ht(t.booking_public_id) : ''} · ${fmt(SA_ts(t.created_at))}</small></div>` +
    (SA_tk.msgs || [])
      .map(
        (m) =>
          `<div class="sec" style="${m.sender_role === 'admin' ? 'border-color:var(--gold,#c9951d)' : ''}"><small class="pp"><b>${m.sender_role === 'admin' ? 'فريق الدعم' : 'أنت'}</b> · ${fmt(SA_ts(m.created_at))}</small><p class="pp" style="white-space:pre-wrap;margin-top:6px;color:var(--tx,#17213a);font-size:14px;line-height:1.8">${ht(m.body)}</p>${m.file_id ? `<a href="/api/files/${ht(m.file_id)}" target="_blank" rel="noopener">📎 مرفق</a>` : ''}</div>`,
      )
      .join('') +
    (closed
      ? '<div class="sec"><p class="pp">هذه التذكرة مغلقة. افتح تذكرة جديدة إن احتجت مساعدة أخرى.</p></div>'
      : `<div class="sec"><label style="font-size:12px;font-weight:700">ردّك</label><div class="fi"><textarea id="tk_r" class="f" rows="3" maxlength="4000" oninput="SA_tk.draft.tk_r=this.value">${tkDraft('tk_r')}</textarea></div><div style="height:8px"></div><button class="gb w" onclick="SA_replyTicket()">إرسال الرد</button></div>`)
  );
};
