/* صفحة الرحلات المحلية — الجزء 1/2
   يعرّف: localPage، LCP */
function localPage() {
  const F = S.F.local || (S.F.local = {}),
    d = S.d.local || 0;
  OFF = [];
  const L = LOC2.filter(
    (r) =>
      (!r.rv || (F.f && F.t)) &&
      (!F.f || r[1] == F.f) &&
      (!F.t || r[2] == F.t) &&
      r[3].includes(d),
  ).sort((a, b) => arTm(a[9]) - arTm(b[9]));
  const dts = DATES.map(
    (x) => `<button class="arDy ${d == x.n ? 'on' : ''}" onclick="S.d['local']=${x.n};render()">${x.w}<b>${x.d}</b>${x.m}</button>`,
  ).join('');
  const cards = L.map((r, j) => {
    const key = ['local', r[0], r[1], r[2], d, r[9]].join(),
      se = r[5] - (S.bk[key] || 0),
      tier = r[8] || 0,
      full = se <= 0;
    const st = tripStatus(d, r[9]),
      gone = st.gone,
      red = gone || full,
      bd = full ? 'المقاعد مكتملة' : st.label;
    const ph = 'lc_' + (r[10] % 3),
      o = {
        key,
        left: se,
        tot: r[5],
        tier,
        n: r[0],
        k: 'local',
        cr: '',
        t: r[1] + ' ← ' + r[2],
        from: r[1],
        to: r[2],
        pr: r[6],
        old: r[7],
        date: DATES[d].full,
        time: r[9],
        ty: r[4],
        se,
        ph: 'p_van1',
        li: r[10] % 3,
        bd,
        br: red,
        vip: tier == 2,
        gone,
      };
    const i = OFF.push(o) - 1,
      src = ari(ph),
      ft = LCF[tier] || LCF[0];
    return `<div class="arCard"><div class="arDet"><div class="arName"><span class="t">${r[0]}</span><span class="v"></span></div><div class="arChips"><span class="c1">سائق معتمد وموثق</span><span class="c2">${r[4]}</span></div><div class="arRoute"><span class="pn">${ARI.pin}<span>${r[1]}</span></span><span class="ln"></span><span class="pn r">${ARI.pin}<span>${r[2]}</span></span></div><div class="arSpec"><div>${ARI.busS}<p><small>نوع الباص</small>${ARL[tier]}</p></div><div>${ARI.clock}<p><small>الانطلاق</small>${r[9]}</p></div><div>${ARI.cal}<p><small>التاريخ</small>${DATES[d].full}</p></div><div>${ARI.seat}<p><small>المقاعد المتاحة</small>${full ? 'مكتمل' : se + ' مقعد'}</p></div></div><div class="arFeat">${ft.map((x) => `<span>${ARI[x[0]]}${x[1]}</span>`).join('')}</div><div class="arBot"><button class="arBook ${full ? 'dis' : ''}" onclick="det(${i})">ابدأ الحجز${ARI.left}</button><div class="arPrice"><small>السعر للشخص</small>${r[7] ? `<s>${curOf(r)}${r[7]}</s>` : ''}<b>${curOf(r)}${r[6]}</b></div></div></div><div class="arPic bus"><img class="bg" src="${src}" alt="" aria-hidden="true"><img class="fg" src="${src}" loading="lazy" alt="${r[1]} ${r[2]}" onerror="fb(this,'p_van1')"><span class="arSt ${red ? 'bad' : 'ok'}">${bd}</span><span class="arVip ${tier == 2 ? '' : 'n'}">${ARL[tier]}</span></div></div>`;
  }).join('');
  const empty = `<div class="empty"><b>🔍</b>لا توجد رحلات في هذا التاريخ${F.f || F.t ? ' لهذا المسار' : ''}<br>جرّب تاريخاً أو مدينة أخرى${nx('local', LOC2)}</div>`;
  return `<div class="arp"><div class="arHead"><div class="arTit"><h1>رحلات محلية</h1><p>رحلات بين المدن من مكاتب مسجلة</p></div><button class="arBack" onclick="bk('home')" aria-label="رجوع">${ARI.back}</button></div>${lcSel('local')}<div class="arDates">${dts}</div><div class="crSep"><b>اختر من بين العروض</b></div><div class="crSub">اسحب للأسفل لعرض المزيد من العروض</div><div class="arList">${cards || empty}</div></div>`;
}
/* ===== SAFARAK ASHAL LOCAL TRIPS PAGE (reference design) ===== */
const LCP = [
  '/apps/customer/assets/images/local-trips-1.jpg',
  '/apps/customer/assets/images/local-trips-2.jpg',
  '/apps/customer/assets/images/local-trips-3.jpg',
];
