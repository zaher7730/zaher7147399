/* صفحة الرحلات المحلية — الجزء 2/2
   يعرّف: lcSel، LCF */
const lcSel = (k) => {
  const F = S.F[k] || (S.F[k] = {}),
    c = (f, lab) =>
      `<button class="lcCity" onclick="setF('${k}','${f}','${lab}',CT.${k},1)"><span class="pi">${ARI.pin}</span><span class="tx"><small>اختر المدينة</small><b class="${F[f] ? '' : 'lcph'}">${F[f] || lab}</b></span>${ARI.chev}</button>`;
  return `<div class="lcSel">${c('f', 'من')}${c('t', 'إلى')}<button class="lcSw" onclick="swap('${k}')" aria-label="تبديل">${ARI.swap}</button></div>`;
};
const LCF = [
  [
    ['seat', 'مقعد مشترك مكيّف'],
    ['bag', 'حقيبة صغيرة'],
    ['thumb', 'سائق خبير بالطريق'],
  ],
  [
    ['seat', 'مقعد أمامي أو بجوار النافذة'],
    ['bag', 'حقيبة كبيرة'],
    ['thumb', 'موعد انطلاق محدد'],
  ],
  [
    ['seat', 'مركبة VIP خاصة'],
    ['food', 'ماء ومشروبات'],
    ['thumb', 'توصيل لنقطة قريبة'],
  ],
];
LCP.forEach((s, i) => {
  IM['lc_' + i] = s;
});
