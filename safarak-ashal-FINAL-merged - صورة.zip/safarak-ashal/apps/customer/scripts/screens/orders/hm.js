/* طلباتي وتفاصيل الطلب — الجزء 1/2
   يعرّف: hm، SC، paid، ttl، BN، bn */
const hm = (t) => {
    const d = new Date(t),
      h = d.getHours();
    return (h % 12 || 12) + ':' + String(d.getMinutes()).padStart(2, '0') + ' ' + (h < 12 ? 'ص' : 'م');
  },
  fmt = (t) => {
    const d = new Date(t);
    return DN[d.getDay()] + ' ' + d.getDate() + ' ' + MN[d.getMonth()] + ' ' + d.getFullYear() + ' · ' + hm(t);
  },
  day = (t) => {
    const d = new Date(t);
    return d.toDateString() == new Date().toDateString() ? 'اليوم' : DN[d.getDay()] + ' ' + d.getDate() + ' ' + MN[d.getMonth()];
  };
const SC = ['wr', 'bu', 'ok', 'rd', 'wr', 'bu', 'rd'],
  PG = [25, 60, 100, 0, 40, 75, 0],
  OI = { bus: '🚌', local: '🚐', air: '✈️', cars: '🚗', pass: '🛂', visa: '🕋' };
const paid = (x) => ([3, 5, 6].includes(x.st) ? 0 : x.t),
  sz = (b) => (b > 1048576 ? (b / 1048576).toFixed(1) + ' ميجابايت' : Math.max(1, Math.round(b / 1024)) + ' كيلوبايت');
const ttl = (x) =>
  x.xr
    ? x.o.t
    : x.o.svc
      ? x.o.svc + ' — باقة ' + TQ(x.o)[x.tier || 0].n
      : (x.o.priv
          ? x.o.dom
            ? 'رحلة خاصة داخلية'
            : 'رحلة خاصة'
          : { bus: 'النقل الدولي', local: 'رحلة محلية', air: 'طيران', cars: 'تأجير سيارة' }[x.o.k]) +
        ' — ' +
        x.o.t;
const BN = [
  ['✅', 'كل شيء جاهز — بانتظار مراجعة المكتب', 'ok'],
  ['⚙️', 'المكتب ينفذ طلبك الآن', 'bu'],
  ['🎉', 'اكتمل الطلب بنجاح', 'ok'],
  ['⛔', 'تم رفض الطلب من المكتب', 'rd'],
  ['📎', 'مطلوب مستندات — أرسلها في الرسائل', 'wr'],
  ['💳', 'بانتظار إتمام الدفع', 'wr'],
  ['🚫', 'تم إلغاء الطلب', 'rd'],
];
const bn = (x) => {
    const b = BN[x.st];
    return `<div class="bn ${b[2]}"><span>${b[0]}</span>${b[1]}</div>`;
  },
  sq = (t, c) => `<i class="sq ${c}">${t}</i>`;
const chp = (x) =>
  x.xr
    ? x.st == 3 || x.st == 6
      ? [sq('✖ مغلق', 'rd')]
      : [sq('✔ تم الإرسال', 'ok')]
    : x.st == 3 || x.st == 6
      ? [sq('✖ مغلق', 'rd')]
      : [
          sq('✔ البيانات', 'ok'),
          x.st == 4 ? sq('ناقص توثيق', 'wr') : sq('✔ المستندات', 'ok'),
          x.st == 5 ? sq('ناقص دفع', 'wr') : sq('✔ مدفوع', 'ok'),
        ];
const orders = () => {
  sync();
  const L = S.ord,
    c = (x) => x.o.cur || CFG.cur || 'YER';
  return (
    `<div class="kk">سجل الطلبات</div><div class="oh"><div><h1 class="h1">طلباتي</h1><p class="sub">${L.length} طلب مرتبط بمكاتب وخدمات مختلفة</p></div><button class="nb" onclick="S.hist=[];go('home')">+ طلب جديد</button></div>` +
    (L.map(
      (x) =>
        `<div class="ord" onclick="S.cur='${x.id}';go('odetail')"><div class="otop">${bn(x)}<div class="sqs">${chp(x).join('')}</div></div><div class="ot"><span class="oi">${OI[x.o.k]}</span><div><b>${ttl(x)}</b><small>${x.o.n}</small></div></div><div class="ometa"><div>رقم الطلب<b class="cd">${x.id}</b></div><div>رقم الفاتورة<b class="cd">${x.inv}</b></div><div style="grid-column:1/-1">تاريخ العملية<b>${fmt(x.ts)}</b></div></div>${x.xr ? '' : `<div class="of"><span>المبلغ المدفوع</span><span><b>${c(x)}${paid(x)}</b> من ${c(x)}${x.t}</span></div>`}<div class="pb"><i class="${SC[x.st]}" style="width:${PG[x.st]}%"></i></div></div>`,
    ).join('') || '<div class="empty"><b>📋</b>لا توجد طلبات بعد</div>')
  );
};
