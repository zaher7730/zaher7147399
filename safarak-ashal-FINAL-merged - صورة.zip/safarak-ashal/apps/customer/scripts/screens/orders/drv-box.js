/* طلباتي وتفاصيل الطلب — الجزء 2/2
   يعرّف: drvBox، odetail، mkc، oco */
const drvBox = (x) => {
  if (!x.o || !x.o.dom || (x.st != 1 && x.st != 2)) return '';
  const n = x.o.custom && x.o.custom.driver,
    p = x.o.custom && x.o.custom.driverPhone;
  if (!n && !p)
    return '<div class="sec"><h4>بيانات السائق</h4><p class="pp">سيُعرض اسم السائق ورقم التواصل هنا بعد أن يحددهما المكتب.</p></div>';
  return `<div class="sec"><h4>بيانات السائق</h4>${n ? `<div class="kv"><span>اسم السائق</span><b>${ht(n)}</b></div>` : ''}<div class="kv"><span>السيارة</span><b>${ht(x.o.ty || '-')}</b></div>${p ? `<div class="kv"><span>رقم السائق</span><b dir="ltr">${ht(p)}</b></div><div class="chips" style="justify-content:center"><button onclick="location.href='tel:${ht(p)}'">اتصال بالسائق</button></div>` : ''}</div>`;
};
const odetail = () => {
  sync();
  const i = S.ord.findIndex((o) => o.id == S.cur),
    x = S.ord[i];
  if (!x) return orders();
  const c = curOf(x.o),
    bad = x.st == 3 || x.st == 6,
    lv = [0, 1, 2, 0, 0, 1, 0][x.st],
    K = (a, b) => `<div class="kv"><span>${a}</span><b>${b}</b></div>`;
  return (
    back('تفاصيل الطلب', 'orders') +
    `<div class="sec"><div class="otop">${bn(x)}<div class="sqs">${chp(x).join('')}</div></div><div class="ot"><span class="oi">${OI[x.o.k]}</span><div><b>${ttl(x)}</b><small>${x.o.n}</small></div><span class="pl ${SC[x.st]}">${ST_[x.st]}</span></div><div class="trk">${[0, 1, 2].map((j) => `<i class="${!bad && j <= lv ? 'on' : ''}"></i>`).join('')}</div><p class="hint">${HT[x.st]}</p></div><div class="sec"><h4>بيانات العملية</h4>${K('رقم الطلب', '<span class="cd">' + x.id + '</span>')}${K('رقم الفاتورة', '<span class="cd">' + x.inv + '</span>')}${K('يوم وتاريخ وساعة العملية', fmt(x.ts))}${K('المكتب', x.o.n)}${K('الخدمة', x.o.t)}${x.xr ? K('رقم الجواز', ht(x.pp)) + (x.nt ? K('الملاحظة', ht(x.nt)) : '') : K('الباقة', TQ(x.o)[x.tier || 0].n)}${x.seat ? K('المقعد', x.seat) : ''}${x.fc ? K('نوع الحجز', 'السيارة كاملة') : ''}${x.tt ? K('نوع الرحلة', x.tt) : ''}${x.dep ? K('مبلغ الضمان', c + x.dep) : ''}${x.pm ? K('وسيلة الدفع', x.pm) : ''}${x.o.date ? K('موعد الخدمة', x.o.date + (x.o.time ? ' · ' + x.o.time : '')) : ''}${x.xr ? '' : K(x.o.k == 'cars' ? 'عدد الأيام' : 'عدد الأفراد', x.pax) + K('الإجمالي', c + x.t) + K('المدفوع', c + paid(x))}${K('مقدم الطلب', ht(x.n || '-') + (x.ph ? ' · ' + ht(x.ph) : ''))}</div>${drvBox(x)}${pendingPayBox(x)}${onlinePayBox(x)}<button class="gb w" onclick="S.cur='${x.id}';go('chat')">💬 راسل المكتب</button><div class="chips" style="justify-content:center"><button onclick="waO()">واتساب</button>${x.st == 0 ? `<button onclick="cancelO(${i})">إلغاء الطلب</button>` : ''}</div>`
  );
};
const mkc = (id) => cvFor(id);
const oco = (i) => {
  S.cur = 'O' + i;
  go('chat');
};
