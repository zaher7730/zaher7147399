/* حالة الرحلة بالوقت الحقيقي (النقل الدولي، الطيران، الرحلات المحلية، الرحلات الخاصة)
   يعرّف: tripDepartMs، tripHoursAr، tripStatus، TRIP_GONE_MSG، tripDayOf، tripDepartDate، tripGoneGuard */
/* موعد المغادرة بالميلي ثانية: اليوم المختار (0 = اليوم) + وقت الانطلاق */
function tripDepartMs(dayIndex, timeText) {
  const base = new Date(TODAY);
  base.setHours(0, 0, 0, 0);
  base.setDate(base.getDate() + Number(dayIndex || 0));
  return base.getTime() + arTm(timeText) * 60000;
}
const tripHoursAr = (h) => (h === 1 ? 'ساعة' : h === 2 ? 'ساعتين' : h <= 10 ? h + ' ساعات' : h + ' ساعة');
/* {gone, label}: الرحلة التي غادرت تبقى ظاهرة بحالة «الرحلة غادرت» ولا يُسمح بحجزها */
function tripStatus(dayIndex, timeText, nowMs) {
  if (!/\d/.test(String(timeText == null ? '' : timeText))) return { gone: false, label: 'متاحة للحجز' };
  const diff = tripDepartMs(dayIndex, timeText) - (nowMs || Date.now());
  if (diff <= 0) return { gone: true, label: 'الرحلة غادرت' };
  const mins = Math.ceil(diff / 60000);
  if (mins < 60) return { gone: false, label: 'بعد ' + mins + ' دقيقة' };
  if (mins < 1440) return { gone: false, label: 'بعد ' + tripHoursAr(Math.floor(mins / 60)) };
  return { gone: false, label: 'متاحة للحجز' };
}

/* الرحلات التي لها وقت انطلاق: النقل الدولي، الطيران، المحلية، الخاصة */
const TRIP_TIMED = ['bus', 'air', 'local', 'priv'];
const TRIP_GONE_MSG = 'الرحلة غادرت — اختر رحلة أخرى';
/* ترتيب يوم الرحلة المختار في DATES من التاريخ المعروض على العرض؛ -1 إن لم يُحدَّد */
const tripDayOf = (o) => (o && o.date ? DATES.findIndex((x) => x.full === o.date) : -1);
/* تاريخ يوم الرحلة بصيغة YYYY-MM-DD لإرساله للخادم (يفحص به أن الرحلة لم تغادر)؛ فارغ إن لم يُحدَّد */
function tripDepartDate(o) {
  const i = tripDayOf(o);
  if (i < 0) return '';
  const d = new Date(TODAY);
  d.setDate(d.getDate() + i);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
/* حارس الحجز: يعمل في كل المسارات (القوائم، صفحة المكتب، تغيير التاريخ). يعرض الرسالة ويعيد true إن كان الحجز ممنوعاً */
function tripGoneGuard(o) {
  if (!o || TRIP_TIMED.indexOf(o.k) < 0 || !/\d/.test(String(o.time == null ? '' : o.time))) return false;
  const i = tripDayOf(o);
  if (i < 0) {
    toast('لا توجد مواعيد متاحة لهذه الرحلة حالياً');
    return true;
  }
  if (!tripStatus(i, o.time).gone) return false;
  toast(TRIP_GONE_MSG);
  return true;
}
