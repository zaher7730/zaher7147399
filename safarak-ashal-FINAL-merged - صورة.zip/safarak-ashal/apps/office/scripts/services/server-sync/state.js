/* حفظ بيانات المكتب في الخادم: الملف، الإعدادات، الأمانات، مستندات العملاء، التوثيق
   الصور: الشعار/الغلاف/المعرض/QR أصول عامة، ووثائق الملكية والمرفقات ملفات خاصة (لا تُخزَّن داخل JSON).
   يعرّف: SA_loadOfficeState، SA_scheduleOfficeState، SA_flushOfficeState، SA_submitVerification، SA_applyOfficeState، SA_officeBody، SA_resolveConflict */
const SA_DATA_URL = /^data:(image\/(?:jpeg|png|webp)|application\/pdf);base64,/i,
  SA_DOC_KEYS = ['licImg', 'crImg', 'idImg', 'taxImg'];
let SA_stateVersion = null,
  SA_stateTimer = null,
  SA_stateBusy = false,
  SA_stateDirty = false;
let SA_baseSnap = {};
const SA_uploaded = new Map();
const SA_extOf = (mime) => ({ 'application/pdf': 'pdf', 'image/png': 'png', 'image/webp': 'webp' })[mime] || 'jpg';
const SA_sig = (d) => d.length + ':' + d.slice(40, 100) + d.slice(-60);
async function SA_uploadPrivate(dataUrl, name) {
  const k = 'p' + SA_sig(dataUrl);
  if (SA_uploaded.has(k)) return SA_uploaded.get(k);
  const mime = dataUrl.match(SA_DATA_URL)[1].toLowerCase();
  const r = await window.SA_API.uploadFile({ filename: name + '.' + SA_extOf(mime), mimeType: mime, base64: dataUrl });
  const v = { id: r.file.id, url: '/api/files/' + r.file.id + (mime.startsWith('image/') ? '?inline=1' : '') };
  SA_uploaded.set(k, v);
  return v;
}
async function SA_uploadPublic(dataUrl, name) {
  const k = 'a' + SA_sig(dataUrl);
  if (SA_uploaded.has(k)) return SA_uploaded.get(k);
  const mime = dataUrl.match(SA_DATA_URL)[1].toLowerCase();
  const r = await window.SA_API.uploadOfferAsset({ filename: name + '.' + SA_extOf(mime), mimeType: mime, base64: dataUrl });
  const v = { id: r.asset.id, url: r.asset.url };
  SA_uploaded.set(k, v);
  return v;
}
/* يستبدل أي data: URL داخل الكائن بملف خاص مرفوع */
async function SA_offload(node, path) {
  if (!node || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    const v = node[k];
    if (typeof v === 'string' && SA_DATA_URL.test(v)) node[k] = (await SA_uploadPrivate(v, path + '_' + k)).url;
    else if (v && typeof v === 'object') await SA_offload(v, path + '_' + k);
  }
}
async function SA_uploadAll() {
  const pf = D.pf;
  for (const k of ['logo', 'cover']) {
    if (typeof pf[k] === 'string' && SA_DATA_URL.test(pf[k])) {
      const a = await SA_uploadPublic(pf[k], k);
      pf[k] = a.url;
      pf[k + 'AssetId'] = a.id;
    }
  }
  if (Array.isArray(pf.gal))
    for (let i = 0; i < pf.gal.length; i++) if (typeof pf.gal[i] === 'string' && SA_DATA_URL.test(pf.gal[i])) pf.gal[i] = (await SA_uploadPublic(pf.gal[i], 'gal' + i)).url;
  if (D.cfg && typeof D.cfg.qr === 'string' && SA_DATA_URL.test(D.cfg.qr)) D.cfg.qr = (await SA_uploadPublic(D.cfg.qr, 'qr')).url;
  for (const k of SA_DOC_KEYS) {
    if (typeof pf[k] === 'string' && SA_DATA_URL.test(pf[k])) {
      const f = await SA_uploadPrivate(pf[k], k);
      pf[k] = f.url;
      pf[k + 'Id'] = f.id;
    }
  }
  await SA_offload(D.cd, 'cd');
  await SA_offload(D.am, 'am');
}
const SA_publicProfile = () => {
  const p = D.pf;
  return {
    displayName: p.name,
    city: p.city,
    address: p.addr,
    years: p.years,
    phone: p.phone,
    whatsapp: p.wa,
    licenseNo: p.lic,
    registrationNo: p.cr,
    about: p.about,
    logoAssetId: p.logoAssetId || undefined,
    coverAssetId: p.coverAssetId || undefined,
    extra: { hours: p.hours, email: p.email, web: p.web, langs: p.langs, branches: p.branches, fb: p.fb, ig: p.ig, x: p.x, tk: p.tk, vac: p.vac, gal: p.gal || [] },
  };
};
/* جسم الحفظ: أجزاء بيانات المكتب بدون كلمة المرور المحلية */
function SA_officeBody() {
  const { pwh, pwd, ver, ...pf } = D.pf;
  return JSON.parse(JSON.stringify({ pf, cfg: D.cfg, sv: D.sv, am: D.am, cd: D.cd }));
}
const SA_snapOf = (body) => Object.fromEntries(Object.keys(body).map((k) => [k, JSON.stringify(body[k])]));
/* يطبّق بيانات قادمة من الخادم على الذاكرة (يحافظ على اسم المكتب ورقمه المحلي) */
function SA_applyOfficeState(v, only) {
  const on = (k) => !only || only.includes(k);
  if (on('pf')) D.pf = Object.assign(D.pf, v.pf || {}, { name: D.pf.name, phone: D.pf.phone, lph: D.pf.lph });
  if (on('cfg')) D.cfg = Object.assign(D.cfg, v.cfg || {});
  if (on('sv')) D.sv = Object.assign(D.sv, v.sv || {});
  if (on('am')) D.am = Array.isArray(v.am) ? v.am : [];
  if (on('cd')) D.cd = v.cd && typeof v.cd === 'object' ? v.cd : {};
}
/* تعارض مع جهاز آخر: نجلب النسخة الحالية، ونأخذ منها كل جزء لم نغيّره هنا، ونُبقي ما غيّرناه نحن، ثم نحفظ برقم النسخة الجديد */
async function SA_resolveConflict(body) {
  const cur = await window.SA_API.getState('office-data');
  const remote = cur.value || {};
  const keep = Object.keys(body).filter((k) => SA_baseSnap[k] === undefined || JSON.stringify(body[k]) !== SA_baseSnap[k]);
  const take = Object.keys(body).filter((k) => !keep.includes(k) && remote[k] !== undefined);
  SA_applyOfficeState(remote, take);
  const merged = SA_officeBody();
  const r = await window.SA_API.putState('office-data', merged, cur.version);
  SA_baseSnap = SA_snapOf(merged);
  return { ...r, merged: 1 };
}
async function SA_flushOfficeState() {
  if (!window.SA_API || !OK) return;
  if (SA_stateBusy) {
    SA_stateDirty = true;
    return;
  }
  SA_stateBusy = true;
  try {
    await SA_uploadAll();
    const body = SA_officeBody();
    const r = await window.SA_API.putState('office-data', body, SA_stateVersion).catch(async (e) => {
      if (e.status !== 409 && e.status !== 428) throw e;
      return SA_resolveConflict(body);
    });
    SA_stateVersion = r.version;
    if (!r.merged) SA_baseSnap = SA_snapOf(body);
    if (D.pf.name) await window.SA_API.saveOfficeProfile(SA_publicProfile());
  } catch (e) {
    toast(e.message || 'تعذر حفظ التغييرات في الخادم');
  } finally {
    SA_stateBusy = false;
    if (SA_stateDirty) {
      SA_stateDirty = false;
      SA_scheduleOfficeState();
    }
  }
}
function SA_scheduleOfficeState() {
  clearTimeout(SA_stateTimer);
  SA_stateTimer = setTimeout(SA_flushOfficeState, 700);
}
const SA_VERMAP = { approved: 2, pending: 1, rejected: 0 };
async function SA_loadOfficeState(user) {
  const [st, pr, vf] = await Promise.allSettled([window.SA_API.getState('office-data'), window.SA_API.officeProfile(), window.SA_API.officeVerification()]);
  if (st.status === 'fulfilled' && st.value.value) {
    const v = st.value.value;
    SA_stateVersion = st.value.version;
    SA_applyOfficeState(v);
    SA_baseSnap = SA_snapOf(SA_officeBody());
  }
  const p = pr.status === 'fulfilled' ? pr.value.profile : null;
  if (p) {
    Object.assign(D.pf, {
      name: p.displayName || D.pf.name,
      city: p.city || D.pf.city,
      addr: p.address || D.pf.addr,
      years: p.years || D.pf.years,
      wa: p.whatsapp || D.pf.wa,
      about: p.about || D.pf.about,
      logo: p.logo || D.pf.logo,
      cover: p.cover || D.pf.cover,
      logoAssetId: p.logoAssetId || D.pf.logoAssetId || '',
      coverAssetId: p.coverAssetId || D.pf.coverAssetId || '',
    });
    if (p.licenseNo) D.pf.lic = p.licenseNo;
    if (p.registrationNo) D.pf.cr = p.registrationNo;
    D.pf.ver = p.verified ? 2 : D.pf.ver || 0;
  }
  const v = vf.status === 'fulfilled' ? vf.value.verification : null;
  if (v) {
    Object.assign(D.pf, { lname: v.legalName, owner: v.ownerName, ownerId: v.ownerId || '', lic: v.licenseNo, cr: v.registrationNo, tax: v.taxNo, issuer: v.issuer, issued: v.issuedAt, expiry: v.expiresAt, verNote: v.note || '' });
    for (const k of SA_DOC_KEYS) if (v.files && v.files[k]) (D.pf[k + 'Id'] = v.files[k]), (D.pf[k] = D.pf[k] || '/api/files/' + v.files[k] + '?inline=1');
    D.pf.ver = SA_VERMAP[v.status] ?? 0;
  }
}
async function SA_submitVerification() {
  const p = D.pf;
  if (!window.SA_API) return false;
  try {
    await SA_flushOfficeState();
    while (SA_stateBusy) await new Promise((r) => setTimeout(r, 100));
    const files = {};
    for (const k of SA_DOC_KEYS) if (p[k + 'Id']) files[k] = p[k + 'Id'];
    await window.SA_API.submitOfficeVerification({
      legalName: p.lname,
      ownerName: p.owner,
      ownerId: p.ownerId,
      licenseNo: p.lic,
      registrationNo: p.cr,
      taxNo: p.tax,
      issuer: p.issuer,
      issuedAt: p.issued,
      expiresAt: p.expiry,
      files,
    });
    p.ver = 1;
    return true;
  } catch (e) {
    toast(e.message || 'تعذر إرسال طلب التوثيق');
    return false;
  }
}
