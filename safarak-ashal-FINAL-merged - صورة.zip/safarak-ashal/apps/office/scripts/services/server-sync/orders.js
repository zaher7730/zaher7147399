/* تحديث الطلبات والحوالات عند وصول حدث لحظي، وإشعارات المكتب
   يعرّف: SA_refreshOrders، SA_officeOnNotification */
let SA_refreshTimer = null;
function SA_refreshOrders() {
  clearTimeout(SA_refreshTimer);
  SA_refreshTimer = setTimeout(async () => {
    await Promise.allSettled([SA_loadOrders(), SA_loadRemittances()]);
    if (['home', 'orders', 'rem', 'txn', 'customers', 'od'].includes(V)) go();
  }, 300);
}
function SA_officeOnNotification(n) {
  toast(n.title + (n.body ? ' — ' + n.body : ''));
  if (n.kind === 'review') SA_loadReviews().then(() => ['rv', 'home'].includes(V) && go());
  if (['booking_new', 'booking_status', 'payment_new', 'payment_review', 'booking_cancelled'].includes(n.kind) || /booking|payment/.test(n.kind)) SA_refreshOrders();
}
