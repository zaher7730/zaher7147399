/* محادثات المكتب مع العملاء (حقيقية، لحظية، مع مرفقات)
   يعرّف: SA_officeMapMsg، SA_loadOfficeConversations، SA_officeLoadMsgs، SA_officeMarkRead، SA_officeSend، SA_officeSendFile، SA_officeOnMessage، SA_officeOnRead */
function SA_officeMapMsg(m) {
  const o = { id: m.id, me: m.senderId === SA_me.id ? 1 : 0, t: SA_ts(m.createdAt), x: m.body || '', rd: m.readAt ? 1 : 0 };
  if (m.fileId) {
    const img = m.kind === 'image';
    o.f = { n: m.fileName || (img ? 'صورة' : 'ملف'), type: m.fileType || (img ? 'image/jpeg' : 'application/pdf'), data: m.fileUrl + (img ? '?inline=1' : ''), kind: '' };
  }
  return o;
}
let SA_me = { id: 0 };
function SA_chatOf(conv) {
  const ph = conv.customer.phone;
  if (!ph) return null;
  const c = D.ch[ph] || (D.ch[ph] = { name: conv.customer.name || ph, un: 0, m: [] });
  c.cid = conv.id;
  c.name = conv.customer.name || c.name;
  c.un = conv.unread || 0;
  return c;
}
async function SA_loadOfficeConversations() {
  if (!window.SA_API) return;
  try {
    SA_me = (await window.SA_API.me()).user;
    D.ch = {};
    const r = await window.SA_API.conversations();
    r.conversations.forEach((cv) => {
      const c = SA_chatOf(cv);
      if (c && cv.lastBody) c.m.push({ x: cv.lastBody, me: 0, t: SA_ts(cv.lastMessageAt || cv.createdAt), preview: 1 });
    });
  } catch (e) {
    console.warn('تعذر تحميل المحادثات:', e.message);
  }
}
async function SA_officeLoadMsgs(ph) {
  const c = D.ch[ph];
  if (!c || c.busy || !c.cid) return;
  c.busy = true;
  try {
    const r = await window.SA_API.messages(c.cid, 0);
    c.m = r.messages.map(SA_officeMapMsg);
    c.loaded = true;
    if (c.un) SA_officeMarkRead(c);
    if (V === 'chats') SA_officeRerender();
  } catch (e) {
    toast(e.message || 'تعذر تحميل المحادثة');
  } finally {
    c.busy = false;
  }
}
function SA_officeMarkRead(c) {
  c.un = 0;
  if (c.cid) window.SA_API.markRead(c.cid).catch(() => {});
}
/* يضمن وجود محادثة على الخادم لهذا العميل (عبر أي حجز له عند المكتب) */
async function SA_officeEnsureConv(ph, name) {
  const c = D.ch[ph] || (D.ch[ph] = { name: name || ph, un: 0, m: [] });
  if (c.cid) return c;
  const o = D.ord.find((x) => x.ph == ph && x.serverId);
  if (!o) throw new Error('لا يمكن بدء محادثة مع عميل ليس لديه طلب عندك');
  const r = await window.SA_API.openConversation({ bookingId: o.serverId });
  c.cid = r.conversation.id;
  return c;
}
async function SA_officeSend(ph, name, text) {
  const tmp = { me: 1, t: Date.now(), x: text, pending: 1 };
  try {
    const c = await SA_officeEnsureConv(ph, name);
    c.m.push(tmp);
    SA_officeRerender();
    const r = await window.SA_API.sendMessage(c.cid, { body: text });
    Object.assign(tmp, SA_officeMapMsg(r.message), { pending: 0 });
  } catch (e) {
    const c = D.ch[ph];
    if (c) c.m = c.m.filter((m) => m !== tmp);
    toast(e.message || 'تعذر إرسال الرسالة');
  }
  SA_officeRerender();
}
async function SA_officeSendFile(ph, name, f, kind, oid, text) {
  try {
    const c = await SA_officeEnsureConv(ph, name);
    const up = await window.SA_API.uploadFile({ filename: f.n, mimeType: f.type, base64: f.data, bookingId: oid || undefined });
    const r = await window.SA_API.sendMessage(c.cid, { body: text || kind + (oid ? ' · ' + oid : ''), fileId: up.file.id });
    const m = SA_officeMapMsg(r.message);
    m.f.kind = kind;
    c.m.push(m);
    const o = oid && D.ord.find((x) => x.id == oid);
    if (o) {
      o.docs.push({ n: f.n, ok: 1, by: 1, kind, data: '/api/files/' + up.file.id });
      lg(o, 'رفع المكتب «' + kind + '» للعميل: ' + f.n);
    }
    toast('تم إرسال الملف للعميل');
  } catch (e) {
    toast(e.message || 'تعذر إرسال الملف');
  }
  SA_officeRerender();
}
function SA_officeOnMessage(m, reloaded) {
  const c = Object.values(D.ch).find((x) => x.cid === m.conversationId);
  if (!c) {
    SA_loadOfficeConversations().then(() => Object.values(D.ch).some((x) => x.cid === m.conversationId) && SA_officeOnMessage(m, true));
    return;
  }
  if (c.m.some((x) => x.id === m.id)) return;
  c.m = c.m.filter((x) => !x.preview && !(x.pending && m.senderId === SA_me.id && x.x === m.body));
  c.m.push(SA_officeMapMsg(m));
  if (m.senderId === SA_me.id) return SA_officeRerender();
  const ph = Object.keys(D.ch).find((k) => D.ch[k] === c);
  if (V === 'chats' && F.ch === ph && document.visibilityState === 'visible') window.SA_API.markRead(c.cid).catch(() => {});
  else {
    if (!reloaded) c.un = (c.un || 0) + 1;
    toast('رسالة جديدة من ' + c.name);
  }
  SA_officeRerender();
}
function SA_officeOnRead(d) {
  const c = Object.values(D.ch).find((x) => x.cid === d.conversationId);
  if (!c) return;
  c.m.forEach((m) => m.me && (m.rd = 1));
  if (V === 'chats') SA_officeRerender();
}
