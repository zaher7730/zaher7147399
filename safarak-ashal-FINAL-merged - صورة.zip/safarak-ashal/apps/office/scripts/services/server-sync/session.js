/* جلسة المكتب مع الخادم: وقت الخادم، إعادة رسم آمنة، بدء/إنهاء المزامنة والأحداث اللحظية
   يعرّف: SA_ts، SA_officeRerender، SA_officeStart، SA_officeEnd */
const SA_ts = (v) => {
  if (!v) return Date.now();
  const s = String(v);
  const t = Date.parse(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : s.replace(' ', 'T') + 'Z');
  return Number.isFinite(t) ? t : Date.now();
};
/* إعادة رسم الصفحة الحالية مع حفظ نص حقل الرسالة وموضع التركيز */
function SA_officeRerender() {
  const i = document.getElementById('mi'),
    v = i ? i.value : null,
    f = !!i && document.activeElement === i;
  go();
  if (v != null) {
    const n = document.getElementById('mi');
    if (n) {
      n.value = v;
      if (f) n.focus();
    }
  }
}
let SA_officeOn = false;
async function SA_officeStart() {
  SA_officeOn = true;
  await Promise.allSettled([SA_loadOfficeConversations(), SA_loadPackages(), SA_loadReviews()]);
  if (window.SA_RT) window.SA_RT.start();
}
function SA_officeEnd() {
  SA_officeOn = false;
  if (window.SA_RT) window.SA_RT.stop();
  D = seed();
  OK = 0;
}
window.SA_ON_UNAUTHORIZED = (err, url) => {
  if (!SA_officeOn || /\/api\/auth\//.test(String(url || ''))) return;
  SA_officeEnd();
  showLogin();
  toast('انتهت الجلسة؛ سجّل الدخول من جديد');
};
if (window.SA_RT) {
  window.SA_RT.on('message', (m) => SA_officeOnMessage(m));
  window.SA_RT.on('read', (d) => SA_officeOnRead(d));
  window.SA_RT.on('notification', (n) => SA_officeOnNotification(n));
  window.SA_RT.on('booking', () => SA_refreshOrders());
}
