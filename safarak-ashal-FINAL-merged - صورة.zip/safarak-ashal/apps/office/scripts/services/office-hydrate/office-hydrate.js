/* تحميل بيانات المكتب من الخادم (يُستدعى بعد الدخول وعند فتح جلسة قائمة)
   يعرّف: SA_hydrateOffice، SA_loadServices، SA_loadOrders، SA_loadMethods، SA_loadRemittances */
const SA_ST = { pending: 0, reviewing: 0, in_progress: 1, completed: 2, rejected: 3, waiting_documents: 4, waiting_payment: 5, cancelled: 6 };
async function SA_loadServices() {
  try {
    const r = await window.SA_API.officeServices();
    const next = { air: [], bus: [], local: [], visa: [], pass: [], cars: [], priv: [] };
    for (const svc of r.services || []) {
      const k = String(svc.service_type || '');
      if (!next[k]) continue;
      next[k].push({
        ...(svc.details && typeof svc.details === 'object' ? svc.details : {}),
        img: svc.details?.imageUrl || '',
        id: svc.id,
        serverId: svc.id,
        title: svc.title,
        on: svc.active ? 1 : 0,
      });
    }
    D.ofr = next;
  } catch (e) {
    console.warn('تعذر تحميل عروض المكتب:', e.message);
  }
}
async function SA_loadOrders() {
  try {
    const r = await window.SA_API.bookings();
    const old = new Map((D.ord || []).map((o) => [o.id, o]));
    D.ord = (r.bookings || []).map((b) => {
      const prev = old.get(b.public_id) || {};
      return {
        id: b.public_id,
        serverId: b.public_id,
        serverStatus: b.status,
        name: b.customer_name || '—',
        ph: b.customer_phone || '',
        svc: b.service_type,
        title: b.title,
        pax: b.passenger_count,
        tot: b.total_amount,
        st: SA_ST[b.status] ?? 0,
        pay: b.payment_status,
        cur: b.currency || 'YER',
        pr: Number((b.details || {}).officeProfit || 0),
        ts: SA_ts(b.created_at),
        note: prev.note || '',
        docs: prev.docs || [],
        lg: prev.lg,
        fd: prev.fd || `الاسم: ${b.customer_name || ''}\nالجوال: ${b.customer_phone || ''}\nالخدمة: ${b.title || ''}\nرقم الطلب: ${b.public_id}`,
      };
    });
  } catch (e) {
    console.warn('تعذر تحميل حجوزات المكتب:', e.message);
  }
}
async function SA_loadMethods() {
  try {
    const r = await window.SA_API.officePaymentMethods();
    D.bk = (r.methods || []).map((m) => ({ id: m.id, serverId: m.id, ty: m.type, n: m.name, no: m.account_no, ho: m.holder || '', cur: m.currency || 'YER', on: m.active ? 1 : 0 }));
  } catch (e) {
    console.warn('تعذر تحميل وسائل الدفع:', e.message);
  }
}
async function SA_loadRemittances() {
  try {
    const r = await window.SA_API.officePayments();
    D.rm = (r.payments || []).map((m) => ({
      id: m.id,
      serverId: m.id,
      oid: m.booking_public_id,
      ph: m.customer_phone,
      name: m.customer_name,
      amt: m.amount,
      cur: m.currency,
      bank: m.method_name,
      ref: m.reference,
      sender: m.sender,
      date: SA_ts(m.transferred_at),
      ts: SA_ts(m.created_at),
      st: { submitted: 0, confirmed: 1, rejected: 2 }[m.status] ?? 0,
      rc: m.mime_type && m.mime_type.startsWith('image/') ? '/api/files/' + m.receipt_file_id : '',
      downloadUrl: m.receipt_file_id ? '/api/files/' + m.receipt_file_id : '',
      note: m.note || '',
      receiptFileId: m.receipt_file_id,
    }));
  } catch (e) {
    console.warn('تعذر تحميل الحوالات:', e.message);
  }
}
async function SA_hydrateOffice(user) {
  if (!window.SA_API) return;
  D = seed();
  D.pf = Object.assign({}, D.pf, { name: user.officeName || user.name, phone: user.phone, lph: user.phone });
  D.cfg = { auto: 0, rmReq: 1, adv: 2, maxp: 9, nOrd: 1, nChat: 1, nRem: 1, nAm: 1, cur: 'YER', tax: 0, rate: '', cancel: '', refund: '', qr: null };
  await Promise.allSettled([SA_loadOfficeState(user), SA_loadServices(), SA_loadOrders(), SA_loadMethods(), SA_loadRemittances()]);
  mig();
  OK = 1;
  await SA_officeStart();
}
