/* معالجة دخول المكتب
   يعرّف: lgn */
async function lgn() {
  const phone = String($('#loginuser')?.value || '').trim(),
    code = String($('#lp')?.value || '').trim();
  if (!window.SA_API && window.SAFARAK_PREVIEW_MODE) {
    if (!officeOtpChallenge) {
      if (!phone) return toast('أدخل رقم الهاتف للمعاينة');
      officeOtpChallenge = 'preview-only';
      const p = $('#lp');
      if (p) {
        p.value = '';
        p.placeholder = 'أدخل أي 4 أرقام للمعاينة';
        p.maxLength = 4;
      }
      const b = document.querySelector('.rg-go');
      if (b) b.textContent = 'عرض لوحة المكتب';
      return toast('معاينة شكلية فقط: أدخل أي 4 أرقام؛ لن يتم إنشاء حساب');
    }
    if (!/^\d{4}$/.test(code)) return toast('أدخل أربعة أرقام');
    D.pf.name = 'معاينة المكتب';
    D.pf.phone = phone;
    OK = 1;
    officeOtpChallenge = null;
    go('home');
    toast('معاينة فقط؛ لا توجد حجوزات أو عروض تجريبية');
    return;
  }
  if (!window.SA_API) return toast('شغّل الخادم المتصل لتسجيل الدخول الحقيقي');
  if (!officeOtpChallenge) {
    if (!phone) return toast('أدخل رقم هاتف المكتب');
    try {
      const r = await window.SA_API.requestOtp({ phone, role: 'office' });
      officeOtpChallenge = r.challengeId;
      const p = $('#lp');
      if (p) {
        p.value = '';
        p.type = 'text';
        p.inputMode = 'numeric';
        p.maxLength = 4;
        p.placeholder = 'أدخل رمز التحقق المرسل إلى واتساب';
      }
      const b = document.querySelector('.rg-go');
      if (b) b.textContent = 'تأكيد الرمز';
      toast('تم طلب رمز التحقق؛ إذا لم تُضبط خدمة واتساب فراجع سجل الخادم في وضع التطوير');
    } catch (e) {
      toast(e.message || 'تعذر إرسال رمز التحقق');
    }
    return;
  }
  if (!/^\d{4}$/.test(code)) return toast('أدخل رمز التحقق المكوّن من 4 أرقام');
  try {
    const r = await window.SA_API.verifyOtp({ challengeId: officeOtpChallenge, code });
    if (r.user.role !== 'office') return toast('الحساب ليس حساب مكتب');
    await SA_hydrateOffice(r.user);
    OK = 1;
    officeOtpChallenge = null;
    save();
    go('home');
  } catch (e) {
    toast(e.message || 'رمز التحقق غير صحيح');
  }
}
