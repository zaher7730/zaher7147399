/* الإقلاع */
try {
  if (localStorage.getItem('safarak_sb') == '1') document.body.classList.add('sbh');
} catch (e) {}
(async () => {
  if (window.SAFARAK_PREVIEW_MODE) {
    if (window.SAFARAK_PREVIEW_DIRECT_HOME) {
      D.pf.name = 'معاينة المكتب';
      D.pf.phone = D.pf.phone || 'معاينة';
      OK = 1;
      go('home');
    } else {
      OK = 0;
      showLogin();
    }
    return;
  }
  if (window.SA_API) {
    try {
      const r = await window.SA_API.me();
      if (r.user.role === 'office') {
        await SA_hydrateOffice(r.user);
        OK = 1;
        go('home');
        return;
      }
    } catch {}
  }
  OK = 0;
  showLogin();
})();
