/* الحالة D والحفظ — الجزء 1/2
   يعرّف: seed، mig، OK، cu، SafarakOffice، serviceSyncTimer */
function seed() {
  return {
    ofr: { air: [], bus: [], local: [], visa: [], pass: [], cars: [], priv: [] },
    ord: [],
    rm: [],
    ch: {},
    am: [],
    pf: {
      name: '',
      city: '',
      years: 0,
      phone: '',
      wa: '',
      lic: '',
      hours: '',
      about: '',
      logo: '',
      cover: '',
      gal: [],
      vac: 0,
      nt: 1,
      email: '',
      web: '',
      addr: '',
      langs: '',
      branches: '',
      fb: '',
      ig: '',
      x: '',
      tk: '',
      lname: '',
      cr: '',
      issuer: '',
      issued: '',
      expiry: '',
      tax: '',
      owner: '',
      ownerId: '',
      licImg: '',
      crImg: '',
      idImg: '',
      taxImg: '',
      ver: 0,
      user: '',
      lph: '',
      lem: '',
      tfa: 0,
      pwh: '',
      pwd: 0,
      registered: 0,
    },
    bk: [],
    cd: {},
    sv: { air: 1, bus: 1, local: 1, visa: 1, pass: 1, cars: 1, priv: 1 },
  };
}
function mig() {
  delete D.cat;
  delete D.pu;
  D.rm = D.rm || RM0();
  D.cd = D.cd || {};
  D.ord.forEach((o) => {
    if (!o.fd) o.fd = mkfd(o);
  });
  D.cfg = Object.assign(
    {
      auto: 0,
      rmReq: 1,
      adv: 2,
      maxp: 9,
      nOrd: 1,
      nChat: 1,
      nRem: 1,
      nAm: 1,
      cur: 'YER',
      tax: 0,
      rate: '',
      cancel: '',
      refund: '',
      terms: '',
      qr: null,
    },
    D.cfg || {},
  );
  D.ofr.priv = D.ofr.priv || PRV0();
  D.ofr.priv.forEach((o) => {
    o.scope = o.scope || 'دولية';
  });
}
let OK = 0,
  officeOtpChallenge = null,
  H = [],
  D,
  V = 'home',
  P = '',
  F = { st: 'all', q: '', ch: null, fs: 'air', tab: {}, eo: null };
const cu = (s) => String((D && D.cfg && D.cfg.cur) || 'YER') + ' ',
  dt = (t) => new Date(t).toLocaleDateString('ar'),
  tm = (t) => new Date(t).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' }),
  ofn = () => D.pf.name;
/* لا تخزين محلي: البيانات تأتي من الخادم بعد الدخول (SA_hydrateOffice) */
D = seed();
mig();
window.SafarakOffice = {
  version: 10,
  get data() {
    return D;
  },
};
let serviceSyncTimer = null;
