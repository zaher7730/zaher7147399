/* الحالة D والحفظ — الجزء 2/2
   يعرّف: save */
const save = () => {
  if (OK && window.SA_API) SA_scheduleOfficeState();
  if (OK && window.SA_API) {
    clearTimeout(serviceSyncTimer);
    serviceSyncTimer = setTimeout(async () => {
      try {
        const services = [];
        for (const [serviceType, rows] of Object.entries(D.ofr || {})) {
          for (const row of Array.isArray(rows) ? rows : []) {
            const title = String(
              row.title ||
                row.svc ||
                (row.from && row.to ? row.from + ' ← ' + row.to : '') ||
                [row.make, row.model].filter(Boolean).join(' ') ||
                '',
            ).trim();
            if (!title) continue;
            if (typeof row.img === 'string' && /^data:image\/(jpeg|png|webp);base64,/i.test(row.img)) {
              const sig = row.img.length + ':' + row.img.slice(-48);
              if (row._uploadedImageSignature !== sig) {
                const mimeType = (row.img.match(/^data:(image\/(?:jpeg|png|webp));base64,/i) || [])[1];
                const uploaded = await window.SA_API.uploadOfferAsset({
                  filename: title.replace(/[^\w\u0600-\u06FF-]/g, '_') + '.img',
                  mimeType,
                  base64: row.img,
                });
                row.imageUrl = uploaded.asset.url;
                row._uploadedImageSignature = sig;
              }
            } else if (typeof row.img === 'string' && row.img.startsWith('/assets/offers/')) row.imageUrl = row.img;
            const details = {};
            for (const [key, value] of Object.entries(row)) {
              if (
                ['id', 'serverId', 'on', 'active', '_uploadedImageSignature'].includes(key) ||
                /(image|img|logo|cover|photo|file|base64)/i.test(key)
              )
                continue;
              if (typeof value === 'function') continue;
              details[key] = value;
            }
            if (row.imageUrl) details.imageUrl = row.imageUrl;
            if (!details.currency) details.currency = D.cfg.cur || 'YER';
            if (D.pf.city && !details.city) details.city = D.pf.city;
            if (D.pf.addr && !details.officeAddress) details.officeAddress = D.pf.addr;
            services.push({ serviceType, title, details, active: row.on !== 0 && row.active !== 0 });
          }
        }
        await window.SA_API.syncOfficeServices(services);
        const methods = (D.bk || []).map((m) => ({
          type: m.ty,
          name: m.n,
          accountNo: m.no,
          holder: m.ho || '',
          currency: m.cur || D.cfg.cur || 'YER',
          active: !!m.on,
        }));
        await window.SA_API.syncOfficePaymentMethods(methods);
      } catch (e) {
        console.warn('تعذرت مزامنة الخدمات أو وسائل الدفع:', e.message);
      }
      for (const o of D.ord || []) {
        if (!o.serverId || o._statusSyncing) continue;
        const statuses = ['pending', 'in_progress', 'completed', 'rejected', 'waiting_documents', 'waiting_payment', 'cancelled'];
        let target = statuses[Number(o.st) || 0] || 'pending';
        if (Number(o.st) === 0 && ['pending', 'reviewing'].includes(o.serverStatus)) target = o.serverStatus;
        if (o.serverStatus === target) continue;
        o._statusSyncing = true;
        try {
          await window.SA_API.updateBookingStatus(o.serverId, { status: target, note: String(o.note || '') });
          o.serverStatus = target;
        } catch (e) {
          console.warn('تعذر تحديث حالة الحجز:', e.message);
        } finally {
          o._statusSyncing = false;
        }
      }
    }, 350);
  }
};
