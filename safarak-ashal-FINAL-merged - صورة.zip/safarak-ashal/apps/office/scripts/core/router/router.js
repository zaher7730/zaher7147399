/* التنقل بين الصفحات
   يعرّف: back، go */
function back() {
  const s = H.pop();
  if (!s) return go('home');
  V = s[0];
  F.id = s[1];
  F.es = s[2];
  F.eid = s[3];
  go();
}
function go(v, id) {
  if (D.pf.pwh && !OK) {
    showLogin();
    return;
  }
  $('#sb').style.display = '';
  $('#mn').style.marginRight = '';

  if (v == 'cp' && id != F.id) F.ct = 0;
  if (v) {
    if ((v != V || (id !== undefined && id != F.id)) && V != 'ed') H.push([V, F.id, F.es, F.eid]);
    V = v;
    if (id !== undefined) F.id = id;
  }
  if (SV[V] && (D.sv || {})[V] === 0) V = 'svcs';
  $('#sb').classList.remove('open');
  $('#ov').classList.remove('on');
  document.body.classList.toggle('hmv', V == 'home');
  const c = cnt(),
    act = V == 'od' ? 'orders' : V == 'cp' ? 'customers' : V == 'ed' ? F.es : V;
  $('#sb').innerHTML =
    `<div class="lg"><img class="lgImg" src="/shared/assets/brand/logo.png" alt="سفرك أسهل"><small>لوحة المكتب · ${h(D.pf.name)}</small></div>` +
    NV.filter((x) => !SV[x[0]] || (D.sv || {})[x[0]] !== 0)
      .map((x) =>
        x[0] == 'g'
          ? `<div class="gt">${x[1]}</div>`
          : `<button class="ni ${act == x[0] ? 'on' : ''}" onclick="go('${x[0]}')"><span>${x[2]}</span>${x[1]}${c[x[0]] ? `<em>${c[x[0]]}</em>` : ''}</button>`,
      )
      .join('');
  $('#tp').innerHTML =
    `<button class="ib" id="mb" onclick="tgs()" title="إظهار / إخفاء القائمة">☰</button><input placeholder="ابحث عن طلب أو عميل أو رقم جوال..." value="${h(F.q)}" onkeydown="if(event.key=='Enter'){F.q=this.value;F.st='all';go('orders')}"><button class="ib" onclick="F.st=0;F.q='';go('orders')">🔔${c.orders + c.chats ? `<b>${c.orders + c.chats}</b>` : ''}</button><div class="av">${h((D.pf.name.replace('مكتب ', '') || 'م')[0])}</div>${V != 'home' ? '<button class="ib" style="padding:0 16px;font-weight:700" onclick="back()">رجوع ›</button>' : ''}`;
  const R = { home, orders, od, customers, chats, docs, amanat, profile, banks, settings, ed: edpage, cp, txn, svcs, rem: rmp, pkg: packages, rv: reviewsPage };
  $('#pg').innerHTML = (R[V] || (() => svc(V)))();
  ['#sb', '#tp', '#pg'].forEach((q) => ($(q).innerHTML = dc($(q).innerHTML)));
  $('#bn').innerHTML = dc(
    [
      ['home', 'الرئيسية', '▦'],
      ['orders', 'الطلبات', '📋'],
      ['svcs', 'الخدمات', '☷'],
      ['chats', 'المحادثات', '💬'],
    ]
      .map(
        (x) =>
          `<button class="${act == x[0] ? 'on' : ''}" onclick="go('${x[0]}')">${x[2]}${x[1]}${c[x[0]] ? `<em>${c[x[0]]}</em>` : ''}</button>`,
      )
      .join('') + '<button onclick="tgs()">☰المزيد</button>',
  );
  const m = $('#ms');
  if (m) m.scrollTop = m.scrollHeight;
  scrollTo(0, 0);
}
