/* ملف المكتب — الجزء 2/2
   يعرّف: ps، vr، sha، pws، pi */
function ps(K_) {
  const p = D.pf;
  K_.forEach((k) => (p[k] = $('#p_' + k).value.trim()));
  if (!p.name) return toast('اكتب اسم المكتب');
  save();
  toast('تم الحفظ');
  go();
}
function vr() {
  const p = D.pf;
  if (!p.lname || !p.cr || !p.lic || !p.owner || !p.licImg || !p.crImg)
    return toast('أكمل الاسم القانوني والسجل والترخيص والمالك وارفع صورتي الترخيص والسجل');
  SA_submitVerification().then((ok) => {
    if (ok) toast('تم إرسال طلب التوثيق للمراجعة');
    go();
  });
}
async function sha(s) {
  try {
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
    return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
  } catch (e) {
    return btoa(unescape(encodeURIComponent(s)));
  }
}
async function pws() {
  toast('الدخول يتم برمز التحقق عبر واتساب؛ لا حاجة لكلمة مرور');
}
const pi = (k, l, ty = 'text') => `<div><label>${l}</label><input id="p_${k}" type="${ty}" value="${h(D.pf[k])}"></div>`,
  pa = (k, l) => `<div class="w"><label>${l}</label><textarea id="p_${k}" rows="3">${h(D.pf[k])}</textarea></div>`,
  pu = (k, l, mx) =>
    `<div class="card" style="margin:0"><label>${l}</label><div class="up">${D.pf[k] ? `<img src="${D.pf[k]}">` : '<div class="ia">📄</div>'}<input type="file" accept="image/*" onchange="rz(this.files[0],d=>{D.pf['${k}']=d;save();go()},${mx || 900})">${D.pf[k] ? `<button class="ib" onclick="D.pf['${k}']='';save();go()">🗑</button>` : ''}</div></div>`,
  VER = ['غير موثق', 'قيد المراجعة', 'موثق'],
  VC = ['wr', 'bu', 'ok'];
