/* الإعدادات — الجزء 2/2
   يعرّف: cfT */
const cfT = (k, t, s, p) => {
    const w = p ? 'pf' : 'cfg';
    return `<div class="dr"><b>${t}${s ? `<br><small style="color:var(--mu)">${s}</small>` : ''}</b><label class="tg"><input type="checkbox" ${D[w][k] ? 'checked' : ''} onchange="D.${w}['${k}']=this.checked?1:0;save()"><i></i></label></div>`;
  },
  cfI = (k, l, ty = 'text', p) => {
    const w = p ? 'pf' : 'cfg';
    return `<div><label>${l}</label><input type="${ty}" min="0" value="${h(D[w][k])}" onchange="D.${w}['${k}']=${ty == 'number' ? '(+this.value||0)' : 'this.value.trim()'};save()"></div>`;
  },
  cfA = (k, l) =>
    `<div class="w"><label>${l}</label><textarea rows="3" onchange="D.cfg['${k}']=this.value.trim();save()">${h(D.cfg[k])}</textarea></div>`;
