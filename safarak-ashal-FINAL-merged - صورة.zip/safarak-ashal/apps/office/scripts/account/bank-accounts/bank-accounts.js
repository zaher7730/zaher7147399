/* الحسابات البنكية
   يعرّف: banks، be، bs، ex، im، ht */
function banks() {
  return (
    hd('الحسابات البنكية', 'تظهر للعميل في صفحة الدفع الخاصة بمكتبك', `<button class="bt g" onclick="be()">+ حساب جديد</button>`) +
    `<div class="card">${D.bk.map((b) => `<div class="row" style="cursor:default"><div class="ia">${b.ty == 'بنك' ? '🏦' : '📱'}</div><div class="rm"><b>${h(b.n)} <span class="pl">${b.ty}</span></b><small>${h(b.no)} · ${h(b.ho) || 'بدون اسم صاحب الحساب'} · ${b.cur}</small></div><label class="tg"><input type="checkbox" ${b.on ? 'checked' : ''} onchange="D.bk.find(x=>x.id==${b.id}).on=this.checked?1:0;save()"><i></i></label><button class="ib" onclick="be(${b.id})">✎</button><button class="ib" onclick="D.bk=D.bk.filter(x=>x.id!=${b.id});save();go()">🗑</button></div>`).join('') || '<p class="em">أضف أول حساب</p>'}</div>`
  );
}
function be(id) {
  const b = id ? D.bk.find((x) => x.id == id) : { ty: 'بنك', cur: D.cfg.cur || 'YER' },
    o = (a, v) => a.map((x) => `<option ${x == v ? 'selected' : ''}>${x}</option>`).join('');
  mo(
    id ? 'تعديل الحساب' : 'حساب جديد',
    `<div class="fg"><div><label>النوع</label><select id="b_ty">${o(['بنك', 'محفظة'], b.ty)}</select></div><div><label>الاسم</label><input id="b_n" value="${h(b.n)}"></div><div><label>رقم الحساب / المحفظة</label><input id="b_no" value="${h(b.no)}"></div><div><label>اسم صاحب الحساب</label><input id="b_ho" value="${h(b.ho)}"></div><div><label>العملة</label><select id="b_cur">${o(['USD', 'SAR', 'YER'], b.cur)}</select></div></div>`,
    `bs(${id || 0})`,
  );
}
function bs(id) {
  const v = (k) => $('#b_' + k).value.trim(),
    b = id ? D.bk.find((x) => x.id == id) : { id: Date.now(), on: 1 };
  if (!v('n') || !v('no')) return toast('اكتب الاسم ورقم الحساب');
  Object.assign(b, { ty: v('ty'), n: v('n'), no: v('no'), ho: v('ho'), cur: v('cur') });
  if (!id) D.bk.push(b);
  save();
  cm();
  go();
}
function ex() {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(D)], { type: 'application/json' }));
  a.download = 'safarak-office-data.json';
  a.click();
}
function im(f) {
  if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    try {
      const d = JSON.parse(r.result);
      if (!d.ofr || !d.ord) throw 0;
      D = d;
      mig();
      save();
      toast('تم الاستيراد');
      go('home');
    } catch (e) {
      toast('الملف غير صالح');
    }
  };
  r.readAsText(f);
}
/* ===== صفحة التفاصيل بنفس تطبيق العميل ===== */
const ht = h;
