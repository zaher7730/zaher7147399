/* تسجيل مكتب جديد — الجزء 2/2
   يعرّف: RGHELP */
const RGHELP = `<div class="rg-help"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a9 9 0 00-9 9v6a3 3 0 003 3h1a1 1 0 001-1v-6a1 1 0 00-1-1H5v-1a7 7 0 0114 0v1h-2a1 1 0 00-1 1v6a1 1 0 001 1h1v.5a2 2 0 01-2 2h-3.1a1.5 1.5 0 100 2H17a4 4 0 004-4V11a9 9 0 00-9-9z"/></svg>خدمة عملاء منصة</div>`;
