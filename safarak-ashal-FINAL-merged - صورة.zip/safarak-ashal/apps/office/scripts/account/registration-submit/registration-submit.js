/* إرسال طلب الانضمام
   يعرّف: regPreview، regsave، REGFILES */
function regPreview(inp, key) {
  const f = inp.files && inp.files[0];
  if (!f) return;
  if (f.size > 4 * 1024 * 1024) {
    toast('حجم الصورة كبير، اختر صورة أقل من 4 ميجابايت');
    inp.value = '';
    return;
  }
  const rd = new FileReader();
  rd.onload = () => {
    REGFILES[key] = rd.result;
    const n = document.getElementById(inp.id + '_n'),
      b = document.getElementById(inp.id + '_b');
    if (n) n.textContent = 'تم اختيار: ' + f.name;
    if (b) b.classList.add('on');
  };
  rd.readAsDataURL(f);
}
async function regsave() {
  const g = (i) => $('#' + i).value.trim(),
    name = g('r_name'),
    owner = g('r_owner'),
    phone = g('r_phone'),
    addr = g('r_addr'),
    cr = g('r_cr'),
    lic = g('r_lic'),
    oid = g('r_oid');
  if (!name || !owner || !phone || !addr || !cr || !oid) return toast('أكمل البيانات المطلوبة المعلّمة بنجمة');
  if (!window.SA_API) return toast('هذه معاينة شكلية فقط؛ لا يتم إرسال طلب تسجيل حقيقي من ملف المعاينة');
  const documents = {};
  for (const key of ['crImg', 'licImg', 'idImg', 'cover', 'logo']) if (REGFILES[key]) documents[key] = REGFILES[key];
  try {
    const result = await window.SA_API.request('/api/public/office-applications', {
      method: 'POST',
      body: JSON.stringify({
        officeName: name,
        ownerName: owner,
        phone,
        address: addr,
        registrationNumber: cr,
        licenseNumber: lic,
        ownerIdNumber: oid,
        documents,
      }),
    });
    REGFILES = {};
    toast(result.application?.message || 'تم إرسال طلب الانضمام للمراجعة');
    showLogin();
  } catch (e) {
    toast(e.message || 'تعذر إرسال طلب الانضمام؛ راجع البيانات وحاول مجدداً');
  }
}
let REGFILES = {};
