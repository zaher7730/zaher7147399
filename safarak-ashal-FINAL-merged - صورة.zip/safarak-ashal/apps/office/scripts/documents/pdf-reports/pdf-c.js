/* تقارير PDF — الجزء 1/3
   يعرّف: pdfC */
function pdfC(ph) {
  const c = cuL().find((x) => x.ph == ph),
    d = c.d,
    O = [...c.o].sort((a, b) => b.ts - a.ts),
    N = O.filter((o) => o.st == 2),
    R = D.rm.filter((r) => r.ph == ph),
    us = [...new Set(O.map((o) => o.svc))],
    cn = (k) => O.filter((o) => k.includes(o.st)).length;
  pdf(
    'ملف العميل',
    PH('بيانات العميل') +
      PK([
        ['الرقم التسلسلي', c.no],
        ['الاسم', c.name],
        ['الجوال', c.ph],
        ['التصنيف', d.tag || 'عادي'],
        ['أول طلب', dt(O[O.length - 1].ts)],
        ['آخر نشاط', dt(O[0].ts)],
        ['البريد', d.em],
        ['تاريخ الميلاد', d.dob],
        ['الوثيقة', (d.idt || 'هوية شخصية') + ' ' + (d.idn || '')],
        ['التوثيق', d.vf ? 'موثّق' : 'غير موثّق'],
        ['المدينة', d.city],
        ['الجنسية', d.nat],
        ['جهة الطوارئ', d.emg],
        ['ملاحظات المكتب', d.note],
      ]) +
      PH('الملخص المالي والتشغيلي') +
      PK([
        ['إجمالي الطلبات', O.length],
        ['طلبات جارية', cn([0, 1, 4, 5])],
        ['طلبات منفذة', N.length],
        ['مرفوضة / ملغية', cn([3, 6])],
        ['قيمة المنفذة', money(N, 'tot')],
        ['ربح المكتب', money(N, 'pr')],
        ['حوالات مؤكدة', rsum(R.filter((r) => r.st == 1))],
        ['حوالات بانتظار التأكيد', R.filter((r) => !r.st).length],
      ]) +
      PH('النشاط حسب الخدمة') +
      PT(
        ['الخدمة', 'الطلبات', 'المنفذة', 'القيمة'],
        us.map((k) => {
          const a = O.filter((o) => o.svc == k);
          return [
            SV[k][0],
            a.length,
            a.filter((o) => o.st == 2).length,
            money(
              a.filter((o) => o.st == 2),
              'tot',
            ),
          ];
        }),
      ) +
      PH('الطلبات') +
      PT(
        ['الرقم', 'الخدمة', 'التفاصيل', 'الأفراد', 'التاريخ', 'الحالة', 'المبلغ'],
        O.map((o) => [osn(o), SV[o.svc][0], o.title, o.pax, dt(o.ts), STS[o.st], (o.cur || '$') + o.tot]),
      ) +
      PH('حوالات العميل') +
      PT(RMH, R.map(RMX)) +
      PH('المستندات') +
      PT(
        ['المستند', 'الطلب', 'الحالة'],
        O.flatMap((o) => o.docs.map((x) => [x.n, osn(o), DR_(x)])),
      ) +
      PH('الجوازات عبر الأمانات') +
      PT(
        ['الاتجاه', 'المستندات', 'مكتب الأمانات', 'الحالة'],
        D.am.filter((a) => a.ph == ph).map((a) => [a.dir == 'out' ? 'إرسال' : 'استقبال', a.items, a.off, AMS(a)]),
      ) +
      PH('سجل النشاط') +
      PT(
        ['التاريخ', 'الحدث'],
        actv(O).map((a) => [dt(a.t) + ' ' + tm(a.t), a.x]),
      ),
    c.no,
  );
}
