/* تقارير PDF — الجزء 2/3
   يعرّف: pdfO، pdfR، pdfAll */
function pdfO(id) {
  const o = D.ord.find((x) => x.id == id),
    c = cuL().find((x) => x.ph == o.ph),
    R = D.rm.filter((r) => r.oid == id),
    k = (o.cur || '$').trim();
  pdf(
    'ملف الطلب',
    PH('بيانات الطلب') +
      PK([
        ['رقم الطلب', osn(o) + ' (' + o.id + ')'],
        ['الخدمة', SV[o.svc][0]],
        ['التفاصيل', o.title],
        ['تاريخ الطلب', dt(o.ts) + ' ' + tm(o.ts)],
        ['الحالة', STS[o.st]],
        ['عدد الأفراد', o.pax],
        ['الإجمالي', k + o.tot],
        ['المؤكد من الحوالات', k + R.filter((r) => r.st == 1).reduce((a, r) => a + +r.amt, 0)],
        ['ربح المكتب', k + (o.pr || 0)],
        ['ملاحظة داخلية', o.note],
      ]) +
      PH('العميل') +
      PK([
        ['الرقم التسلسلي', c.no],
        ['الاسم', o.name],
        ['الجوال', o.ph],
        ['خدمات العميل', [...new Set(c.o.map((x) => SV[x.svc][0]))].join('، ')],
      ]) +
      PH('الحوالات') +
      PT(RMH, R.map(RMX)) +
      PH('المستندات') +
      PT(
        ['المستند', 'الحالة'],
        o.docs.map((x) => [x.n, DR_(x)]),
      ) +
      PH('سجل الطلب') +
      PT(
        ['التاريخ', 'الحدث'],
        ordLog(o).map((a) => [dt(a.t) + ' ' + tm(a.t), a.x]),
      ),
    osn(o),
  );
}
function pdfR(id) {
  const r = D.rm.find((x) => x.id == id),
    o = rmO(r);
  pdf(
    'سند حوالة',
    PH('بيانات الحوالة') +
      PK([
        ['رقم الحوالة', r.id],
        ['الحالة', RMS[r.st]],
        ['المبلغ', (r.cur || '$').trim() + r.amt],
        ['الحساب المستلِم', r.bank],
        ['المرجع', r.ref],
        ['اسم المحوّل', r.sender],
        ['تاريخ التحويل', dt(r.date)],
        ['تاريخ التأكيد', r.at ? dt(r.at) + ' ' + tm(r.at) : '—'],
        ['ملاحظة', r.note],
      ]) +
      PH('العميل والطلب') +
      PK([
        ['العميل', r.name],
        ['الجوال', r.ph],
        ['الطلب', o ? osn(o) + ' · ' + o.title : '—'],
        ['إجمالي الطلب', o ? (o.cur || '$').trim() + o.tot : '—'],
      ]),
    r.id,
  );
}
function pdfAll() {
  const A = cuL();
  pdf(
    'قائمة العملاء',
    PK([
      ['عدد العملاء', A.length],
      [
        'إجمالي المنفذ',
        money(
          D.ord.filter((o) => o.st == 2),
          'tot',
        ),
      ],
      ['حوالات مؤكدة', rsum(D.rm.filter((r) => r.st == 1))],
    ]) +
      PT(
        ['الرقم', 'الاسم', 'الجوال', 'الطلبات', 'جارية', 'منفذة', 'قيمة المنفذة', 'حوالات مؤكدة', 'آخر طلب', 'التصنيف'],
        A.map((c) => [
          c.no,
          c.name,
          c.ph,
          c.o.length,
          c.o.filter((o) => [0, 1, 4, 5].includes(o.st)).length,
          c.o.filter((o) => o.st == 2).length,
          money(
            c.o.filter((o) => o.st == 2),
            'tot',
          ),
          rsum(D.rm.filter((r) => r.ph == c.ph && r.st == 1)),
          dt(Math.max(...c.o.map((o) => o.ts))),
          c.d.tag || 'عادي',
        ]),
      ),
    'CUSTOMERS',
  );
}
