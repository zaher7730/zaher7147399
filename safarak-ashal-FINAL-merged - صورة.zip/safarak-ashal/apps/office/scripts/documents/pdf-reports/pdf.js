/* تقارير PDF — الجزء 3/3
   يعرّف: pdf، PK */
/* ===== التصدير PDF ===== */
const pdf = (ti, b, no) => {
  const p = D.pf;
  $('#prt').innerHTML =
    `<div dir="rtl" class="pd" style="padding:6px;color:#111"><div style="display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #d9a53a;padding-bottom:10px;margin-bottom:14px"><div style="display:flex;gap:10px;align-items:center">${p.logo ? `<img src="${p.logo}" style="width:54px;height:54px;object-fit:contain">` : ''}<div><h1 style="font-size:21px">${h(p.name)}</h1><div style="color:#555;font-size:11.5px">${h(p.city)} · ${h(p.phone)}${p.lic ? ' · ترخيص ' + h(p.lic) : ''}${p.cr ? ' · سجل ' + h(p.cr) : ''}</div></div></div><div style="text-align:left"><b style="font-size:15px">${ti}</b><div style="color:#555;font-size:11.5px">${no ? 'رقم المستند: ' + h(no) + '<br>' : ''}${dt(Date.now())} · ${tm(Date.now())}</div></div></div>${b}<div style="margin-top:24px;display:flex;justify-content:space-between;font-size:11.5px;color:#444"><div>ختم وتوقيع المكتب: ____________</div><div>صادر من لوحة المكتب · سفرك أسهل</div></div></div>`;
  toast('اختر «حفظ كملف PDF» من نافذة الطباعة');
  setTimeout(() => print(), 400);
};
const PK = (r) =>
    '<table class="pt">' +
    r.map((x) => `<tr><th style="width:30%">${x[0]}</th><td>${h(x[1] === 0 ? 0 : x[1] || '—')}</td></tr>`).join('') +
    '</table>',
  PT = (a, r) =>
    '<table class="pt"><thead><tr>' +
    a.map((x) => `<th>${x}</th>`).join('') +
    '</tr></thead><tbody>' +
    (r.map((x) => '<tr>' + x.map((y) => `<td>${h(y === 0 ? 0 : y || '—')}</td>`).join('') + '</tr>').join('') ||
      `<tr><td colspan="${a.length}">لا يوجد</td></tr>`) +
    '</tbody></table>',
  PH = (x) => `<h3 style="margin:14px 0 6px;color:#0f2a6b">${x}</h3>`,
  DR_ = (d) => (d.ok == 1 ? 'مقبول' : d.ok == 0 ? 'مرفوض' : 'بانتظار المراجعة'),
  RMX = (r) => [r.id, r.ref, r.sender, r.bank, (r.cur || '$').trim() + r.amt, dt(r.date), RMS[r.st]],
  RMH = ['الرقم', 'المرجع', 'المحوّل', 'الحساب', 'المبلغ', 'التاريخ', 'الحالة'],
  rsum = (L) =>
    money(
      L.map((r) => ({ cur: r.cur, t: r.amt })),
      't',
    );
