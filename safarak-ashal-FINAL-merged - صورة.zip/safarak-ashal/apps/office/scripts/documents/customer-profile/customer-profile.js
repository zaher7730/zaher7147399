/* ملف العميل
   يعرّف: cpInfo، cps */
/* ===== ملف العميل الشخصي ===== */
function cpInfo(c) {
  const d = c.d,
    O = c.o,
    ph = c.ph,
    k = (a, b) => `<div><small>${a}</small><b>${h(b || '—')}</b></div>`,
    i = (f, l, ty = 'text') => `<div><label>${l}</label><input id="c_${f}" type="${ty}" value="${h(d[f] || '')}"></div>`;
  return `<div class="card"><h3>البيانات الشخصية <span class="pl ${d.vf ? 'ok' : 'wr'}">${d.vf ? 'موثّق ✔' : 'غير موثّق'}</span></h3><div class="kv">${k('الاسم', c.name)}${k('الجوال', c.ph)}${k('الرقم التسلسلي', c.no)}${k('عميل منذ', dt(Math.min(...O.map((o) => o.ts))))}${k('آخر طلب', dt(Math.max(...O.map((o) => o.ts))))}${k('التصنيف', d.tag || 'عادي')}${k('البريد', d.em)}${k('تاريخ الميلاد', d.dob)}${k('الهوية', (d.idt || 'هوية شخصية') + ' ' + (d.idn || ''))}${k('المدينة', d.city)}${k('الجنسية', d.nat)}${k('جهة طوارئ', d.emg)}</div>${d.idi ? `<img src="${d.idi}" style="max-width:260px;border-radius:12px;margin-top:10px;display:block">` : ''}</div><div class="card"><h3>تعديل بيانات العميل وتوثيقه</h3><div class="fg">${i('em', 'البريد الإلكتروني', 'email')}${i('dob', 'تاريخ الميلاد', 'date')}<div><label>نوع الوثيقة</label><select id="c_idt">${['هوية شخصية', 'جواز سفر'].map((x) => `<option ${d.idt == x ? 'selected' : ''}>${x}</option>`).join('')}</select></div>${i('idn', 'رقم الوثيقة')}${i('city', 'المدينة')}${i('nat', 'الجنسية')}${i('emg', 'جهة اتصال للطوارئ')}<div><label>صورة الوثيقة</label><input type="file" accept="image/*" onchange="rz(this.files[0],x=>{D.cd[F.id]={...(D.cd[F.id]||{}),idi:x};save();go()},900)"></div></div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="bt g" onclick="cps('${ph}')">حفظ البيانات</button><button class="bt s" onclick="D.cd['${ph}']={...D.cd['${ph}'],vf:${d.vf ? 0 : 1}};save();go()">${d.vf ? 'إلغاء التوثيق' : 'توثيق العميل'}</button><button class="bt o" onclick="pdfC('${ph}')">📄 ملف العميل PDF</button></div></div>`;
}
function cps(ph) {
  const g = (f) => $('#c_' + f).value.trim();
  D.cd[ph] = {
    ...(D.cd[ph] || {}),
    em: g('em'),
    dob: g('dob'),
    idt: g('idt'),
    idn: g('idn'),
    city: g('city'),
    nat: g('nat'),
    emg: g('emg'),
  };
  save();
  toast('تم حفظ بيانات العميل');
  go();
}
