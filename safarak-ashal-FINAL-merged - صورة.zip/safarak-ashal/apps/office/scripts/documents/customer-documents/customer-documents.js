/* مستندات العملاء
   يعرّف: docs */
function docs() {
  const L = D.ord.flatMap((o) => o.docs.map((d) => ({ o, d })));
  return (
    hd('مستندات العملاء', 'اضغط على المستند لفتح طلبه ومراجعته') +
    `<div class="card">${L.map(({ o, d }) => `<div class="row" onclick="go('od','${o.id}')"><div class="ia">📎</div><div class="rm"><b>${h(d.n)}</b><small>${h(o.name)} · ${SV[o.svc][0]} · ${o.id}</small></div><span class="pl ${d.ok == 1 ? 'ok' : d.ok == 0 ? 'rd' : 'wr'}">${d.ok == 1 ? 'مقبول' : d.ok == 0 ? 'مرفوض' : 'بانتظار المراجعة'}</span></div>`).join('') || '<p class="em">لا توجد مستندات</p>'}</div>`
  );
}
