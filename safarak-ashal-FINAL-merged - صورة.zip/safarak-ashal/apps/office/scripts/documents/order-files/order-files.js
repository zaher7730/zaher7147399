/* ملفات الطلبات وبيانات العميل
   يعرّف: rf، opd، sendFile، ofu، ofs، atc */
function rf(f, cb) {
  if (!f) return;
  if (/^image/.test(f.type)) return rz(f, (d) => cb({ n: f.name, type: 'image/jpeg', data: d }), 1100);
  if (f.type != 'application/pdf') return toast('المسموح: PDF أو صورة');
  if (f.size > 8e5) return toast('حجم الـ PDF كبير (الحد 800 كيلو)، صغّره أولاً');
  const r = new FileReader();
  r.onload = () => cb({ n: f.name, type: f.type, data: r.result });
  r.readAsDataURL(f);
}
function opd(oid, i) {
  const d = D.ord.find((x) => x.id == oid).docs[i],
    a = document.createElement('a');
  a.href = d.data;
  a.download = d.n;
  a.target = '_blank';
  a.click();
}
function sendFile(ph, name, f, kind, oid) {
  return SA_officeSendFile(ph, name, f, kind, oid);
}
function ofu(oid) {
  const o = D.ord.find((x) => x.id == oid);
  F.of = null;
  mo(
    'رفع ملف للعميل · ' + osn(o),
    `<div class="fg"><div><label>نوع الملف</label><select id="o_k">${KINDS.map((k) => `<option>${k}</option>`).join('')}</select></div><div><label>الملف (PDF أو صورة)</label><input type="file" accept="image/*,application/pdf" onchange="rf(this.files[0],f=>{F.of=f;toast('تم اختيار '+f.n)})"></div></div><div class="nt" style="margin-top:10px">يُحفظ الملف في مستندات الطلب ويصل العميل داخل المحادثة.</div>`,
    `ofs('${oid}')`,
  );
}
function ofs(oid) {
  const o = D.ord.find((x) => x.id == oid);
  if (!F.of) return toast('اختر الملف أولاً');
  sendFile(o.ph, o.name, F.of, $('#o_k').value, oid);
  F.of = null;
  save();
  cm();
  toast('تم رفع الملف وإرساله للعميل');
  go();
}
function atc(f) {
  rf(f, (x) => {
    F.af = x;
    go();
  });
}
/* ===== بيانات الطلب كما أدخلها العميل ===== */
function mkfd(o) {
  return Object.assign({ 'الاسم الكامل': o.name || '', 'رقم الجوال': o.ph || '' }, o.fd || {});
}
function fde(id) {
  const o = D.ord.find((x) => x.id == id);
  mo(
    'تصحيح بيانات الطلب',
    `<label>سطر لكل بيان (العنوان: القيمة)</label><textarea id="fd_t" rows="10">${h(
      Object.entries(o.fd || {})
        .map(([k, v]) => k + ': ' + v)
        .join('\n'),
    )}</textarea>`,
    `fds('${id}')`,
  );
}
function fds(id) {
  const o = D.ord.find((x) => x.id == id),
    r = {};
  $('#fd_t')
    .value.split('\n')
    .forEach((l) => {
      const i = l.indexOf(':');
      if (i > 0) r[l.slice(0, i).trim()] = l.slice(i + 1).trim();
    });
  o.fd = r;
  lg(o, 'تصحيح بيانات الطلب من المكتب');
  save();
  cm();
  go();
}
/* ===== الملفات: رفع من المكتب للعميل (PDF / صورة) ===== */
const KINDS = ['تأشيرة', 'تذكرة', 'جواز', 'إيصال', 'ملف الطلب', 'ملف آخر'];
const fchip = (f) =>
  /^image/.test(f.type)
    ? `<a href="${f.data}" download="${h(f.n)}" target="_blank"><img src="${f.data}" style="max-width:220px;border-radius:10px;display:block;margin-bottom:4px"></a>`
    : `<a href="${f.data}" download="${h(f.n)}" target="_blank" style="display:flex;gap:6px;align-items:center;font-weight:700;color:inherit">📄 ${h(f.n)}</a>`;
const fdCard = (o) =>
  `<div class="card"><div class="hd" style="margin:0 0 6px"><div><h3 style="margin:0">بيانات الطلب كما أدخلها العميل</h3></div><button class="bt s" onclick="fde('${o.id}')">✎ تصحيح</button></div><div class="kv">${
    Object.entries(o.fd || {})
      .map(([k, v]) => `<div><small>${h(k)}</small><b>${h(v)}</b></div>`)
      .join('') || '<p class="em">لا توجد بيانات</p>'
  }</div></div>`;
