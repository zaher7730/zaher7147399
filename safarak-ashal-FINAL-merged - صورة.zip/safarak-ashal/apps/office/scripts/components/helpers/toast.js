/* مساعدات الواجهة والأيقونات والقائمة — الجزء 1/2
   يعرّف: toast، rz، cm، hd، say، NV */
function toast(t) {
  const e = document.createElement('div');
  e.textContent = t;
  e.style.cssText =
    'position:fixed;z-index:99999;bottom:18px;left:50%;transform:translateX(-50%);background:#142b4f;color:white;padding:11px 16px;border-radius:10px;max-width:90vw;font:14px Tahoma,Arial;box-shadow:0 8px 24px #0003';
  document.body.append(e);
  setTimeout(() => e.remove(), 2300);
}
function rz(f, cb, mx = 700) {
  if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    const m = new Image();
    m.onload = () => {
      const c = document.createElement('canvas'),
        k = Math.min(1, mx / m.width);
      c.width = m.width * k;
      c.height = m.height * k;
      c.getContext('2d').drawImage(m, 0, 0, c.width, c.height);
      cb(c.toDataURL('image/jpeg', 0.72));
    };
    m.src = r.result;
  };
  r.readAsDataURL(f);
}
const cm = () => ($('#md').innerHTML = '');
const hd = (t, s, b = '') => `<div class="hd"><div><div class="bc">لوحة المكتب › ${t}</div><h1>${t}</h1><p>${s}</p></div>${b}</div>`,
  bk = () => '';
const say = (ph, name, x) => SA_officeSend(ph, name, x);
const NV = [
  ['home', 'الرئيسية', '▦'],
  ['txn', 'المعاملات والأرباح', '💰'],
  ['g', 'العروض والخدمات'],
  ['air', 'الطيران', '✈️'],
  ['bus', 'النقل الدولي', '🚌'],
  ['visa', 'التأشيرات', '📄'],
  ['pass', 'الجوازات والوثائق', '🛂'],
  ['cars', 'تأجير السيارات', '🚗'],
  ['priv', 'رحلات خاصة', '🚘'],
  ['svcs', 'إدارة الخدمات', '☷'],
  ['g', 'الطلبات والتواصل'],
  ['orders', 'طلبات العملاء', '📋'],
  ['rem', 'حوالات العملاء', '💳'],
  ['customers', 'العملاء', '👥'],
  ['chats', 'المحادثات', '💬'],
  ['rv', 'تقييمات العملاء', '⭐'],
  ['docs', 'مستندات العملاء', '📎'],
  ['amanat', 'استقبال وإرسال الجوازات', '📮'],
  ['g', 'شراء عروض تطبيقنا'],
  ['pkg', 'باقات العروض والرصيد', '🛒'],
  ['g', 'إعدادات المكتب'],
  ['profile', 'ملف المكتب وبياناته', '🏢'],
  ['banks', 'الحسابات البنكية', '🏦'],
  ['settings', 'الإعدادات والربط', '⚙️'],
];
const cnt = () => ({
  orders: D.ord.filter((o) => o.st == 0).length,
  chats: Object.values(D.ch).reduce((a, c) => a + (c.un || 0), 0),
  amanat: D.am.filter((a) => (a.dir || 'in') == 'in' && a.st == 0).length,
  rem: D.rm.filter((r) => !r.st).length,
  rv: (D.rvs || []).filter((r) => !r.officeReply && r.status !== 'hidden').length,
});
