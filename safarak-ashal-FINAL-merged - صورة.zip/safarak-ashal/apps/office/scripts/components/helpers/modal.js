/* النافذة المنبثقة وإظهار/إخفاء القائمة الجانبية
   يعرّف: tgs، mo */
const tgs = () => {
  if (innerWidth > 900) {
    const c = document.body.classList.toggle('sbh');
    try {
      localStorage.setItem('safarak_sb', c ? 1 : 0);
    } catch (e) {}
  } else {
    $('#sb').classList.toggle('open');
    $('#ov').classList.toggle('on');
  }
};
function mo(t, b, s, x = '') {
  $('#md').innerHTML = dc(
    `<div class="mb" onclick="if(event.target==this)cm()"><div class="mc"><div class="mh"><b>${t}</b><button class="ib" onclick="cm()">✕</button></div><div class="mbd">${b}</div><div class="mf">${s ? `<button class="bt g" onclick="${s}">حفظ</button>` : ''}${x}<button class="bt o" onclick="cm()">إغلاق</button></div></div></div>`,
  );
}
