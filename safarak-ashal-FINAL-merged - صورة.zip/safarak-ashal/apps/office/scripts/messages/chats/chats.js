/* المحادثات
   يعرّف: chats، sm */
function chats() {
  const L = Object.entries(D.ch).sort((a, b) => (b[1].m.slice(-1)[0] || { t: 0 }).t - (a[1].m.slice(-1)[0] || { t: 0 })),
    c = D.ch[F.ch];
  if (c && !c.loaded && !c.busy) SA_officeLoadMsgs(F.ch);
  else if (c && c.un) SA_officeMarkRead(c);
  return (
    hd('المحادثات', 'محادثة لكل عميل، وتصل العميل داخل التطبيق') +
    `<div class="cw ${c ? 'op' : ''}"><div class="card cl">${L.map(([p, x]) => `<div class="ci ${p == F.ch ? 'on' : ''}" onclick="F.ch='${p}';go()"><div class="ia">${h(x.name[0])}</div><div><b>${h(x.name)}</b><small>${(x.m.slice(-1)[0] || {}).f ? '📎 ' : ''}${h((x.m.slice(-1)[0] || {}).x || '')}</small></div>${x.un ? `<em>${x.un}</em>` : ''}</div>`).join('') || '<p class="em">لا توجد محادثات</p>'}</div><div class="card ct">${
      c
        ? `<div class="cth"><button class="ib bkb" onclick="F.ch=null;go()">›</button><b>${h(c.name)}</b><small dir="ltr">${F.ch}</small></div><div class="msgs" id="ms">${c.m.map((m) => `<div class="mg ${m.me ? 'me' : ''}">${m.f ? fchip(m.f) : ''}${h(m.x)}<small>${tm(m.t)}</small></div>`).join('')}</div><div class="qr">${(D.cfg.qr && D.cfg.qr.length ? D.cfg.qr : QR).map((q) => `<button class="ch" onclick="sm('${q}')">${q}</button>`).join('')}</div>${
            F.af
              ? `<div class="nt" style="margin:6px 12px">${/^image/.test(F.af.type) ? '🖼' : '📄'} ${h(F.af.n)} <button class="ib" onclick="F.af=null;go()">✕</button><div class="fg" style="margin-top:8px"><select id="ck">${KINDS.map((k) => `<option>${k}</option>`).join('')}</select><select id="co"><option value="">بدون ربط بطلب</option>${D.ord
                  .filter((o) => o.ph == F.ch)
                  .map((o) => `<option value="${o.id}">${osn(o)} · ${h(o.title)}</option>`)
                  .join('')}</select></div></div>`
              : ''
          }<div class="sn"><button class="ib" title="إرفاق PDF أو صورة" onclick="$('#cf').click()">📎</button><input id="cf" type="file" accept="image/*,application/pdf" hidden onchange="atc(this.files[0])"><input id="mi" placeholder="اكتب رسالتك..." onkeydown="if(event.key=='Enter')sm()"><button class="bt" onclick="sm()">إرسال</button></div>`
        : '<p class="em" style="margin:auto">اختر محادثة للبدء</p>'
    }</div></div>`
  );
}
function sm(t) {
  const i = $('#mi'),
    x = t || (i && i.value.trim()),
    f = F.af;
  if (!x && !f) return;
  const c = D.ch[F.ch];
  if (i) i.value = '';
  if (f) {
    SA_officeSendFile(F.ch, c.name, f, ($('#ck') || {}).value || 'ملف ', ($('#co') || {}).value, x);
    F.af = null;
  } else SA_officeSend(F.ch, c.name, x);
  go();
}
