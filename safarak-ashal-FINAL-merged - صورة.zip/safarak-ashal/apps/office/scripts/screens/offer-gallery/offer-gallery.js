/* صور العروض الإضافية
   يعرّف: gadd، gdel، GL */
function gadd(fs) {
  sync();
  const o = F.eo;
  o.pics = o.pics || [];
  [...fs].slice(0, 3 - o.pics.length).forEach((f) =>
    rz(
      f,
      (d) => {
        o.pics.push(d);
        go();
      },
      900,
    ),
  );
}
function gdel(i) {
  sync();
  F.eo.pics.splice(i, 1);
  go();
}
/* ===== صور إضافية للسيارة ===== */
const GL = () =>
  `<div class="w"><label>صور إضافية (خلفية / داخلية / جانبية، حتى 3)</label><div class="up">${(F.eo.pics || []).map((x, i) => `<img src="${x}" title="اضغط للحذف" onclick="gdel(${i})">`).join('')}<input type="file" accept="image/*" multiple onchange="gadd(this.files)"></div></div>`;
