/* تقييمات العملاء: عرضها من الخادم والرد عليها (يصل الرد للعميل ويظهر في صفحة المكتب)
   يعرّف: reviewsPage، SA_loadReviews، rvReply، rvReplySend، rvStars */
async function SA_loadReviews() {
  if (!window.SA_API) return;
  try {
    const r = await window.SA_API.reviews();
    D.rvs = (r.reviews || []).slice();
    D.rvsLoaded = 1;
  } catch (e) {
    console.warn('تعذر تحميل التقييمات:', e.message);
    D.rvs = D.rvs || [];
    D.rvsFailed = 1;
  }
}
const rvStars = (n) => '★'.repeat(n) + '☆'.repeat(5 - n);
function reviewsPage() {
  if (!D.rvsLoaded && !D.rvsFailed && !D.rvsBusy) {
    D.rvsBusy = 1;
    SA_loadReviews().then(() => {
      D.rvsBusy = 0;
      if (V == 'rv') go();
    });
  }
  const L = D.rvs || [],
    shown = L.filter((r) => r.status !== 'hidden'),
    avg = shown.length ? (shown.reduce((a, r) => a + r.rating, 0) / shown.length).toFixed(1) : '—',
    open = shown.filter((r) => !r.officeReply).length;
  return (
    hd('تقييمات العملاء', 'ما كتبه العملاء بعد اكتمال طلباتهم، ويمكنك الرد على كل تقييم ليصل ردك للعميل') +
    `<div class="gr" style="margin-bottom:16px"><div class="sc"><i>⭐</i><div><b style="font-size:26px">${avg}</b><small>متوسط التقييم</small></div></div><div class="sc"><i>💬</i><div><b style="font-size:26px">${shown.length}</b><small>عدد التقييمات</small></div></div><div class="sc"><i>✍️</i><div><b style="font-size:26px">${open}</b><small>بانتظار ردك</small></div></div></div>` +
    `<div class="card">${
      L.map(
        (r) =>
          `<div class="row" style="align-items:flex-start"><div class="ia">${h((r.customerName || 'ع')[0])}</div><div class="rm" style="flex:1"><b>${h(r.customerName || 'عميل')} <span style="color:#d4a017;letter-spacing:2px">${rvStars(r.rating)}</span></b><small>${dt(SA_ts(r.createdAt))}${r.bookingId ? ' · طلب ' + h(r.bookingId) : ''}</small>${r.comment ? `<p style="margin:6px 0">${h(r.comment)}</p>` : '<p style="margin:6px 0;color:var(--mu)">تقييم بدون تعليق</p>'}${r.officeReply ? `<div style="background:var(--bg,#f6f7f9);border-radius:10px;padding:8px 10px;margin-top:4px"><small style="display:block;color:var(--mu)">ردّك</small>${h(r.officeReply)}</div>` : ''}</div>${r.status === 'hidden' ? '<span class="pl er">مخفي من الإدارة</span>' : `<button class="bt s" onclick="rvReply(${r.id})">${r.officeReply ? 'تعديل الرد' : 'رد'}</button>`}</div>`,
      ).join('') || '<p class="em">لا توجد تقييمات بعد؛ تظهر هنا بعد أن يقيّم العملاء طلباتهم المكتملة</p>'
    }</div>`
  );
}
function rvReply(id) {
  const r = (D.rvs || []).find((x) => x.id == id);
  if (!r) return;
  mo('الرد على تقييم ' + h(r.customerName || 'العميل'), `<div class="fg"><div class="w"><label>ردّك (يصل للعميل)</label><textarea id="rv_t" rows="4" maxlength="2000">${h(r.officeReply || '')}</textarea></div></div>`, `rvReplySend(${r.id})`);
}
async function rvReplySend(id) {
  const reply = ($('#rv_t').value || '').trim();
  if (!reply) return toast('اكتب الرد أولاً');
  try {
    await window.SA_API.replyReview(id, reply);
    cm();
    toast('تم إرسال ردك للعميل');
    await SA_loadReviews();
    go();
  } catch (e) {
    toast(e.message || 'تعذر إرسال الرد');
  }
}
