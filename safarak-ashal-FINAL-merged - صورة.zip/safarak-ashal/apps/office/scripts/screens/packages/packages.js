/* شراء عروض تطبيقنا: باقات الإدارة، طلب كمية مخصصة، الرصيد المتبقي وسجل الطلبات
   يعرّف: packages، SA_loadPackages، pkReq، pkCustom، pkCustomSend */
const PKS = { requested: ['بانتظار المراجعة', 'wr'], approved: ['تمت الموافقة · بانتظار الدفع', 'bu'], paid: ['تم الدفع · قيد التفعيل', 'bu'], fulfilled: ['تم تفعيل الرصيد', 'ok'], rejected: ['مرفوض', 'er'] };
async function SA_loadPackages() {
  if (!window.SA_API) return;
  try {
    const [a, b] = await Promise.all([window.SA_API.packages(), window.SA_API.officePackagePurchases()]);
    D.pk = { list: a.packages || [], purchases: b.purchases || [], quotas: b.quotas || [], loaded: 1 };
  } catch (e) {
    console.warn('تعذر تحميل الباقات:', e.message);
    D.pk = D.pk || { list: [], purchases: [], quotas: [] };
  }
}
function packages() {
  const P = D.pk || { list: [], purchases: [], quotas: [] };
  if (!P.loaded && !P.busy) {
    P.busy = 1;
    D.pk = P;
    SA_loadPackages().then(() => V == 'pkg' && go());
  }
  const q = (k) => (P.quotas.find((x) => x.service_type == k) || {}).remaining || 0;
  return (
    hd('شراء عروض تطبيقنا', 'رصيد عروضك المتاح، الباقات التي تعرضها الإدارة، وطلب كمية مخصصة', '<button class="bt g" onclick="pkCustom()">+ طلب كمية مخصصة</button>') +
    `<div class="gr" style="margin-bottom:16px">${Object.keys(SV)
      .map((k) => `<div class="sc"><i>${SV[k][1]}</i><div><b style="font-size:26px">${q(k)}</b><small>رصيد ${SV[k][0]}</small></div></div>`)
      .join('')}</div>` +
    `<div class="card"><h3>الباقات المتاحة</h3>${
      P.list
        .map(
          (p) =>
            `<div class="row"><div class="ia">${(SV[p.service_type] || ['', '🛒'])[1]}</div><div class="rm"><b>${h(p.title)}</b><small>${h((SV[p.service_type] || [p.service_type])[0])} · ${p.quantity} عرض${p.description ? ' · ' + h(p.description) : ''}</small></div><span class="pl bu">${p.price} ${h(p.currency)}</span><button class="bt s" onclick="pkReq(${p.id})">اطلب الشراء</button></div>`,
        )
        .join('') || '<p class="em">لا توجد باقات منشورة حالياً، يمكنك طلب كمية مخصصة</p>'
    }</div>` +
    `<div class="card"><h3>سجل طلباتك</h3>${
      P.purchases
        .map((x) => {
          const s = PKS[x.status] || [x.status, 'wr'];
          return `<div class="row"><div class="ia">${(SV[x.service_type] || ['', '🛒'])[1]}</div><div class="rm"><b>${h(x.package_title || 'كمية مخصصة')} · ${x.quantity} × ${h((SV[x.service_type] || [x.service_type])[0])}</b><small>${dt(SA_ts(x.created_at))}${x.total_price ? ' · ' + x.total_price + ' ' + h(x.currency) : ''}${x.note ? ' · ' + h(x.note) : ''}</small></div><span class="pl ${s[1]}">${s[0]}</span></div>`;
        })
        .join('') || '<p class="em">لا توجد طلبات بعد</p>'
    }</div>`
  );
}
async function pkReq(id) {
  try {
    await window.SA_API.requestPackage({ packageId: id });
    toast('تم إرسال طلب الشراء للإدارة');
    await SA_loadPackages();
    go();
  } catch (e) {
    toast(e.message || 'تعذر إرسال الطلب');
  }
}
function pkCustom() {
  mo(
    'طلب كمية مخصصة',
    `<div class="fg"><div><label>نوع الخدمة</label><select id="pk_t">${Object.keys(SV)
      .map((k) => `<option value="${k}">${SV[k][0]}</option>`)
      .join('')}</select></div><div><label>عدد العروض</label><input id="pk_q" type="number" min="1" value="10"></div><div class="w"><label>ملاحظة للإدارة (اختياري)</label><input id="pk_n"></div></div>`,
    'pkCustomSend()',
  );
}
async function pkCustomSend() {
  const quantity = Number($('#pk_q').value),
    serviceType = $('#pk_t').value;
  if (!Number.isInteger(quantity) || quantity < 1) return toast('اكتب عدداً صحيحاً');
  try {
    await window.SA_API.requestPackage({ serviceType, quantity, note: $('#pk_n').value.trim() });
    cm();
    toast('تم إرسال طلبك؛ ستحدد الإدارة السعر وتتواصل معك');
    await SA_loadPackages();
    go();
  } catch (e) {
    toast(e.message || 'تعذر إرسال الطلب');
  }
}
