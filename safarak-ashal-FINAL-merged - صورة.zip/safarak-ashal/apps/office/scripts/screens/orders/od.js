/* طلبات العملاء — الجزء 2/3
   يعرّف: od */
function od() {
  const o = D.ord.find((x) => x.id == F.id);
  if (!o) return orders();
  const k = (a, b) => `<div><small>${a}</small><b>${b}</b></div>`,
    c = cuL().find((x) => x.ph == o.ph) || { no: '—' },
    A = {
      0: [
        ['⚙️ قبول وبدء التنفيذ', 1, 'g'],
        ['📎 طلب وثائق', 4, 'o'],
        ['💳 بانتظار الدفع', 5, 'o'],
        ['⛔ رفض الطلب', 3, 'r'],
      ],
      1: [
        ['🎉 إتمام التنفيذ', 2, 'g'],
        ['📎 طلب وثائق', 4, 'o'],
        ['⛔ رفض الطلب', 3, 'r'],
      ],
      4: [
        ['⚙️ قبول وبدء التنفيذ', 1, 'g'],
        ['↩ إعادة للمراجعة', 0, 'o'],
      ],
      5: [
        ['⚙️ قبول وبدء التنفيذ', 1, 'g'],
        ['↩ إعادة للمراجعة', 0, 'o'],
      ],
    }[o.st] || [['↩ إعادة فتح الطلب', 0, 'o']],
    bad = o.st == 3 || o.st == 6;
  return (
    bk('orders', 'رجوع إلى الطلبات') +
    hd('طلب ' + osn(o), o.id + ' · ' + SV[o.svc][0]) +
    `<div class="card"><div class="bn ${STC[o.st]}">${BN[o.st]}</div><div class="trk ${bad ? 'red' : ''}" style="margin:10px 0">${[0, 1, 2].map((i) => `<i class="${bad || i < (o.st == 2 ? 3 : o.st == 1 ? 2 : 1) ? 'on' : ''}"></i>`).join('')}</div><div style="display:flex;gap:8px;flex-wrap:wrap">${A.map((a) => `<button class="bt ${a[2]}" onclick="ss('${o.id}',${a[1]})">${a[0]}</button>`).join('')}<button class="bt o" onclick="pdfO('${o.id}')">📄 ملف الطلب PDF</button></div></div>
<div class="card"><h3>بيانات الطلب</h3><div class="kv">${k('رقم الطلب', osn(o))}${k('الخدمة', SV[o.svc][0])}${k('التفاصيل', h(o.title))}${k('التاريخ', dt(o.ts))}${k('عدد الأفراد', o.pax)}${k('الإجمالي', (o.cur || D.cfg.cur || 'YER') + o.tot)}</div><div class="fg" style="margin-top:12px"><div><label>ربح المكتب من هذه المعاملة (${(o.cur || D.cfg.cur || 'YER').trim()})</label><input id="pr" type="number" min="0" value="${o.pr || 0}"></div><div style="align-self:end"><button class="bt" onclick="{const v=+$('#pr').value;if(v<0||isNaN(v))return toast('رقم غير صحيح');D.ord.find(x=>x.id=='${o.id}').pr=v;save();toast('تم حفظ الربح')}">حفظ الربح</button></div></div></div>
<div class="card"><h3>العميل</h3><div class="kv">${k('الاسم', h(o.name))}${k('الرقم التسلسلي', c.no)}${k('الجوال', '<span dir="ltr">' + h(o.ph) + '</span>')}</div><div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap"><button class="bt" onclick="go('cp','${o.ph}')">👤 صفحة العميل الكاملة</button><button class="bt o" onclick="F.ch='${o.ph}';go('chats')">💬 مراسلة</button></div></div>
${fdCard(o)}${rmCard(o)}<div class="card"><div class="hd" style="margin:0 0 6px"><div><h3 style="margin:0">المستندات والملفات</h3></div><button class="bt s" onclick="ofu('${o.id}')">⬆ رفع ملف للعميل (PDF / صورة)</button></div>${o.docs.map((d, i) => `<div class="dr"><span>📎 ${h(d.n)} ${d.by ? '<i class="pl bu" style="font-style:normal">من المكتب · ' + h(d.kind || '') + '</i>' : ''}</span>${d.data ? `<button class="ib" onclick="opd('${o.id}',${i})">👁</button>` : ''}<span class="pl ${d.ok == 1 ? 'ok' : d.ok == 0 ? 'rd' : 'wr'}">${d.ok == 1 ? 'مقبول' : d.ok == 0 ? 'مرفوض' : 'بانتظار المراجعة'}</span><button class="ib" onclick="dk('${o.id}',${i},1)">✓</button><button class="ib" onclick="dk('${o.id}',${i},0)">✕</button></div>`).join('') || '<p class="em">لا توجد مستندات</p>'}</div>
<div class="card"><h3>سجل الطلب</h3>${ordLog(o)
      .map((a) => `<div class="dr"><span>${h(a.x)}</span><small style="color:var(--mu)">${dt(a.t)} ${tm(a.t)}</small></div>`)
      .join('')}</div>
<div class="card"><h3>ملاحظة داخلية (لا يراها العميل)</h3><textarea id="nt" rows="2">${h(o.note)}</textarea><button class="bt" style="margin-top:10px" onclick="D.ord.find(x=>x.id=='${o.id}').note=$('#nt').value;save();toast('تم حفظ الملاحظة')">حفظ الملاحظة</button></div>`
  );
}
