/* طلبات العملاء — الجزء 1/3
   يعرّف: ocard، orders */
/* الطلبات: نفس تصميم «طلباتي» عند العميل */
function ocard(o) {
  const f = o.st == 2 ? 3 : o.st == 1 ? 2 : o.st == 3 || o.st == 6 ? 0 : 1,
    bad = o.st == 3 || o.st == 6,
    dn = o.docs.filter((d) => d.ok == 1).length;
  return `<div class="oc2" onclick="go('od','${o.id}')"><div class="ot"><div class="ia">${SV[o.svc][1]}</div><div><b>${h(o.title)}</b><small>${SV[o.svc][0]} · ${osn(o)} · ${o.id}</small></div><span class="pl ${STC[o.st]}">${STS[o.st]}</span></div><div class="om"><div><small>العميل</small><b>${h(o.name)}</b></div><div><small>التاريخ</small><b>${dt(o.ts)}</b></div><div><small>الأفراد</small><b>${o.pax}</b></div><div><small>الإجمالي</small><b>${o.cur || D.cfg.cur || 'YER'}${o.tot}</b></div></div><div class="trk ${bad ? 'red' : ''}">${[0, 1, 2].map((i) => `<i class="${bad ? 'on' : i < f ? 'on' : ''}"></i>`).join('')}</div><i class="sq">✔ البيانات</i><i class="sq ${dn == o.docs.length ? '' : 'wr'}">المستندات ${dn}/${o.docs.length}</i><i class="sq ${o.st == 5 ? 'wr' : ''}">${o.st == 5 ? 'الدفع ناقص' : '✔ الدفع'}</i></div>`;
}
function orders() {
  const q = F.q,
    L = D.ord.filter((o) => (F.st == 'all' || o.st == F.st) && (!q || [o.name, o.id, o.ph, o.title].join(' ').includes(q)));
  return (
    hd('طلبات العملاء', 'كل طلبات العملاء مع حالاتهم ومستنداتهم', '<button class="bt g" onclick="onew()">+ طلب يدوي</button>') +
    (q ? `<div class="nt">نتائج البحث عن «${h(q)}» <button class="bt s" onclick="F.q='';go()">مسح</button></div>` : '') +
    `<div style="margin-bottom:10px"><button class="ch ${F.st == 'all' ? 'on' : ''}" onclick="F.st='all';go()">الكل ${D.ord.length}</button>${STS.map((s, i) => `<button class="ch ${F.st === i ? 'on' : ''}" onclick="F.st=${i};go()">${s} ${D.ord.filter((o) => o.st == i).length}</button>`).join('')}</div>` +
    (L.map(ocard).join('') || '<div class="card em">لا توجد طلبات</div>')
  );
}
