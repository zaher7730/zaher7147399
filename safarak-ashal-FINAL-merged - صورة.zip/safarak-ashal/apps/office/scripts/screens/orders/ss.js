/* طلبات العملاء — الجزء 3/3
   يعرّف: ss، dk */
async function ss(id, i) {
  let o = D.ord.find((x) => x.id == id);
  if (!o || o._statusSyncing) return;
  let r = '';
  if (i == 3) {
    r = prompt('سبب الرفض (يصل العميل)؟');
    if (r === null) return;
  }
  /* الحالة تُحفظ على الخادم أولاً؛ لا تتغيّر الواجهة ولا يُبلَّغ العميل ولا تظهر رسالة نجاح إلا بعد تأكيده */
  if (window.SA_API && o.serverId) {
    const target = Object.keys(SA_ST).find((k) => SA_ST[k] === i);
    o._statusSyncing = true;
    try {
      await window.SA_API.updateBookingStatus(o.serverId, { status: target, note: String(o.note || '') });
      o.serverStatus = target;
    } catch (e) {
      toast(e.message || 'تعذّر حفظ الحالة على الخادم؛ لم تتغيّر حالة الطلب');
      return;
    } finally {
      o._statusSyncing = false;
    }
    o = D.ord.find((x) => x.id == id) || o;
    o.serverStatus = target;
  }
  o.st = i;
  lg(o, 'الحالة: ' + STS[i] + (r ? ' — ' + r : ''));
  say(o.ph, o.name, 'تم تحديث حالة طلبك ' + osn(o) + ' إلى: ' + STS[i] + (r ? ' — السبب: ' + r : ''));
  save();
  toast('تم تحديث الحالة وإبلاغ العميل');
  go();
}
function dk(id, i, v) {
  const o = D.ord.find((x) => x.id == id);
  o.docs[i].ok = v;
  lg(o, (v ? 'قبول' : 'رفض') + ' المستند: ' + o.docs[i].n);
  if (!v) {
    o.st = 4;
    say(o.ph, o.name, 'تم رفض مستند «' + o.docs[i].n + '»، يرجى إعادة إرساله');
  }
  save();
  go();
}
