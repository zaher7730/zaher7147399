/* سجل الطلب من الخادم: تغييرات الحالة والحوالات والتقييم بالعربية، مع الرجوع للسجل المحلي إن لم يتوفر الخادم
   يعرّف: ordLog، SA_loadOrderLog */
async function SA_loadOrderLog(o) {
  try {
    const r = await window.SA_API.bookingTimeline(o.serverId);
    o.tl = (r.timeline || [])
      .map((e) => ({ t: SA_ts(e.at), x: e.text + (e.note ? ' — ' + e.note : '') + (e.actor ? ' (' + e.actor + ')' : '') }))
      .sort((a, b) => b.t - a.t);
    o.tlLoaded = 1;
  } catch (e) {
    o.tlFailed = 1;
  }
  o.tlBusy = 0;
  if (V == 'od' && F.id == o.id) go();
}
function ordLog(o) {
  if (o.tlLoaded) return o.tl;
  if (window.SA_API && o.serverId && !o.tlBusy && !o.tlFailed) {
    o.tlBusy = 1;
    SA_loadOrderLog(o);
  }
  return actv([o]);
}
