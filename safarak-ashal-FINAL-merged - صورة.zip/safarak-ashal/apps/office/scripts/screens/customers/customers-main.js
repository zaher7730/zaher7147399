/* العملاء — الجزء 1/2
   يعرّف: customers، cp */
function customers() {
  const q = F.cq || '',
    A = cuL(),
    L = A.filter((c) => !q || [c.name, c.ph, c.no].join(' ').includes(q));
  return (
    hd(
      'العملاء',
      A.length + ' عميل · لكل عميل رقم تسلسلي وصفحة كاملة',
      `<button class="bt o" onclick="pdfAll()">📄 قائمة العملاء PDF</button>`,
    ) +
    `<input placeholder="ابحث بالاسم أو الجوال أو الرقم التسلسلي" value="${h(q)}" style="margin-bottom:14px" onchange="F.cq=this.value;go()"><div class="card">${L.map((c) => `<div class="row" onclick="go('cp','${c.ph}')"><div class="ia">${h(c.name[0])}</div><div class="rm"><b>${h(c.name)} <span class="pl bu">${c.no}</span>${c.d.tag && c.d.tag != 'عادي' ? `<span class="pl ${c.d.tag == 'محظور' ? 'rd' : 'wr'}">${c.d.tag}</span>` : ''}</b><small>${c.ph} · ${c.o.length} طلب · آخر خدمة: ${SV[[...c.o].sort((a, b) => b.ts - a.ts)[0].svc][0]}</small></div><span>‹</span></div>`).join('') || '<p class="em">لا يوجد عملاء</p>'}</div>`
  );
}
function cp() {
  const c = cuL().find((x) => x.ph == F.id);
  if (!c) return customers();
  const tb = F.ct || 0,
    d = c.d,
    O = [...c.o].sort((a, b) => b.ts - a.ts),
    DK = O.flatMap((o) => o.docs.map((x) => ({ o, x }))),
    ch = D.ch[c.ph],
    ms = D.am.filter((a) => a.ph == c.ph),
    N = O.filter((o) => o.st == 2),
    wa = c.ph.startsWith('967') ? c.ph : '967' + c.ph,
    n = (a) => O.filter((o) => a.includes(o.st)).length,
    US = Object.keys(SV).filter((k) => O.some((o) => o.svc == k)),
    T = [
      'نظرة عامة',
      'الطلبات (' + O.length + ')',
      'المستندات (' + DK.length + ')',
      'الجوازات (' + ms.length + ')',
      'سجل النشاط',
      'المحادثة',
      'الحوالات (' + D.rm.filter((r) => r.ph == c.ph).length + ')',
    ],
    kv = (a, b) => `<div><small>${a}</small><b>${b}</b></div>`;
  const B = [
    `${cpInfo(c)}
<div class="card"><h3>نشاطه حسب الخدمة</h3>${US.map((k) => {
      const a = O.filter((o) => o.svc == k),
        m = a.filter((o) => o.st == 2);
      return `<div class="dr"><b>${SV[k][1]} ${SV[k][0]}</b><span class="pl">${a.length} طلب</span><span class="pl ok">${m.length} منفذ</span><span class="pl bu">${money(m, 'tot')}</span><span class="pl wr">ربح ${money(m, 'pr')}</span></div>`;
    }).join('')}</div>
<div class="card"><h3>آخر طلب</h3>${ocard(O[0])}</div>
<div class="card"><h3>تصنيف وملاحظات المكتب</h3><div class="fg"><div><label>تصنيف العميل</label><select id="c_tag">${['عادي', 'VIP', 'محظور'].map((x) => `<option ${d.tag == x ? 'selected' : ''}>${x}</option>`).join('')}</select></div><div class="w"><label>ملاحظات المكتب (لا يراها العميل)</label><textarea id="c_note" rows="2">${h(d.note)}</textarea></div></div><button class="bt g" style="margin-top:12px" onclick="cs('${c.ph}')">حفظ</button></div>`,
    US.map(
      (k) =>
        `<div class="card"><h3>${SV[k][1]} ${SV[k][0]} · ${O.filter((o) => o.svc == k).length}</h3>${O.filter((o) => o.svc == k)
          .map(ocard)
          .join('')}</div>`,
    ).join(''),
    `<div class="card"><h3>مستندات العميل</h3>${DK.map(({ o, x }) => `<div class="row" onclick="go('od','${o.id}')"><div class="ia">📎</div><div class="rm"><b>${h(x.n)}</b><small>${SV[o.svc][0]} · ${osn(o)}</small></div><span class="pl ${x.ok == 1 ? 'ok' : x.ok == 0 ? 'rd' : 'wr'}">${DR_(x)}</span></div>`).join('') || '<p class="em">لا توجد مستندات</p>'}</div>`,
    `<div class="card"><div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap"><button class="bt s" onclick="ame('in')">+ تسجيل استقبال</button><button class="bt s" onclick="ame('out')">+ تسجيل إرسال</button></div>${ms.map((a) => `<div class="dr"><span>${a.dir == 'out' ? '📤 إرسال' : '📥 استقبال'} · ${h(a.items)} · ${h(a.off)}</span><span class="pl bu">${AMS(a)}</span></div>`).join('') || '<p class="em">لا توجد جوازات مسجلة لهذا العميل</p>'}</div>`,
    `<div class="card"><h3>سجل النشاط</h3>${actv(O)
      .map((a) => `<div class="dr"><span>${h(a.x)}</span><small style="color:var(--mu)">${dt(a.t)} ${tm(a.t)}</small></div>`)
      .join('')}</div>`,
    `<div class="card"><h3>المحادثة</h3>${
      ch
        ? ch.m
            .slice(-10)
            .map(
              (m) =>
                `<div class="mg ${m.me ? 'me' : ''}" style="max-width:100%;margin-bottom:6px">${h(m.x)}<small>${tm(m.t)}</small></div>`,
            )
            .join('')
        : '<p class="em">لا توجد محادثة بعد</p>'
    }<div class="sn" style="padding:10px 0 0"><input id="mi" placeholder="اكتب رسالة للعميل..."><button class="bt" onclick="sm2('${c.ph}')">إرسال</button></div></div>`,
    `<div class="card">${
      D.rm
        .filter((r) => r.ph == c.ph)
        .map(rmRow)
        .join('') || '<p class="em">لا توجد حوالات</p>'
    }</div>`,
  ][tb];
  return (
    `<div class="sh"><i>${h(c.name[0])}</i><div><h1>${h(c.name)} ${d.tag && d.tag != 'عادي' ? `<span class="pl ${d.tag == 'محظور' ? 'rd' : 'wr'}">${d.tag}</span>` : ''}</h1><p>${c.no} · <span dir="ltr">${c.ph}</span></p></div><button class="bt g" onclick="F.ch='${c.ph}';go('chats')">💬 المحادثات</button><a class="bt" style="background:#fff;color:var(--nv);text-decoration:none" href="tel:${c.ph}">📞 اتصال</a><a class="bt" style="background:#fff;color:var(--nv);text-decoration:none" href="https://wa.me/${wa}" target="_blank">واتساب</a><button class="bt" style="background:#fff;color:var(--nv)" onclick="pdfC('${c.ph}')">📄 ملف PDF</button></div>
<div class="gr" style="margin-bottom:16px">${[
      ['📋', O.length, 'كل الطلبات'],
      ['⚙️', n([0, 1, 4, 5]), 'طلبات جارية'],
      ['✅', N.length, 'معاملات منفذة'],
      ['📎', DK.length, 'مستندات'],
      ['💵', money(N, 'tot'), 'قيمة المنفذة'],
      ['💰', money(N, 'pr'), 'ربح المكتب'],
    ]
      .map(
        (x) =>
          `<div class="sc"><i>${x[0]}</i><div><b style="font-size:${String(x[1]).length > 8 ? 18 : 26}px">${x[1]}</b><small>${x[2]}</small></div></div>`,
      )
      .join('')}</div>
<div class="tb" style="overflow:auto">${T.map((x, i) => `<button class="${tb == i ? 'on' : ''}" style="white-space:nowrap" onclick="F.ct=${i};go()">${x}</button>`).join('')}</div>` +
    B
  );
}
