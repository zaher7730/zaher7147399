/* العملاء — الجزء 2/2
   يعرّف: cs، sm2 */
function cs(ph) {
  D.cd = D.cd || {};
  D.cd[ph] = { ...(D.cd[ph] || {}), tag: $('#c_tag').value, note: $('#c_note').value.trim() };
  save();
  toast('تم الحفظ');
  go();
}
const sm2 = (ph) => {
  const x = $('#mi').value.trim();
  if (!x) return;
  say(ph, (cuL().find((c) => c.ph == ph) || {}).name, x);
  save();
  go();
};
