/* الرئيسية — الجزء 2/2
   يعرّف: HM_ILL، PLT */
const HM_ILL = '/apps/office/assets/images/home-1.jpg';
const PLT = [
    [100, 2],
    [300, 2.5],
    [700, 3],
    [1500, 3.5],
    [1e12, 4],
  ],
  plr = (u) => (PLT.find((x) => u <= x[0]) || PLT[PLT.length - 1])[1];
