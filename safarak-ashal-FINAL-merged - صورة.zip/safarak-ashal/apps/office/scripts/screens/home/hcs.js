/* الرئيسية — الجزء 1/2
   يعرّف: hcs، home */
function hcs() {
  const n = String((D.cfg && D.cfg.wa) || D.pf.wa || '').replace(/\D/g, '');
  if (!n) return toast('رقم خدمة العملاء غير مضبوط');
  window.open('https://wa.me/' + n + '?text=' + encodeURIComponent('مرحباً، أحتاج مساعدة من خدمة العملاء'), '_blank');
}
function home() {
  const O = D.ord,
    N = O.filter((o) => o.st == 2),
    c = cnt(),
    sv = (p) =>
      `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="${p}"/></svg>`,
    usd = (o) => {
      const t = +o.tot || 0,
        cu = String(o.cur || D.cfg.cur || 'YER').trim();
      return cu == '$' || cu == 'USD' || !(+D.cfg.rate > 0) ? t : t / +D.cfg.rate;
    },
    fees = N.map((o) => ({ cur: o.cur, fee: Math.round((((+o.tot || 0) * plr(usd(o))) / 100) * 100) / 100 })),
    avg = N.length ? N.reduce((x, o) => x + usd(o), 0) / N.length : 0,
    rate = plr(avg),
    K = [
      [
        'M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6M14 3l5 5v3M14 3v5h5M9 13h4M9 17h3M18 15v6M15 18h6',
        c.orders,
        'طلبات جديدة',
        '#2f7de0',
        '#e8f1fd',
        "F.st=0;go('orders')",
      ],
      [
        'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M12 7v5l3 2',
        O.filter((o) => o.st == 1).length,
        'قيد التنفيذ',
        '#f59e0b',
        '#fff3dc',
        "F.st=1;go('orders')",
      ],
      ['M9 12l2 2 4-4M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18', N.length, 'معاملات منفذة', '#14b8a6', '#dcf8f4', "F.st=2;go('orders')"],
      ['M3 17l6-6 4 4 8-8M15 7h6v6', money(fees, 'fee'), 'نسبة أرباح المنصة', '#22c55e', '#e2f8e9', "go('txn')"],
      [
        'M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 6v4c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 10v4c0 1.7 3.6 3 8 3s8-1.3 8-3v-4M4 14v4c0 1.7 3.6 3 8 3s8-1.3 8-3v-4',
        money(N, 'pr'),
        'مجموع الأرباح',
        '#6d4ad8',
        '#efe9fd',
        "go('txn')",
      ],
    ],
    SK = [
      [
        'visa',
        'التأشيرات',
        'M6 3h12a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zM12 7.5a4 4 0 1 0 0 8 4 4 0 0 0 0-8M8.5 11.5h7M12 7.5c-1.6 1.2-1.6 6.8 0 8M12 7.5c1.6 1.2 1.6 6.8 0 8M8.5 19h7',
        28,
      ],
      ['air', 'طيران', IP.plane, 24],
      ['priv', 'رحلات خاصة', 'M3 8h18v12H3zM9 8V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3M8 8v12M16 8v12', 18],
      ['bus', 'نقل بري', 'M6 3h12a2 2 0 0 1 2 2v12H4V5a2 2 0 0 1 2-2zM4 11h16M7 20v-3M17 20v-3M8 14.5h.01M16 14.5h.01', 16],
      [
        'cars',
        'تأجير سيارات',
        'M4 14l1.6-5a2 2 0 0 1 1.9-1.4h9a2 2 0 0 1 1.9 1.4L20 14M3 14h18v4H3zM6 18v2M18 18v2M7 16h.01M17 16h.01',
        14,
      ],
    ],
    dys = F.hp == null ? 7 : +F.hp,
    lim = dys ? Date.now() - dys * 864e5 : 0,
    cn = SK.map((k) => O.filter((o) => o.svc == k[0] && (+o.ts || 0) >= lim).length),
    tt = cn.reduce((x, y) => x + y, 0),
    rows = SK.map((k, i) => ({ k: k, p: tt ? Math.round((cn[i] * 100) / tt) : k[3] })).sort((x, y) => y.p - x.p),
    FE = [
      ['M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M12 7v5l3 2', 'توفير الوقت والجهد', ''],
      ['M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z', 'خبرة وموثوقية', ''],
      ['M4 14v-2a8 8 0 0 1 16 0v2M4 14h3v5H4zM17 14h3v5h-3zM20 19c0 1.5-2 2-5 2', 'خدمة عملاء متميزة', 'hcs()'],
      ['M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM8.5 12l2.5 2.5 4.5-5', 'أمان في كل رحلة', ''],
    ];
  return `<div class="hm"><div class="hm-hero"><div class="hm-ht"><small>مرحباً بك في</small><h1>${h(D.pf.name)}</h1><p>معك في كل خطوة .. إلى وجهتك</p></div><span class="hm-loc">${sv('M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11M12 7.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5')}اليمن · ${h(D.pf.city || 'عدن')}</span></div>
<div class="hm-k">${K.map((k) => `<button class="hm-kc" onclick="${k[5]}"><i style="background:${k[4]};color:${k[3]}">${sv(k[0])}</i><b>${k[1]}</b><span>${k[2]}</span></button>`).join('')}</div>
<div class="hm-ch"><div class="hm-chh"><h3><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20V11M9 20V6M14 20v-7M19 20V3M2 20h20"/></svg>أكثر الخدمات طلباً في المكتب</h3><label class="hm-sel"><select onchange="F.hp=+this.value;go()"><option value="7"${dys == 7 ? ' selected' : ''}>آخر 7 أيام</option><option value="30"${dys == 30 ? ' selected' : ''}>آخر 30 يوماً</option><option value="0"${dys == 0 ? ' selected' : ''}>كل الفترة</option></select></label></div>
${rows.map((r) => `<button class="hm-r" onclick="go('${r.k[0]}')"><i>${r.k[0] == 'air' ? `<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1" stroke-linejoin="round"><path d="${r.k[2]}"/></svg>` : sv(r.k[2])}</i><span>${r.k[1]}</span><u><em style="width:${Math.min(r.p * 0.9, 80)}%"></em></u><b>${r.p}%</b></button>`).join('')}</div>
<div class="hm-il"><img src="${HM_ILL}" alt=""><h2>نحن نسهل لك عرض خدماتك<br>للعملاء عبر منصتنا</h2><h4>وترتيب معاملاتك بنضام محاسبي دقيق</h4><p class="hm-rt" onclick="toast('نسبة المنصة تتغير حسب قيمة العملية: 2% · 2.5% · 3% · 3.5% · 4%')">نسبة أرباح المنصة من كل عملية تتم عبرها ${rate}%</p></div>
<div class="hm-f">${FE.map((f) => `<button${f[2] ? ` onclick="${f[2]}"` : ''}>${sv(f[0])}<span>${f[1]}</span></button>`).join('')}</div></div>`;
}
