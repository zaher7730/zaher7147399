/* حوالات العملاء — الجزء 2/3
   يعرّف: rmr، rmd، rmn */
async function rmr(id) {
  const r = D.rm.find((x) => x.id == id),
    o = rmO(r),
    w = prompt('سبب رفض الحوالة (يصل العميل)؟');
  if (w == null) return;
  if (window.SA_API && r.serverId) {
    try {
      await window.SA_API.reviewOfficePayment(r.serverId, { status: 'rejected', note: w });
    } catch (e) {
      return toast(e.message || 'تعذر رفض الحوالة على الخادم');
    }
  }
  r.st = 2;
  r.note = w;
  r.at = Date.now();
  if (o) {
    if (o.st == 1) o.st = 5;
    lg(o, 'رفض الحوالة ' + (r.ref || r.id) + (w ? ': ' + w : ''));
  }
  save();
  toast('تم رفض الحوالة وتحديث قاعدة البيانات');
  if (window.SA_API) {
    const me = await window.SA_API.me();
    await SA_hydrateOffice(me.user);
  }
  go();
}
function rmd(id) {
  const r = D.rm.find((x) => x.id == id),
    o = rmO(r);
  mo(
    'حوالة ' + r.id,
    `<div class="kv">${[
      ['العميل', r.name],
      ['الجوال', r.ph],
      ['المبلغ', (r.cur || D.cfg.cur || 'YER').trim() + r.amt],
      ['الحساب', r.bank],
      ['المرجع', r.ref],
      ['المحوّل', r.sender],
      ['التاريخ', dt(r.date)],
      ['الطلب', o ? osn(o) : '—'],
      ['الحالة', RMS[r.st]],
    ]
      .map((x) => `<div><small>${x[0]}</small><b>${h(x[1] || '—')}</b></div>`)
      .join(
        '',
      )}</div>${r.rc ? `<img src="${r.rc}" style="width:100%;border-radius:12px;margin-top:10px">` : r.downloadUrl ? `<a class="bt s" href="${r.downloadUrl}" target="_blank" rel="noopener">تنزيل سند التحويل</a>` : '<p class="em">لا توجد صورة سند مرفقة</p>'}${r.note ? `<div class="nt" style="margin-top:10px">${h(r.note)}</div>` : ''}`,
    0,
    `<button class="bt s" onclick="pdfR('${id}')">📄 PDF</button>`,
  );
}
function rmn(oid) {
  mo(
    'تسجيل حوالة',
    '<div class="fg"><div class="w"><label>الطلب</label><select id="m_o">' +
      D.ord
        .map(
          (o) =>
            `<option value="${o.id}" ${o.id == oid ? 'selected' : ''}>${osn(o)} · ${h(o.name)} · ${(o.cur || D.cfg.cur || 'YER').trim()}${o.tot}</option>`,
        )
        .join('') +
      '</select></div><div><label>المبلغ</label><input id="m_a" type="number" min="0"></div><div><label>الحساب المستلِم</label><select id="m_b">' +
      D.bk.map((b) => `<option>${h(b.n)}</option>`).join('') +
      '</select></div><div><label>رقم الحوالة / المرجع</label><input id="m_r"></div><div><label>اسم المحوّل</label><input id="m_s"></div><div><label>تاريخ التحويل</label><input id="m_d" type="date"></div><div><label>صورة السند</label><input type="file" accept="image/*" onchange="rz(this.files[0],d=>F.rc=d,900)"></div></div>',
    'rms()',
  );
}
