/* حوالات العملاء — الجزء 1/3
   يعرّف: RM0، PRV0، rmp، rmc */
function RM0() {
  const n = Date.now(),
    r = (i, o, st, amt, ago) => ({
      id: 'RM-' + i,
      oid: o.id,
      ph: o.ph,
      name: o.name,
      amt: amt || o.tot,
      cur: o.cur || '$',
      bank: 'بنك الكريمي الإسلامي',
      ref: 'TR' + (5000 + i),
      sender: o.name,
      date: n - ago * 864e5,
      ts: n - ago * 864e5,
      st,
      rc: '',
      note: '',
    });
  return D.ord
    .filter((o) => [1, 2].includes(o.st))
    .map((o, i) => r(i + 1, o, o.st == 2 ? 1 : 0, o.id.endsWith('46') ? o.tot - 200 : 0, i + 1));
}
function PRV0() {
  return [
    {
      id: 7,
      on: 1,
      scope: 'داخلية',
      from: 'صنعاء',
      to: 'عدن',
      days: 'يومياً',
      time: '7:00 ص',
      ty: 'سيدان',
      kind: 'ذهاب',
      seats: 4,
      price: 60,
      old: 70,
      tier: 0,
      pick: 'صنعاء - شارع الستين',
      feat: 'سيارة نظيفة ومكيفة\nسائق محترف',
    },
    {
      id: 6,
      on: 1,
      scope: 'دولية',
      from: 'عدن',
      to: 'جدة',
      days: 'يومياً',
      time: '6:00 ص',
      ty: 'دفع رباعي',
      kind: 'ذهاب',
      seats: 4,
      price: 180,
      old: 200,
      tier: 1,
      pick: 'عدن - كريتر',
      feat: 'سيارة نظيفة ومكيفة\nسائق محترف\nانطلاق من باب البيت',
    },
  ];
}
function rmp() {
  const t = F.rt ?? 0,
    A = D.rm,
    Q = F.rq || '',
    Ls = A.filter((r) => (t == 'all' || r.st == t) && (!Q || [r.name, r.ph, r.ref, r.sender, r.id].join(' ').includes(Q))).sort(
      (a, b) => b.ts - a.ts,
    );
  return (
    hd(
      'حوالات العملاء',
      'سندات التحويل التي أرسلها العملاء عند الدفع؛ تتحقق من وصول المبلغ ثم تؤكد الحوالة فيبدأ تنفيذ الطلب',
      `<button class="bt g" onclick="rmn()">+ تسجيل حوالة</button>`,
    ) +
    `<div class="gr" style="margin-bottom:14px">${[
      ['⏳', 'بانتظار التأكيد', 0],
      ['✅', 'مؤكدة', 1],
      ['⛔', 'مرفوضة', 2],
    ]
      .map(
        (k) =>
          `<div class="card" style="margin:0"><b style="font-size:22px">${k[0]} ${A.filter((r) => r.st == k[2]).length}</b><div>${k[1]}</div><small style="color:var(--mu)">${rsum(A.filter((r) => r.st == k[2]))}</small></div>`,
      )
      .join('')}</div><div class="tb">${[
      [0, 'بانتظار التأكيد'],
      [1, 'مؤكدة'],
      [2, 'مرفوضة'],
      ['all', 'الكل'],
    ]
      .map((x) => `<button class="${t == x[0] ? 'on' : ''}" onclick="F.rt='${x[0]}';go()">${x[1]}</button>`)
      .join(
        '',
      )}</div><input placeholder="ابحث بالاسم أو الجوال أو رقم الحوالة..." value="${h(Q)}" style="margin-bottom:12px" onchange="F.rq=this.value;go()"><div class="card">${Ls.map(rmRow).join('') || '<p class="em">لا توجد حوالات</p>'}</div>`
  );
}
async function rmc(id) {
  const r = D.rm.find((x) => x.id == id),
    o = rmO(r);
  if (o && +r.amt < +o.tot && !confirm('المبلغ المحوّل أقل من إجمالي الطلب. تأكيد الحوالة؟')) return;
  if (window.SA_API && r.serverId) {
    try {
      await window.SA_API.reviewOfficePayment(r.serverId, { status: 'confirmed', note: '' });
    } catch (e) {
      return toast(e.message || 'تعذر تأكيد الحوالة على الخادم');
    }
  }
  r.st = 1;
  r.at = Date.now();
  if (o) {
    if (o.st == 5) o.st = 1;
    const d = (o.docs || []).find((x) => /سند/.test(x.n));
    if (d) d.ok = 1;
    lg(o, 'تأكيد الحوالة ' + (r.ref || r.id));
  }
  save();
  toast('تم تأكيد الحوالة وتحديث قاعدة البيانات');
  if (window.SA_API) {
    const me = await window.SA_API.me();
    await SA_hydrateOffice(me.user);
  }
  go();
}
