/* حوالات العملاء — الجزء 3/3
   يعرّف: rms، RMS، rmRow، rmCard */
async function rms() {
  const o = D.ord.find((x) => x.id === $('#m_o').value),
    a = +$('#m_a').value,
    method = $('#m_b').value,
    reference = $('#m_r').value.trim(),
    sender = $('#m_s').value.trim(),
    transferredAt = $('#m_d').value;
  if (!o || !(a > 0) || !method || !reference || !sender || !transferredAt)
    return toast('أكمل المبلغ ووسيلة الدفع والمرجع واسم المحوّل والتاريخ');
  if (!window.SA_API) return toast('هذه معاينة فقط؛ لا يمكن حفظ حوالة حقيقية هنا');
  let receiptFileId = null;
  if (F.rc) {
    try {
      const mimeType = (F.rc.match(/^data:(image\/(?:jpeg|png|webp));base64,/i) || [])[1] || 'image/jpeg';
      const file = await window.SA_API.uploadFile({
        bookingId: o.serverId || o.id,
        filename: 'receipt.' + (mimeType === 'image/png' ? 'png' : mimeType === 'image/webp' ? 'webp' : 'jpg'),
        mimeType,
        base64: F.rc,
      });
      receiptFileId = file.file.id;
    } catch (e) {
      return toast(e.message || 'تعذر رفع سند الحوالة');
    }
  }
  try {
    await window.SA_API.createOfficePayment({
      bookingId: o.serverId || o.id,
      amount: a,
      methodName: method,
      reference,
      sender,
      transferredAt,
      receiptFileId,
    });
    F.rc = '';
    cm();
    const me = await window.SA_API.me();
    await SA_hydrateOffice(me.user);
    toast('تم تسجيل الحوالة في قاعدة البيانات بانتظار المراجعة');
    go();
  } catch (e) {
    toast(e.message || 'تعذر تسجيل الحوالة');
  }
}
/* ===== حوالات العملاء: استقبال وتأكيد ===== */
const RMS = ['بانتظار التأكيد', 'مؤكدة', 'مرفوضة'],
  RMC = ['wr', 'ok', 'rd'],
  rmO = (r) => D.ord.find((o) => o.id == r.oid);
const rmRow = (r) => {
  const o = rmO(r),
    lo = o && +r.amt < +o.tot;
  return `<div class="row" style="cursor:default;flex-wrap:wrap"><div class="ia">💳</div><div class="rm"><b>${h(r.name)} · ${(r.cur || D.cfg.cur || 'YER').trim()}${r.amt}</b><small>${o ? osn(o) + ' · ' : ''}${h(r.bank || '—')} · مرجع ${h(r.ref || '—')} · المحوّل ${h(r.sender || '—')} · ${dt(r.date)}</small>${lo ? `<small style="color:var(--rd)">⚠ أقل من إجمالي الطلب (${(o.cur || D.cfg.cur || 'YER').trim()}${o.tot})</small>` : ''}</div><span class="pl ${RMC[r.st]}">${RMS[r.st]}</span>${r.st == 0 ? `<button class="bt g" onclick="rmc('${r.id}')">✓ تأكيد الحوالة</button><button class="bt r" onclick="rmr('${r.id}')">رفض</button>` : ''}<button class="ib" onclick="rmd('${r.id}')">👁</button><button class="ib" onclick="pdfR('${r.id}')">📄</button></div>`;
};
const rmCard = (o) => {
  const R = D.rm.filter((r) => r.oid == o.id);
  return `<div class="card"><div class="hd" style="margin:0 0 6px"><div><h3 style="margin:0">الدفع والحوالات</h3></div><button class="bt s" onclick="rmn('${o.id}')">+ تسجيل حوالة</button></div>${R.map(rmRow).join('') || '<p class="em">لم تصل حوالة لهذا الطلب بعد</p>'}</div>`;
};
