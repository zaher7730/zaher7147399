/* الأمانات والجوازات
   يعرّف: amanat، ame، ams، am، lg، AMS */
function amanat() {
  const d = F.ad || 'in',
    S = d == 'in' ? AMI : AMO,
    X = d == 'in' ? NXI : NXO,
    L = D.am.filter((a) => (a.dir || 'in') == d).sort((a, b) => b.ts - a.ts),
    cn = (k) => D.am.filter((a) => (a.dir || 'in') == k).length;
  return (
    hd(
      'استقبال وإرسال الجوازات',
      'الجوازات والمستندات تنتقل عبر مكاتب الأمانات، وهنا تتابع حالتها وتبلغ العميل',
      `<button class="bt g" onclick="ame('${d}')">+ تسجيل ${d == 'in' ? 'استقبال' : 'إرسال'}</button>`,
    ) +
    `<div class="tb"><button class="${d == 'in' ? 'on' : ''}" onclick="F.ad='in';go()">📥 استقبال من العملاء (${cn('in')})</button><button class="${d == 'out' ? 'on' : ''}" onclick="F.ad='out';go()">📤 إرسال إلى العملاء (${cn('out')})</button></div><div class="nt">${d == 'in' ? 'العميل يرسل جوازه ومستنداته عبر مكتب أمانات إلى مكتبك، وتؤكد أنت الوصول والاستلام.' : 'بعد إنجاز المعاملة ترسل الجواز أو المستندات للعميل عبر مكتب أمانات، وتحدّث الحالة ويصل العميل إشعار.'}</div><div class="card">${L.map((a) => `<div class="row" style="cursor:default"><div class="ia">${d == 'in' ? '📥' : '📤'}</div><div class="rm"><b>${h(a.name)}${a.no ? ` <span class="pl">${h(a.no)}</span>` : ''}</b><small>${h(a.items)} · عبر ${h(a.off)} · ${h(a.city)} · ${dt(a.ts)}</small></div><span class="pl ${a.st == S.length - 1 ? 'ok' : a.st ? 'bu' : 'wr'}">${S[a.st]}</span>${a.st < S.length - 1 ? `<button class="bt s" onclick="am(${a.id})">${X[a.st]}</button>` : ''}</div>`).join('') || '<p class="em">لا توجد سجلات</p>'}</div>`
  );
}
function ame(d) {
  mo(
    d == 'in' ? 'تسجيل استقبال جواز' : 'تسجيل إرسال جواز',
    '<div class="fg"><div class="w"><label>العميل</label><select id="a_c">' +
      cuL()
        .map((c) => `<option value="${c.ph}">${h(c.name)} · ${c.no}</option>`)
        .join('') +
      '</select></div><div class="w"><label>المستندات</label><input id="a_i" placeholder="جواز + صورة شخصية"></div><div><label>مكتب الأمانات</label><input id="a_o"></div><div><label>المدينة</label><select id="a_y">' +
      CT.map((c) => `<option>${c}</option>`).join('') +
      '</select></div><div class="w"><label>رقم الشحنة (اختياري)</label><input id="a_n"></div></div>',
    `ams('${d}')`,
  );
}
function ams(d) {
  const c = cuL().find((x) => x.ph == $('#a_c').value),
    i = $('#a_i').value.trim(),
    o = $('#a_o').value.trim();
  if (!c || !i || !o) return toast('اكتب المستندات واسم مكتب الأمانات');
  D.am.push({
    id: Date.now(),
    dir: d,
    name: c.name,
    ph: c.ph,
    off: o,
    city: $('#a_y').value,
    items: i,
    no: $('#a_n').value.trim(),
    st: 0,
    ts: Date.now(),
  });
  say(c.ph, c.name, d == 'out' ? 'جارٍ تجهيز مستنداتك (' + i + ') لإرسالها عبر ' + o : 'سُجّل استقبال مستنداتك (' + i + ') عبر ' + o);
  save();
  cm();
  F.ad = d;
  go();
}
function am(id) {
  const a = D.am.find((x) => x.id == id);
  a.st++;
  say(a.ph, a.name, (a.dir == 'out' ? 'مستنداتك: ' : '') + AMS(a));
  save();
  toast('تم تحديث الحالة وإبلاغ العميل');
  go();
}
const lg = (o, x) => {
    (o.lg = o.lg || []).push({ t: Date.now(), x });
  },
  actv = (O) =>
    O.flatMap((o) =>
      [{ t: o.ts, x: 'استلام طلب ' + osn(o) + ' (' + o.title + ')' }].concat((o.lg || []).map((l) => ({ t: l.t, x: osn(o) + ': ' + l.x }))),
    ).sort((a, b) => b.t - a.t);
const AMS = (a) => (a.dir == 'out' ? AMO : AMI)[a.st];
