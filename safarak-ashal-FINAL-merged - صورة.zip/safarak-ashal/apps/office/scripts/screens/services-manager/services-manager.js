/* إدارة الخدمات
   يعرّف: svcs، tsv، SVon */
function svcs() {
  return (
    hd('إدارة الخدمات', 'فعّل الخدمات التي يقدمها مكتبك فقط، وتظهر للعميل الخدمات المفعّلة') +
    `<div class="gr" style="grid-template-columns:repeat(auto-fill,minmax(290px,1fr))">${Object.keys(SV)
      .map((k) => {
        const on = (D.sv || {})[k] !== 0;
        return `<div class="card" style="margin:0"><div class="ot"><div class="ia">${SV[k][1]}</div><div><b>${SV[k][0]}</b><small>${SV[k][2]}</small></div><label class="tg"><input type="checkbox" ${on ? 'checked' : ''} onchange="tsv('${k}',this.checked)"><i></i></label></div><div class="om" style="grid-template-columns:1fr 1fr"><div><small>العروض</small><b>${D.ofr[k].length}</b></div><div><small>الطلبات</small><b>${D.ord.filter((o) => o.svc == k).length}</b></div></div>${on ? `<button class="bt" onclick="go('${k}')">فتح الخدمة ‹</button>` : '<span class="pl wr">غير مفعّلة</span>'}</div>`;
      })
      .join('')}</div>`
  );
}
function tsv(k, v) {
  D.sv = D.sv || {};
  D.sv[k] = v ? 1 : 0;
  save();
  toast(v ? 'تم تفعيل الخدمة' : 'تم إيقاف الخدمة، وعروضها محفوظة');
  go();
}
const SVon = () => Object.keys(SV).filter((k) => (D.sv || {})[k] !== 0);
