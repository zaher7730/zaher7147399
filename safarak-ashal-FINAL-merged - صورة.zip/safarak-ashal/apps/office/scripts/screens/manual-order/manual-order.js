/* إنشاء طلب يدوي
   يعرّف: onew، osv */
function onew() {
  mo(
    'طلب يدوي جديد',
    '<div class="fg"><div><label>اسم العميل</label><input id="n_n"></div><div><label>رقم الجوال</label><input id="n_p" inputmode="numeric"></div><div><label>الخدمة</label><select id="n_s">' +
      SVon()
        .map((k) => `<option value="${k}">${SV[k][0]}</option>`)
        .join('') +
      '</select></div><div><label>الحالة</label><select id="n_t">' +
      STS.map((x, i) => `<option value="${i}" ${i == 1 ? 'selected' : ''}>${x}</option>`).join('') +
      '</select></div><div class="w"><label>التفاصيل (مثال: عدن ← جدة)</label><input id="n_d"></div><div><label>عدد الأفراد</label><input id="n_c" type="number" min="1" value="1"></div><div><label>الإجمالي</label><input id="n_a" type="number" min="0"></div><div><label>ربح المكتب</label><input id="n_r" type="number" min="0" value="0"></div></div>',
    'osv()',
  );
}
async function osv() {
  const g = (k) => $('#n_' + k).value.trim(),
    nm = g('n'),
    ph = g('p').replace(/\D/g, ''),
    d = g('d'),
    pax = +g('c'),
    tot = +g('a'),
    pr = +g('r'),
    svc = g('s'),
    status = ['pending', 'in_progress', 'completed', 'rejected', 'waiting_documents', 'waiting_payment', 'cancelled'][+g('t')] || 'pending';
  if (!SV[svc]) return toast('فعّل الخدمة أولاً');
  if (!nm || ph.length < 9 || !d || !(pax >= 1) || g('a') === '' || tot < 0 || pr < 0)
    return toast('أكمل الاسم والجوال (9 أرقام على الأقل) والتفاصيل والإجمالي');
  if (!window.SA_API) return toast('هذه معاينة فقط؛ لا يمكن تسجيل طلب حقيقي دون الخادم');
  try {
    const r = await window.SA_API.createOfficeBooking({
      customerName: nm,
      customerPhone: ph,
      serviceType: svc,
      title: d,
      passengerCount: pax,
      totalAmount: tot,
      currency: D.cfg.cur || 'YER',
      status,
      details: { officeProfit: pr, createdManually: true },
    });
    const me = await window.SA_API.me();
    await SA_hydrateOffice(me.user);
    save();
    cm();
    toast('تم تسجيل الطلب الحقيقي في قاعدة البيانات المشتركة');
    go('od', r.booking.public_id);
  } catch (e) {
    toast(e.message || 'تعذر تسجيل الطلب؛ تأكد من نشر عرض فعلي لهذه الخدمة');
  }
}
