/* معاينة العرض — الجزء 1/2
   يعرّف: dpHead، dpv */
function dpHead(back, name, sub, loc) {
  return `<div class="dpHead"><button class="dpBack" onclick="return false" aria-label="رجوع">${DPI.back}</button><div class="dpTtl"><h1><span>${ht(name || '')}</span><i>${DPI.chk}</i></h1>${sub ? `<p>${ht(sub)}</p>` : ''}${loc ? `<p class="loc">${DPI.pin}${ht(loc)}</p>` : ''}</div></div>`;
}
function dpv(s, o, t) {
  t = t || {};
  const L = (x) =>
      String(x || '')
        .split('\n')
        .map((y) => y.trim())
        .filter(Boolean),
    cr = cu(s).trim(),
    p = D.pf,
    loc = [p.city, p.addr].filter(Boolean).join(' - '),
    nm = ofn(),
    src = o.img || DIMG[s],
    rq = L(t.rq),
    wn = L(t.wn),
    e = (x) => h(x) || '—',
    cell = (l, v, x) => `<div class="${x || ''}"><small>${l}</small><b>${v}</b></div>`,
    pr = cr + (o.price || 0) + (o.old ? ' <s>' + cr + o.old + '</s>' : ''),
    hero = (c) =>
      `<div class="dpHero ${c}"><img src="${src}" alt=""><span class="dpRate">تقييم العملاء ★</span><button class="dpRateBtn" type="button">★ قيّم بالنجوم</button></div>`,
    ct = (w) =>
      `<div class="dpCt"><button type="button">${DPI.chat}محادثة داخل التطبيق</button><button type="button" class="wa">${w ? DPI.wa : DPI.chat}تواصل عبر واتساب</button></div>`,
    sec = (a, b) => `<div class="dpH sm">${a}</div><div class="dpLoc"><span>${b}</span></div>`,
    ex =
      (t.desc ? sec('نبذة عن العرض', h(t.desc)) : '') +
      (t.steps && L(t.steps).length
        ? sec(
            'خطوات الإنجاز',
            L(t.steps)
              .map((x, i) => i + 1 + '. ' + h(x))
              .join('<br>'),
          )
        : '') +
      (L(t.inc).length
        ? sec(
            'ما يشمله العرض',
            L(t.inc)
              .map((x) => '✓ ' + h(x))
              .join('<br>'),
          )
        : '') +
      (L(t.nt).length
        ? sec(
            'ملاحظات هامة',
            L(t.nt)
              .map((x) => '• ' + h(x))
              .join('<br>'),
          )
        : '') +
      (t.pol ? sec('سياسة الإلغاء والتعديل', h(t.pol)) : '') +
      (t.loc ? sec('موقع المكتب', '<a href="' + h(t.loc) + '" target="_blank">فتح الخريطة</a>') : '') +
      (t.xs || [])
        .map((x) =>
          sec(
            h(x.t),
            L(x.x)
              .map((y) => '• ' + h(y))
              .join('<br>'),
          ),
        )
        .join(''),
    cta = `<div class="dpFine">${DPFINE}</div>${ex}<div class="dpCta"><button type="button">ابدأ الحجز الآن</button></div>`;
  if (['air', 'bus', 'local', 'priv'].includes(s)) {
    const dom = s == 'priv' && o.scope == 'داخلية',
      stops = s == 'air' ? L(t.route) : L(t.route).length ? L(t.route) : [o.from, o.to].filter(Boolean);
    return `<div class="dpw"><div class="dp trip">${dpHead(s, nm, s == 'priv' ? 'رحلة خاصة ' + (o.scope || '') : '', loc)}${hero('bus')}${ct(0)}<div class="dpRoute">${DPI.pin}<span>${e(o.from)}</span><em>←</em><span>${e(o.to)}</span><small class="tno">رقم الرحلة تلقائي</small></div><div class="dpInfo wr one">${cell(s == 'air' ? 'سعر التذكرة' : 'سعر المقعد', pr, 'pr')}${s == 'air' ? cell('شركة الطيران', e(o.carrier || 'حسب الحجز')) : cell(s == 'priv' ? 'نوع السيارة' : 'نوع الباص', e(s == 'priv' ? o.ty : o.kind))}${cell(s == 'air' ? 'موعد الإقلاع' : 'موعد الانطلاق', e(o.time))}${cell('تاريخ الرحلة', e(o.date || o.days))}${cell('المقاعد المتاحة', e(o.seats))}</div>${dpTW({ rq, wn })}${s == 'priv' ? '' : dpSup()}${t.pick ? `<div class="dpH sm">موقع التجمع للمغادرة</div><div class="dpLoc">${DPI.pin}<span>${h(t.pick)}</span></div>` : ''}${dom ? '<div class="dpH sm">مرونة وقت الانطلاق</div><div class="dpLoc"><span>⏱ يمكن تقديم أو تأخير الانطلاق حتى 30 دقيقة، ويؤكد لك المكتب الموعد النهائي بعد الحجز.</span></div>' : ''}${stops.length ? `<div class="dpH sm">مسار الرحلة</div><div class="dpPath"><div class="dpTl">${stops.map((x, i) => `<div><i>${i + 1}</i><b>${h(x)}</b></div>`).join('')}</div><small>المحطات توضيحية وقد تختلف حسب مسار المكتب.</small></div>` : ''}${cta}</div></div>`;
  }
  if (s == 'cars') {
    const pics = [o.img || DIMG.cars, ...(o.pics || [])],
      cap = ['أمامية', 'خلفية', 'داخلية', 'جانبية'],
      c = (l, v, x) => `<div><span>${l}</span> <b class="${x || ''}">${v}</b></div>`;
    return `<div class="dpw"><div class="dp">${dpHead('cars', nm, '', loc)}<div class="dpHero car"><div class="dpSl">${pics.map((x, i) => `<div><img src="${x}" alt=""><span class="dpCap">${cap[i] || ''}</span></div>`).join('')}</div><span class="dpRate">تقييم العملاء ★</span><button class="dpRateBtn" type="button">قيّم بالنجوم</button></div>${ct(1)}<div class="dpTbl"><div class="dpH" style="margin-inline:4px">تفاصيل السيارة</div><div class="dpR">${c('نوع السيارة', e((o.make || '') + ' ' + (o.model || '')))}${c('الموديل', e(o.year))}${c('الوقود', e(t.fuel))}</div><div class="dpR">${c('ناقل الحركة', e(t.trans))}${c('نظام الدفع', e(t.drive))}${c('المحرك', e(t.eng))}</div><div class="dpR">${c('السعر اليومي', pr, 'or')}${c('السعر الأسبوعي', cr + e(o.week), 'or')}${c('الضمان المالي', cr + e(o.dep), 'or')}</div><div class="dpR"><div><b>ضمان ذهب ${h(t.gold || '10 جرام')}</b></div><div><b>${h(t.cg || 'احضار ضمان تجاري')}</b></div></div></div>${dpTW({ rq, wn })}${cta}</div></div>`;
  }
  const strip = L(t.strip)
      .slice(0, 4)
      .map((x) => {
        const i = x.search(/[:：]/);
        return i < 0 ? [x, '—'] : [x.slice(0, i).trim(), x.slice(i + 1).trim() || '—'];
      }),
    cells = strip.length
      ? strip
      : [
          ['مدة التنفيذ', o.dur || '—'],
          ['الباقة', TI[o.tier || 0]],
        ];
  return `<div class="dpw"><div class="dp svcp">${dpHead(s, nm, '', loc)}${hero('svc')}${ct(0)}<div class="dpRoute">${DPI.shield}<span>${e(t.ttl || o.svc)}</span></div><div class="dpInfo wr one" style="grid-template-columns:1.25fr repeat(${cells.length},1fr)"><div class="pr"><small>السعر للشخص</small><b>${pr}</b></div>${cells.map((x) => `<div><small>${h(x[0])}</small><b>${h(x[1])}</b></div>`).join('')}</div>${dpSX(rq, L(o.feat), s == 'pass' ? 'مميزات الخدمة' : 'مميزات الرحلة', wn)}${cta}</div></div>`;
}
