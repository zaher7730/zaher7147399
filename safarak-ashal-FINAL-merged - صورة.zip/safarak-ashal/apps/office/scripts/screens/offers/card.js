/* العروض: إنشاء وتعديل — الجزء 1/5
   يعرّف: card */
/* بطاقة العرض: نفس شكل البطاقة عند العميل */
function card(s, o, ac) {
  const air = ['air', 'bus', 'local', 'priv'].includes(s),
    ft = String(o.feat || '')
      .split('\n')
      .filter(Boolean)
      .slice(0, 6),
    t = TI[o.tier || 0],
    sp = {
      air: [
        ['🕒', o.time || '—', 'الإقلاع'],
        ['📅', o.days || '—', 'الأيام'],
        ['💺', o.seats === '' || o.seats == null ? '—' : o.seats, 'مقعد'],
      ],
      priv: [
        ['🕒', o.time || '—', 'الانطلاق'],
        ['📅', o.days || '—', 'الأيام'],
        ['💺', o.seats === '' || o.seats == null ? '—' : o.seats, 'مقعد'],
      ],
      bus: [
        ['🕒', o.time || '—', 'الانطلاق'],
        ['📅', o.days || '—', 'الأيام'],
        ['💺', o.seats === '' || o.seats == null ? '—' : o.seats, 'مقعد'],
      ],
      cars: [
        ['📅', o.year || '—', 'الموديل'],
        ['💺', o.seats === '' || o.seats == null ? '—' : o.seats, 'مقاعد'],
        ['📍', o.city || '—', 'المدينة'],
      ],
      visa: [
        ['⏱', o.dur || '—', 'المدة'],
        ['⭐', t, 'الباقة'],
      ],
      pass: [
        ['⏱', o.dur || '—', 'المدة'],
        ['⭐', t, 'الباقة'],
      ],
    }[s],
    ti = air ? '' : s == 'cars' ? (o.make || '') + ' ' + (o.model || '') : o.svc || '—',
    ch2 = air
      ? s == 'priv'
        ? (o.scope || '') + ' · ' + (o.ty || '')
        : (o.carrier || '') + ' · ' + (o.kind || '')
      : s == 'cars'
        ? o.kind
        : t;
  return `<div class="ac ${o.on ? '' : 'off'}"><div class="ad"><div class="an"><span>${h(ofn())}</span><i>✔</i></div><div class="cs"><span>مكتب معتمد وموثوق</span><span>${h(ch2 || t)}</span></div>${air ? `<div class="rt"><span>📍 ${h(o.from)}</span><u></u><span>${h(o.to)}</span></div>` : `<div class="rt2">${h(ti)}</div>`}<div class="sp">${sp.map((x) => `<div>${x[0]}<p>${h(x[1])}<small>${x[2]}</small></p></div>`).join('')}</div><div class="ft">${ft.map((f) => `<span>✓ ${h(f)}</span>`).join('')}</div><div class="pb"><span>${cu(s)}${o.price || 0}</span>${o.old ? `<s>${o.old}</s>` : ''}<small>${s == 'cars' ? 'في اليوم' : s == 'pass' ? 'للمعاملة' : 'للشخص'}</small></div></div>
<div class="ap">${o.img ? `<img src="${o.img}">` : SV[s][1]}<span class="st ${o.on ? '' : 'bd'}">${o.on ? 'متاح' : 'موقوف'}</span>${ac ? `<div class="ax"><button onclick="ed('${s}',${o.id})">✎ تعديل كل البيانات</button><button onclick="tgo('${s}',${o.id})">${o.on ? '⏸' : '▶'}</button><button class="x" style="background:#0f2a6b" onclick="dup('${s}',${o.id})">⧉</button><button class="x" onclick="rm('${s}',${o.id})">🗑</button></div>` : ''}</div></div>`;
}
