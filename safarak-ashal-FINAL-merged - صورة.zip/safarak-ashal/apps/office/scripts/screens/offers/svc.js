/* العروض: إنشاء وتعديل — الجزء 2/5
   يعرّف: svc، tgo، rm، rm2، ed، sync */
function svc(s) {
  const t = F.tab[s] || 0,
    L = D.ofr[s];
  return (
    `<div class="sh"><i>${SV[s][1]}</i><div><h1>${SV[s][0]}</h1><p>${SV[s][2]}</p></div>${t ? '' : `<button class="bt g" onclick="ed('${s}')">+ إضافة بطاقة عرض</button>`}</div>
<div class="tb"><button class="${t ? '' : 'on'}" onclick="F.tab['${s}']=0;go()">بطاقات العروض (${L.length})</button><button class="${t ? 'on' : ''}" onclick="F.tab['${s}']=1;go()">صفحات التفاصيل بعد الضغط على البطاقة</button></div>` +
    (t
      ? `<div class="card"><h3>صفحة تفاصيل كل عرض</h3><p style="color:var(--mu);font-size:13px;margin-bottom:8px">هي الصفحة التي يفتحها العميل عند الضغط على البطاقة: تفاصيل الرحلة، المتطلبات، الممنوعات، ما يشمله العرض.</p>${L.map((o) => `<div class="row" onclick="dde('${s}',${o.id})"><div class="ia">${SV[s][1]}</div><div class="rm"><b>${h(tt(s, o))}</b><small>${o.dt && o.dt.rq ? 'تفاصيل العرض جاهزة' : 'لم تُجهَّز بعد'}</small></div><span class="pl ${o.dt && o.dt.rq ? 'ok' : 'wr'}">${o.dt && o.dt.rq ? 'مكتملة' : 'ناقصة'}</span><span>‹</span></div>`).join('') || '<p class="em">أضف بطاقة عرض أولاً</p>'}</div>`
      : L.length
        ? `${s == 'priv' ? PRT() : ''}<input placeholder="ابحث في العروض..." value="${h((F.sq || {})[s] || '')}" style="margin-bottom:12px" onchange="(F.sq=F.sq||{})['${s}']=this.value;go()"><div class="ogr">${L.filter(
            (o) =>
              (s != 'priv' || !F.ps || o.scope == F.ps) && (!(F.sq || {})[s] || (tt(s, o) + ' ' + (o.carrier || '')).includes(F.sq[s])),
          )
            .map((o) => card(s, o, 1))
            .join('')}</div>`
        : `<div class="card em">ما أضفت أي عرض في ${SV[s][0]} بعد. اضغط «إضافة بطاقة عرض» وابدأ.</div>`)
  );
}
function tgo(s, id) {
  const o = D.ofr[s].find((x) => x.id == id);
  o.on = o.on ? 0 : 1;
  save();
  go();
}
function rm(s, id) {
  mo(
    'حذف العرض',
    '<p>هل تريد حذف هذه البطاقة نهائياً؟ الطلبات القديمة لن تتأثر.</p>',
    0,
    `<button class="bt r" onclick="rm2('${s}',${id})">نعم، احذف</button>`,
  );
}
function rm2(s, id) {
  D.ofr[s] = D.ofr[s].filter((x) => x.id != id);
  save();
  cm();
  go();
}
/* محرر البطاقة مع معاينة حية */
function ed(s, id) {
  F.es = s;
  F.eid = id;
  const o = id
    ? JSON.parse(JSON.stringify(D.ofr[s].find((x) => x.id == id)))
    : s == 'priv'
      ? { on: 1, tier: 0, scope: 'دولية' }
      : { on: 1, tier: 0 };
  o.dt = o.dt || { rq: DR[s].rq.join('\n'), wn: DR[s].wn.join('\n') };
  o.dt.xs = o.dt.xs || [];
  F.eo = o;
  P = o.img || '';
  F.stp = 1;
  go('ed');
}
function sync() {
  const s = F.es,
    o = F.eo,
    t = o.dt;
  rd(s, o);
  DF(s).forEach(([k]) => {
    const e = $('#x_' + k);
    if (e) t[k] = e.value.trim();
  });
  t.xs = t.xs.map((x, i) => ({ t: ($('#xt_' + i) || { value: x.t }).value.trim(), x: ($('#xx_' + i) || { value: x.x }).value.trim() }));
  return o;
}
function rd(s, o) {
  for (const [k, l, t] of FS[s]) {
    if (t == 'i') continue;
    const e = $('#f_' + k);
    if (!e) continue;
    let v = e.value.trim();
    if (t == 'n') v = v === '' ? '' : +v;
    if (k == 'tier') v = +v;
    o[k] = v;
  }
  o.img = P;
  return o;
}
