/* العروض: إنشاء وتعديل — الجزء 5/5
   يعرّف: ftg، dup، pv، xa */
const ftg = (b) => {
  const e = $('#f_feat'),
    v = b.dataset.v;
  let L = e.value
    .split('\n')
    .map((x) => x.trim())
    .filter(Boolean);
  L = L.includes(v) ? L.filter((x) => x != v) : [...L, v];
  e.value = L.join('\n');
  b.classList.toggle('on');
  pv();
};
const dup = (s, id) => {
  D.ofr[s].unshift({ ...JSON.parse(JSON.stringify(D.ofr[s].find((x) => x.id == id))), id: Date.now() });
  save();
  toast('تم نسخ العرض');
  go();
};
const pv = () => {
  const o = sync(),
    a = $('#pvw'),
    b = $('#dpw');
  if (a) a.innerHTML = dc(card(F.es, o));
  if (b) b.innerHTML = dc(dpv(F.es, o, o.dt));
};
const xa = () => {
    sync();
    F.eo.dt.xs.push({ t: '', x: '' });
    go();
  },
  xr = (i) => {
    sync();
    F.eo.dt.xs.splice(i, 1);
    go();
  };
