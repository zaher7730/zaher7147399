/* العروض: إنشاء وتعديل — الجزء 4/5
   يعرّف: sv، tt، osn، cuL، DF، dde */
function sv() {
  const s = F.es,
    o = sync();
  if (['air', 'bus', 'local', 'priv'].includes(s) && o.from == o.to) return toast('مدينة الانطلاق والوصول متطابقتان');
  const pm = s == 'priv' && privChk(o);
  if (pm) return toast(pm);
  if (!(+o.price > 0)) return toast('اكتب السعر');
  if (['seats', 'old', 'week', 'dep'].some((k) => o[k] !== undefined && o[k] !== '' && +o[k] < 0)) return toast('تأكد من الأرقام');
  o.dt.xs = o.dt.xs.filter((x) => x.t || x.x);
  if (F.eid) {
    D.ofr[s][D.ofr[s].findIndex((x) => x.id == F.eid)] = o;
  } else {
    o.id = Date.now();
    D.ofr[s].unshift(o);
  }
  save();
  toast('تم حفظ العرض');
  F.tab[s] = 0;
  go(s);
}
/* صفحة الخدمة: تبويبان */
const tt = (s, o) =>
    ['air', 'bus', 'local', 'priv'].includes(s)
      ? o.from + ' ← ' + o.to
      : s == 'cars'
        ? (o.make || '') + ' ' + (o.model || '')
        : o.svc || '—',
  SC = { air: 'AIR', bus: 'BUS', visa: 'VSA', pass: 'PSP', cars: 'CAR', priv: 'PRV' },
  pad = (n) => String(n).padStart(4, '0');
const osn = (o) =>
  SC[o.svc] +
  '-' +
  pad(
    D.ord
      .filter((x) => x.svc == o.svc)
      .sort((a, b) => a.ts - b.ts)
      .findIndex((x) => x.id == o.id) + 1,
  );
const cuL = () => {
  const m = {};
  D.ord.forEach((o) => {
    const c = (m[o.ph] = m[o.ph] || { ph: o.ph, name: o.name, o: [] });
    c.o.push(o);
  });
  D.cd = D.cd || {};
  const L = Object.values(m).sort((a, b) => Math.min(...a.o.map((x) => x.ts)) - Math.min(...b.o.map((x) => x.ts)));
  L.forEach((c, i) => {
    c.no = 'CU-' + pad(i + 1);
    c.d = D.cd[c.ph] || {};
  });
  return L;
};
const DF = (s) =>
  ({
    air: [
      ['bag', 'الأمتعة', 't'],
      ['pick', 'موقع التجمع / الصالة', 't'],
      ['route', 'مسار الرحلة (محطة بكل سطر، اختياري)', 'a'],
    ],
    priv: [
      ['pick', 'موقع التجمع للمغادرة', 't'],
      ['route', 'مسار الرحلة (محطة بكل سطر)', 'a'],
      ['bag', 'الأمتعة', 't'],
    ],
    bus: [
      ['pick', 'موقع التجمع للمغادرة', 't'],
      ['route', 'مسار الرحلة (محطة بكل سطر)', 'a'],
      ['bag', 'الأمتعة', 't'],
    ],
    cars: [
      ['fuel', 'الوقود', 't'],
      ['trans', 'ناقل الحركة', 't'],
      ['drive', 'نظام الدفع', 't'],
      ['eng', 'المحرك', 't'],
      ['km', 'الكيلومترات المسموحة', 't'],
      ['gar', 'نوع الضمان', 't'],
      ['gold', 'ضمان الذهب (جرام)', 't'],
      ['cg', 'الضمان التجاري المطلوب', 't'],
    ],
    visa: [
      ['steps', 'خطوات الإنجاز (خطوة بكل سطر)', 'a'],
      ['strip', 'شريط المعلومات (عنوان: قيمة بكل سطر، حتى 4)', 'a'],
    ],
    pass: [
      ['steps', 'خطوات الإنجاز (خطوة بكل سطر)', 'a'],
      ['strip', 'شريط المعلومات (عنوان: قيمة بكل سطر، حتى 4)', 'a'],
    ],
  })[s].concat([
    ['desc', 'وصف مختصر للعرض', 'a'],
    ['rq', 'المتطلبات (بند بكل سطر)', 'a'],
    ['wn', 'الممنوعات والتحذيرات', 'a'],
    ['nt', 'ملاحظات هامة', 'a'],
    ['inc', 'ما يشمله العرض', 'a'],
    ['pol', 'سياسة الإلغاء والتعديل', 'a'],
    ['ttl', 'عنوان مخصص لصفحة التفاصيل', 't'],
    ['loc', 'رابط موقع المكتب على الخرائط', 't'],
  ]);
const dde = (s, id) => ed(s, id);
const stp = (n) => {
  sync();
  if (n > 1) {
    const o = F.eo,
      s = F.es;
    if (['air', 'bus', 'local', 'priv'].includes(s) && o.from == o.to) return toast('مدينة الانطلاق والوصول متطابقتان');
    const pm = s == 'priv' && privChk(o);
    if (pm) return toast(pm);
    if (!(+o.price > 0)) return toast('اكتب السعر أولاً');
  }
  F.stp = n;
  go();
};
