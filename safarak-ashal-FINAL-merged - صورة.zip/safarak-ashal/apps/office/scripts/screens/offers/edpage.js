/* العروض: إنشاء وتعديل — الجزء 3/5
   يعرّف: edpage */
function edpage() {
  const s = F.es,
    o = F.eo,
    t = o.dt,
    n = F.stp || 1,
    SP = ['بيانات البطاقة الخارجية', 'بيانات الصفحة الداخلية', 'مراجعة ونشر'];
  const f1 =
    FS[s]
      .map(([k, l, ty, op]) => {
        const v = o[k] ?? '',
          w = ty == 'a' || ty == 'i' ? ' class="w"' : '';
        return (
          `<div${w}><label>${l}${['price', 'week', 'dep', 'old'].includes(k) ? ' (' + cu(s).trim() + ')' : ''}</label>` +
          (ty == 's'
            ? `<select id="f_${k}">${(k == 'tier' ? TI : op).map((x, i) => `<option value="${k == 'tier' ? i : x}" ${v == (k == 'tier' ? i : x) ? 'selected' : ''}>${x}</option>`).join('')}</select>`
            : ty == 'a'
              ? `<textarea id="f_${k}" rows="3">${h(v)}</textarea>` +
                (k == 'feat'
                  ? `<div style="margin-top:8px">${(PF[s] || []).map((x) => `<button type="button" class="ch ${String(v).split('\n').includes(x) ? 'on' : ''}" data-v="${h(x)}" onclick="ftg(this)">${h(x)}</button>`).join('')}</div>`
                  : '')
              : ty == 'i'
                ? `<div class="up"><img id="pi" src="${P}" ${P ? '' : 'hidden'}><input type="file" accept="image/*" onchange="rz(this.files[0],d=>{P=d;$('#pi').src=d;$('#pi').hidden=false;pv()})"></div>`
                : `<input id="f_${k}" type="${ty == 'n' ? 'number' : ty == 'd' ? 'date' : 'text'}" min="0" value="${h(v)}">`) +
          '</div>'
        );
      })
      .join('') + (s == 'cars' ? GL() : '');
  const f2 = DF(s)
    .map(
      ([k, l, ty]) =>
        `<div class="${ty == 'a' ? 'w' : ''}"><label>${l}</label>${ty == 'a' ? `<textarea id="x_${k}" rows="3">${h(t[k] || '')}</textarea>` : `<input id="x_${k}" value="${h(t[k] || '')}">`}</div>`,
    )
    .join('');
  const xs = t.xs
    .map(
      (x, i) =>
        `<div class="fg" style="margin-bottom:10px" oninput="pv()"><div><label>عنوان القسم</label><input id="xt_${i}" value="${h(x.t)}"></div><div style="display:flex;align-items:flex-end"><button class="bt r" onclick="xr(${i})">حذف القسم</button></div><div class="w"><label>المحتوى (بند بكل سطر)</label><textarea id="xx_${i}" rows="2">${h(x.x)}</textarea></div></div>`,
    )
    .join('');
  return (
    hd(F.eid ? 'تعديل العرض' : 'إضافة عرض جديد', SV[s][0] + ' · أولاً بيانات البطاقة الخارجية، ثم بيانات الصفحة الداخلية') +
    `<div class="stp">${SP.map((x, i) => `<button class="${n == i + 1 ? 'on' : ''}" onclick="stp(${i + 1})"><b>${i + 1}</b>${x}</button>`).join('')}</div>` +
    (n == 1
      ? `<div class="edp"><div class="card"><div class="hd" onclick="this.parentElement.parentElement.classList.toggle('mini')" style="margin:0 0 8px;cursor:pointer"><h3 style="margin:0">معاينة مباشرة للبطاقة</h3><span style="color:var(--mu);font-size:12px">إخفاء / إظهار ▾</span></div><div class="pvb"><div class="ogr" id="pvw" style="grid-template-columns:1fr">${card(s, o)}</div></div></div></div><div class="card"><h3>بيانات البطاقة الخارجية</h3><div class="fg" oninput="pv()" onchange="pv()">${f1}</div></div>`
      : n == 2
        ? `<div class="edp"><div class="card"><div class="hd" onclick="this.parentElement.parentElement.classList.toggle('mini')" style="margin:0 0 8px;cursor:pointer"><h3 style="margin:0">معاينة مباشرة لصفحة التفاصيل (كما تظهر عند العميل)</h3><span style="color:var(--mu);font-size:12px">إخفاء / إظهار ▾</span></div><div class="pvb"><div id="dpw">${dpv(s, o, t)}</div></div></div></div><div class="card"><h3>بيانات الصفحة الداخلية (تفتح بعد الضغط على البطاقة)</h3><div class="fg" oninput="pv()">${f2}</div></div><div class="card"><h3>أقسام إضافية من عندك</h3>${xs}<button class="bt s" onclick="xa()">+ إضافة قسم</button></div>`
        : `<div class="card"><h3>البطاقة الخارجية</h3><div class="ogr" id="pvw" style="grid-template-columns:1fr">${card(s, o)}</div></div><div class="card"><h3>الصفحة الداخلية</h3><div id="dpw">${dpv(s, o, t)}</div></div><div class="card"><div class="dr"><b>نشر العرض للعملاء فور الحفظ<br><small style="color:var(--mu)">أوقفه لتحفظ العرض كمسودة</small></b><label class="tg"><input type="checkbox" ${o.on ? 'checked' : ''} onchange="F.eo.on=this.checked?1:0"><i></i></label></div></div>`) +
    `<div class="stk">${n > 1 ? `<button class="bt o" style="background:#fff" onclick="stp(${n - 1})">السابق</button>` : ''}${n < 3 ? `<button class="bt g" onclick="stp(${n + 1})">التالي: ${SP[n]}</button>` : '<button class="bt g" onclick="sv()">حفظ العرض</button>'}<button class="bt o" style="background:#fff" onclick="go('${s}')">إلغاء</button></div>`
  );
}
