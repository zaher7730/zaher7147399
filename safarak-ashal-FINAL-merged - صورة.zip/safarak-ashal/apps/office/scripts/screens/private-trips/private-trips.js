/* الرحلات الخاصة
   يعرّف: privChk، FOR، PRT */
function privChk(o) {
  if (!o.scope) return 'حدد نطاق الرحلة: دولية أو داخلية';
  const f = FOR.includes(o.from) || FOR.includes(o.to),
    b = FOR.includes(o.from) && FOR.includes(o.to);
  if (o.scope == 'دولية' && !f) return 'الرحلة الدولية يجب أن تنتهي أو تبدأ خارج اليمن';
  if (o.scope == 'دولية' && b) return 'أحد طرفي الرحلة الدولية يجب أن يكون داخل اليمن';
  if (o.scope == 'داخلية' && f) return 'الرحلة الداخلية بين مدن يمنية فقط';
  return '';
}
/* ===== الرحلات الخاصة: دولية / داخلية ===== */
const FOR = ['جدة', 'الرياض', 'مكة المكرمة', 'المدينة المنورة', 'أبها', 'صلالة', 'مسقط'];
const PRT = () =>
  `<div class="tb">${[
    ['', 'الكل'],
    ['دولية', 'رحلات دولية'],
    ['داخلية', 'رحلات داخلية'],
  ]
    .map(
      (x) =>
        `<button class="${(F.ps || '') == x[0] ? 'on' : ''}" onclick="F.ps='${x[0]}';go()">${x[1]} (${D.ofr.priv.filter((o) => !x[0] || o.scope == x[0]).length})</button>`,
    )
    .join('')}</div>`;
