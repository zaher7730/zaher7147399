/* المعاملات والأرباح
   يعرّف: txn، orow، money */
function txn() {
  const pe = F.tp || 'all',
    lim = { all: 0, day: 864e5, week: 7 * 864e5, month: 30 * 864e5 }[pe],
    A = D.ord.filter((o) => !lim || o.ts >= Date.now() - lim),
    N = A.filter((o) => o.st == 2),
    run = A.filter((o) => [0, 1, 4, 5].includes(o.st)).length,
    bad = A.filter((o) => o.st == 3 || o.st == 6).length;
  return (
    hd('المعاملات والأرباح', 'المعاملات الداخلة، ما تم تنفيذه منها، والربح') +
    `<div style="margin-bottom:10px">${[
      ['all', 'الكل'],
      ['day', 'اليوم'],
      ['week', 'آخر 7 أيام'],
      ['month', 'آخر 30 يوم'],
    ]
      .map((x) => `<button class="ch ${pe == x[0] ? 'on' : ''}" onclick="F.tp='${x[0]}';go()">${x[1]}</button>`)
      .join('')}</div>
<div class="gr" style="margin-bottom:16px">${[
      ['📥', A.length, 'معاملات داخلة'],
      ['✅', N.length, 'معاملات منفذة'],
      ['⏳', run, 'جارية'],
      ['🚫', bad, 'مرفوضة / ملغية'],
      ['💵', money(N, 'tot'), 'إجمالي مبيعات المنفذة'],
      ['💰', money(N, 'pr'), 'صافي الربح'],
    ]
      .map(
        (x) =>
          `<div class="sc"><i>${x[0]}</i><div><b style="font-size:${String(x[1]).length > 8 ? 18 : 26}px">${x[1]}</b><small>${x[2]}</small></div></div>`,
      )
      .join('')}</div>
<div class="card"><h3>حسب الخدمة</h3>${Object.keys(SV)
      .map((k) => {
        const a = A.filter((o) => o.svc == k),
          n = a.filter((o) => o.st == 2);
        return `<div class="dr"><b>${SV[k][1]} ${SV[k][0]}</b><span class="pl">${a.length} داخلة</span><span class="pl ok">${n.length} منفذة</span><span class="pl bu">${money(n, 'tot')}</span><span class="pl wr">ربح ${money(n, 'pr')}</span></div>`;
      })
      .join('')}</div>
<div class="card"><h3>سجل المعاملات المنفذة</h3>${
      [...N]
        .sort((a, b) => b.ts - a.ts)
        .map(
          (o) =>
            `<div class="row" onclick="go('od','${o.id}')"><div class="ia">${SV[o.svc][1]}</div><div class="rm"><b>${h(o.name)} <span class="pl bu">${osn(o)}</span></b><small>${SV[o.svc][0]} · ${h(o.title)} · ${dt(o.ts)}</small></div><div style="text-align:left"><b>${o.cur || '$'}${o.tot}</b><br><span class="pl ok">ربح ${o.cur || '$'}${o.pr || 0}</span></div></div>`,
        )
        .join('') || '<p class="em">لا توجد معاملات منفذة في هذه الفترة</p>'
    }</div>`
  );
}
const orow = (o) =>
  `<div class="row" onclick="go('od','${o.id}')"><div class="ia">${h(o.name[0])}</div><div class="rm"><b>${h(o.name)}</b><small>${SV[o.svc][0]} · ${h(o.title)} · ${dt(o.ts)}</small></div><span class="pl ${STC[o.st]}">${STS[o.st]}</span></div>`;
const money = (L, k) => {
  const m = {};
  L.forEach((o) => {
    const c = (o.cur || '$').trim();
    m[c] = (m[c] || 0) + (+o[k] || 0);
  });
  return (
    Object.entries(m)
      .map(([c, v]) => (c == '$' ? '$' + v.toLocaleString('en') : v.toLocaleString('en') + ' ' + c))
      .join(' + ') || '$0'
  );
};
