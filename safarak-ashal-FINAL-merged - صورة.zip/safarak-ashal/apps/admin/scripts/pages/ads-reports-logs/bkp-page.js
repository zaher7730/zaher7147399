/* واجهة النسخ الاحتياطي: قائمة النسخ، إنشاء نسخة فورية، وبيان ما تشمله
   يعرّف: SA_backupsPage، SA_loadBackups، SA_makeBackup، SA_fmtSize */
const SA_fmtSize = (b) => (b > 1073741824 ? (b / 1073741824).toFixed(2) + ' جيجابايت' : b > 1048576 ? (b / 1048576).toFixed(1) + ' ميجابايت' : Math.max(1, Math.round((b || 0) / 1024)) + ' كيلوبايت');
let SA_bkp = { list: [], loaded: 0, busy: 0, keep: 0, every: 0 };
async function SA_loadBackups() {
  if (!window.SA_API) return;
  SA_bkp.busy = 1;
  try {
    const r = await window.SA_API.adminBackups();
    SA_bkp = { list: r.backups || [], loaded: 1, busy: 0, keep: r.keep || 0, every: r.everyHours || 0 };
  } catch (e) {
    SA_bkp.busy = 0;
    SA_bkp.loaded = 1;
    toast(e.message || 'تعذّر تحميل النسخ الاحتياطية');
  }
  if (S.p == 'bkp') render();
}
async function SA_makeBackup() {
  if (!window.SA_API) return toast('شغّل الخادم لإنشاء نسخة احتياطية حقيقية');
  if (SA_bkp.working) return;
  SA_bkp.working = 1;
  toast('جارٍ إنشاء النسخة…');
  try {
    const r = await window.SA_API.adminBackup();
    toast('تم إنشاء النسخة' + (r.backup ? ' (' + r.backup.fileCount + ' ملف)' : ''));
  } catch (e) {
    toast(e.message || 'تعذّر إنشاء النسخة');
  }
  SA_bkp.working = 0;
  await SA_loadBackups();
}
function SA_backupsPage() {
  if (!SA_bkp.loaded && !SA_bkp.busy) SA_loadBackups();
  const B = SA_bkp,
    every = B.every ? 'كل ' + B.every + ' ساعة' : 'غير مفعّل في هذا التشغيل (يُفعَّل تلقائياً في وضع الإنتاج)';
  return (
    sh(E.bkp.t, E.bkp.d, '<button class="bt g" onclick="SA_makeBackup()">إنشاء نسخة الآن</button>') +
    `<div class="card"><h3>سياسة النسخ</h3><p style="color:var(--mu);font-size:13px;line-height:1.9">النسخ التلقائي: <b>${every}</b>${B.keep ? ' · يُحتفظ بآخر <b>' + B.keep + '</b> نسخة' : ''}.<br>كل نسخة تشمل <b>قاعدة البيانات</b> و<b>الملفات الخاصة</b> (هويات ومستندات وسندات الحوالات) و<b>صور العروض</b> مع بيان بتجزئة كل ملف للتحقق من سلامتها.<br>الاستعادة تتم من الخادم بعد إيقافه بالأمر <span dir="ltr">node scripts/restore.mjs ‎&lt;ملف النسخة&gt;</span> وتُعيد القاعدة والملفات معاً. انسخ النسخ دورياً إلى مكان خارج الخادم.</p></div>` +
    `<div class="card">${tb(
      ['الملف', 'التاريخ', 'الحجم', 'تشمل الملفات', 'عدد الملفات'],
      (B.list || [])
        .map((b) => `<tr><td dir="ltr" style="text-align:right">${esc(b.file)}</td><td>${new Date(b.createdAt).toLocaleString('ar-u-nu-latn', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</td><td>${SA_fmtSize(b.sizeBytes)}</td><td><span class="pl ${b.includesFiles ? 'ok' : 'wr'}">${b.includesFiles ? 'نعم' : 'قاعدة البيانات فقط'}</span></td><td>${b.fileCount}</td></tr>`)
        .join(''),
    )}</div>`
  );
}
