/* الإعلانات والتقارير والسجل
   يعرّف: rep */
function rep() {
  const O = D.of
      .map((o) => {
        const R = D.or.filter((r) => r.of == o.id),
          s = R.reduce((a, r) => a + r.tot, 0),
          c = R.reduce((a, r) => a + r.com, 0);
        return `<tr><td><b>${esc(o.n)}</b></td><td>${R.length}</td><td>${s.toLocaleString('en')}</td><td>${c.toLocaleString('en')}</td><td>${(s - c).toLocaleString('en')}</td></tr>`;
      })
      .join(''),
    V = SVN.slice(0, 5)
      .map((n) => {
        const R = D.or.filter((r) => r.sv == n);
        return `<tr><td><b>${n}</b></td><td>${R.length}</td><td>${R.reduce((a, r) => a + r.tot, 0).toLocaleString('en')}</td><td>${R.reduce((a, r) => a + r.com, 0).toLocaleString('en')}</td></tr>`;
      })
      .join('');
  return (
    sh(E.rep.t, E.rep.d) +
    `<div class="card"><h3>حسب المكتب</h3>${tb(['المكتب', 'الطلبات', 'المبيعات', 'عمولة المنصة', 'صافي المكتب'], O)}</div><div class="card"><h3>حسب الخدمة</h3>${tb(['الخدمة', 'الطلبات', 'المبيعات', 'العمولة'], V)}</div>`
  );
}
