/* واجهة حصص المكاتب: عرض الرصيد المتبقي وتعديله، وتشغيل خصم الرصيد عند كل طلب
   يعرّف: SA_quotasPage، SA_loadQuotas، SA_putQuota، SA_saveQuota، SA_addQuota، SA_toggleEnforce، SA_typeName */
let SA_qt = { list: [], loaded: 0, busy: 0 };
const SA_typeName = (code) => Object.keys(SA_TYPE_R).find((k) => SA_TYPE_R[k] === code) || code;
async function SA_loadQuotas() {
  if (!window.SA_API) return;
  SA_qt.busy = 1;
  try {
    const r = await window.SA_API.adminQuotas();
    SA_qt = { list: r.quotas || [], loaded: 1, busy: 0 };
  } catch (e) {
    SA_qt.busy = 0;
    SA_qt.loaded = 1;
    toast(e.message || 'تعذّر تحميل الحصص');
  }
  if (S.p == 'qt') render();
}
async function SA_putQuota(officeId, serviceType, remaining) {
  if (!officeId) return toast('اختر مكتباً');
  if (!Number.isInteger(remaining) || remaining < 0) return toast('اكتب عدداً صحيحاً لا يقل عن صفر');
  try {
    await window.SA_API.setQuota({ officeId, serviceType, remaining });
    toast('تم حفظ الرصيد');
    await SA_loadQuotas();
  } catch (e) {
    toast(e.message || 'تعذّر حفظ الرصيد');
  }
}
function SA_saveQuota(officeId, serviceType, inputId) {
  SA_putQuota(officeId, serviceType, Number($('#' + inputId).value));
}
function SA_addQuota() {
  SA_putQuota(Number($('#qt_o').value), $('#qt_t').value, Number($('#qt_n').value));
}
async function SA_toggleEnforce() {
  const on = !D.set.enforceQuota;
  try {
    await window.SA_API.saveAdminSettings({ enforceQuota: on });
    D.set.enforceQuota = on;
    toast(on ? 'سيُخصم رصيد المكتب عند كل طلب جديد' : 'لن يُخصم رصيد المكتب عند الطلبات');
    render();
  } catch (e) {
    toast(e.message || 'تعذّر حفظ الإعداد');
  }
}
function SA_quotasPage() {
  if (!SA_qt.loaded && !SA_qt.busy) SA_loadQuotas();
  const offices = D.of.filter((o) => o.serverId && o.id > 0),
    on = !!D.set.enforceQuota;
  return (
    sh(E.qt.t, E.qt.d) +
    `<div class="card"><h3>خصم الرصيد عند الطلبات</h3><p style="color:var(--mu);font-size:13px;margin-bottom:10px">${on ? 'مفعّل: لا يستقبل المكتب طلباً جديداً إلا إذا كان رصيده من هذه الخدمة أكبر من صفر، ويُخصم واحد عند كل طلب.' : 'متوقف: يستقبل المكتب الطلبات دون خصم من رصيده.'}</p><button class="bt ${on ? 'r' : 'g'}" onclick="SA_toggleEnforce()">${on ? 'إيقاف خصم الرصيد' : 'تشغيل خصم الرصيد'}</button></div>` +
    `<div class="card"><h3>إضافة أو تعديل رصيد</h3><div class="fg"><div><label>المكتب</label><select id="qt_o">${offices.map((o) => `<option value="${o.serverId}">${esc(o.n)}</option>`).join('') || '<option value="0">لا توجد مكاتب</option>'}</select></div><div><label>الخدمة</label><select id="qt_t">${Object.keys(SA_TYPE_R).map((k) => `<option value="${SA_TYPE_R[k]}">${k}</option>`).join('')}</select></div><div><label>الرصيد المتبقي</label><input id="qt_n" type="number" min="0" value="10"></div></div><div style="margin-top:10px"><button class="bt g" onclick="SA_addQuota()">حفظ الرصيد</button></div></div>` +
    `<div class="card">${tb(
      ['المكتب', 'الخدمة', 'الرصيد المتبقي', 'تعديل'],
      (SA_qt.list || [])
        .map((q, i) => `<tr><td>${esc(q.office_name || '#' + q.office_id)}</td><td>${esc(SA_typeName(q.service_type))}</td><td><span class="pl ${q.remaining > 0 ? 'ok' : 'wr'}">${q.remaining}</span></td><td style="white-space:nowrap"><input id="qv_${i}" type="number" min="0" value="${q.remaining}" style="width:90px"> <button class="bt s" onclick="SA_saveQuota(${q.office_id},'${q.service_type}','qv_${i}')">حفظ</button></td></tr>`)
        .join(''),
    )}</div>`
  );
}
