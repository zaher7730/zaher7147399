/* الإعلانات والتقارير والسجل
   يعرّف: logp */
function logp() {
  const when = (t) => new Date(t).toLocaleString('ar-u-nu-latn', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  return (
    sh(E.log.t, E.log.d) +
    `<div class="card">${tb(['الوقت', 'المنفّذ', 'العملية', 'التفاصيل'], D.log.map((l) => `<tr><td>${when(l.ts)}</td><td>${esc(l.u)}</td><td>${esc(l.t)}</td><td>${esc(l.d || '')}</td></tr>`).join(''))}</div>`
  );
}
