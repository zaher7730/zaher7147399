/* الإعلانات والتقارير والسجل
   يعرّف: adx */
/* الإعلانات والتقارير والسجل
   يعرّف: adx، pv، rep، logp */
function adx() {
  return `<div class="gr" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))"><div class="card"><h3>معاينة مباشرة</h3><div class="ad" id="adp"></div></div><div class="card"><h3>مدة بقاء كل صورة</h3><p style="margin-bottom:8px">كل <b id="av">${D.set.adsInt}</b> ثانية (من 5 إلى 60)</p><input type="range" min="5" max="60" step="5" value="${D.set.adsInt}" oninput="D.set.adsInt=+this.value;$('#av').textContent=this.value;sv();pv()"><p style="margin-top:10px;color:var(--mu);font-size:12.5px">الإعلانات المفعّلة وضمن تاريخ العرض فقط تدخل في الدوران. وترتيبها كما في الجدول.</p></div></div>`;
}
