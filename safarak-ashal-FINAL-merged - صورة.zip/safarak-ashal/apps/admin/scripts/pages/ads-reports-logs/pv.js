/* الإعلانات والتقارير والسجل
   يعرّف: pv */
function pv() {
  clearInterval(AT);
  const el = $('#adp');
  if (!el) return;
  const L = D.ads.filter((a) => a.on);
  if (!L.length) {
    el.innerHTML = '<div class="em" style="margin:auto">لا توجد إعلانات مفعّلة</div>';
    return;
  }
  let i = 0;
  const G = [
      'linear-gradient(135deg,#0f2a6b,#c9951d)',
      'linear-gradient(135deg,#8a5a06,#d9a53a)',
      'linear-gradient(135deg,#0f766e,#5eead4)',
    ],
    s = () => {
      const a = L[i % L.length];
      el.style.backgroundImage = a.im ? `url('${a.im}')` : G[i % 3];
      el.innerHTML = `<div><b>${esc(a.h)}</b>${esc(a.p || '')} ${a.of ? '· ' + lab('of', a.of) : ''}</div>`;
      i++;
    };
  s();
  AT = setInterval(s, (D.set.adsInt || 8) * 1000);
}
