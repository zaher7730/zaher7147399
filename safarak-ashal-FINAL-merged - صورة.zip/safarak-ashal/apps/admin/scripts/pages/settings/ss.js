/* الإعدادات العامة
   يعرّف: ss */
async function ss() {
  collect(E.set.F, D.set);
  D.set.adsInt = Math.min(60, Math.max(5, D.set.adsInt || 8));
  lg('تحديث الإعدادات العامة');
  if (window.SA_API) {
    try {
      await window.SA_API.saveAdminSettings(D.set);
      toast('تم حفظ الإعدادات في قاعدة البيانات المشتركة');
    } catch (e) {
      toast(e.message || 'تعذر حفظ الإعدادات على الخادم');
      return;
    }
  } else toast('حُفظت هذه التغييرات داخل المعاينة فقط؛ شغّل الخادم لحفظها فعلياً');
}
