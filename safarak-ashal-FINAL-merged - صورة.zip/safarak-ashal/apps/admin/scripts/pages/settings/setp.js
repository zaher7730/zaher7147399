/* الإعدادات العامة
   يعرّف: setp */
/* الإعدادات العامة
   يعرّف: setp، ss */
function setp() {
  const e = E.set;
  return sh(e.t, e.d, '<button class="bt g" onclick="ss()">حفظ التغييرات</button>') + `<div class="card">${form(e.F, D.set)}</div>`;
}
