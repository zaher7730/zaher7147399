/* القوائم والتفاصيل
   يعرّف: cm */
function cm() {
  $('#md').classList.remove('on');
}
