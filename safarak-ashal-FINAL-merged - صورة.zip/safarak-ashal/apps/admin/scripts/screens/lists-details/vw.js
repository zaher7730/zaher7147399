/* القوائم والتفاصيل
   يعرّف: vw */
function vw(k, id, pg) {
  if (k != 'lt' && !pg) {
    S.hs = S.hs || [];
    if (S.rc) S.hs.push(S.rc);
    S.fm = null;
    S.rc = [B(k), id];
    cm();
    render();
    return;
  }
  if (k == 'lt') {
    S.rc = null;
    S.fm = null;
    S.p = 'lt';
    S.t = id;
    S.seat = 0;
    cm();
    render();
    return;
  }
  const b = B(k),
    e = E[b],
    r = D[b].find((x) => x.id == id);
  if (!r) return;
  let h = pg ? '' : `<div class="mh"><h3>${lab(b, id)}</h3><button class="bt s" onclick="cm()">✕</button></div>`,
    o = 0;
  if (b == 'cu' && S.p == 'lt') h += cuBk(id) + cuDocs(id);
  let fs = e.F.filter(
    (f) =>
      f.sec ||
      ((!f.w || f.w.split(',').includes(r.sv)) &&
        !(b == 'ofr' && f.t != 'c' && (r[f.k] == null || r[f.k] === '' || (Array.isArray(r[f.k]) && !r[f.k].length)))),
  );
  fs = fs.filter((f, i) => !f.sec || (fs[i + 1] && !fs[i + 1].sec));
  fs.forEach((f) => {
    if (f.sec) {
      h += (o ? '</div>' : '') + `<h4>${f.sec}</h4><div class="kv">`;
      o = 1;
    } else {
      if (!o) {
        h += '<div class="kv">';
        o = 1;
      }
      h += `<div><small>${f.l}</small><b>${vf(f, r[f.k])}</b></div>`;
    }
  });
  h += o ? '</div>' : '';
  if (b == 'cu' && S.p != 'lt') h += cuUp(id);
  if (b == 'or') h += orX(id);
  (e.rel || []).forEach((x) => {
    const L = D[x[0]].filter((y) => y[x[1]] == id);
    h +=
      `<h4>${x[2]} (${L.length})</h4>` +
      (L.map(
        (y) =>
          `<div class="row" onclick="vw('${x[0]}',${y.id})"><b>${lab(x[0], y.id)}</b><span style="flex:1"></span>${y.st ? fmt({ t: 's', o: ((E[x[0]].F || []).find((f) => f.k == 'st') || {}).o || '' }, y.st) : ''}</div>`,
      ).join('') || '<div class="em" style="padding:6px">لا يوجد</div>');
  });
  const ab =
    (e.fn ? `<button class="bt g" onclick="${e.fn}(${id})">${e.fl}</button>` : '') +
    (e.ac || [])
      .map((a, i) =>
        e.acf && !e.acf(r)
          ? ''
          : !a[4] || a[4].split(',').includes(String(r[a[1]]))
            ? `<button class="bt ${a[3]}" onclick="ac('${b}',${id},${i})">${a[0]}</button>`
            : '',
      )
      .join('') +
    (e.ro
      ? ''
      : `<button class="bt o" onclick="ed('${b}',${id})">تعديل البيانات</button><button class="bt r" id="dl" onclick="dl('${b}',${id})">حذف</button>`) +
    '';
  if (ab.includes('<button')) h += '<h4>الإجراءات</h4><div style="display:flex;gap:8px;flex-wrap:wrap">' + ab + '</div>';
  if (pg) return h;
  om(h);
}
