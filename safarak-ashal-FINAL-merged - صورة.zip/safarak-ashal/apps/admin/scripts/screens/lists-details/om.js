/* القوائم والتفاصيل
   يعرّف: om */
function om(h) {
  const m = $('#md');
  m.innerHTML = '<div class="md">' + h + '</div>';
  m.classList.add('on');
}
