/* القوائم والتفاصيل
   يعرّف: list */
/* القوائم والتفاصيل
   يعرّف: list، cm، om، vw */
function list(k) {
  const e = E[k],
    b = B(k),
    F = fl(k),
    cols = e.cols.split(',').map((c) => F.find((x) => x.k == c)),
    sf = cols.find((c) => c.k == 'st' && c.t == 's' && OPT(c.o)[0].c) || cols.find((c) => c.t == 's' && OPT(c.o)[0].c);
  let R = D[b].filter((r) => !e.flt || Object.entries(e.flt).every(([a, v]) => r[a] == v));
  const all = R.length;
  if (S.fl && sf) R = R.filter((r) => r[sf.k] == S.fl);
  return (
    sh(e.t, e.d, e.ro ? '' : `<button class="bt g" onclick="ed('${k}')">+ إضافة</button>`) +
    (k == 'ads' ? adx() : '') +
    `<div class="card">${
      sf
        ? `<div style="margin-bottom:10px"><button class="ch ${S.fl ? '' : 'on'}" onclick="S.fl='';render()">الكل (${all})</button>${OPT(
            sf.o,
          )
            .map((o) => `<button class="ch ${S.fl == o.v ? 'on' : ''}" onclick="S.fl='${o.v}';render()">${o.v}</button>`)
            .join('')}</div>`
        : ''
    }${tb(
      cols.map((c) => c.l),
      R.map((r) => `<tr class="k" onclick="vw('${k}',${r.id})">${cols.map((c) => `<td>${fmt(c, r[c.k])}</td>`).join('')}</tr>`).join(''),
    )}</div>`
  );
}
