/* الرحلات المحلية — الجزء 1/4
   يعرّف: ld */
function ld(d) {
  S.f.d = S.f.d == d ? '' : d;
  render();
}
