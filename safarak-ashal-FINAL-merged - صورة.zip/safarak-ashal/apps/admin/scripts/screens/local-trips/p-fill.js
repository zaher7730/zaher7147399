/* الرحلات المحلية — الجزء 3/4
   يعرّف: pFill */
function pFill() {
  const c = D.cu.find((x) => x.id == +$('#pc').value);
  if (c) {
    $('#pn').value = c.n;
    $('#pp').value = c.ph;
  }
}
