/* الرحلات المحلية — الجزء 3/4
   يعرّف: pAdd */
function pAdd(id) {
  const t = D.lt.find((x) => x.id == id),
    n = $('#pn').value.trim();
  if (!n) {
    toast('اكتب اسم الراكب');
    return;
  }
  t.bk.push({ s: S.seat, cu: +$('#pc').value, n, ph: $('#pp').value, pay: $('#py').value });
  tl(t, `حجز المقعد ${S.seat} باسم ${n}`);
  S.seat = 0;
  if (t.bk.length >= t.seats) {
    if (D.set.autoGo) dep(t);
    else {
      t.st = 'ممتلئة';
      tl(t, 'امتلأت المركبة');
    }
  }
  lg('حجز مقعد في الرحلة ' + t.no);
  render();
}
