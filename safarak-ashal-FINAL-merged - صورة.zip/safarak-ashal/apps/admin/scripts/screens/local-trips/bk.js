/* الرحلات المحلية — الجزء 1/4
   يعرّف: bk */
function bk() {
  if ($('#md').classList.contains('on')) {
    cm();
    return;
  }
  if (S.fm) S.fm = null;
  else if (S.rc) S.rc = (S.hs || []).pop() || null;
  else if (S.te != null) S.te = null;
  else if (S.t) S.t = null;
  else if (S.p != 'home') {
    go('home');
    return;
  } else return;
  render();
}
