/* الرحلات المحلية — الجزء 1/4
   يعرّف: trips */
function trips() {
  if (S.te != null) return tform();
  if (S.t) return trip(S.t);
  const f = S.f,
    up = f.tab == 'up',
    days = [...Array(6)].map((_, i) => new Date(Date.now() + i * DY).toISOString().slice(0, 10)),
    L = D.lt.filter(LTF).sort((a, b) => a.no - b.no),
    out = f.d && !days.includes(f.d),
    OP = (v) =>
      `<option value=>الكل</option>` +
      GVN()
        .map((c) => `<option ${v == c ? 'selected' : ''}>${c}</option>`)
        .join('');
  return `<div class="sh"><div><h1>الرحلات المحليه</h1><p>قائمه تحكم وعرض الرحلات</p></div><span><button class="tb2 ${up ? 'on' : ''}" onclick="ltab('up')">قادمه</button><button class="tb2 ${up ? '' : 'on'}" onclick="ltab('dep')">غادرة</button><button class="tb2 g" onclick="S.te=0;render()">اضافه+</button></span></div>
<div class="dsb">${days
    .map((d) => {
      const dd = new Date(d);
      return `<button class="dyb ${f.d == d ? 'on' : ''}" onclick="ld('${d}')"><small>${dd.toLocaleDateString('ar-u-nu-latn', { month: 'long', timeZone: 'UTC' }).replace(/^أ/, 'ا')}</small><b>${dd.getUTCDate()}</b></button>`;
    })
    .join(
      '',
    )}<div class="dpw"><button class="dyb q">${out ? fd(f.d) : 'ابحث بتاريخ<br>المحدد'}</button><input type="date" id="dpk" value="${f.d}" onclick="try{this.showPicker()}catch(e){}" onchange="if(this.value)lf('d',this.value)"></div></div>
<div class="rt"><select onchange="lf('from',this.value)">${OP(f.from)}</select><button class="sw" onclick="sw2()">⇄</button><select onchange="lf('to',this.value)">${OP(f.to)}</select></div>
<div class="card">${tb(['الاسم', 'موقع الرحلة', 'وقت المغادره', 'حاله الرحلة', 'رقم الرحلة'], L.map((t) => `<tr class="k ${up ? 'tu' : 'td'}" onclick="tOpen(${t.id})"><td>${esc(dn(t.dv))}</td><td>${esc(zn(t.fz))}</td><td>${tf(t.time).replace(' ', '')}</td><td>${stx(t)}</td><td><b>${t.no}</b></td></tr>`).join(''))}</div>`;
}
