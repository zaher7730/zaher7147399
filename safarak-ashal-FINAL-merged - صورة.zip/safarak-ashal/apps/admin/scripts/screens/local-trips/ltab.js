/* الرحلات المحلية — الجزء 1/4
   يعرّف: ltab */
function ltab(x) {
  S.f.tab = x;
  S.f.d = TD();
  render();
}
