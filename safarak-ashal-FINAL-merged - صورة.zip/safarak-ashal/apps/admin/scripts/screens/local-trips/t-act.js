/* الرحلات المحلية — الجزء 3/4
   يعرّف: tAct */
function tAct(id, a) {
  const t = D.lt.find((x) => x.id == id);
  if (a == 'load') {
    const ah = grp(t).filter((x) => x.q < t.q && AC.includes(x.st)).length;
    if (ah) {
      toast('الدور لم يصل: ' + ah + ' رحلة قبلها في الفرزة');
      return;
    }
    t.st = t.bk.length >= t.seats ? 'ممتلئة' : 'قيد التحميل';
    tl(t, 'بدأ التحميل');
  } else if (a == 'go') dep(t);
  else if (a == 'reopen') {
    t.st = 'في الانتظار';
    t.rs = '';
    tl(t, 'أُعيد تفعيل الرحلة');
  } else if (a == 'cancel') {
    om(
      `<div class="mh"><h3>إلغاء الرحلة ${t.no}</h3></div><label>سبب الإلغاء</label><textarea id="rs" rows="3"></textarea><p style="margin-top:12px"><button class="bt r" onclick="tCan(${id})">تأكيد الإلغاء</button> <button class="bt o" onclick="cm()">رجوع</button></p>`,
    );
    return;
  }
  lg('رحلة ' + t.no + ': ' + a);
  render();
}
