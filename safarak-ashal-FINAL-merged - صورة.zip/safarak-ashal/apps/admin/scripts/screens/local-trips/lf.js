/* الرحلات المحلية — الجزء 1/4
   يعرّف: lf */
/* الرحلات المحلية — الجزء 1/4
   يعرّف: lf، bk، ltab، ld، sw2، tOpen */
function lf(k, v) {
  S.f[k] = v;
  render();
}
