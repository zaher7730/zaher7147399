/* الرحلات المحلية — الجزء 2/4
   يعرّف: trip */
/* الرحلات المحلية — الجزء 2/4
   يعرّف: trip */
function trip(id) {
  const t = D.lt.find((x) => x.id == id);
  if (!t) {
    S.t = null;
    return trips();
  }
  const dr = D.dv.find((x) => x.id == t.dv) || {},
    fz = D.fz.find((x) => x.id == t.fz) || {},
    G = grp(t).filter((x) => AC.includes(x.st)),
    pos = G.indexOf(t) + 1,
    paid = t.bk.filter((p) => p.pay == 'مدفوع').length,
    tot = t.bk.length * t.price,
    com = Math.round((tot * (D.set.ltCom || 0)) / 100),
    stp = ['في الانتظار', 'قيد التحميل', 'ممتلئة', 'غادرت'],
    si = stp.indexOf(t.st),
    A = (l, a, c) => `<button class="tb2 ${c || ''}" onclick="tAct(${t.id},'${a}')">${l}</button>`,
    kv = (a) => `<div class="kv">${a.map((x) => `<div><small>${x[0]}</small><b>${x[1]}</b></div>`).join('')}</div>`;
  const bt =
    t.st == 'في الانتظار'
      ? A('بدء التحميل', 'load', 'g') + A('إلغاء الرحلة', 'cancel')
      : t.st == 'قيد التحميل'
        ? A('انطلاق الرحلة', 'go', 'g') + A('إلغاء الرحلة', 'cancel')
        : t.st == 'ممتلئة'
          ? A('انطلاق الرحلة', 'go', 'g')
          : t.st == 'ملغاة'
            ? A('إعادة تفعيل', 'reopen', 'g')
            : '';
  return `<div class="sh"><div><h1>رحلة رقم ${t.no}</h1><p>${t.from} ← ${t.to} · ${esc(fz.n || '')} · ${fd(t.date)} ${tf(t.time)}</p></div><span><button class="tb2" onclick="S.t=null;render()">→ كل الرحلات</button>${bt}<button class="tb2" onclick="S.te=${t.id};render()">تعديل</button></span></div>
<div class="stp">${t.st == 'ملغاة' ? '<div class="cur" style="background:var(--rd);border-color:var(--rd)">ملغاة: ' + esc(t.rs || '') + '</div>' : stp.map((s, i) => `<div class="${i < si ? 'dn' : i == si ? 'cur' : ''}">${s}</div>`).join('')}</div>
<div class="gr" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))"><div class="card"><h3>بيانات الرحلة</h3>${kv([
    ['الرقم التسلسلي', t.no],
    ['الفرزة', esc(fz.n || '—')],
    ['المسار', t.from + ' ← ' + t.to],
    ['الموعد', fd(t.date) + ' · ' + tf(t.time)],
    ['الحالة', lp(t)],
    ['الدور في الفرزة', AC.includes(t.st) ? pos + ' من ' + G.length : '—'],
    ['سعر المقعد', t.price + ' ر.س'],
  ])}</div>
<div class="card"><h3>السائق والمركبة</h3>${kv([
    ['السائق', esc(dr.n || '—')],
    ['الجوال', dr.ph || '—'],
    ['رقم الرخصة', dr.lic || '—'],
    ['المركبة', esc(t.vh || '—')],
    ['اللوحة', t.pl || '—'],
    ['تقييم السائق', dr.rate ? dr.rate + ' ⭐' : '—'],
  ])}</div>
<div class="card"><h3>الحسابات</h3>${kv([
    ['المقاعد المحجوزة', t.bk.length + ' من ' + t.seats],
    ['المقاعد المتبقية', t.seats - t.bk.length],
    ['إجمالي الحجوزات', tot + ' ر.س'],
    ['المحصّل (مدفوع)', paid * t.price + ' ر.س'],
    ['عمولة المنصة (' + (D.set.ltCom || 0) + '%)', com + ' ر.س'],
    ['صافي السائق', tot - com + ' ر.س'],
  ])}</div></div>
<div class="gr" style="grid-template-columns:repeat(auto-fit,minmax(320px,1fr))"><div class="card"><h3>خريطة المقاعد</h3><div class="seats">${Array.from(
    { length: t.seats },
    (_, i) => {
      const s = i + 1,
        p = t.bk.find((x) => x.s == s);
      return `<button class="seat ${p ? (p.pay == 'مدفوع' ? 'p' : 't') : ''} ${S.seat == s ? 'sel' : ''}" onclick="S.seat=${s};render()">${s}${p ? `<small>${esc(p.n.split(' ')[0])}</small>` : ''}</button>`;
    },
  ).join(
    '',
  )}</div><p style="margin-top:10px;font-size:12px;color:var(--mu)">أبيض: متاح · أخضر: مدفوع · كحلي: محجوز (الدفع عند الركوب)</p></div><div class="card">${seatPanel(t)}</div></div>
<div class="card"><h3>الركاب (${t.bk.length})</h3>${tb(['المقعد', 'الراكب', 'الجوال', 'الدفع', 'الحساب', ''], t.bk.map((p) => `<tr><td><b>${p.s}</b></td><td>${esc(p.n)}</td><td>${esc(p.ph || '—')}</td><td>${p.pay == 'مدفوع' ? '<span class="pl ok">مدفوع</span>' : '<span class="pl wr">عند الركوب</span>'}</td><td>${p.cu ? `<button class="bt s" onclick="vw('cu',${p.cu})">ملف العميل</button>` : 'بدون حساب'}</td><td><button class="bt s r" onclick="pRm(${t.id},${p.s})">حذف</button></td></tr>`).join(''))}</div>
<div class="card"><h3>سجل الرحلة</h3>${(t.lg || [])
    .slice()
    .reverse()
    .map(
      (l) =>
        `<div class="lgl">${esc(l.x)} <small>· ${new Date(l.ts).toLocaleString('ar-u-nu-latn', { dateStyle: 'medium', timeStyle: 'short' })}</small></div>`,
    )
    .join('')}</div>`;
}
