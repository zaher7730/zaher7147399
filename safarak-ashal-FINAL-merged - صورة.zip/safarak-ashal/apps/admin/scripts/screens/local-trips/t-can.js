/* الرحلات المحلية — الجزء 3/4
   يعرّف: tCan */
function tCan(id) {
  const t = D.lt.find((x) => x.id == id);
  t.st = 'ملغاة';
  t.rs = $('#rs').value || 'بدون سبب';
  tl(t, 'أُلغيت: ' + t.rs);
  lg('إلغاء الرحلة ' + t.no);
  nextQ(t);
  cm();
  render();
}
