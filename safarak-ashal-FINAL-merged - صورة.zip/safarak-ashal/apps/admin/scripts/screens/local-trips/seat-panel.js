/* الرحلات المحلية — الجزء 3/4
   يعرّف: seatPanel */
/* الرحلات المحلية — الجزء 3/4
   يعرّف: seatPanel، pFill، nextQ، dep، tAct، tCan */
function seatPanel(t) {
  const s = S.seat,
    p = t.bk.find((x) => x.s == s);
  if (!s) return '<h3>الراكب</h3><div class="em">اختر مقعداً من الخريطة لإضافة راكب أو عرض بياناته</div>';
  if (p)
    return `<h3>المقعد ${s}</h3><div class="kv"><div><small>الراكب</small><b>${esc(p.n)}</b></div><div><small>الجوال</small><b>${esc(p.ph || '—')}</b></div><div><small>الدفع</small><b>${p.pay}</b></div></div><p style="margin-top:12px">${p.pay != 'مدفوع' ? `<button class="bt g" onclick="pPay(${t.id},${s})">تأكيد استلام المبلغ</button> ` : ''}<button class="bt r" onclick="pRm(${t.id},${s})">حذف الحجز</button></p>`;
  if (t.st == 'غادرت' || t.st == 'ملغاة') return `<h3>المقعد ${s}</h3><div class="em">الرحلة مغلقة، لا يمكن الحجز</div>`;
  return `<h3>حجز المقعد ${s}</h3><div class="fg"><div class="w"><label>العميل (من حسابات المنصة)</label><select id="pc" onchange="pFill()"><option value="0">راكب بدون حساب</option>${D.cu.map((c) => `<option value="${c.id}">${esc(c.n)} · ${c.ph}</option>`).join('')}</select></div><div><label>اسم الراكب</label><input id="pn"></div><div><label>الجوال</label><input id="pp"></div><div class="w"><label>الدفع</label><select id="py"><option>عند الركوب</option><option>مدفوع</option></select></div></div><p style="margin-top:12px"><button class="bt g" onclick="pAdd(${t.id})">حفظ الحجز</button></p>`;
}
