/* الرحلات المحلية — الجزء 4/4 — المتغيرات والتنفيذ عند التحميل
   يعرّف: lp، dn، zn، tl، TD، GVN، GVM، gm، LTF، FLT */
const lp = (t) => {
    const o = OPT(TS).find((x) => x.v == t.st);
    return `<span class="pl ${PC[o.c]}">${esc(rtm(t))}</span>`;
  },
  dn = (id) => (D.dv.find((x) => x.id == id) || { n: '—' }).n,
  zn = (id) => (D.fz.find((x) => x.id == id) || { n: '—' }).n,
  tl = (t, x) => {
    (t.lg = t.lg || []).push({ ts: Date.now(), x });
  },
  TD = () => new Date().toISOString().slice(0, 10);
const GVN = () => D.ct.filter((c) => c.ty == 'داخلية' && c.on !== 0).map((c) => c.n),
  GVM = { المكلا: 'حضرموت', سيئون: 'حضرموت' },
  gm = (c, v) => !v || c == v || (GVM[c] || c) == v || (v == 'أمانة العاصمة' && c == 'صنعاء');
const LTF = (t) => {
  const f = S.f;
  return (f.tab == 'up' ? AC.includes(t.st) : t.st == 'غادرت') && (!f.d || t.date == f.d) && gm(t.from, f.from) && gm(t.to, f.to);
};
const FLT = PFd([
  '#المسار والفرزة',
  'from|من|s|' + CT.join(','),
  'to|إلى|s|' + CT.join(','),
  'fz|الفرزة|r|fz',
  'date|تاريخ الرحلة|d',
  'time|وقت المغادرة|h',
  '#السائق والمركبة',
  'dv|السائق|r|dv',
  'vh|نوع المركبة|s|من بيانات السائق,' + VHL,
  'pl|رقم اللوحة (فارغ = من بيانات السائق)',
  'seats|عدد المقاعد (0 = حسب المركبة)|n',
  '#السعر',
  'price|سعر المقعد (ر.س)|n',
  'old|السعر قبل الخصم (ر.س)|n',
  'tier|الفئة|s|اقتصادي,مميز,VIP',
  'feat|المزايا (ميزة بكل سطر)|l',
  'img|صورة الرحلة|i',
  'note|ملاحظات|a',
]);
