/* الرحلات المحلية — الجزء 4/4
   يعرّف: tform */
function tform() {
  const r = S.te ? D.lt.find((x) => x.id == S.te) : { date: TD(), time: '08:00', price: 0, seats: 0 };
  TMP = {};
  return `<div class="sh"><div><h1>${S.te ? 'تعديل الرحلة ' + r.no : 'إضافة رحلة جديدة'}</h1><p>يُعطى رقماً تسلسلياً تلقائياً، ويدخل السائق في دور الفرزة حسب ترتيب الإضافة</p></div><span><button class="tb2" onclick="S.te=null;render()">→ رجوع</button></span></div><div class="card">${form(FLT, r)}<p style="margin-top:14px"><button class="bt g" onclick="tSave()">حفظ الرحلة</button> <button class="bt o" onclick="S.te=null;render()">إلغاء</button></p></div>`;
}
