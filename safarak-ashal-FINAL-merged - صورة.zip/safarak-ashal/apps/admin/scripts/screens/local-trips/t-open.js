/* الرحلات المحلية — الجزء 1/4
   يعرّف: tOpen */
function tOpen(id) {
  S.t = id;
  S.seat = 0;
  render();
}
