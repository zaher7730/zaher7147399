/* الرحلات المحلية — الجزء 4/4
   يعرّف: pRm */
/* الرحلات المحلية — الجزء 4/4
   يعرّف: pRm، pPay، tform، tSave، lp، GVN */
function pRm(id, s) {
  const t = D.lt.find((x) => x.id == id);
  t.bk = t.bk.filter((p) => p.s != s);
  if (t.st == 'ممتلئة') t.st = 'قيد التحميل';
  tl(t, 'حذف حجز المقعد ' + s);
  S.seat = 0;
  lg('حذف حجز من الرحلة ' + t.no);
  render();
}
