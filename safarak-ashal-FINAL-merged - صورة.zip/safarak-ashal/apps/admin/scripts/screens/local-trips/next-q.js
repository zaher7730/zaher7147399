/* الرحلات المحلية — الجزء 3/4
   يعرّف: nextQ */
function nextQ(t) {
  const g = grp(t);
  if (g.some((x) => x.st == 'قيد التحميل')) return;
  const n = g.find((x) => x.st == 'في الانتظار');
  if (n) {
    n.st = 'قيد التحميل';
    tl(n, 'جاء دورها في الفرزة وبدأ التحميل');
  }
}
