/* الرحلات المحلية — الجزء 4/4
   يعرّف: pPay */
function pPay(id, s) {
  const t = D.lt.find((x) => x.id == id);
  t.bk.find((p) => p.s == s).pay = 'مدفوع';
  tl(t, 'استلام مبلغ المقعد ' + s);
  render();
}
