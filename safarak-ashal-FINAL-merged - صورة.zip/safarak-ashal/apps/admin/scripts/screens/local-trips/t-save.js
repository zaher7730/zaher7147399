/* الرحلات المحلية — الجزء 4/4
   يعرّف: tSave */
function tSave() {
  const n = !S.te,
    r = n ? { id: Math.max(0, ...D.lt.map((x) => x.id)) + 1, bk: [], lg: [], st: 'في الانتظار' } : D.lt.find((x) => x.id == S.te);
  collect(FLT, r);
  const d = D.dv.find((x) => x.id == r.dv) || {};
  if (r.vh == 'من بيانات السائق') r.vh = d.vh || VHL.split(',')[0];
  r.pl = r.pl || d.pl || '';
  r.seats = r.seats || VC[r.vh] || d.seats || 14;
  if (n) {
    r.no = Math.max(0, ...D.lt.map((x) => x.no)) + 1;
    r.q = Math.max(0, ...grp(r).map((x) => x.q)) + 1;
    D.lt.push(r);
    tl(r, 'أُنشئت الرحلة برقم تسلسلي ' + r.no);
    if (r.date == TD() && !grp(r).some((x) => x !== r && AC.includes(x.st))) {
      r.st = 'قيد التحميل';
      tl(r, 'أول الدور في الفرزة وبدأ التحميل');
    }
  }
  lg((n ? 'إضافة' : 'تعديل') + ' الرحلة ' + r.no);
  S.te = null;
  S.t = n ? r.id : S.t;
  render();
}
