/* الرحلات المحلية — الجزء 3/4
   يعرّف: dep */
function dep(t) {
  t.st = 'غادرت';
  t.dep = Date.now();
  tl(t, 'انطلقت الرحلة بـ ' + t.bk.length + ' راكب');
  lg('انطلاق الرحلة ' + t.no);
  nextQ(t);
}
