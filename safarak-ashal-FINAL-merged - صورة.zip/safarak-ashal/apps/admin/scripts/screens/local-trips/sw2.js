/* الرحلات المحلية — الجزء 1/4
   يعرّف: sw2 */
function sw2() {
  [S.f.from, S.f.to] = [S.f.to, S.f.from];
  render();
}
