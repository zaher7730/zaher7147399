/* الرحلات المحلية — الجزء 1/4
   يعرّف: stx */
function stx(t) {
  if (t.st == 'غادرت') return 'غادرت';
  if (t.st != 'في الانتظار') return t.st;
  const m = Math.round((dts(t) - Date.now()) / 6e4);
  return m <= 0
    ? 'حان موعدها'
    : m < 60
      ? `بعد ${m} <small>دقيقة</small>`
      : ((h) => `بعد ${h} <small>${h == 1 ? 'ساعة' : h == 2 ? 'ساعتين' : 'ساعات'}</small>`)(Math.round(m / 60));
}
