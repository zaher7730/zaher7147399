/* الرئيسية والمالية — الجزء 2/2
   يعرّف: finHome */
/* الرئيسية والمالية — الجزء 2/2
   يعرّف: finHome */
function finHome() {
  const M = (n) => (+n || 0).toLocaleString('en'),
    done = D.or.filter((o) => o.st == 'مكتمل'),
    sales = done.reduce((a, o) => a + o.tot, 0),
    com = done.reduce((a, o) => a + o.com, 0),
    open = D.or.filter((o) => !['مكتمل', 'ملغي', 'مرفوض'].includes(o.st) && o.pay != 'مدفوع').reduce((a, o) => a + o.tot, 0),
    rmP = D.rm.filter((r) => r.st == 'بانتظار التأكيد'),
    rmOk = D.rm.filter((r) => /مؤكد|مقبول|مكتمل/.test(r.st)).reduce((a, r) => a + r.amt, 0),
    dep = D.lt.filter((t) => t.st == 'غادرت'),
    rev = (t) => t.bk.length * t.price,
    lt = dep.reduce((a, t) => a + rev(t), 0),
    td = TD(),
    ltT = dep.filter((t) => t.date == td).reduce((a, t) => a + rev(t), 0),
    days = [...Array(7)].map((_, i) => new Date(Date.now() - (6 - i) * DY).toISOString().slice(0, 10)),
    bv = days.map((d) => dep.filter((t) => t.date == d).reduce((a, t) => a + rev(t), 0)),
    mx = Math.max(1, ...bv),
    tt = D.lt.filter((t) => t.date == td),
    tW = tt.filter((t) => t.st == 'في الانتظار').length,
    tL = tt.filter((t) => t.st == 'قيد التحميل').length,
    tD = tt.filter((t) => t.st == 'غادرت').length,
    ofA = D.of.filter((o) => o.st == 'معتمد').length,
    seatsT = tt.reduce((a, t) => a + t.seats, 0),
    seatsB = tt.reduce((a, t) => a + t.bk.length, 0),
    top = D.of
      .map((o) => [o, D.or.filter((r) => r.of == o.id && r.st == 'مكتمل').reduce((a, r) => a + r.tot, 0)])
      .sort((x, y) => y[1] - x[1])
      .slice(0, 5);
  return `<div class="fin"><div class="fc m"><small>إجمالي دخل التطبيق (ر.س)</small><b>${M(sales + lt)}</b><em>مبيعات المكاتب + الرحلات المحلية</em></div><div class="fc"><small>عمولات المكاتب</small><b>${M(com)}</b><em>من ${done.length} طلب مكتمل</em></div><div class="fc"><small>دخل الرحلات المحلية</small><b>${M(lt)}</b><em>اليوم: ${M(ltT)} ر.س</em></div><div class="fc"><small>مبالغ قيد التحصيل</small><b>${M(open)}</b><em>طلبات غير مدفوعة</em></div><div class="fc"><small>حوالات مؤكدة</small><b>${M(rmOk)}</b><em>${rmP.length} حوالة بانتظار التأكيد</em></div></div>
<div class="gr" style="grid-template-columns:repeat(auto-fit,minmax(320px,1fr))"><div class="card"><h3>دخل الرحلات المحلية · آخر 7 أيام</h3><div class="bars">${bv.map((v, i) => `<div class="${i == 6 ? 't' : ''}"><b>${v ? M(v) : ''}</b><i style="height:${Math.max(3, (v / mx) * 100)}%"></i>${new Date(days[i]).getUTCDate()}</div>`).join('')}</div></div>
<div class="card"><h3>أعلى المكاتب مبيعًا</h3>${top.map((x) => `<div class="row" onclick="vw('of',${x[0].id})"><b style="flex:1">${esc(x[0].n)}</b><span>${M(x[1])} ر.س</span></div>`).join('') || '<div class="em">لا توجد بيانات</div>'}</div></div>
<div class="card"><h3>التحكم المركزي</h3><div class="ctl"><button onclick="go('lt')">رحلات اليوم<b>${tt.length}</b><small>تحميل ${tL} · غادرت ${tD} · انتظار ${tW}</small></button><button onclick="go('lt')">إشغال المقاعد اليوم<b>${seatsT ? Math.round((seatsB / seatsT) * 100) : 0}%</b><div class="pbar"><i style="width:${seatsT ? Math.round((seatsB / seatsT) * 100) : 0}%"></i></div></button><button onclick="go('of')">المكاتب المعتمدة<b>${ofA} / ${D.of.length}</b></button><button onclick="go('dv')">سائقو الرحلات<b>${D.dv.filter((x) => x.st == 'نشط').length}</b></button><button onclick="go('cu')">العملاء<b>${D.cu.length}</b></button></div></div>`;
}
