/* الرئيسية والمالية — الجزء 1/2
   يعرّف: home */
/* الرئيسية والمالية — الجزء 1/2
   يعرّف: home */
function home() {
  const sales = D.or.filter((o) => o.st == 'مكتمل').reduce((a, o) => a + o.tot, 0),
    T = [
      ['cu', '👥', D.cu.length, 'عدد العملاء'],
      ['of', '🏢', D.of.filter((o) => o.st == 'معتمد').length, 'المكاتب المعتمدة'],
      ['or', '📋', D.or.length, 'عدد الطلبات'],
      ['rep', '💰', sales.toLocaleString('en'), 'مبيعات مكتملة (ر.س)'],
    ];
  return (
    sh('مرحباً بك في لوحة التحكم', 'تحكم مركزي شامل بتطبيق العميل وتطبيق المكتب وكل ما بينهما') +
    `<div class="gr">${T.map((t) => `<button class="sc" onclick="go('${t[0]}')"><i>${t[1]}</i><div><b>${t[2]}</b><small>${t[3]}</small></div></button>`).join('')}</div><div class="card"><h3>تحتاج إجراءً منك</h3><div class="al">${
      ALR.map((a) => [a, pend[a[0]]()])
        .filter((a) => a[1])
        .map((a) => `<button onclick="go('${a[0][0]}')">${a[0][1]} <b>${a[1]}</b></button>`)
        .join('') || '<span class="em">لا شيء معلّق</span>'
    }</div></div>${finHome()}<div class="gr" style="grid-template-columns:repeat(auto-fit,minmax(320px,1fr))"><div class="card"><h3>آخر الطلبات</h3>${D.or
      .slice(0, 6)
      .map(
        (o) =>
          `<div class="row" onclick="vw('or',${o.id})"><b>${o.no}</b><span style="flex:1">${lab('cu', o.cu)} ← ${lab('of', o.of)}</span>${fmt(
            fl('or').find((f) => f.k == 'st'),
            o.st,
          )}</div>`,
      )
      .join('')}</div><div class="card"><h3>آخر العمليات الإدارية</h3>${
      D.log
        .slice(0, 6)
        .map((l) => `<div class="row" style="cursor:default"><span style="flex:1">${esc(l.t)}</span><small>${fd(l.ts)}</small></div>`)
        .join('') || '<div class="em">لا توجد عمليات بعد</div>'
    }</div></div>`
  );
}
