/* صفحات السجلات
   يعرّف: renum */
function renum() {
  const G = {};
  D.lt.forEach((t) => {
    const k = [t.fz, t.from, t.to, t.date].join('|');
    (G[k] = G[k] || []).push(t);
  });
  Object.values(G).forEach((a) =>
    a.sort((x, y) => (x.time < y.time ? -1 : x.time > y.time ? 1 : x.q - y.q)).forEach((t, i) => (t.q = i + 1)),
  );
  D.lt
    .slice()
    .sort((a, b) => dts(a) - dts(b) || a.fz - b.fz || a.q - b.q || a.id - b.id)
    .forEach((t, i) => (t.no = i + 1));
}
