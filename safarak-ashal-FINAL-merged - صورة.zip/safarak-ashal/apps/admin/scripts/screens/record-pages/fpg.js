/* صفحات السجلات
   يعرّف: fpg */
function fpg() {
  const b = S.fm[0],
    id = S.fm[1],
    e = E[b],
    r = id ? D[b].find((x) => x.id == id) : {};
  return (
    sh((id ? 'تعديل: ' : 'إضافة: ') + e.t, id ? esc(lab(b, id)) : 'سجل جديد', '<button class="tb2" onclick="bk()">→ رجوع</button>') +
    `<div class="card">${form(e.F, r)}<p style="margin-top:14px"><button class="bt g" onclick="sd('${b}',${id || 0})">حفظ</button> <button class="bt o" onclick="bk()">إلغاء</button></p></div>`
  );
}
