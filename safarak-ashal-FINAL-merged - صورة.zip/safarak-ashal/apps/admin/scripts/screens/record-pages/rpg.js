/* صفحات السجلات
   يعرّف: rpg */
/* صفحات السجلات
   يعرّف: rpg، fpg، renum، topUp، CP، d */
function rpg(b, id) {
  const e = E[b];
  return (
    sh(esc(lab(b, id)), esc(e.t), '<button class="tb2" onclick="bk()">→ رجوع</button>') +
    vw(b, id, 1)
      .split(/(?=<h4>)/)
      .filter((x) => x.trim())
      .map((c) => '<div class="card pgd">' + c + '</div>')
      .join('')
  );
}
