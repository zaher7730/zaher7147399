/* صفحات السجلات — المتغيرات والتنفيذ عند التحميل
   يعرّف: CP */
const CP = { rep: rep, log: logp, lt: trips, int: () => SA_integrationsPage(), bkp: () => SA_backupsPage(), qt: () => SA_quotasPage() };
S.f.d = TD();
