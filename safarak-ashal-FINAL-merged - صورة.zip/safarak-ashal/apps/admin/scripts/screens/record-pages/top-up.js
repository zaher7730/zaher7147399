/* صفحات السجلات
   يعرّف: topUp */
function topUp() {
  D.tu = 7;
  renum();
  sv();
}
