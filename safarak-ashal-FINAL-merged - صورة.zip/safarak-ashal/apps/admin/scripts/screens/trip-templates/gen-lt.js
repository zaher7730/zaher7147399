/* قوالب الرحلات
   يعرّف: genLt */
/* قوالب الرحلات
   يعرّف: genLt */
function genLt(id) {
  const t = D.ltp.find((x) => x.id == id),
    W = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
    d = D.dv.find((x) => x.id == t.dv) || {};
  let n = 0;
  for (let i = 0; i < 7; i++) {
    const ds = new Date(Date.now() + i * DY).toISOString().slice(0, 10);
    if (
      !(t.days || []).includes(W[new Date(ds + 'T12:00:00').getDay()]) ||
      D.lt.some((x) => x.from == t.from && x.to == t.to && x.date == ds && x.time == t.time)
    )
      continue;
    const vh = t.vh || d.vh || VHL.split(',')[0],
      r = {
        id: Math.max(0, ...D.lt.map((x) => x.id)) + 1,
        from: t.from,
        to: t.to,
        fz: t.fz,
        date: ds,
        time: t.time,
        dv: t.dv,
        vh,
        pl: d.pl || '',
        seats: t.seats || VC[vh] || d.seats || 14,
        price: t.price,
        old: t.old,
        tier: t.tier,
        bk: [],
        lg: [],
        st: 'في الانتظار',
        note: '',
      };
    r.no = Math.max(0, ...D.lt.map((x) => x.no)) + 1;
    r.q = Math.max(0, ...grp(r).map((x) => x.q)) + 1;
    D.lt.push(r);
    tl(r, 'أُنشئت من القالب برقم تسلسلي ' + r.no);
    n++;
  }
  lg('إنشاء رحلات من القالب: ' + t.from + ' ← ' + t.to);
  toast(n ? 'تم إنشاء ' + n + ' رحلة' : 'رحلات الأسبوع القادم موجودة مسبقاً');
  render();
}
