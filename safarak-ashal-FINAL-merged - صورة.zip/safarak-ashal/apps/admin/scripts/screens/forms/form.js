/* النماذج والحفظ — الجزء 1/2
   يعرّف: form */
function form(F, r) {
  let h = '',
    o = 0;
  F.forEach((f) => {
    if (f.sec) {
      h += (o ? '</div>' : '') + `<h4>${f.sec}</h4><div class="fg">`;
      o = 1;
    } else
      h += `<div class="${f.t == 'a' || f.t == 'l' || f.t == 'm' || f.t == 'i' ? 'w' : ''}" ${f.w ? `data-w="${f.w}"` : ''}><label>${f.l}</label>${inp(f, r[f.k])}</div>`;
  });
  return h + (o ? '</div>' : '');
}
