/* النماذج والحفظ — الجزء 2/2
   يعرّف: sd */
/* النماذج والحفظ — الجزء 2/2
   يعرّف: sd */
async function sd(b, id) {
  const e = E[b];
  let r = id ? D[b].find((x) => x.id == id) : { id: Math.max(0, ...D[b].map((x) => x.id)) + 1 };
  collect(e.F, r);
  if (b === 'pg') r.upd = new Date().toISOString().slice(0, 10); /* تاريخ آخر تحديث تلقائي؛ تطبيق العميل يعرض النص المعدَّل فقط */
  if (b === 'of' && window.SA_API) {
    try {
      if (!id) {
        if (!r.n || !r.ph) return toast('أدخل اسم المكتب ورقم هاتفه');
        await window.SA_API.adminOffices({ name: r.n, officeName: r.n, phone: r.ph, email: r.email || '' });
      } else {
        await window.SA_API.updateAdminUser(r.id, { name: r.n, officeName: r.n, phone: r.ph, email: r.email || '' });
      }
      S.fm = null;
      await SA_hydrateAdmin();
      toast(id ? 'تم تحديث بيانات المكتب' : 'تم إنشاء حساب المكتب؛ يسجل الدخول برقم الهاتف ورمز واتساب');
      return;
    } catch (err) {
      return toast(err.message || 'تعذر حفظ بيانات المكتب على الخادم');
    }
  }
  if (b === 'ap' && window.SA_API) {
    try {
      if (!r.n || !r.city || !r.addr) return toast('أدخل اسم النقطة والمدينة والعنوان');
      const payload = { name: r.n, city: r.city, address: r.addr, phone: r.ph || '', active: !!r.on };
      if (id) await window.SA_API.updateAdminPoint(r.id, payload);
      else await window.SA_API.createAdminPoint(payload);
      S.fm = null;
      await SA_hydrateAdmin();
      toast(id ? 'تم تحديث نقطة الأمانات' : 'تم حفظ نقطة الأمانات في قاعدة البيانات');
      return;
    } catch (err) {
      return toast(err.message || 'تعذر حفظ نقطة الأمانات');
    }
  }
  if (b === 'bk' && window.SA_API) {
    try {
      if (!r.n || !r.no || !r.ty) return toast('أدخل نوع وسيلة الدفع واسمها ورقم الحساب');
      const payload = {
        ownerId: r.of ? Number(r.of) : null,
        type: r.ty,
        name: r.n,
        accountNo: r.no,
        holder: r.ho || '',
        currency: r.cur || D.set.cur || 'YER',
        active: !!r.on,
      };
      if (id) await window.SA_API.updateAdminPaymentMethod(r.id, payload);
      else await window.SA_API.createAdminPaymentMethod(payload);
      S.fm = null;
      await SA_hydrateAdmin();
      toast(id ? 'تم تحديث وسيلة الدفع' : 'تم حفظ وسيلة الدفع في قاعدة البيانات');
      return;
    } catch (err) {
      return toast(err.message || 'تعذر حفظ وسيلة الدفع');
    }
  }
  if (b === 'ofr' && window.SA_API) {
    try {
      if (!r.title) r.title = r.from ? r.from + ' ← ' + r.to : r.svc || [r.make, r.model].filter(Boolean).join(' ');
      const typeMap = {
        طيران: 'air',
        'نقل دولي': 'bus',
        تأشيرات: 'visa',
        جوازات: 'pass',
        'تأجير سيارات': 'cars',
        'رحلات خاصة': 'priv',
        'رحلات محلية': 'local',
        'برنت بصمة': 'visa',
        'الموافقات الأمنية': 'visa',
      };
      let imageUrl = r.imageUrl || '';
      if (typeof r.img === 'string' && /^data:image\/(jpeg|png|webp);base64,/i.test(r.img)) {
        const sig = r.img.length + ':' + r.img.slice(-48);
        if (r._uploadedImageSignature !== sig) {
          const mimeType = (r.img.match(/^data:(image\/(?:jpeg|png|webp));base64,/i) || [])[1];
          imageUrl = (
            await window.SA_API.uploadOfferAsset({
              filename: r.title.replace(/[^\w\u0600-\u06FF-]/g, '_') + '.img',
              mimeType,
              base64: r.img,
            })
          ).asset.url;
          r._uploadedImageSignature = sig;
          r.imageUrl = imageUrl;
        }
      }
      const details = {};
      for (const [key, value] of Object.entries(r)) {
        if (['id', 'serverId', 'of', 'sv', 'title', 'st', 'on', 'img', 'imageUrl', '_uploadedImageSignature', 'details'].includes(key))
          continue;
        if (typeof value !== 'function') details[key] = value;
      }
      if (imageUrl) details.imageUrl = imageUrl;
      /* «برنت بصمة» و«الموافقات الأمنية» تُنشر كخدمة تأشيرات باسمها حتى تظهر تحت «خدمات أخرى» عند العميل */
      if (['برنت بصمة', 'الموافقات الأمنية'].includes(r.sv)) details.svc = r.sv;
      if (!details.currency) details.currency = D.set.cur || 'YER';
      const active = !!r.on && r.st === 'معتمد';
      if (!id) {
        const made = await window.SA_API.createAdminService({
          officeId: r.of,
          serviceType: typeMap[r.sv] || r.sv,
          title: r.title,
          details,
          active,
        });
        r.id = made.service.id;
      } else await window.SA_API.updateAdminService(r.id, { title: r.title, details, active });
      S.fm = null;
      await SA_hydrateAdmin();
      toast(id ? 'تم تحديث العرض الحقيقي' : 'تم إنشاء العرض على الخادم؛ راجعه وانشره عند الجاهزية');
      return;
    } catch (err) {
      return toast(err.message || 'تعذر حفظ العرض على الخادم');
    }
  }
  if (['pk', 'pp', 'ov'].includes(b) && window.SA_API) {
    try {
      await SA_pushLive(b, r);
      S.fm = null;
      await SA_hydrateAdmin(true);
      toast('تم الحفظ في الخادم');
    } catch (err) {
      toast(err.message || 'تعذر الحفظ في الخادم');
    }
    return;
  }
  if (id && ['rv', 'tk', 'cu'].includes(b) && window.SA_API) {
    try {
      await SA_pushAdminRecord(b, r);
    } catch (err) {
      return toast(err.message || 'تعذر حفظ التغيير على الخادم');
    }
  }
  if (!id) {
    D[b].push(r);
  }
  if (b == 'or') rl(r, id ? 'تعديل بيانات الطلب' : 'إنشاء الطلب');
  lg((id ? 'تعديل: ' : 'إضافة: ') + lab(b, r.id));
  S.fm = null;
  if (!id) S.rc = null;
  cm();
  render();
}
