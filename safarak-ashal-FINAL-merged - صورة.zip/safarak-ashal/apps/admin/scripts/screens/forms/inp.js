/* النماذج والحفظ — الجزء 1/2
   يعرّف: inp */
/* النماذج والحفظ — الجزء 1/2
   يعرّف: inp، im، sw، form، collect، ed */
function inp(f, v) {
  const i = 'f_' + f.k;
  if (f.t == 's') {
    return `<select id="${i}" onchange="sw()">${f.o.startsWith('x:') ? '' : ''}${OPT(f.o)
      .map((o) => `<option ${o.v == v ? 'selected' : ''}>${o.v}</option>`)
      .join('')}</select>`;
  }
  if (f.t == 'r')
    return `<select id="${i}"><option value="0">—</option>${D[B(f.o)].map((r) => `<option value="${r.id}" ${r.id == v ? 'selected' : ''}>${lab(f.o, r.id)}</option>`).join('')}</select>`;
  if (f.t == 'c') return `<input type="checkbox" id="${i}" ${v ? 'checked' : ''}>`;
  if (f.t == 'a' || f.t == 'l') return `<textarea id="${i}" rows="3"${f.o == 'ro' ? ' readonly style="background:#f6f4ee;cursor:default"' : ''}>${esc(v || '')}</textarea>`;
  if (f.t == 'm')
    return `<div class="mc" id="${i}">${f.o
      .split(',')
      .map((o) => `<label><input type="checkbox" value="${o}" ${(v || []).includes(o) ? 'checked' : ''}>${o}</label>`)
      .join('')}</div>`;
  if (f.t == 'i') {
    TMP[f.k] = v || '';
    return `<input type="file" accept="image/*" onchange="im(this,'${f.k}')"><img id="p_${f.k}" class="th" style="width:${f.k == 'photo' ? '60px;height:90px' : '90px;height:60px'};margin-top:6px;${v ? '' : 'display:none'}" src="${v || ''}">`;
  }
  return `<input id="${i}" type="${f.t == 'n' ? 'number' : f.t == 'd' ? 'date' : f.t == 'h' ? 'time' : 'text'}" value="${esc(v ?? '')}">`;
}
