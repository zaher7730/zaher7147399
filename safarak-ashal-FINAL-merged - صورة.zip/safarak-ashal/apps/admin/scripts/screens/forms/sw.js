/* النماذج والحفظ — الجزء 1/2
   يعرّف: sw */
function sw() {
  const s = $('#f_sv');
  if (!s) return;
  document.querySelectorAll('[data-w]').forEach((d) => (d.style.display = d.dataset.w.split(',').includes(s.value) ? '' : 'none'));
}
