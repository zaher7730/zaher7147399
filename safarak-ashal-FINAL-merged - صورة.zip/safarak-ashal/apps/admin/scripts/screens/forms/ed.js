/* النماذج والحفظ — الجزء 1/2
   يعرّف: ed */
function ed(k, id) {
  const b = B(k);
  TMP = {};
  if (S.rc && S.rc[0] != b) S.rc = null;
  S.fm = [b, id || 0];
  cm();
  render();
  sw();
}
