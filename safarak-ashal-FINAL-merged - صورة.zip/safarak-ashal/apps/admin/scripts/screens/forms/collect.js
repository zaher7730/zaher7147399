/* النماذج والحفظ — الجزء 1/2
   يعرّف: collect */
function collect(F, r) {
  F.forEach((f) => {
    if (!f.k) return;
    const e = $('#f_' + f.k) || {};
    r[f.k] =
      f.t == 'c'
        ? e.checked
          ? 1
          : 0
        : f.t == 'n'
          ? +e.value || 0
          : f.t == 'r'
            ? +e.value
            : f.t == 'i'
              ? TMP[f.k]
              : f.t == 'm'
                ? [...e.querySelectorAll('input:checked')].map((x) => x.value)
                : e.value;
  });
}
