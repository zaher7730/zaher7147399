/* النماذج والحفظ — الجزء 1/2
   يعرّف: im */
function im(i, k) {
  const f = i.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = (e) => {
    const m = new Image();
    m.onload = () => {
      const s = Math.min(1, 1800 / m.width),
        c = document.createElement('canvas');
      c.width = m.width * s;
      c.height = m.height * s;
      c.getContext('2d').drawImage(m, 0, 0, c.width, c.height);
      TMP[k] = c.toDataURL('image/jpeg', 0.9);
      const p = $('#p_' + k);
      p.src = TMP[k];
      p.style.display = 'block';
    };
    m.src = e.target.result;
  };
  r.readAsDataURL(f);
}
