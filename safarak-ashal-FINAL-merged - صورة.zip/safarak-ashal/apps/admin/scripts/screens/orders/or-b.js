/* الطلبات — الجزء 1/2
   يعرّف: orB */
function orB(r) {
  const L = (t) => String(t).split('\n').filter(Boolean);
  return (
    (r.fd
      ? `<h4>البيانات التي أدخلها العميل</h4><div class="kv">${L(r.fd)
          .map((l) => {
            const i = l.indexOf(':');
            return i > 0
              ? `<div><small>${esc(l.slice(0, i))}</small><b>${esc(l.slice(i + 1).trim() || '—')}</b></div>`
              : `<div><small>—</small><b>${esc(l)}</b></div>`;
          })
          .join('')}</div>`
      : '') +
    (r.psg
      ? `<h4>المسافرون الإضافيون</h4>` +
        tb(
          ['#', 'بيانات المسافر'],
          L(r.psg)
            .map((l, i) => `<tr><td>${i + 2}</td><td>${esc(l)}</td></tr>`)
            .join(''),
        )
      : '')
  );
}
