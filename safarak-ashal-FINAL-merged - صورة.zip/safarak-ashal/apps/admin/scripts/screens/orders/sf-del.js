/* الطلبات — الجزء 2/2
   يعرّف: sfDel */
function sfDel(id, i) {
  const r = D.or.find((x) => x.id == id);
  rl(r, 'حذف ملف مرسل: ' + r.sf[i].n);
  r.sf.splice(i, 1);
  sv();
  render();
}
