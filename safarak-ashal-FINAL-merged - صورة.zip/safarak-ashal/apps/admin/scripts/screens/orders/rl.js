/* الطلبات — الجزء 1/2
   يعرّف: rl */
function rl(r, t) {
  (r.lg = r.lg || []).push({ t, d: new Date().toISOString() });
}
