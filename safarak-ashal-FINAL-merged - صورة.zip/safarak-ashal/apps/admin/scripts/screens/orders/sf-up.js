/* الطلبات — الجزء 2/2
   يعرّف: sfUp */
function sfUp(id, el) {
  const f = el.files[0];
  if (!f) return;
  if (f.size > 1.5e6) {
    toast('الحجم الأقصى للملف 1.5 ميجا');
    return;
  }
  const rd = new FileReader();
  rd.onload = () => {
    const r = D.or.find((x) => x.id == id);
    (r.sf = r.sf || []).push({ n: f.name, u: rd.result, ts: new Date().toISOString() });
    rl(r, 'إرسال ملف للعميل: ' + f.name);
    sv();
    render();
  };
  rd.readAsDataURL(f);
}
