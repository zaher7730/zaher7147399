/* الطلبات — الجزء 2/2
   يعرّف: orL */
/* الطلبات — الجزء 2/2
   يعرّف: orL، sfUp، sfDel */
function orL(r) {
  return (
    `<h4>ملفات مرسلة للعميل (${(r.sf || []).length})</h4><div class="mg">${(r.sf || []).map((f, i) => `<div class="mx"><b>${esc(f.n)}</b>${/^data:image/.test(f.u) ? `<img class="bi" src="${f.u}" onclick="zi(this.src)" alt="${esc(f.n)}">` : `<a class="bt o" href="${f.u}" download="${esc(f.n)}">تنزيل الملف</a>`}<small>${fd(f.ts)}</small><div class="bar"><button class="bt r" onclick="sfDel(${r.id},${i})">حذف</button></div></div>`).join('') || '<div class="em">لم تُرسل ملفات لهذا الطلب</div>'}</div><p style="margin-top:10px"><input type="file" id="sfi" style="display:none" onchange="sfUp(${r.id},this)"><button class="bt o" onclick="$('#sfi').click()">+ إرسال ملف للعميل</button></p><h4>سجل الطلب</h4>` +
    tb(
      ['الوقت', 'الإجراء'],
      (r.lg || [])
        .slice()
        .reverse()
        .map((x) => `<tr><td>${x.d.slice(0, 16).replace('T', ' ')}</td><td>${esc(x.t)}</td></tr>`)
        .join(''),
    )
  );
}
