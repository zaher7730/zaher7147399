/* الطلبات — الجزء 1/2
   يعرّف: orX */
/* الطلبات — الجزء 1/2
   يعرّف: orX، rl، orB */
function orX(id) {
  const r = D.or.find((x) => x.id == id),
    c = D.cu.find((x) => x.id == r.cu) || {},
    DC = D.dc.filter((x) => x.or == id),
    RM = D.rm.filter((x) => x.or == id),
    q = D.rq.find((x) => x.sv == r.sv),
    req = q ? q.req : DREQ[r.sv] || [],
    have = DC.map((x) => x.ty),
    M = (n) => (+n || 0).toLocaleString('en'),
    ok = RM.filter((x) => x.st == 'مؤكدة').reduce((a, x) => a + x.amt, 0),
    wt = RM.filter((x) => x.st == 'بانتظار التأكيد').reduce((a, x) => a + x.amt, 0),
    st = (k, v) =>
      fmt(
        fl(k).find((f) => f.k == 'st'),
        v,
      ),
    img = (u, t) =>
      u
        ? `<img class="bi${t == 'صورة شخصية' ? ' p46' : ''}" src="${u}" onclick="zi(this.src)" alt="${t}">`
        : '<span class="bi" style="display:grid;place-items:center;color:var(--mu);font-weight:500">لم يُرفع</span>',
    btn = (b, x) =>
      (E[b].ac || [])
        .map((a, i) =>
          E[b].acf && !E[b].acf(x)
            ? ''
            : !a[4] || a[4].split(',').includes(x[a[1]])
              ? `<button class="bt ${a[3]}" onclick="ac('${b}',${x.id},${i})">${a[0]}</button>`
              : '',
        )
        .join('');
  return (
    `<h4>بيانات العميل</h4><div class="kv"><div><small>الاسم</small><b><a class="lk" onclick="vw('cu',${c.id})">${esc(c.n || '—')}</a></b></div><div><small>الجوال</small><b>${esc(c.ph || '—')}</b></div><div><small>المدينة</small><b>${esc(c.city || '—')}</b></div><div><small>رقم الهوية أو الجواز</small><b>${esc(c.idn || '—')}</b></div><div><small>حالة الحساب</small><b>${esc(c.st || '—')}</b></div></div>${orB(r)}
<h4>المستندات المطلوبة لخدمة ${esc(r.sv)} (${req.filter((t) => have.includes(t)).length} من ${req.length})</h4><div class="mc">${req.map((t) => `<span class="pl ${have.includes(t) ? 'ok' : 'wr'}">${have.includes(t) ? '✓' : '✕'} ${t}</span>`).join('') || '<span class="em">لا توجد مستندات مطلوبة لهذه الخدمة</span>'}</div>
<h4>المستندات والصور المرفوعة (${DC.length})</h4><div class="mg">${DC.map((x) => `<div class="mx"><b>${esc(x.ty)}</b>${img(x.img, x.ty)}<div>${st('dc', x.st)}</div><div class="bar">${btn('dc', x)}<button class="bt o" onclick="vw('dc',${x.id})">فتح</button></div></div>`).join('') || '<div class="em">لم يرفع العميل أي مستند لهذا الطلب</div>'}</div>
<h4>الإيداعات المالية (${RM.length})</h4><div class="kv"><div><small>إجمالي الطلب</small><b>${M(r.tot)} ${esc(r.cur || '')}</b></div><div><small>مؤكَّد</small><b>${M(ok)}</b></div><div><small>بانتظار التأكيد</small><b>${M(wt)}</b></div><div><small>المتبقي</small><b>${M(Math.max(0, r.tot - ok))}</b></div></div><div class="mg" style="margin-top:12px">${RM.map((x) => `<div class="mx"><b>${M(x.amt)} — ${esc(x.ref)}</b>${img(x.img, 'سند')}<small>${esc(x.snd || '')} · ${esc(x.acc || '')} · ${fd(x.date)}</small><div>${st('rm', x.st)}</div><div class="bar">${btn('rm', x)}<button class="bt o" onclick="vw('rm',${x.id})">فتح</button></div></div>`).join('') || '<div class="em">لا توجد إيداعات لهذا الطلب</div>'}</div>` +
    orL(r)
  );
}
