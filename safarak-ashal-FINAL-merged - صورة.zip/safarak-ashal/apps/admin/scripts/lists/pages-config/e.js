/* سجل صفحات لوحة الإدارة (يُملأ بملف لكل صفحة في مجلدات account / messages / documents / screens / pages)
   يعرّف: E */
const E = {};
