/* قائمة افتراضية: X.OFR
   يعرّف: X.OFR */
X.OFR = { air: [], bus: [], visa: [], pass: [], cars: [] };
