/* قائمة افتراضية: X.OFFS
   يعرّف: X.OFFS */
X.OFFS = [];
