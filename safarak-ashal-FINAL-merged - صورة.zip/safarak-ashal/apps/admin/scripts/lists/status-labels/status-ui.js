/* تسميات حالات وأنواع الطلبات في لوحة الإدارة
   يعرّف: SA_STATUS_UI، SA_TYPE_UI */
/* تحميل بيانات الإدارة من الخادم — الجزء 2/2
   يعرّف: SA_STATUS_UI، SA_TYPE_UI */
const SA_STATUS_UI = {
  pending: 'قيد المراجعة',
  reviewing: 'قيد المراجعة',
  in_progress: 'قيد التنفيذ',
  completed: 'مكتمل',
  rejected: 'مرفوض',
  waiting_documents: 'بانتظار الوثائق',
  waiting_payment: 'بانتظار الدفع',
  cancelled: 'ملغي',
};
const SA_TYPE_UI = {
  air: 'طيران',
  bus: 'نقل دولي',
  visa: 'تأشيرات',
  pass: 'جوازات',
  cars: 'تأجير سيارات',
  priv: 'رحلات خاصة',
  local: 'رحلات محلية',
};
