/* معاينات SVG للمستندات — المتغيرات والتنفيذ عند التحميل
   يعرّف: svgU، SF، svgId، svgRc، vf */
const svgU = (x) => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(x),
  SF = 'font-family="Tajawal,Tahoma,sans-serif"';
const svgId = (n, no) =>
  svgU(
    `<svg xmlns="http://www.w3.org/2000/svg" width="320" height="200" viewBox="0 0 320 200"><rect width="320" height="200" rx="14" fill="#eef3fc" stroke="#c5d3f2" stroke-width="2"/><rect x="18" y="52" width="82" height="108" rx="10" fill="#d6e0f5"/><circle cx="59" cy="90" r="19" fill="#9fb4e6"/><rect x="34" y="118" width="50" height="28" rx="12" fill="#9fb4e6"/><text x="302" y="36" ${SF} font-size="16" font-weight="700" fill="#0f2a6b" text-anchor="end">بطاقة هوية (نموذج)</text><text x="302" y="92" ${SF} font-size="17" font-weight="700" fill="#10244f" text-anchor="end">${esc(n || '')}</text><text x="302" y="124" ${SF} font-size="14" fill="#6b7a99" text-anchor="end">${esc(no || '')}</text></svg>`,
  );
const svgRc = (am, rf) =>
  svgU(
    `<svg xmlns="http://www.w3.org/2000/svg" width="320" height="200" viewBox="0 0 320 200"><rect width="320" height="200" rx="14" fill="#fffaf0" stroke="#f1dca6" stroke-width="2"/><text x="302" y="36" ${SF} font-size="16" font-weight="700" fill="#8a5a06" text-anchor="end">سند حوالة (نموذج)</text><text x="302" y="92" ${SF} font-size="26" font-weight="800" fill="#10244f" text-anchor="end">${esc(String(am || 0))} ر.س</text><text x="302" y="128" ${SF} font-size="14" fill="#6b7a99" text-anchor="end">${esc(rf || '')}</text></svg>`,
  );
const vf = (f, v) =>
  f.t == 'r' && v
    ? `<a class="lk" onclick="vw('${f.o}',${v})">${fmt(f, v)}</a>`
    : f.t == 'i'
      ? v
        ? `<img class="bi${f.k == 'photo' ? ' p46' : ''}" src="${v}" onclick="zi(this.src)">`
        : `<span class="bi${f.k == 'photo' ? ' p46' : ''}" style="display:grid;place-items:center;color:var(--mu);font-weight:500">لم يُرفع</span>`
      : fmt(f, v);
