/* معاينات SVG للمستندات
   يعرّف: zi */
/* معاينات SVG للمستندات
   يعرّف: zi، svgU، svgId، svgRc، vf */
function zi(u) {
  om(
    `<div class="mh"><h3>عرض الصورة</h3><button class="bt s" onclick="cm()">✕</button></div><img src="${u}" style="width:100%;border-radius:12px">`,
  );
}
