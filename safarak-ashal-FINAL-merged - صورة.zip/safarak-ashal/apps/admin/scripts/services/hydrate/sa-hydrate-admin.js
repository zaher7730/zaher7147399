/* تحميل بيانات الإدارة من الخادم — الجزء 1/2
   يعرّف: SA_hydrateAdmin */
/* تحميل بيانات الإدارة من الخادم — الجزء 1/2
   يعرّف: SA_hydrateAdmin */
async function SA_hydrateAdmin(quiet) {
  if (!window.SA_API) return;
  const me = await window.SA_API.me();
  if (me.user.role !== 'admin') {
    location.href = '/apps/customer/?access=admin';
    return;
  }
  const [ur, br, sr, settingsResult, pointsResult, paymentResult] = await Promise.all([
    window.SA_API.adminUsers(),
    window.SA_API.bookings(),
    window.SA_API.request('/api/office/services'),
    window.SA_API.adminSettings(),
    window.SA_API.adminPoints(),
    window.SA_API.adminPaymentMethods(),
  ]);
  const users = ur.users || [];
  D.cu = users
    .filter((u) => u.role === 'customer')
    .map((u) => ({
      id: u.id,
      serverId: u.id,
      n: u.name,
      ph: u.phone,
      wa: u.phone,
      em: u.email || '',
      st: u.active ? 'نشط' : 'موقوف',
      nt: 1,
      cls: 'عادي',
      dreq: 'لا',
    }));
  D.of = users
    .filter((u) => u.role === 'office')
    .map((u) => ({
      id: u.id,
      serverId: u.id,
      n: u.office_name || u.name,
      ph: u.phone,
      wa: u.phone,
      email: u.email || '',
      st: u.active ? 'معتمد' : 'موقوف',
      badge: 'بدون شارة',
      rate: null,
      rc: null,
      svc: [],
      city: '',
      years: null,
    }));
  const applicationResult = await window.SA_API.adminOfficeApplications();
  for (const a of applicationResult.applications || []) {
    const docs = a.documents || {};
    D.of.push({
      id: -Number(a.id),
      applicationId: Number(a.id),
      n: a.office_name,
      owner: a.owner_name,
      ph: a.phone,
      wa: a.phone,
      addr: a.address,
      cr: a.registration_number,
      lic: a.license_number,
      ownerId: a.owner_id_number,
      st: 'قيد المراجعة',
      badge: 'بدون شارة',
      rate: null,
      rc: null,
      svc: [],
      city: '',
      years: null,
      crImg: docs.crImg?.url || '',
      licImg: docs.licImg?.url || '',
      idImg: docs.idImg?.url || '',
      cover: docs.cover?.url || '',
      logo: docs.logo?.url || '',
    });
  }
  D.or = (br.bookings || []).map((b) => ({
    id: b.id,
    serverId: b.public_id,
    no: b.public_id,
    inv: b.public_id,
    cu: b.customer_id,
    of: b.office_id || 0,
    sv: SA_TYPE_UI[b.service_type] || b.service_type,
    title: b.title,
    pax: b.passenger_count,
    date: b.created_at,
    tot: Number(b.total_amount || 0),
    cur: b.currency || 'YER',
    com: null,
    prf: Number((b.details || {}).officeProfit || 0),
    pay:
      { pending: 'غير مدفوع', submitted: 'مدفوع جزئياً', confirmed: 'مدفوع', rejected: 'مرفوض', refunded: 'مسترد' }[b.payment_status] ||
      'غير مدفوع',
    st: SA_STATUS_UI[b.status] || 'قيد المراجعة',
    note: '',
    details: b.details || {},
    serverStatus: b.status,
  }));
  D.ofr = (sr.services || []).map((s) => {
    const details = s.details && typeof s.details === 'object' ? s.details : {};
    return {
      id: s.id,
      serverId: s.id,
      of: s.office_id,
      sv: SA_TYPE_UI[s.service_type] || s.service_type,
      title: s.title,
      st: s.active ? 'معتمد' : 'بانتظار الاعتماد',
      on: s.active ? 1 : 0,
      price: details.price,
      old: details.old,
      seats: details.seats,
      from: details.from,
      to: details.to,
      city: details.city,
      make: details.make,
      model: details.model,
      year: details.year,
      days: details.days,
      time: details.time,
      carrier: details.carrier,
      kind: details.kind,
      svc: details.svc,
      dur: details.dur,
      tier: details.tier,
      feat: details.feat,
      desc: details.desc,
      imageUrl: details.imageUrl || '',
      img: details.imageUrl || '',
      details: details,
    };
  });
  D.ap = (pointsResult.points || []).map((p) => ({
    id: p.id,
    serverId: p.id,
    n: p.name,
    city: p.city,
    addr: p.address,
    ph: p.phone || '',
    on: p.active ? 1 : 0,
  }));
  D.bk = (paymentResult.methods || []).map((m) => ({
    id: m.id,
    serverId: m.id,
    of: m.owner_id || 0,
    ty: m.type,
    n: m.name,
    no: m.account_no,
    ho: m.holder || '',
    cur: m.currency || 'YER',
    on: m.active ? 1 : 0,
  }));
  D.set = { ...(settingsResult.settings || {}) };
  D.integrations = (await window.SA_API.adminIntegrations().catch(() => ({ integrations: [] }))).integrations;
  await Promise.allSettled([SA_loadLive(), SA_loadDocs()]);
  if (!quiet && window.SA_RT) window.SA_RT.start();
  render();
}
