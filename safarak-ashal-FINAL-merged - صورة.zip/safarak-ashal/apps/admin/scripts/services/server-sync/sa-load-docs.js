/* محتوى المنصة (إعلانات، خدمات التطبيق، مدن، صفحات، فرز، سائقون، رحلات، فريق...) يُحفظ في الخادم كمستندات
   يعرّف: SA_loadDocs */
async function SA_loadDocs() {
  try {
    const r = await window.SA_API.adminDocs();
    const by = {};
    for (const d of r.docs || []) (by[d.collection] ||= []).push(d);
    SA_snap = {};
    for (const c of Object.keys(SA_PLAT)) {
      const list = (by[c] || []).map((d) => ({ ...d.data, id: d.data.id ?? (Number(d.id) || d.id) }));
      if (list.length || !Array.isArray(D[c]) || !D[c].length) D[c] = list.length ? list : D[c] || [];
      SA_snap[c] = {};
      for (const x of list) SA_snap[c][String(x.id)] = JSON.stringify(x);
    }
  } catch (e) {
    console.warn('تعذر تحميل محتوى المنصة:', e.message);
  }
}
