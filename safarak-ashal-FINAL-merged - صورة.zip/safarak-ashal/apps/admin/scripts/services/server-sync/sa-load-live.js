/* بيانات الإدارة الحية من جداول الخادم: التقييمات، الدعم، الحوالات، السجل، باقات المكاتب، التوثيق، الربط الخارجي
   يعرّف: SA_CHS_AR، SA_CHS_EN، SA_loadLive */
const SA_CHS_AR = { open: 'مفتوحة', reported: 'مُبلَّغ عنها', closed: 'مغلقة' };
const SA_CHS_EN = { 'مفتوحة': 'open', 'مُبلَّغ عنها': 'reported', 'مغلقة': 'closed' };
async function SA_loadLive() {
  const api = window.SA_API;
  const [rv, tk, pay, au, pk, pp, vf, cv] = await Promise.allSettled([
    api.adminReviews(),
    api.tickets(),
    api.adminPayments(),
    api.adminAudit({ limit: 150 }),
    api.adminPackages(),
    api.adminPackagePurchases(),
    api.adminOfficeVerifications(),
    api.adminConversations(),
  ]);
  /* المحادثات بين العملاء والمكاتب: قراءة حية للإدارة (الحالة قابلة للتعديل، ونص المحادثة للقراءة فقط) */
  if (cv.status === 'fulfilled')
    D.ch = cv.value.conversations.map((c) => ({
      id: c.id, serverId: c.id, cu: c.customerId, of: c.officeId, last: c.lastBody || '', st: SA_CHS_AR[c.status] || SA_CHS_AR.open,
      m: c.transcript.map((x) => (x.from === 'customer' ? 'العميل' : 'المكتب') + ': ' + (x.text || '📎 مرفق')).join('\n'),
      img1: c.images[0] ? '/api/files/' + c.images[0] + '?inline=1' : '', img2: c.images[1] ? '/api/files/' + c.images[1] + '?inline=1' : '', img3: c.images[2] ? '/api/files/' + c.images[2] + '?inline=1' : '',
    }));
  if (rv.status === 'fulfilled')
    D.rv = rv.value.reviews.map((r) => ({ id: r.id, serverId: r.id, cu: r.customer_id, of: r.office_id, rt: r.rating, tx: r.comment || '', st: r.status === 'hidden' ? 'مخفي' : 'ظاهر', reply: r.office_reply || '' }));
  if (tk.status === 'fulfilled')
    D.tk = tk.value.tickets.map((t) => ({
      id: t.id,
      serverId: t.id,
      cu: t.user_role === 'customer' ? t.user_id : 0,
      of: t.user_role === 'office' ? t.user_id : 0,
      or: SA_orderOf(t.booking_public_id),
      sb: t.subject,
      ty: t.kind === 'dispute' ? 'نزاع' : t.kind === 'data_deletion' ? 'طلب استرجاع' : 'استفسار',
      pr: t.priority === 'high' ? 'عالية' : 'عادية',
      st: SA_TKS[t.status] || 'مفتوحة',
      res: '',
      kind: t.kind,
    }));
  if (pay.status === 'fulfilled')
    D.rm = pay.value.payments.map((p) => ({
      id: p.id,
      serverId: p.id,
      or: SA_orderOf(p.booking_public_id),
      cu: p.customer_id,
      src: 'خدمة',
      amt: p.amount,
      acc: p.method_name || '',
      ref: p.reference || '',
      snd: p.sender || '',
      date: p.transferred_at || p.created_at,
      img: p.receipt_file_id ? '/api/files/' + p.receipt_file_id + '?inline=1' : '',
      st: { submitted: 'بانتظار التأكيد', confirmed: 'مؤكدة', rejected: 'مرفوضة' }[p.status] || 'بانتظار التأكيد',
    }));
  if (au.status === 'fulfilled')
    D.log = au.value.entries.map((e) => ({ u: e.actor_name || (/^(auth\.login_failed|office_application\.submit)$/.test(e.action) ? 'زائر' : 'النظام'), t: e.label + (e.entity ? ' · ' + e.entity : ''), d: e.detail || '', ts: SA_ts(e.created_at) }));
  const offs = D.of;
  const officeRef = (id) => (offs.some((o) => o.id === id) ? id : 0);
  if (pk.status === 'fulfilled')
    D.pk = pk.value.packages.map((p) => ({ id: p.id, serverId: p.id, n: p.title, sv: Object.keys(SA_TYPE_R).find((k) => SA_TYPE_R[k] === p.service_type) || p.service_type, qty: p.quantity, price: p.price, cur: p.currency, desc: p.description || '', on: p.active ? 1 : 0 }));
  if (pp.status === 'fulfilled')
    D.pp = pp.value.purchases.map((p) => ({ id: p.id, serverId: p.id, of: officeRef(p.office_id), n: p.package_title || 'كمية مخصصة', sv: Object.keys(SA_TYPE_R).find((k) => SA_TYPE_R[k] === p.service_type) || p.service_type, qty: p.quantity, tot: p.total_price, cur: p.currency, st: SA_PKS[p.status] || 'بانتظار المراجعة', note: p.note || '', custom: p.custom_request }));
  if (vf.status === 'fulfilled')
    D.ov = vf.value.verifications.map((v) => {
      const f = v.files || {},
        u = (k) => (f[k] ? '/api/files/' + f[k] + '?inline=1' : '');
      return { id: v.officeId, serverId: v.officeId, of: officeRef(v.officeId), lname: v.legalName, owner: v.ownerName, ownerId: v.ownerId || '', lic: v.licenseNo, cr: v.registrationNo, tax: v.taxNo, issuer: v.issuer, issued: v.issuedAt, expiry: v.expiresAt, licImg: u('licImg'), crImg: u('crImg'), idImg: u('idImg'), taxImg: u('taxImg'), st: SA_VFS[v.status] || 'بانتظار المراجعة', rej: v.note || '' };
    });
  D.of.forEach((o) => {
    const v = (D.ov || []).find((x) => x.id === o.id);
    if (v && v.st === 'موثّق') o.badge = o.badge === 'بدون شارة' ? 'موثّق' : o.badge;
  });
}
