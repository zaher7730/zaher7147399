/* بيانات الإدارة الحية من جداول الخادم: التقييمات، الدعم، الحوالات، السجل، باقات المكاتب، التوثيق، الربط الخارجي
   يعرّف: SA_pushLive */
/* يدفع تغيير سجل مرتبط بجدول في الخادم؛ يعيد true إن عالجه */
async function SA_pushLive(b, r) {
  const api = window.SA_API;
  if (b === 'rv') {
    await api.moderateReview(r.serverId, r.st === 'مخفي' ? 'hidden' : 'published');
    return true;
  }
  if (b === 'ch' && r.serverId) {
    await api.adminConversationUpdate(r.serverId, { status: SA_CHS_EN[r.st] || 'open' });
    return true;
  }
  if (b === 'tk') {
    if (r.res && r.res !== r._resSent) {
      await api.ticketMessage(r.serverId, { body: r.res });
      r._resSent = r.res;
    }
    await api.adminTicketUpdate(r.serverId, { status: SA_TKS_R[r.st] || 'open', priority: r.pr === 'عالية' ? 'high' : 'normal' });
    return true;
  }
  if (b === 'pk') {
    const p = { title: r.n, serviceType: SA_TYPE_R[r.sv] || r.sv, quantity: Number(r.qty), price: Number(r.price), currency: r.cur || 'YER', description: r.desc || '', active: !!r.on };
    if (r.serverId) await api.updateAdminPackage(r.serverId, p);
    else await api.createAdminPackage(p);
    return true;
  }
  if (b === 'pp') {
    await api.reviewPackagePurchase(r.serverId, { status: SA_PKS_R[r.st] || 'requested', totalPrice: Number(r.tot || 0), note: r.rej || r.note || '' });
    return true;
  }
  if (b === 'ov') {
    await api.reviewOfficeVerification(r.serverId, { status: SA_VFS_R[r.st] || 'pending', note: r.rej || '' });
    return true;
  }
  if ((b === 'cu' || b === 'of') && r.serverId) {
    const p = { active: !['موقوف', 'مرفوض', 'منفّذ'].includes(r.st) };
    if (r.n && r.ph) Object.assign(p, { name: r.n, phone: r.ph, email: r.email || r.em || '' }, b === 'of' ? { officeName: r.n } : {});
    await api.updateAdminUser(r.serverId, p);
    return true;
  }
  if (b === 'nf' && r.st === 'مُرسَل' && !r.sentAt) {
    const audience = { 'كل العملاء': 'customer', 'كل المكاتب': 'office', الجميع: 'all' }[r.aud] || 'all';
    const res = await api.adminBroadcast({ title: r.n, body: r.body || '', audience });
    r.sentAt = Date.now();
    r.recipients = res.recipients;
    return false; /* يُحفظ أيضاً كمستند */
  }
  return false;
}
