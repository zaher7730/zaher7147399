/* محتوى المنصة (إعلانات، خدمات التطبيق، مدن، صفحات، فرز، سائقون، رحلات، فريق...) يُحفظ في الخادم كمستندات
   يعرّف: SA_flushDocs */
async function SA_flushDocs() {
  if (!window.SA_API) return;
  if (SA_docBusy) {
    SA_docDirty = true;
    return;
  }
  SA_docBusy = true;
  try {
    for (const [c, pub] of Object.entries(SA_PLAT)) {
      const list = Array.isArray(D[c]) ? D[c] : [];
      const snap = (SA_snap[c] = SA_snap[c] || {});
      const seen = new Set();
      for (const rec of list) {
        const id = String(rec.id);
        seen.add(id);
        if (snap[id] === JSON.stringify(rec)) continue;
        await SA_offloadDoc(rec, c + id, !!pub);
        const json = JSON.stringify(rec);
        await window.SA_API.putAdminDoc(c, id, rec, !!pub);
        snap[id] = json;
      }
      for (const id of Object.keys(snap))
        if (!seen.has(id)) {
          await window.SA_API.deleteAdminDoc(c, id);
          delete snap[id];
        }
    }
  } catch (e) {
    toast(e.message || 'تعذر حفظ التغييرات في الخادم');
  } finally {
    SA_docBusy = false;
    if (SA_docDirty) {
      SA_docDirty = false;
      SA_scheduleDocSync();
    }
  }
}
