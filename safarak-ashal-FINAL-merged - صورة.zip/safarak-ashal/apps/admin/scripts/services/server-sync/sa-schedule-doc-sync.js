/* محتوى المنصة (إعلانات، خدمات التطبيق، مدن، صفحات، فرز، سائقون، رحلات، فريق...) يُحفظ في الخادم كمستندات
   يعرّف: SA_scheduleDocSync */
function SA_scheduleDocSync() {
  clearTimeout(SA_docTimer);
  SA_docTimer = setTimeout(SA_flushDocs, 600);
}
