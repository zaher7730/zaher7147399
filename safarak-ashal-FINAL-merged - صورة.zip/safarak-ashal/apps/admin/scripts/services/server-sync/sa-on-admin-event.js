/* بيانات الإدارة الحية من جداول الخادم: التقييمات، الدعم، الحوالات، السجل، باقات المكاتب، التوثيق، الربط الخارجي
   يعرّف: SA_onAdminEvent */
function SA_onAdminEvent() {
  clearTimeout(SA_onAdminEvent.t);
  SA_onAdminEvent.t = setTimeout(async () => {
    await SA_hydrateAdmin(true);
  }, 400);
}
