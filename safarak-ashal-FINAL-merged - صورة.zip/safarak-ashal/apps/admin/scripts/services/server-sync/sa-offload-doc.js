/* محتوى المنصة (إعلانات، خدمات التطبيق، مدن، صفحات، فرز، سائقون، رحلات، فريق...) يُحفظ في الخادم كمستندات
   يعرّف: SA_offloadDoc */
async function SA_offloadDoc(node, name, pub) {
  if (!node || typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    const v = node[k];
    if (typeof v === 'string' && SA_IMG.test(v)) node[k] = await SA_uploadAny(v, name + '_' + k, pub);
    else if (v && typeof v === 'object') await SA_offloadDoc(v, name + '_' + k, pub);
  }
}
