/* بيانات الإدارة الحية من جداول الخادم: التقييمات، الدعم، الحوالات، السجل، باقات المكاتب، التوثيق، الربط الخارجي
   يعرّف: SA_integrationsPage */
function SA_integrationsPage() {
  const I = D.integrations || [];
  return (
    sh('الربط الخارجي', 'حالة الخدمات التي تحتاج مفاتيح من خارج المستودع. التعليمات الكاملة في docs/EXTERNAL_SERVICES_AR.md') +
    `<div class="card">${tb(
      ['الخدمة', 'الحالة', 'ما المطلوب'],
      I.map((x) => `<tr><td><b>${esc(x.name || x.id)}</b></td><td><span class="pl ${x.ready ? 'ok' : 'wr'}">${x.ready ? 'مفعّلة' : 'غير مربوطة'}</span></td><td>${esc(x.purpose || '')}${x.ready || !(x.env || []).length ? '' : '<br><small dir="ltr">' + esc(x.env.join(' · ')) + '</small>'}</td></tr>`).join(''),
    )}</div>`
  );
}
