/* محتوى المنصة (إعلانات، خدمات التطبيق، مدن، صفحات، فرز، سائقون، رحلات، فريق...) يُحفظ في الخادم كمستندات
   يعرّف: SA_uploadAny */
async function SA_uploadAny(dataUrl, name, pub) {
  const k = (pub ? 'a' : 'p') + SA_sg(dataUrl);
  if (SA_up.has(k)) return SA_up.get(k);
  const mime = dataUrl.match(SA_IMG)[1].toLowerCase(),
    ext = { 'application/pdf': 'pdf', 'image/png': 'png', 'image/webp': 'webp' }[mime] || 'jpg';
  let url;
  if (pub && mime.startsWith('image/')) url = (await window.SA_API.uploadOfferAsset({ filename: name + '.' + ext, mimeType: mime, base64: dataUrl })).asset.url;
  else url = '/api/files/' + (await window.SA_API.uploadFile({ filename: name + '.' + ext, mimeType: mime, base64: dataUrl })).file.id + (mime.startsWith('image/') ? '?inline=1' : '');
  SA_up.set(k, url);
  return url;
}
