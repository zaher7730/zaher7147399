/* بيانات الإدارة الحية من جداول الخادم: التقييمات، الدعم، الحوالات، السجل، باقات المكاتب، التوثيق، الربط الخارجي — المتغيرات والتنفيذ عند التحميل
   يعرّف: SA_ts، SA_TKS، SA_TKS_R، SA_PKS، SA_PKS_R، SA_VFS، SA_VFS_R، SA_TYPE_R، SA_orderOf */
/* بيانات الإدارة الحية من جداول الخادم: التقييمات، الدعم، الحوالات، السجل، باقات المكاتب، التوثيق، الربط الخارجي
   يعرّف: SA_loadLive، SA_pushLive، SA_onAdminEvent، SA_integrationsPage */
const SA_ts = (v) => {
  if (!v) return Date.now();
  const s = String(v),
    t = Date.parse(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : s.replace(' ', 'T') + 'Z');
  return Number.isFinite(t) ? t : Date.now();
};
const SA_TKS = { open: 'مفتوحة', pending: 'قيد المعالجة', resolved: 'محلولة', closed: 'مغلقة' },
  SA_TKS_R = Object.fromEntries(Object.entries(SA_TKS).map(([k, v]) => [v, k])),
  SA_PKS = { requested: 'بانتظار المراجعة', approved: 'تمت الموافقة', paid: 'تم الدفع', fulfilled: 'تم تفعيل الرصيد', rejected: 'مرفوض' },
  SA_PKS_R = Object.fromEntries(Object.entries(SA_PKS).map(([k, v]) => [v, k])),
  SA_VFS = { pending: 'بانتظار المراجعة', approved: 'موثّق', rejected: 'مرفوض' },
  SA_VFS_R = Object.fromEntries(Object.entries(SA_VFS).map(([k, v]) => [v, k])),
  SA_TYPE_R = { طيران: 'air', 'نقل دولي': 'bus', 'رحلات محلية': 'local', تأشيرات: 'visa', جوازات: 'pass', 'تأجير سيارات': 'cars', 'رحلات خاصة': 'priv' };
const SA_orderOf = (pid) => (D.or.find((o) => o.serverId === pid) || {}).id || 0;
if (window.SA_RT) {
  window.SA_RT.on('notification', (n) => {
    if (/ticket|package|verification|booking|payment|review/.test(n.kind)) {
      toast(n.title + (n.body ? ' — ' + n.body : ''));
      SA_onAdminEvent();
    }
  });
  window.SA_RT.on('booking', () => SA_onAdminEvent());
}
