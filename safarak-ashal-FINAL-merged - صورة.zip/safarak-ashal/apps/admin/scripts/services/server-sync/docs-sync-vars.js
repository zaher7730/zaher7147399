/* محتوى المنصة (إعلانات، خدمات التطبيق، مدن، صفحات، فرز، سائقون، رحلات، فريق...) يُحفظ في الخادم كمستندات — المتغيرات والتنفيذ عند التحميل
   يعرّف: SA_PLAT، SA_IMG، SA_snap، SA_docTimer، SA_docBusy، SA_docDirty، SA_up، SA_sg */
/* محتوى المنصة (إعلانات، خدمات التطبيق، مدن، صفحات، فرز، سائقون، رحلات، فريق...) يُحفظ في الخادم كمستندات
   المجموعات العامة (is_public) يقرؤها تطبيق العميل؛ الباقي خاص بالإدارة. الصور تُرفع كملفات ولا تُخزَّن داخل JSON.
   يعرّف: SA_PLAT، SA_loadDocs، SA_scheduleDocSync، SA_flushDocs */
const SA_PLAT = { ads: 1, sv: 1, ct: 1, pg: 1, ls: 1, rq: 1, nf: 0, cm: 0, tm: 0, fz: 0, dv: 0, lt: 0, ltp: 0, am: 0, dc: 0, fin: 0, ch: 0 };
const SA_IMG = /^data:(image\/(?:jpeg|png|webp)|application\/pdf);base64,/i;
let SA_snap = {},
  SA_docTimer = null,
  SA_docBusy = false,
  SA_docDirty = false;
const SA_up = new Map();
const SA_sg = (d) => d.length + ':' + d.slice(40, 100) + d.slice(-60);
