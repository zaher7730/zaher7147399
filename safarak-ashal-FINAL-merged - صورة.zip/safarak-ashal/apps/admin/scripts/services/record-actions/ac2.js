/* إجراءات السجلات — الجزء 1/2
   يعرّف: ac2 */
function ac2(b, id, i) {
  const a = E[b].ac[i],
    r = D[b].find((x) => x.id == id);
  r[a[1]] = a[2];
  r.rej = $('#rs').value;
  const ro = b == 'or' ? r : r.or && D.or && D.or.find((x) => x.id == r.or);
  if (ro) rl(ro, a[0] + (b != 'or' ? ' (' + E[b].t + ')' : '') + (r.rej ? ' — ' + r.rej : ''));
  lg(`${a[0]}: ${lab(b, id)}`);
  SA_pushAdminRecord(b, r)
    .then(() => {
      cm();
      render();
    })
    .catch((e) => toast(e.message || 'تعذر حفظ التغيير على الخادم'));
}
