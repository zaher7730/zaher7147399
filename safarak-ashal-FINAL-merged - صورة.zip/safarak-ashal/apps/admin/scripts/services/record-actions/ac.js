/* إجراءات السجلات — الجزء 1/2
   يعرّف: ac */
async function ac(b, id, i) {
  const a = E[b].ac[i],
    r = D[b].find((x) => x.id == id);
  if (b === 'of' && r && r.applicationId && window.SA_API) {
    const status = String(a[0]).includes('اعتماد') ? 'approved' : String(a[0]).includes('رفض') ? 'rejected' : '';
    if (!status) return toast('هذا طلب انضمام؛ اختر اعتماد المكتب أو رفض الطلب');
    const note = status === 'rejected' ? prompt('سبب رفض الطلب (اختياري)') || '' : '';
    try {
      await window.SA_API.reviewOfficeApplication(r.applicationId, { status, note });
      await SA_hydrateAdmin();
      cm();
      toast(status === 'approved' ? 'تم اعتماد المكتب؛ يمكنه الدخول برقم الهاتف ورمز واتساب' : 'تم رفض طلب المكتب');
    } catch (e) {
      toast(e.message || 'تعذرت مراجعة طلب المكتب');
    }
    return;
  }
  if (a[5] == 'r') {
    om(
      `<div class="mh"><h3>${a[0]}</h3></div><label>السبب (يظهر للمكتب)</label><textarea id="rs" rows="3"></textarea><p style="margin-top:12px"><button class="bt" onclick="ac2('${b}',${id},${i})">تأكيد</button> <button class="bt o" onclick="cm()">إلغاء</button></p>`,
    );
    return;
  }
  if (b == 'dv' && a[2] == 'موثّق' && !(r.idi && r.lici && r.regi)) {
    toast('ارفع صورة الهوية والرخصة والاستمارة أولاً قبل التوثيق');
    return;
  }
  if (b === 'ofr') {
    if (String(a[0]).includes('اعتماد')) {
      r.st = 'معتمد';
      r.on = 1;
    } else if (String(a[0]).includes('رفض')) {
      r.st = 'مرفوض';
      r.on = 0;
    } else r[a[1]] = a[2];
  } else r[a[1]] = a[2];
  const lb =
    b == 'rm' && r.lt && a[2] == 'مؤكدة' ? (D.lt.find((x) => x.id == r.lt) || { bk: [] }).bk.find((p) => p.s == r.seat && p.cu == r.cu) : 0;
  if (lb) lb.pay = 'مدفوع';
  if (b == 'cu' && a[2] == 'منفّذ') {
    Object.assign(r, { n: 'عميل محذوف', ph: '', wa: '', em: '', dob: '', idn: '', photo: '', idimg: '', ppimg: '', st: 'موقوف' });
  }
  const ro = b == 'or' ? r : r.or && D.or && D.or.find((x) => x.id == r.or);
  if (ro) rl(ro, a[0] + (b != 'or' ? ' (' + E[b].t + ')' : ''));
  lg(`${a[0]}: ${lab(b, id)}`);
  try {
    await SA_pushAdminRecord(b, r);
  } catch (e) {
    toast(e.message || 'تعذر حفظ التغيير على الخادم');
    return;
  }
  if (b === 'or' || b === 'ofr') {
    await SA_hydrateAdmin();
    cm();
    return;
  }
  cm();
  render();
}
