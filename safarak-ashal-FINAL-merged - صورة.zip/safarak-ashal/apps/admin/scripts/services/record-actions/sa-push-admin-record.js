/* إجراءات السجلات — الجزء 1/2
   يعرّف: SA_pushAdminRecord */
/* إجراءات السجلات — الجزء 1/2
   يعرّف: SA_pushAdminRecord، ac، ac2 */
async function SA_pushAdminRecord(b, r) {
  if (!window.SA_API) return;
  const statusMap = {
    'قيد المراجعة': 'reviewing',
    'قيد التنفيذ': 'in_progress',
    مكتمل: 'completed',
    مرفوض: 'rejected',
    'بانتظار الوثائق': 'waiting_documents',
    'بانتظار الدفع': 'waiting_payment',
    ملغي: 'cancelled',
  };
  if (await SA_pushLive(b, r)) return;
  if (b === 'or' && r.serverId) {
    const status = statusMap[r.st];
    if (status) await window.SA_API.updateBookingStatus(r.serverId, { status, note: String(r.note || '') });
    r.serverStatus = status || r.serverStatus;
  }
  if (b === 'ofr' && r.id) {
    const details = { ...(r.details || {}) };
    for (const [key, value] of Object.entries(r)) {
      if (['id', 'serverId', 'of', 'sv', 'title', 'st', 'on', 'img', 'imageUrl', 'details'].includes(key)) continue;
      if (value !== undefined) details[key] = value;
    }
    if (r.imageUrl) details.imageUrl = r.imageUrl;
    await window.SA_API.updateAdminService(r.id, { title: r.title, details, active: !!r.on && r.st === 'معتمد' });
  }
}
