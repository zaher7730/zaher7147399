/* إجراءات السجلات — الجزء 2/2
   يعرّف: dl */
/* إجراءات السجلات — الجزء 2/2
   يعرّف: dl */
async function dl(b, id) {
  const e = $('#dl');
  if (e.textContent != 'تأكيد الحذف') {
    e.textContent = 'تأكيد الحذف';
    return;
  }
  if (b === 'ap' && window.SA_API) {
    try {
      await window.SA_API.deleteAdminPoint(id);
      await SA_hydrateAdmin();
      lg('حذف: ' + E[b].t);
      S.rc = (S.hs || []).pop() || null;
      cm();
      return;
    } catch (err) {
      toast(err.message || 'تعذر حذف نقطة الأمانات');
      return;
    }
  }
  if (b === 'bk' && window.SA_API) {
    try {
      await window.SA_API.deleteAdminPaymentMethod(id);
      await SA_hydrateAdmin();
      lg('حذف: ' + E[b].t);
      S.rc = (S.hs || []).pop() || null;
      cm();
      return;
    } catch (err) {
      toast(err.message || 'تعذر حذف وسيلة الدفع');
      return;
    }
  }
  if (b === 'pk' && window.SA_API) {
    try {
      await window.SA_API.deleteAdminPackage(id);
      await SA_hydrateAdmin(true);
      cm();
      return;
    } catch (err) {
      return toast(err.message || 'تعذر حذف الباقة');
    }
  }
  D[b] = D[b].filter((x) => x.id != id);
  lg('حذف: ' + E[b].t);
  S.rc = (S.hs || []).pop() || null;
  cm();
  render();
}
