/* إقلاع جلسة المدير: تحميل البيانات من الخادم أو التحويل لصفحة الدخول (يقرر وضع المعاينة)
   يعرّف: (تنفيذ عند التحميل) */
if (window.SAFARAK_PREVIEW_MODE) {
  topUp();
  render();
} else if (window.SA_API) {
  SA_hydrateAdmin().catch((e) => {
    console.warn('Admin data load failed:', e.message);
    location.href = '/apps/customer/?access=admin';
  });
} else {
  topUp();
  render();
}
