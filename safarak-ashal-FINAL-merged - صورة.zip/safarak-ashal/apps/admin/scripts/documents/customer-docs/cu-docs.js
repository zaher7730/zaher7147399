/* مستندات العملاء — الجزء 2/2
   يعرّف: cuDocs */
/* مستندات العملاء — الجزء 2/2
   يعرّف: cuDocs */
function cuDocs(id) {
  const c = D.cu.find((x) => x.id == id) || {},
    T = D.lt.filter((t) => t.bk.some((p) => p.cu == id)).sort((x, y) => Math.abs(dts(x) - Date.now()) - Math.abs(dts(y) - Date.now()))[0],
    pb = T ? T.bk.find((p) => p.cu == id) : null,
    a = (pb && pb.att) || {},
    dc = D.dc.find((x) => x.cu == id && x.img && (x.ty == 'هوية وطنية' || x.ty == 'جواز سفر')) || {},
    rm = D.rm.filter((r) => r.cu == id).sort((x, y) => ((y.date || '') > (x.date || '') ? 1 : -1))[0] || {},
    am = rm.amt || (T ? T.price : 0),
    ii = a['هوية'] || a['جواز سفر'] || dc.img,
    ri = a['سند حوالة'] || rm.img;
  return `<h4>مرفقات العميل</h4><div class="ag"><div class="at">صورة البطاقة<img src="${ii || svgId(c.n, c.idn)}">${ii ? '' : '<small>لم يرفع العميل صورة بعد</small>'}</div><div class="at">صورة سند الحوالة<img src="${ri || svgRc(am, rm.ref)}">${ri ? '' : '<small>لم يرفع العميل السند بعد</small>'}</div></div><h4>تفاصيل الحوالة</h4><div class="kv"><div><small>المبلغ</small><b>${(+am || 0).toLocaleString('en')} ر.س</b></div><div><small>رقم الحوالة</small><b>${esc(rm.ref || '—')}</b></div><div><small>اسم المحوّل</small><b>${esc(rm.snd || '—')}</b></div><div><small>الحساب المستلِم</small><b>${esc(rm.acc || '—')}</b></div><div><small>تاريخ التحويل</small><b>${fd(rm.date)}</b></div><div><small>حالة الحوالة</small><b>${esc(rm.st || '—')}</b></div></div>`;
}
