/* مستندات العملاء — الجزء 1/2
   يعرّف: cuUp */
/* مستندات العملاء — الجزء 1/2
   يعرّف: cuUp، cuBk */
function cuUp(id) {
  const U = D.dc.filter((x) => x.cu == id && x.img);
  return `<h4>المستندات والصور التي رفعها العميل (${U.length})</h4><div class="mg">${U.map((x) => `<div class="mx"><b>${esc(x.ty)}</b><img class="bi${x.ty == 'صورة شخصية' ? ' p46' : ''}" src="${x.img}" onclick="zi(this.src)" alt=""><small>${x.or ? esc(lab('or', x.or)) : ''}</small></div>`).join('') || '<div class="em">لم يرفع العميل مستندات بعد</div>'}</div>`;
}
