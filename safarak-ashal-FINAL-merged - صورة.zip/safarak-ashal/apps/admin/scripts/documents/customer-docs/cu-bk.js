/* مستندات العملاء — الجزء 1/2
   يعرّف: cuBk */
function cuBk(id) {
  const T =
    (S.t && D.lt.find((x) => x.id == S.t && x.bk.some((p) => p.cu == id))) ||
    D.lt.filter((t) => t.bk.some((p) => p.cu == id)).sort((x, y) => Math.abs(dts(x) - Date.now()) - Math.abs(dts(y) - Date.now()))[0];
  if (!T) return '<h4>تفاصيل الحجز</h4><div class="em">لا توجد رحلة محلية لهذا العميل</div>';
  const P = T.bk.filter((p) => p.cu == id),
    dr = D.dv.find((x) => x.id == T.dv) || {},
    fz = D.fz.find((x) => x.id == T.fz) || {},
    K = (a) => `<div class="kv">${a.map((x) => `<div><small>${x[0]}</small><b>${x[1]}</b></div>`).join('')}</div>`;
  return (
    `<h4>تفاصيل الحجز · رحلة ${T.no}</h4>` +
    K([
      ['المقعد المختار', P.map((p) => p.s).join('، ')],
      [
        'فئة المقعد',
        P.map((p) => {
          const x = (p.s - 1) / T.seats;
          return x < 0.15 ? 'المقعد الأمامي بجوار السائق' : x < 0.5 ? 'جانب النافذة' : x < 0.8 ? 'مقاعد وسط' : 'الصف الخلفي';
        }).join('، '),
      ],
      ['رقم الرحلة', T.no],
      ['المسار', T.from + ' ← ' + T.to],
      ['الفرزة', esc(fz.n || '—')],
      ['الموعد', fd(T.date) + ' · ' + tf(T.time)],
      ['حالة الرحلة', lp(T)],
      ['السائق', esc(dr.n || '—')],
      ['جوال السائق', dr.ph || '—'],
      ['المركبة', esc(T.vh || '—') + (T.pl ? ' · ' + T.pl : '')],
      ['سعر المقعد', T.price + ' ر.س'],
      ['إجمالي الحجز', P.length * T.price + ' ر.س'],
      ['الدفع', [...new Set(P.map((p) => p.pay))].join('، ')],
    ]) +
    `<div class="seats" style="margin-top:12px">${Array.from({ length: T.seats }, (_, i) => {
      const s = i + 1,
        m = P.some((p) => p.s == s),
        oc = T.bk.some((p) => p.s == s);
      return `<div class="seat ${m ? 't sel' : ''}" ${!m && oc ? 'style="background:#eef2f8;color:var(--mu)"' : ''}>${s}</div>`;
    }).join(
      '',
    )}</div><p style="margin-top:8px;font-size:12px;color:var(--mu)">المقعد المحاط بالذهبي هو اختيار العميل، والرمادي مقاعد محجوزة لغيره</p>`
  );
}
