/* الحالة D والحفظ والترحيل — الجزء 2/3
   يعرّف: mig */
/* الحالة D والحفظ والترحيل — الجزء 2/3
   يعرّف: mig، tf، grp، D */
function mig() {
  Object.assign(DREQ, {
    'برنت بصمة': ['جواز سفر', 'صورة شخصية'],
    'الموافقات الأمنية': ['جواز سفر', 'هوية وطنية'],
    'إرسال جواز عبر الأمانات': ['جواز سفر', 'هوية وطنية'],
  });
  const nx = (a) => Math.max(0, ...a.map((x) => x.id)) + 1;
  D.rq = D.rq || [];
  SVO.forEach((n) => {
    if (!D.rq.some((x) => x.sv == n)) D.rq.push({ id: nx(D.rq), sv: n, req: DREQ[n] || [] });
  });
  D.dv.forEach((d) => {
    d.vf = d.vf || 'بانتظار التوثيق';
  });
  const CS = {
      bus: ['عدن', 'جدة', 'صنعاء', 'الرياض', 'المكلا', 'تعز', 'سيئون', 'أبها', 'مكة المكرمة'],
      local: ['عدن', 'المكلا', 'تعز', 'سيئون', 'شبوة', 'صنعاء', 'إب', 'الحديدة', 'مأرب'],
      air: ['عدن', 'جدة', 'صنعاء', 'الرياض', 'سيئون', 'القاهرة', 'عمّان', 'أبها'],
      priv: ['عدن', 'صلالة', 'مسقط', 'المكلا', 'سيئون', 'صنعاء', 'جدة', 'أبها', 'الرياض'],
      privd: [
        'عدن',
        'صنعاء',
        'تعز',
        'إب',
        'الحديدة',
        'المكلا',
        'سيئون',
        'شبوة',
        'مأرب',
        'لحج',
        'أبين',
        'الضالع',
        'البيضاء',
        'ذمار',
        'عمران',
        'حجة',
        'صعدة',
        'المحويت',
        'ريمة',
        'الجوف',
        'المهرة',
      ],
    },
    SK = { bus: 'نقل دولي', local: 'رحلات محلية', air: 'طيران', priv: 'رحلات خاصة (انطلاق)', privd: 'رحلات خاصة (وجهة)' },
    EX = ['القاهرة', 'عمّان', 'صلالة', 'مسقط'];
  Object.values(CS)
    .flat()
    .forEach((n) => {
      if (!D.ct.some((c) => c.n == n)) D.ct.push({ id: nx(D.ct), n, ty: EX.includes(n) ? 'خارجية' : 'داخلية', on: 1 });
    });
  D.ct.forEach((c) => {
    if (!c.svs)
      c.svs = Object.keys(CS)
        .filter((k) => CS[k].includes(c.n))
        .map((k) => SK[k]);
  });
  D.rm.forEach((r) => {
    r.src = r.src || 'خدمة';
  });
  D.cu.forEach((c) => {
    c.vf = c.vf || (c.idn && c.idimg ? 'موثّق' : 'غير موثّق');
    c.idt = c.idt || 'هوية';
    c.dreq = c.dreq || 'لا';
    if (c.nt == null) c.nt = 1;
  });
  [
    ['pmM', 1],
    ['pmMc', 0],
    ['pmVisa', 0],
    ['sdFee', 0],
  ].forEach(([k, v]) => {
    if (D.set[k] == null) D.set[k] = v;
  });
  D.or.forEach((o) => {
    const c = D.cu.find((x) => x.id == o.cu) || {};
    o.inv = o.inv || o.no.replace('RHL', 'INV');
    if (o.prf == null) o.prf = o.tot - (o.com || 0);
    o.pm = o.pm || 'تحويل يدوي';
    o.lg = o.lg || [{ t: 'إنشاء الطلب', d: new Date(o.date || Date.now()).toISOString() }];
    if (!o.fd) o.fd = 'الاسم: ' + (c.n || '') + '\nالجوال: ' + (c.ph || '') + '\nرقم الهوية أو الجواز: ' + (c.idn || '');
  });

  D.ls = D.ls || [];
  D.ltp = D.ltp || [];
}
