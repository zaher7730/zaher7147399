/* الحالة D والحفظ والترحيل — الجزء 1/3
   يعرّف: fmt */
function fmt(f, v) {
  if (f.t == 's') {
    const o = OPT(f.o).find((x) => x.v == v);
    return o && o.c ? `<span class="pl ${PC[o.c]}">${esc(v)}</span>` : v ? esc(v) : '—';
  }
  if (f.t == 'r') return v ? lab(f.o, v) : '—';
  if (f.t == 'c') return v ? '✓' : '—';
  if (f.t == 'i') return v ? `<img class="th${f.k == 'photo' ? ' t46' : ''}" src="${v}">` : '—';
  if (f.t == 'n') return v || v === 0 ? (+v).toLocaleString('en') : '—';
  if (f.t == 'm') return esc((v || []).join('، ')) || '—';
  if (f.t == 'd') return fd(v);
  return v ? esc(String(v).slice(0, 60)) : '—';
}
