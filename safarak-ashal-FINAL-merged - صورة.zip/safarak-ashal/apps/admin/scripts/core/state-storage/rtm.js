/* الحالة D والحفظ والترحيل — الجزء 1/3
   يعرّف: rtm */
/* الحالة D والحفظ والترحيل — الجزء 1/3
   يعرّف: rtm، seed، toast، lg، fmt */
function rtm(t) {
  if (t.st != 'في الانتظار')
    return t.st == 'غادرت' ? 'غادرت ' + (t.dep ? tf(new Date(t.dep).toTimeString().slice(0, 5)) : tf(t.time)) : t.st;
  const m = Math.round((dts(t) - Date.now()) / 6e4);
  return m <= 0 ? 'حان موعدها' : m < 60 ? 'بعد ' + m + ' دقيقة' : 'بعد ' + Math.round(m / 60) + ' ساعات';
}
