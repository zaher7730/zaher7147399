/* الحالة D والحفظ والترحيل — الجزء 1/3
   يعرّف: lg */
function lg(t) {
  D.log.unshift({ u: 'المدير العام', t, ts: Date.now() });
  D.log = D.log.slice(0, 120);
  sv();
}
