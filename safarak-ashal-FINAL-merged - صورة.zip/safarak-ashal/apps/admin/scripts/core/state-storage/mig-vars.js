/* الحالة D والحفظ والترحيل — الجزء 2/3 — المتغيرات والتنفيذ عند التحميل
   يعرّف: tf، dts، AC، TS، VC، grp، D */
const tf = (t) => {
    if (!t) return '—';
    const [h, m] = t.split(':');
    return (+h % 12 || 12) + ':' + m + (+h < 12 ? ' ص' : ' م');
  },
  dts = (t) => new Date(t.date + 'T' + t.time).getTime(),
  AC = ['في الانتظار', 'قيد التحميل', 'ممتلئة'],
  TS = 'في الانتظار:y,قيد التحميل:b,ممتلئة:b,غادرت:g,ملغاة:r',
  VC = { 'هايس 14 راكب': 14, 'فان 8 ركاب': 8, 'سيارة صالون': 4, 'باص كبير 28 راكب': 28 };
const grp = (t) => D.lt.filter((x) => x.fz == t.fz && x.from == t.from && x.to == t.to && x.date == t.date).sort((a, b) => a.q - b.q);
/* لا تخزين محلي: البيانات من الخادم بعد تسجيل دخول المدير (SA_hydrateAdmin) */
let D = seed();
D.pk = D.pk || [];
D.pp = D.pp || [];
D.ov = D.ov || [];
mig();
