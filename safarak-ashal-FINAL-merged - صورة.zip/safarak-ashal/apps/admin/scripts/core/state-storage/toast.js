/* الحالة D والحفظ والترحيل — الجزء 1/3
   يعرّف: toast */
function toast(t) {
  const e = $('#to');
  e.textContent = t;
  e.style.display = 'block';
  clearTimeout(toast.t);
  toast.t = setTimeout(() => (e.style.display = 'none'), 2200);
}
