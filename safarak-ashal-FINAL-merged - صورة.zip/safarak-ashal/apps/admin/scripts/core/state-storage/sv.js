/* الحالة D والحفظ والترحيل — الجزء 3/3
   يعرّف: sv، lab، S، cnt */
const sv = () => {
    if (window.SA_API) SA_scheduleDocSync();
  },
  B = (k) => E[k].a || k,
  esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;'),
  fd = (t) => (t ? new Date(t).toLocaleDateString('ar-u-nu-latn', { day: 'numeric', month: 'short', year: 'numeric' }) : '—');
const lab = (k, id) => {
    const b = B(k),
      r = (D[b] || []).find((x) => x.id == id);
    return r ? esc(r[E[b].L || 'n'] || r.n || r.id) : '—';
  },
  fl = (k) => E[B(k)].F.filter((f) => f.k);
let S = { p: 'home', fl: '', q: '', f: { tab: 'up', d: '', from: '', to: '', fz: 0 }, t: null, te: null, seat: 0 },
  TMP = {},
  AT = null;
const cnt = (k) => {
    const e = E[k];
    if (!D[B(k)]) return 0;
    return D[B(k)].filter((r) => !e.flt || Object.entries(e.flt).every(([a, b]) => r[a] == b)).length;
  },
  pend = {
    ofj: () => cnt('ofj'),
    rl: () => D.rm.filter((r) => r.src == 'رحلة محلية' && r.st == 'بانتظار التأكيد').length,
    tk: () => D.tk.filter((r) => r.st == 'مفتوحة').length,
    ch: () => D.ch.filter((r) => r.st == 'مُبلَّغ عنها').length,
    dv: () => D.dv.filter((r) => r.vf == 'بانتظار التوثيق').length,
    cud: () => D.cu.filter((r) => r.dreq == 'مطلوب').length,
    pp: () => (D.pp || []).filter((r) => r.st == 'بانتظار المراجعة').length,
    ov: () => (D.ov || []).filter((r) => r.st == 'بانتظار المراجعة').length,
  };
