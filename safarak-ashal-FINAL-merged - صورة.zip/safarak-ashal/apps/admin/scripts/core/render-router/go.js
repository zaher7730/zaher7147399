/* العرض والتنقل
   يعرّف: go */
function go(k) {
  S.rc = null;
  S.fm = null;
  S.hs = [];
  S.p = k;
  S.fl = '';
  S.q = '';
  S.t = null;
  S.te = null;
  S.seat = 0;
  if (innerWidth <= 900) $('#sb').classList.remove('open');
  render();
}
