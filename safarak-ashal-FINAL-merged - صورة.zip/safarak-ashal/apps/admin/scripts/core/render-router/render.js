/* العرض والتنقل
   يعرّف: render */
function render() {
  clearInterval(AT);
  const tot = ALR.reduce((a, x) => a + pend[x[0]](), 0);
  $('#bn').textContent = tot;
  $('#sb').innerHTML =
    `<div class="lg"><i>✈</i><div><b>سفرك أسهل</b><small>لوحة الإدارة المركزية</small></div><button onclick="tg()" style="margin-inline-start:auto;color:#fff;font-size:20px">✕</button></div>` +
    GRP.map(
      (g) =>
        `<div class="gt">${g[0]}</div>` +
        g[1]
          .map((k) => {
            const n = k == 'home' ? 'الرئيسية' : E[k].t,
              ic = k == 'home' ? '▦' : E[k].ic,
              c = pend[k] ? pend[k]() : 0;
            return `<button class="ni ${S.p == k ? 'on' : ''}" onclick="go('${k}')"><span>${ic}</span>${n}${c ? `<em>${c}</em>` : ''}</button>`;
          })
          .join(''),
    ).join('');
  S.rc && !(D[B(S.rc[0])] || []).some((x) => x.id == S.rc[1]) && (S.rc = null);
  $('#tp .bk').style.display = S.p == 'home' && !S.rc && !S.fm ? 'none' : '';
  $('#pg').innerHTML = S.fm
    ? fpg()
    : S.rc
      ? rpg(S.rc[0], S.rc[1])
      : S.p == 'home'
        ? home()
        : E[S.p].custom
          ? CP[S.p]()
          : E[S.p].single
            ? setp()
            : list(S.p);
  if (S.p == 'ads') pv();
  $('#sq').value = S.q;
  if (S.q) flt(S.q);
  scrollTo(0, 0);
}
