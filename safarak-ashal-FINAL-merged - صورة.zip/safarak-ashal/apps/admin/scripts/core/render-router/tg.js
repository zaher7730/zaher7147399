/* العرض والتنقل
   يعرّف: tg */
function tg() {
  if (innerWidth <= 900) $('#sb').classList.toggle('open');
  else document.body.classList.toggle('sbh');
}
