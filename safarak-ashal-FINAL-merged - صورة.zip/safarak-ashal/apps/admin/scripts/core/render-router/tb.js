/* العرض والتنقل
   يعرّف: tb */
function tb(h, r) {
  return `<div class="tw"><table><thead><tr>${h.map((x) => `<th>${x}</th>`).join('')}</tr></thead><tbody>${r || `<tr><td colspan="${h.length}" class="em">لا توجد بيانات</td></tr>`}</tbody></table></div>`;
}
