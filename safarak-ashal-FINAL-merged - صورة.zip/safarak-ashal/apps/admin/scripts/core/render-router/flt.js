/* العرض والتنقل
   يعرّف: flt */
function flt(q) {
  S.q = q;
  document.querySelectorAll('tbody tr').forEach((r) => (r.style.display = r.textContent.includes(q) ? '' : 'none'));
}
