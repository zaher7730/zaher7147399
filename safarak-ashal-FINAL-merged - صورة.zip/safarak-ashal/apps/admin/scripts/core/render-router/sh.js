/* العرض والتنقل
   يعرّف: sh */
/* العرض والتنقل
   يعرّف: sh، tb، render، go، tg، flt */
function sh(t, d, b) {
  return `<div class="sh"><div><h1>${t}</h1><p>${d}</p></div>${b || ''}${S.p != 'home' && !(b || '').includes('bk()') ? '<button class="tb2" onclick="bk()">→ رجوع</button>' : ''}</div>`;
}
