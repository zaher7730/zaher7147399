// توثيق المكتب: لا يوثّق نفسه، الوثائق خاصة، والمدير وحده يعتمد.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, PNG, b64 } from './helpers.mjs';

let S, admin, office, customer;
test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000003', 'عميل');
});
test.after(() => S.stop());

test('إرسال طلب التوثيق ومراجعة المدير', async () => {
  const up = async (n) => (await S.request('/api/files', 'POST', { filename: n + '.png', mimeType: 'image/png', base64: b64(PNG) }, office.cookie)).data.file.id;
  const files = { licImg: await up('lic'), crImg: await up('cr') };
  const body = { legalName: 'شركة الاختبار للسفر', ownerName: 'مالك', ownerId: '01234567', licenseNo: 'L-1', registrationNo: 'R-1', files };
  assert.equal((await S.request('/api/office/verification', 'POST', body, customer.cookie)).status, 403);
  assert.equal((await S.request('/api/office/verification', 'POST', { ...body, files: { licImg: files.licImg } }, office.cookie)).status, 400);
  const other = (await S.request('/api/files', 'POST', { filename: 'x.png', mimeType: 'image/png', base64: b64(PNG) }, customer.cookie)).data.file.id;
  assert.equal((await S.request('/api/office/verification', 'POST', { ...body, files: { licImg: other, crImg: files.crImg } }, office.cookie)).status, 400, 'ملف غيرك مرفوض');
  const r = await S.request('/api/office/verification', 'POST', body, office.cookie);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal(r.data.verification.status, 'pending');
  assert.equal((await S.request(`/api/admin/office-verifications/${office.id}`, 'PATCH', { status: 'approved' }, office.cookie)).status, 403, 'المكتب لا يوثّق نفسه');
  assert.equal((await S.request('/api/admin/office-verifications', 'GET', undefined, customer.cookie)).status, 403);
  const list = await S.request('/api/admin/office-verifications', 'GET', undefined, admin);
  assert.equal(list.data.verifications[0].ownerId, '01234567');
  assert.equal((await fetch(S.base + '/api/files/' + files.licImg, { headers: { cookie: admin } })).status, 200, 'المدير يقرأ الوثيقة');
  assert.equal((await fetch(S.base + '/api/files/' + files.licImg, { headers: { cookie: customer.cookie } })).status, 403);
  assert.equal((await S.request(`/api/admin/office-verifications/${office.id}`, 'PATCH', { status: 'rejected' }, admin)).status, 400, 'الرفض يحتاج سبباً');
  assert.equal((await S.request(`/api/admin/office-verifications/${office.id}`, 'PATCH', { status: 'approved' }, admin)).status, 200);
  const pub = await S.request('/api/public/offices');
  assert.equal(pub.data.offices[0].profile.verified, true);
  const n = await S.request('/api/notifications', 'GET', undefined, office.cookie);
  assert.ok(n.data.notifications.some((x) => x.kind === 'verification'));
  // لا يمكن تعديل verified من ملف المكتب
  await S.request('/api/office/profile', 'PUT', { displayName: 'x', verified: false }, office.cookie);
  assert.equal((await S.request('/api/public/offices')).data.offices[0].profile.verified, true);
});
