// المحادثات، المفضلة، حفظ الحالة، الملف الشخصي، التذاكر، الأحداث اللحظية.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { startServer, PNG, b64, sleep } from './helpers.mjs';

let S, admin, office, customer, other;
test.before(async () => {
  S = await startServer({ STRIPE_WEBHOOK_SECRET: 'whsec_test', PAYMENT_PROVIDER: 'stripe' });
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000003', 'Test Customer');
  other = await S.otpLogin('customer', '770000005', 'Other Customer');
});
test.after(() => S.stop());

test('محادثة عميل ↔ مكتب مع مرفق وقراءة وإشعار', async () => {
  const conv = await S.request('/api/conversations', 'POST', { officeId: office.id }, customer.cookie);
  assert.equal(conv.status, 201, JSON.stringify(conv.data));
  const id = conv.data.conversation.id;
  const again = await S.request('/api/conversations', 'POST', { officeId: office.id }, customer.cookie);
  assert.equal(again.data.conversation.id, id, 'لا تتكرر المحادثة');
  assert.equal((await S.request(`/api/conversations/${id}/messages`, 'GET', undefined, other.cookie)).status, 403);
  assert.equal((await S.request(`/api/conversations/${id}/messages`, 'POST', { body: '' }, customer.cookie)).status, 400);
  const img = await S.request('/api/files', 'POST', { filename: 'p.png', mimeType: 'image/png', base64: b64(PNG) }, customer.cookie);
  const sent = await S.request(`/api/conversations/${id}/messages`, 'POST', { body: 'السلام عليكم، هل المقعد متاح؟', fileId: img.data.file.id }, customer.cookie);
  assert.equal(sent.status, 201, JSON.stringify(sent.data));
  assert.equal(sent.data.message.kind, 'image');
  const list = await S.request('/api/conversations', 'GET', undefined, office.cookie);
  assert.equal(list.data.conversations[0].unread, 1);
  assert.equal((await S.request('/api/messages/unread-count', 'GET', undefined, office.cookie)).data.count, 1);
  assert.equal((await fetch(S.base + sent.data.message.fileUrl, { headers: { cookie: office.cookie } })).status, 200, 'المكتب يقرأ مرفق المحادثة');
  assert.equal((await fetch(S.base + sent.data.message.fileUrl, { headers: { cookie: other.cookie } })).status, 403);
  const msgs = await S.request(`/api/conversations/${id}/messages`, 'GET', undefined, office.cookie);
  assert.equal(msgs.data.messages.length, 1);
  await S.request(`/api/conversations/${id}/read`, 'POST', {}, office.cookie);
  assert.equal((await S.request('/api/messages/unread-count', 'GET', undefined, office.cookie)).data.count, 0);
  const reply = await S.request(`/api/conversations/${id}/messages`, 'POST', { body: 'نعم متاح' }, office.cookie);
  assert.equal(reply.status, 201);
  const n = await S.request('/api/notifications', 'GET', undefined, customer.cookie);
  assert.ok(n.data.notifications.some((x) => x.kind === 'message'));
  assert.equal((await S.request('/api/conversations', 'GET', undefined, admin)).status, 403);
});

test('الأحداث اللحظية SSE تصل للمستخدم المتصل', async () => {
  const ctrl = new AbortController();
  const res = await fetch(S.base + '/api/events', { headers: { cookie: customer.cookie }, signal: ctrl.signal });
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type'), /text\/event-stream/);
  const reader = res.body.getReader();
  let buf = '';
  const pump = (async () => { for (;;) { const { value, done } = await reader.read().catch(() => ({ done: true })); if (done) return; buf += new TextDecoder().decode(value); } })();
  await sleep(150);
  await S.request('/api/admin/broadcast', 'POST', { title: 'إعلان اختبار', body: 'مرحباً', audience: 'customer' }, admin);
  await sleep(300);
  ctrl.abort();
  await pump;
  assert.match(buf, /event: ready/);
  assert.match(buf, /event: notification/);
  assert.match(buf, /إعلان اختبار/);
  assert.equal((await S.request('/api/events')).status, 401);
});

test('المفضلة محفوظة على الخادم لكل مستخدم', async () => {
  assert.equal((await S.request('/api/favorites', 'PUT', { kind: 'office', id: office.id }, customer.cookie)).status, 200);
  assert.equal((await S.request('/api/favorites', 'PUT', { kind: 'service', id: office.serviceId }, customer.cookie)).data.favorites.length, 2);
  assert.equal((await S.request('/api/favorites', 'PUT', { kind: 'office', id: 99999 }, customer.cookie)).status, 400);
  assert.equal((await S.request('/api/favorites', 'GET', undefined, other.cookie)).data.favorites.length, 0);
  assert.equal((await S.request('/api/favorites', 'PUT', { kind: 'office', id: office.id, on: false }, customer.cookie)).data.favorites.length, 1);
});

test('حفظ حالة الواجهة بنسخ وكشف التعارض', async () => {
  const put1 = await S.request('/api/state/customer-ui', 'PUT', { value: { recent: ['عدن'], theme: 'light' } }, customer.cookie);
  assert.equal(put1.data.version, 1);
  const get = await S.request('/api/state/customer-ui', 'GET', undefined, customer.cookie);
  assert.deepEqual(get.data.value.recent, ['عدن']);
  assert.equal((await S.request('/api/state/customer-ui', 'PUT', { value: { a: 1 }, version: 1 }, customer.cookie)).data.version, 2);
  assert.equal((await S.request('/api/state/customer-ui', 'PUT', { value: { a: 2 }, version: 1 }, customer.cookie)).status, 409);
  assert.equal((await S.request('/api/state/customer-ui', 'GET', undefined, other.cookie)).data.value, null);
  assert.equal((await S.request('/api/state/bad%20name', 'GET', undefined, customer.cookie)).status, 400);
  assert.equal((await S.request('/api/state/x', 'PUT', { value: 'y'.repeat(1100000) }, customer.cookie)).status, 413);
});

test('الملف الشخصي والتصدير وطلب الحذف', async () => {
  assert.equal((await S.request('/api/me', 'PATCH', { name: 'اسم جديد', email: 'a@b.co' }, customer.cookie)).data.user.name, 'اسم جديد');
  assert.equal((await S.request('/api/me', 'PATCH', { email: 'bad' }, customer.cookie)).status, 400);
  const img = await S.request('/api/files', 'POST', { filename: 'id.png', mimeType: 'image/png', base64: b64(PNG) }, customer.cookie);
  const pr = await S.request('/api/me/profile', 'PUT', { idType: 'جواز', idNumber: 'A123', city: 'عدن', idFileId: img.data.file.id }, customer.cookie);
  assert.equal(pr.status, 200, JSON.stringify(pr.data));
  assert.equal((await S.request('/api/me/profile', 'PUT', { idFileId: img.data.file.id }, other.cookie)).status, 400);
  assert.equal((await S.request('/api/me', 'GET', undefined, customer.cookie)).data.profile.city, 'عدن');
  const ex = await S.request('/api/me/export', 'GET', undefined, customer.cookie);
  assert.equal(ex.status, 200);
  assert.equal(ex.data.user.name, 'اسم جديد');
  const del = await S.request('/api/me/delete-request', 'POST', {}, customer.cookie);
  assert.equal(del.status, 201);
  assert.equal((await S.request('/api/me/delete-request', 'POST', {}, customer.cookie)).status, 409);
});

test('ملف المكتب العام: بيانات وصورة وظهور للعملاء', async () => {
  const asset = await S.request('/api/office/assets', 'POST', { filename: 'logo.png', mimeType: 'image/png', base64: b64(PNG) }, office.cookie);
  assert.equal(asset.status, 201);
  const put = await S.request('/api/office/profile', 'PUT', { displayName: 'مكتب الاختبار للسفر', city: 'عدن', address: 'المنصورة', years: 7, whatsapp: '967770000002', licenseNo: 'L-1', about: 'نبذة', logoAssetId: asset.data.asset.id }, office.cookie);
  assert.equal(put.status, 200, JSON.stringify(put.data));
  const pub = await S.request('/api/public/offices');
  const mine = pub.data.offices.find((o) => o.id === office.id);
  assert.equal(mine.profile.city, 'عدن');
  assert.equal(mine.profile.logo, '/assets/offers/' + asset.data.asset.id);
  assert.equal(mine.office_name, 'مكتب الاختبار للسفر');
  const foreign = await S.request('/api/office/assets', 'POST', { filename: 'l.png', mimeType: 'image/png', base64: b64(PNG) }, admin);
  assert.equal((await S.request('/api/office/profile', 'PUT', { displayName: 'x', logoAssetId: foreign.data.asset.id }, office.cookie)).status, 400);
  assert.equal((await S.request('/api/office/dashboard', 'GET', undefined, office.cookie)).status, 200);
});

test('التذاكر والدعم', async () => {
  const t = await S.request('/api/tickets', 'POST', { subject: 'مشكلة في الدفع', body: 'لم تصلني رسالة التأكيد', kind: 'support' }, customer.cookie);
  assert.equal(t.status, 201, JSON.stringify(t.data));
  const id = t.data.ticket.id;
  assert.equal((await S.request('/api/tickets/' + id, 'GET', undefined, other.cookie)).status, 403);
  assert.equal((await S.request(`/api/tickets/${id}/messages`, 'POST', { body: 'تفاصيل إضافية' }, customer.cookie)).status, 201);
  assert.ok((await S.request('/api/tickets', 'GET', undefined, admin)).data.tickets.length >= 2);
  assert.equal((await S.request(`/api/tickets/${id}/messages`, 'POST', { body: 'نعمل على حلها' }, admin)).status, 201);
  assert.equal((await S.request('/api/admin/tickets/' + id, 'PATCH', { status: 'resolved' }, admin)).data.ticket.status, 'resolved');
  assert.equal((await S.request('/api/admin/tickets/' + id, 'PATCH', { status: 'resolved' }, customer.cookie)).status, 403);
  const n = await S.request('/api/notifications', 'GET', undefined, customer.cookie);
  assert.ok(n.data.notifications.some((x) => x.kind === 'ticket_reply'));
});

test('محتوى المنصة والإعدادات والإحصاءات والنسخ الاحتياطي', async () => {
  assert.equal((await S.request('/api/admin/docs/ads/home1', 'PUT', { data: { title: 'عرض الصيف', img: '' }, public: true }, admin)).status, 200);
  assert.equal((await S.request('/api/admin/docs/secret/s1', 'PUT', { data: { k: 1 }, public: false }, admin)).status, 200);
  const pub = await S.request('/api/public/docs');
  assert.equal(pub.data.docs.ads[0].title, 'عرض الصيف');
  assert.equal(pub.data.docs.secret, undefined);
  assert.equal((await S.request('/api/admin/docs/Bad Name/x', 'PUT', { data: {} }, admin)).status, 400);
  const st = await S.request('/api/admin/stats', 'GET', undefined, admin);
  assert.ok(st.data.users.find((u) => u.role === 'customer').count >= 2);
  const bk = await S.request('/api/admin/backup', 'POST', {}, admin);
  assert.equal(bk.status, 200);
  assert.match(bk.data.file, /^safarak-.*\.sqlite$/);
  const au = await S.request('/api/admin/audit?limit=10', 'GET', undefined, admin);
  assert.ok(au.data.entries.length > 0);
});

test('ويب هوك الدفع الإلكتروني: توقيع مطلوب ويمنع التكرار', async () => {
  const cfg = await S.request('/api/payments/config');
  assert.equal(cfg.data.online, false, 'لا مفاتيح => الدفع الإلكتروني غير مفعّل');
  const body = JSON.stringify({ id: 'evt_1', type: 'checkout.session.completed', data: { object: { payment_status: 'paid', metadata: { intent_id: 'none' } } } });
  assert.equal((await S.request('/api/payments/webhook/stripe', 'POST', body)).status, 403);
  const t = Math.floor(Date.now() / 1000);
  const sig = crypto.createHmac('sha256', 'whsec_test').update(`${t}.${body}`).digest('hex');
  const ok = await S.request('/api/payments/webhook/stripe', 'POST', body, undefined, { headers: { 'stripe-signature': `t=${t},v1=${sig}` } });
  assert.equal(ok.status, 200, JSON.stringify(ok.data));
  const dup = await S.request('/api/payments/webhook/stripe', 'POST', body, undefined, { headers: { 'stripe-signature': `t=${t},v1=${sig}` } });
  assert.equal(dup.data.duplicate, true);
  const b = await S.request('/api/bookings/none/checkout', 'POST', {}, customer.cookie);
  assert.ok([404, 501].includes(b.status));
});
