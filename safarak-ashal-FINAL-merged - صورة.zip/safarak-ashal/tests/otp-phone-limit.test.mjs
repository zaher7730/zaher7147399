// المرحلة 24: حد المحاولات الخاطئة على مستوى الرقم (لا يُتجاوز بطلب رموز جديدة).
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';

let S;
test.before(async () => { S = await startServer(); });
test.after(() => S.stop());

test('بعد 9 محاولات خاطئة لنفس الرقم عبر عدة رموز يُحجب الرقم، ولا يُسمح بطلب رمز جديد', async () => {
  const phone = '770000055';
  for (let round = 0; round < 3; round += 1) {
    const rq = await S.request('/api/auth/request-otp', 'POST', { role: 'customer', phone, name: 'Brute Test' });
    assert.equal(rq.status, 200, 'طلب الرمز الأول يجب أن ينجح في الجولة ' + round);
    const real = Number(await S.otpCode(phone));
    for (let i = 0; i < 3; i += 1) {
      const wrong = String((real + 1 + i) % 10000).padStart(4, '0');
      const r = await S.request('/api/auth/verify-otp', 'POST', { challengeId: rq.data.challengeId, code: wrong });
      assert.ok([400, 401].includes(r.status), 'تخمين خاطئ يُرفض');
    }
  }
  const blocked = await S.request('/api/auth/request-otp', 'POST', { role: 'customer', phone, name: 'Brute Test' });
  assert.equal(blocked.status, 429, 'الرقم يجب أن يكون محجوباً بعد 9 محاولات خاطئة');
});

test('رقم آخر لم تُسجَّل له محاولات خاطئة لا يتأثر', async () => {
  const rq = await S.request('/api/auth/request-otp', 'POST', { role: 'customer', phone: '770000056', name: 'Clean Test' });
  assert.equal(rq.status, 200);
});
