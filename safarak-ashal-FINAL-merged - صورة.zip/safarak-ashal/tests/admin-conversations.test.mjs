// مراقبة الإدارة للمحادثات: المدير فقط يرى كل المحادثات، الاطلاع يُسجَّل، والإغلاق يمنع الرسائل الجديدة.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';

let S, admin, office, customer, other, convId, convCustomerId;
test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000051', 'عميل المراقبة');
  other = await S.otpLogin('customer', '770000052', 'عميل آخر');
  const c = await S.request('/api/conversations', 'POST', { officeId: office.id, subject: 'استفسار' }, customer.cookie);
  assert.equal(c.status, 201, JSON.stringify(c.data));
  convId = c.data.conversation.id;
  convCustomerId = c.data.conversation.customer.id;
  assert.equal((await S.request(`/api/conversations/${convId}/messages`, 'POST', { body: 'هل توجد رحلة غداً؟' }, customer.cookie)).status, 201);
  assert.equal((await S.request(`/api/conversations/${convId}/messages`, 'POST', { body: 'نعم، الساعة 8' }, office.cookie)).status, 201);
});
test.after(async () => S && S.stop());

test('المدير يرى المحادثة بنصها وأطرافها وحالتها', async () => {
  const r = await S.request('/api/admin/conversations', 'GET', undefined, admin);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const c = r.data.conversations.find((x) => x.id === convId);
  assert.ok(c);
  assert.equal(c.status, 'open');
  assert.equal(c.messageCount, 2);
  assert.deepEqual(c.transcript.map((m) => [m.from, m.text]), [['customer', 'هل توجد رحلة غداً؟'], ['office', 'نعم، الساعة 8']]);
  assert.equal(c.customerId, convCustomerId);
  assert.equal(c.officeId, office.id);
});

test('العميل والمكتب والزائر لا يستطيعون استعمال مسارات الإدارة للمحادثات', async () => {
  for (const cookie of [customer.cookie, office.cookie, undefined]) {
    assert.ok([401, 403].includes((await S.request('/api/admin/conversations', 'GET', undefined, cookie)).status));
    assert.ok([401, 403].includes((await S.request(`/api/admin/conversations/${convId}`, 'PATCH', { status: 'closed' }, cookie)).status));
  }
});

test('الاطلاع يُسجَّل في سجل التدقيق مرة واحدة ضمن النافذة', async () => {
  await S.request('/api/admin/conversations', 'GET', undefined, admin);
  const a = await S.request('/api/admin/audit?limit=100', 'GET', undefined, admin);
  const n = a.data.entries.filter((e) => e.action === 'conversation.admin_view').length;
  assert.equal(n, 1);
});

test('حالة غير صحيحة → 400، وتعليم «مُبلَّغ عنها» يظهر للمدير', async () => {
  assert.equal((await S.request(`/api/admin/conversations/${convId}`, 'PATCH', { status: 'x' }, admin)).status, 400);
  assert.equal((await S.request(`/api/admin/conversations/${convId}`, 'PATCH', { status: 'reported' }, admin)).status, 200);
  const r = await S.request('/api/admin/conversations', 'GET', undefined, admin);
  assert.equal(r.data.conversations.find((x) => x.id === convId).status, 'reported');
});

test('إغلاق المحادثة يمنع الرسائل الجديدة ويُشعر الطرفين، وإعادة فتحها تسمح بها', async () => {
  assert.equal((await S.request(`/api/admin/conversations/${convId}`, 'PATCH', { status: 'closed' }, admin)).status, 200);
  assert.equal((await S.request(`/api/conversations/${convId}/messages`, 'POST', { body: 'بعد الإغلاق' }, customer.cookie)).status, 409);
  assert.equal((await S.request(`/api/conversations/${convId}/messages`, 'POST', { body: 'بعد الإغلاق' }, office.cookie)).status, 409);
  assert.equal((await S.request(`/api/conversations/${convId}/messages`, 'GET', undefined, customer.cookie)).status, 200, 'القراءة تبقى مسموحة');
  assert.equal((await S.request(`/api/conversations/${convId}/messages`, 'GET', undefined, other.cookie)).status, 403, 'عميل آخر لا يقرأ');
  assert.equal((await S.request(`/api/admin/conversations/${convId}`, 'PATCH', { status: 'open' }, admin)).status, 200);
  assert.equal((await S.request(`/api/conversations/${convId}/messages`, 'POST', { body: 'بعد إعادة الفتح' }, customer.cookie)).status, 201);
});

test('نص المحادثة في صفحة الإدارة للقراءة فقط (المحفوظ هو الحالة فقط)', async () => {
  const { readFileSync } = await import('node:fs');
  const cfg = readFileSync(new URL('../apps/admin/scripts/messages/pages-config/chats.js', import.meta.url), 'utf8');
  assert.match(cfg, /'m\|[^']*\|l\|ro'/, 'حقل نص المحادثة غير معلَّم للقراءة فقط');
  const inp = readFileSync(new URL('../apps/admin/scripts/screens/forms/inp.js', import.meta.url), 'utf8');
  assert.match(inp, /f\.o == 'ro' \? ' readonly/, 'مولّد الحقول لا يدعم readonly');
});
