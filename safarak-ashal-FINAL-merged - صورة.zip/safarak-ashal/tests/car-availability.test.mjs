// تأجير السيارات: السيارة المحجوزة «غير متاحة» لبقية العملاء حتى يكتمل الحجز أو يُرفض أو يُلغى.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, ymdLocal } from './helpers.mjs';

let S, admin, office, customerA, customerB, carId, bookingId;
const carBody = () => ({ serviceId: carId, serviceType: 'cars', title: 'سيارة اختبار', passengerCount: 1, totalAmount: 120, currency: 'YER', details: { form: {} } });
const listed = async () => (await S.request('/api/public/services')).data.services.find((x) => x.id === carId);

test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customerA = (await S.otpLogin('customer', '770000003', 'عميل أ')).cookie;
  customerB = (await S.otpLogin('customer', '770000005', 'عميل ب')).cookie;
  const sync = await S.request('/api/office/services/sync', 'PUT', { services: [{ serviceType: 'cars', title: 'كامري 2023', details: { price: 100, dep: 20, currency: 'YER', city: 'عدن' }, active: true }] }, office.cookie);
  assert.equal(sync.status, 200, JSON.stringify(sync.data));
  carId = sync.data.services.find((x) => x.service_type === 'cars').id;
});
test.after(() => S.stop());

test('السيارة غير المحجوزة تظهر متاحة (reserved=false)', async () => {
  const car = await listed();
  assert.equal(car.reserved, false);
});

test('علامة reserved خاصة بالسيارات: عرض رحلة محجوز لا يُعلَّم محجوزاً', async () => {
  const sync = await S.request('/api/office/services/sync', 'PUT', { services: [
    { serviceType: 'cars', title: 'كامري 2023', details: { price: 100, dep: 20, currency: 'YER', city: 'عدن' }, active: true },
    { serviceType: 'bus', title: 'رحلة اختبار', details: { price: 500, currency: 'YER', from: 'عدن', to: 'المكلا', days: 'يومياً', time: '8:00 ص' }, active: true },
  ] }, office.cookie);
  const bus = sync.data.services.find((x) => x.service_type === 'bus');
  const b = await S.request('/api/bookings', 'POST', { serviceId: bus.id, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details: { form: {}, departDate: ymdLocal(1) } }, customerB);
  assert.equal(b.status, 201, JSON.stringify(b.data));
  const again = await S.request('/api/bookings', 'POST', { serviceId: bus.id, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details: { form: {}, departDate: ymdLocal(1) } }, customerA);
  assert.equal(again.status, 201, 'الرحلات تقبل أكثر من حجز');
  const listedBus = (await S.request('/api/public/services')).data.services.find((x) => x.id === bus.id);
  assert.equal(listedBus.reserved, false);
});

test('عميل يحجز السيارة فتصبح غير متاحة للجميع', async () => {
  const r = await S.request('/api/bookings', 'POST', carBody(), customerA);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  bookingId = r.data.booking.public_id;
  assert.equal((await listed()).reserved, true);
});

test('عميل آخر لا يستطيع حجزها (409) ولا يُنشأ حجز', async () => {
  const r = await S.request('/api/bookings', 'POST', carBody(), customerB);
  assert.equal(r.status, 409, JSON.stringify(r.data));
  assert.match(r.data.error, /محجوزة/);
  const mine = await S.request('/api/bookings', 'GET', undefined, customerB);
  assert.equal(mine.data.bookings.filter((x) => x.service_type === 'cars').length, 0);
});

test('إلغاء الحجز يعيد السيارة متاحة ويستطيع غيره حجزها', async () => {
  const c = await S.request(`/api/bookings/${bookingId}/cancel`, 'POST', {}, customerA);
  assert.ok([200, 201].includes(c.status), JSON.stringify(c.data));
  assert.equal((await listed()).reserved, false);
  const r = await S.request('/api/bookings', 'POST', carBody(), customerB);
  assert.equal(r.status, 201, JSON.stringify(r.data));
});

test('اكتمال الحجز من المكتب يعيدها متاحة', async () => {
  const mine = await S.request('/api/bookings', 'GET', undefined, customerB);
  const id = mine.data.bookings.find((x) => x.service_type === 'cars').public_id;
  assert.equal((await listed()).reserved, true);
  const done = await S.request(`/api/bookings/${id}/status`, 'PATCH', { status: 'completed' }, office.cookie);
  assert.equal(done.status, 200, JSON.stringify(done.data));
  assert.equal((await listed()).reserved, false);
});
