// أدوات الاختبار: تشغيل خادم حقيقي على منفذ عشوائي بقاعدة مؤقتة، وتسجيل دخول OTP عبر سجل الخادم.
import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';

const ROOT = path.resolve(new URL('..', import.meta.url).pathname);
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l8sAAAAASUVORK5CYII=', 'base64');
export const PDF = Buffer.from('%PDF-1.4\nSafarak receipt test\n%%EOF', 'utf8');

/** توقيت الجهاز بصيغة +HH:MM؛ يستعمله الخادم في الاختبارات ليتفق مع ساعة المتصفح (في الإنتاج الافتراضي +03:00) */
export function localUtcOffset(date = new Date()) {
  const m = -date.getTimezoneOffset(), a = Math.abs(m);
  return (m < 0 ? '-' : '+') + String(Math.floor(a / 60)).padStart(2, '0') + ':' + String(a % 60).padStart(2, '0');
}
/** تاريخ اليوم (بتوقيت الجهاز) بصيغة YYYY-MM-DD مع إزاحة بالأيام */
export function ymdLocal(offsetDays = 0) {
  const d = new Date(); d.setDate(d.getDate() + offsetDays);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

export async function startServer(extraEnv = {}) {
  const tmp = await mkdtemp(path.join(os.tmpdir(), 'safarak-test-'));
  const port = 20000 + Math.floor(Math.random() * 20000);
  const base = `http://127.0.0.1:${port}`;
  let log = '';
  const proc = spawn(process.execPath, ['--no-warnings', 'server/index.mjs'], {
    cwd: ROOT,
    env: {
      ...process.env, HOST: '127.0.0.1', PORT: String(port), NODE_ENV: 'development',
      DB_PATH: path.join(tmp, 'test.sqlite'), PRIVATE_UPLOADS_DIR: path.join(tmp, 'private'), PUBLIC_OFFER_UPLOADS_DIR: path.join(tmp, 'public'), BACKUP_DIR: path.join(tmp, 'backups'),
      SAFARAK_ENV_FILE: '', OTP_PEPPER: 'test-only-pepper-which-is-long-enough', ADMIN_NAME: 'Test Admin', ADMIN_PHONE: '770000001', ADMIN_PASSWORD: 'TestAdminPass!2026',
      COOKIE_SECURE: 'false', RATE_LIMIT_PER_MINUTE: '100000', PLATFORM_UTC_OFFSET: localUtcOffset(), ...extraEnv,
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  proc.stdout.on('data', (b) => (log += b));
  proc.stderr.on('data', (b) => (log += b));
  const start = Date.now();
  for (;;) {
    try { if ((await fetch(base + '/api/health')).ok) break; } catch { /* waiting */ }
    if (Date.now() - start > 20000) throw new Error('server did not start:\n' + log);
    await sleep(100);
  }

  async function request(url, method = 'GET', body, cookie, options = {}) {
    const r = await fetch(base + url, {
      method, redirect: options.redirect || 'follow',
      headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...(cookie ? { cookie } : {}), ...(options.headers || {}) },
      body: body ? (typeof body === 'string' ? body : JSON.stringify(body)) : undefined,
    });
    const type = r.headers.get('content-type') || '';
    const data = type.includes('application/json') ? await r.json() : await r.text();
    const m = (r.headers.get('set-cookie') || '').match(/safarak_session=([^;]+)/);
    return { status: r.status, data, cookie: m ? `safarak_session=${m[1]}` : undefined, headers: r.headers };
  }
  const normalize = (p) => '+967' + String(p).replace(/\D/g, '');
  async function otpCode(phone) {
    const wanted = normalize(phone), end = Date.now() + 5000;
    while (Date.now() < end) {
      for (const line of log.split(/\r?\n/).reverse()) {
        if (line.includes('[OTP-DEV]') && line.includes('phone=' + wanted)) { const m = line.match(/code=(\d{4})/); if (m) return m[1]; }
      }
      await sleep(50);
    }
    throw new Error('OTP not found in log for ' + wanted);
  }
  async function otpLogin(role, phone, name = 'Test User') {
    const rq = await request('/api/auth/request-otp', 'POST', { role, phone, name });
    assert.equal(rq.status, 200, JSON.stringify(rq.data));
    const code = await otpCode(phone);
    const vr = await request('/api/auth/verify-otp', 'POST', { challengeId: rq.data.challengeId, code });
    assert.equal(vr.status, 200, JSON.stringify(vr.data));
    return { cookie: vr.cookie, user: vr.data.user };
  }
  async function adminLogin() {
    const r = await request('/api/auth/login', 'POST', { identifier: '770000001', password: 'TestAdminPass!2026' });
    assert.equal(r.status, 200, JSON.stringify(r.data));
    return r.cookie;
  }
  /** مكتب جاهز: حساب + عرض منشور + حساب دفع */
  async function seedOffice(admin, { phone = '770000002', name = 'Test Office', price = 500 } = {}) {
    const c = await request('/api/admin/offices', 'POST', { name: name + ' User', officeName: name, phone }, admin);
    assert.equal(c.status, 201, JSON.stringify(c.data));
    const office = await otpLogin('office', phone, name);
    const sync = await request('/api/office/services/sync', 'PUT', { services: [{ serviceType: 'bus', title: 'رحلة اختبار', details: { price, currency: 'YER', from: 'عدن', to: 'المكلا' }, active: true }] }, office.cookie);
    assert.equal(sync.status, 200, JSON.stringify(sync.data));
    const pm = await request('/api/office/payment-methods/sync', 'PUT', { methods: [{ type: 'بنك', name: 'حساب الاختبار', accountNo: 'ACC-001', holder: 'Holder', currency: 'YER', active: true }] }, office.cookie);
    assert.equal(pm.status, 200, JSON.stringify(pm.data));
    return { id: c.data.office.id, cookie: office.cookie, serviceId: sync.data.services[0].id, methodId: pm.data.methods[0].id };
  }
  return {
    base, dbPath: path.join(tmp, 'test.sqlite'), request, otpCode, otpLogin, adminLogin, seedOffice, getLog: () => log,
    async stop() { proc.kill('SIGTERM'); await sleep(200); await rm(tmp, { recursive: true, force: true }); },
  };
}
export const b64 = (buf) => buf.toString('base64');
