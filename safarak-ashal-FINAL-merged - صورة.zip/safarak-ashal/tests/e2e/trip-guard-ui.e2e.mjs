// اختبار متصفح: لا يمكن حجز رحلة غادرت من أي مسار (القوائم، أو صفحة المكتب ← الخدمة، أو تغيير التاريخ).
// ساعة المتصفح مثبّتة على 12:00 ظهراً، فالرحلة اليومية 08:00 «غادرت» اليوم و«متاحة» غداً في أي ساعة تشغيل.
import test from 'node:test';
import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { startServer, sleep } from '../helpers.mjs';

let S, browser, page, customer, office, ERRS = [];
const until = async (fn, ms = 6000) => { const end = Date.now() + ms; for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('timeout'); await sleep(100); } };
const toasts = () => page.evaluate(() => [...document.querySelectorAll('.toast')].map((e) => e.textContent).join('|'));
const openOfficeService = (officeId) => page.evaluate(async (id) => { const i = OFFS.findIndex((o) => o.id === id); await oSvc(i, 'bus'); }, officeId);

test.before(async () => {
  S = await startServer();
  const admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000041', 'عميل الحارس');
  const sy = await S.request('/api/office/services/sync', 'PUT', { services: [{ serviceType: 'bus', title: 'باص الصباح', active: true, details: { price: 500, currency: 'YER', from: 'عدن', to: 'المكلا', days: 'يومي', time: '08:00', seats: 10 } }] }, office.cookie);
  assert.equal(sy.status, 200, JSON.stringify(sy.data));
  browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: 'block' });
  const now = new Date(); now.setHours(12, 0, 0, 0);
  await ctx.clock.install({ time: now });
  await ctx.addCookies([{ name: 'safarak_session', value: customer.cookie.split('=')[1], url: S.base }]);
  page = await ctx.newPage();
  page.on('pageerror', (e) => ERRS.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.goto(S.base + '/apps/customer/');
  await until(() => page.evaluate(() => typeof S !== 'undefined' && S.u.in === 1 && OFFS.length >= 1));
});
test.after(async () => { await browser?.close(); await S?.stop(); });

test('صفحة المكتب ← الخدمة: رحلة اليوم 08:00 بعد الظهر لا تُحجز وتظهر رسالة «الرحلة غادرت»', async () => {
  await openOfficeService(office.id);
  assert.equal(await page.evaluate(() => S.scr), 'detail');
  await page.locator('button:has-text("ابدأ الحجز الآن")').click();
  await sleep(300);
  assert.equal(await page.evaluate(() => S.scr), 'detail', 'يجب أن يبقى في صفحة التفاصيل');
  assert.match(await toasts(), /الرحلة غادرت — اختر رحلة أخرى/);
});

test('نفس الرحلة بتاريخ الغد متاحة للحجز', async () => {
  await openOfficeService(office.id);
  await page.evaluate(() => { S.ofm.d = 1; ofSet(); render(); });
  await sleep(200);
  await page.locator('button:has-text("ابدأ الحجز الآن")').click();
  await until(() => page.evaluate(() => S.scr === 'book'));
});

test('خط الدفاع الأخير: send() و toPay() يمنعان إرسال حجز لرحلة غادرت حتى لو فُتحت شاشة الحجز', async () => {
  await openOfficeService(office.id); // اليوم (غادرت)
  await page.evaluate(() => { S.scr = 'book'; render(); });
  const before = await S.request('/api/bookings', 'GET', undefined, customer.cookie);
  await page.evaluate(() => { toPay(); });
  assert.equal(await page.evaluate(() => S.scr), 'book');
  await page.evaluate(async () => { await send(); });
  const after = await S.request('/api/bookings', 'GET', undefined, customer.cookie);
  assert.equal(after.data.bookings.length, before.data.bookings.length, 'لا يجب إنشاء حجز');
});

test('الخادم يرفض أيضاً الحجز المباشر لموعد غادر (تجاوز الواجهة)', async () => {
  const sid = (await S.request('/api/public/services')).data.services.find((x) => x.title === 'باص الصباح').id;
  const d = new Date(); d.setDate(d.getDate() - 1);
  const y = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const r = await S.request('/api/bookings', 'POST', { serviceId: sid, serviceType: 'bus', title: 'باص الصباح', passengerCount: 1, totalAmount: 500, currency: 'YER', details: { form: {}, departDate: y } }, customer.cookie);
  assert.equal(r.status, 409, JSON.stringify(r.data));
});

test('لا أخطاء جافاسكربت', () => assert.deepEqual(ERRS, []));
