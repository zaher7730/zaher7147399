// دورة الحجز عبر الواجهات الثلاث بضغطات حقيقية (لا استدعاءات API بديلة عن الواجهة):
//  أ) الحوالة المعلّقة تبقى بعد التحديث وبعد الخروج والدخول، وإعادة الإرسال لا تُكرّر سجلاً ولا ملفاً.
//  ب) المكتب يغيّر حالة الطلب من واجهته، فتُحفظ على الخادم وتبقى بعد التحديث ويراها العميل لحظياً.
//  ج) الإدارة ترى الطلب في صفحة الطلبات بالبيانات المطابقة للخادم، دون خلط مع مكتب أو عميل آخر.
// طلبات API هنا للتحقق من حالة الخادم فقط، لا لتنفيذ الخطوة المختبَرة.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, PDF, sleep } from '../helpers.mjs';

import { chromium } from 'playwright';

const until = async (fn, ms = 10000, what = '') => { const end = Date.now() + ms; for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('timeout ' + what); await sleep(100); } };
const ERRS = [];
let S, admin, officeA, officeB, customer, customerB, browser, cctx, cpage;
let bk1, bk2, bk3, bkB;

const server = (url, method = 'GET', body, cookie) => S.request(url, method, body, cookie);
const bookingsOf = async (cookie) => (await server('/api/bookings', 'GET', undefined, cookie)).data.bookings;
const paymentsOf = async (id, cookie) => (await server(`/api/bookings/${id}/payments`, 'GET', undefined, cookie)).data.payments;
const receiptsOf = async (internalId, cookie) => (await server('/api/files', 'GET', undefined, cookie)).data.files.filter((f) => f.booking_id === internalId && /^rc\./.test(f.original_name));

async function openPage(cookie, path, { width = 390, height = 844 } = {}) {
  const ctx = await browser.newContext({ viewport: { width, height }, serviceWorkers: 'block' });
  await ctx.addCookies([{ name: 'safarak_session', value: cookie.split('=')[1], url: S.base }]);
  const page = await ctx.newPage();
  page.on('pageerror', (e) => ERRS.push(path + ': ' + e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.goto(S.base + path);
  return { ctx, page };
}
async function loadCustomer(page) {
  await page.waitForFunction(() => typeof S !== 'undefined' && S.u.in === 1 && typeof OFFS !== 'undefined' && OFFS.length >= 1, null, { timeout: 15000 });
  await page.waitForFunction(() => typeof SA_loadBookings === 'function', null, { timeout: 15000 });
  await page.evaluate(async () => { await SA_loadBookings(); });
}

test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  officeA = await S.seedOffice(admin);
  officeB = await S.seedOffice(admin, { phone: '770000004', name: 'Office B' });
  const sync = await server('/api/office/services/sync', 'PUT', { services: [{ serviceType: 'bus', title: 'رحلة اختبار', details: { price: 500, currency: 'YER', from: 'عدن', to: 'المكلا', days: 'يومي', seats: 10 }, active: true }] }, officeA.cookie);
  assert.equal(sync.status, 200, JSON.stringify(sync.data));
  customer = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
  customerB = await S.otpLogin('customer', '770000005', 'عميل آخر');
  browser = await chromium.launch();
  ({ ctx: cctx, page: cpage } = await openPage(customer.cookie, '/apps/customer/'));
  await loadCustomer(cpage);
  await cpage.evaluate((oid) => SA_loadPaymentMethods(oid), officeA.id);
  await cpage.waitForFunction(() => BANKS.length + PMS.length > 0, null, { timeout: 10000 });
});
test.after(async () => { await browser?.close(); await S?.stop(); });

/* ---------- أدوات الواجهة ---------- */
const clickBtn = async (page, text) => { const ok = await page.evaluate((t) => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes(t)); if (!b) return false; b.click(); return true; }, text); if (!ok) throw new Error('button not found: ' + text); };
const clickOn = (page, onclick) => page.evaluate((o) => { const b = [...document.querySelectorAll('button')].find((x) => (x.getAttribute('onclick') || '') === o); if (!b) throw new Error('no button ' + o); b.click(); }, onclick);

async function fillBookingForm(page) {
  await page.evaluate(() => {
    for (const x of missing(fields(S.o))) {
      const [t, k] = x;
      if (t === 'c') S.v[k] = Math.max(1, +S.v[k] || 1);
      else if (t === 'tg') S.v[k] = x[4][0];
      else if (t === 'd') S.v[k] = '1990-01-01';
      else if (t === 'p') S.v[k] = '+967770000003';
      else if (t === 's') S.v[k] = x[4][0];
      else if (t === 'sd') S.v[k] = seatMap(S.o).filter((a) => a[1] > 0)[0][0];
      else if (t === 't') S.v[k] = 'تجربة ' + k;
    }
    S.v.a = Math.max(1, +S.v.a || 1);
    render();
  });
  await sleep(200);
  const fKeys = await page.evaluate(() => missing(fields(S.o)).filter((x) => x[0] === 'f').map((x) => x[1]));
  for (const k of fKeys) {
    await page.locator(`input[type=file][onchange*="S.fl['${k}']"]`).setInputFiles({ name: k + '.png', mimeType: 'image/png', buffer: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l8sAAAAASUVORK5CYII=', 'base64') });
    await sleep(300);
  }
}

/** حجز كامل من واجهة العميل حتى الضغط على إرسال؛ يُرجع رقم الطلب بعد ظهور شاشة الإتمام */
async function bookThroughUi(page, reference) {
  await page.evaluate((oid) => { const i = OFFS.findIndex((o) => o.id === oid); return oSvc(i, 'bus'); }, officeA.id);
  await sleep(300);
  await clickBtn(page, 'ابدأ الحجز الآن');
  await sleep(300);
  await fillBookingForm(page);
  await clickOn(page, 'toPay()');
  await sleep(300);
  assert.equal(await page.evaluate(() => S.scr), 'pay');
  await clickOn(page, 'pmBank(0)');
  await sleep(200);
  await page.locator(`input[type=file][onchange*="S.fl['rc']"]`).setInputFiles({ name: 'receipt.pdf', mimeType: 'application/pdf', buffer: PDF });
  await until(() => page.evaluate(() => String(S.fu.rc || '').startsWith('data:application/pdf;base64,')), 10000, 'receipt read');
  const total = await page.evaluate(() => total());
  await page.evaluate(([t, ref]) => { document.querySelector('[data-k="tn"]').value = 'عميل تجريبي'; document.querySelector('[data-k="tr"]').value = ref; }, [total, reference]);
  await clickOn(page, 'send()');
  await until(() => page.evaluate(() => S.scr === 'done'), 15000, 'done screen');
  return page.evaluate(() => S.cur);
}
const openOrderDetail = async (page, id) => {
  await page.evaluate(() => { S.hist = []; go('orders'); });
  await page.locator(`.ord[onclick*="'${id}'"]`).first().click();   // بطاقة الطلب في «طلباتي»
  await until(() => page.evaluate(() => S.scr === 'odetail'), 5000, 'order detail');
};
const retryButton = (page) => page.locator('button[onclick^="retryPayment("]');
const pickInput = (page) => page.locator('input[type=file][onchange^="pickRetryReceipt("]');

async function relogin() {
  assert.equal((await server('/api/auth/logout', 'POST', {}, customer.cookie)).status, 200);
  customer = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
  await cctx.clearCookies();
  await cctx.addCookies([{ name: 'safarak_session', value: customer.cookie.split('=')[1], url: S.base }]);
  await cpage.reload();
  await loadCustomer(cpage);
}

/* ================= أ) الحوالة المعلّقة ================= */

test('أ-1: فشل رفع السند → الحجز يُحفظ، وبعد تحديث الصفحة تعود الحوالة المعلّقة من الخادم ويُعاد إرسالها بسند جديد', async () => {
  await cpage.route('**/api/files', async (route) => (route.request().postData() || '').includes('"filename":"rc.') ? route.abort() : route.continue());
  bk1 = await bookThroughUi(cpage, 'TX-REFRESH');
  await cpage.unroute('**/api/files');
  assert.ok(await cpage.evaluate(() => !!S.ord[0].pendingPayment), 'الحوالة المعلّقة ظاهرة فوراً');
  const row = (await bookingsOf(customer.cookie)).find((b) => b.public_id === bk1);
  assert.equal(row.payment_status, 'pending');
  assert.equal(row.details.payment.methodName, await cpage.evaluate(() => S.pm), 'وسيلة الدفع محفوظة مع الحجز');
  assert.equal((await paymentsOf(bk1, customer.cookie)).length, 0);
  assert.equal((await receiptsOf(row.id, customer.cookie)).length, 0, 'السند لم يُرفع');

  await cpage.reload();                                   // تحديث الصفحة: تضيع كل متغيرات الواجهة
  await loadCustomer(cpage);
  const restored = await cpage.evaluate((id) => { const x = S.ord.find((o) => o.id === id); return x && x.pendingPayment ? { ref: x.pendingPayment.fields.reference, sender: x.pendingPayment.fields.sender, hasReceipt: !!(x.pendingPayment.receiptId || x.pendingPayment.receiptData) } : null; }, bk1);
  assert.deepEqual(restored, { ref: 'TX-REFRESH', sender: 'عميل تجريبي', hasReceipt: false }, 'الحوالة المعلّقة عادت من الخادم ببياناتها');
  await openOrderDetail(cpage, bk1);
  assert.equal(await retryButton(cpage).count(), 0, 'لا زر إعادة إرسال قبل وجود سند');
  assert.equal(await pickInput(cpage).count(), 1, 'يُطلب إرفاق السند من جديد');
  await pickInput(cpage).setInputFiles({ name: 'receipt-again.pdf', mimeType: 'application/pdf', buffer: PDF });
  await retryButton(cpage).waitFor({ timeout: 5000 });
  await retryButton(cpage).click();
  await until(async () => (await paymentsOf(bk1, customer.cookie)).length === 1, 10000, 'payment saved');
  const pay = (await paymentsOf(bk1, customer.cookie))[0];
  assert.equal(pay.reference, 'TX-REFRESH');
  assert.equal(pay.office_id, officeA.id);
  const rc = await receiptsOf(row.id, customer.cookie);
  assert.equal(rc.length, 1);
  assert.equal(rc[0].id, pay.receipt_file_id, 'السند مرتبط بالحوالة والحجز الصحيحين');
  assert.equal((await server('/api/bookings/' + bk1, 'GET', undefined, customer.cookie)).data.booking.payment_status, 'submitted');
  await until(() => cpage.evaluate((id) => !S.ord.find((o) => o.id === id).pendingPayment, bk1), 8000, 'pending box cleared after server confirmed');
  assert.equal(await retryButton(cpage).count(), 0);
});

test('أ-2: فشل تسجيل الحوالة → بعد الخروج والدخول يُعاد استخدام السند المرفوع ولا يتكرر سجل ولا ملف رغم ضغطات متزامنة', async () => {
  await cpage.route('**/api/bookings/*/payment', (route) => route.abort());
  bk2 = await bookThroughUi(cpage, 'TX-RELOGIN');
  await cpage.unroute('**/api/bookings/*/payment');
  const row = (await bookingsOf(customer.cookie)).find((b) => b.public_id === bk2);
  assert.equal(row.payment_status, 'pending');
  assert.equal((await paymentsOf(bk2, customer.cookie)).length, 0);
  assert.equal((await receiptsOf(row.id, customer.cookie)).length, 1, 'السند رُفع قبل فشل التسجيل');

  await relogin();                                         // خروج ثم دخول بجلسة جديدة
  const st = await cpage.evaluate((id) => { const x = S.ord.find((o) => o.id === id); return x && x.pendingPayment ? { ref: x.pendingPayment.fields.reference, receiptId: x.pendingPayment.receiptId } : null; }, bk2);
  assert.ok(st, 'الحوالة المعلّقة عادت بعد تسجيل الدخول');
  assert.equal(st.ref, 'TX-RELOGIN');
  const stored = (await receiptsOf(row.id, customer.cookie))[0];
  assert.equal(st.receiptId, stored.id, 'عُثر على السند المحفوظ على الخادم');
  await openOrderDetail(cpage, bk2);
  assert.equal(await pickInput(cpage).count(), 0, 'لا حاجة لإعادة رفع السند');
  await retryButton(cpage).waitFor({ timeout: 5000 });
  // ثلاث محاولات في اللحظة نفسها: نقرة حقيقية على الزر + استدعاءان مباشران (ضغط مزدوج / تبويبان)
  await cpage.evaluate((id) => { document.querySelector('button[onclick^="retryPayment("]').click(); retryPayment(id); retryPayment(id); }, bk2);
  await until(async () => (await paymentsOf(bk2, customer.cookie)).length >= 1, 10000, 'payment saved');
  await sleep(800);
  const pays = await paymentsOf(bk2, customer.cookie);
  assert.equal(pays.length, 1, 'لا تكرار للحوالة');
  assert.equal((await receiptsOf(row.id, customer.cookie)).length, 1, 'لا تكرار لرفع السند');
  assert.equal(pays[0].receipt_file_id, stored.id);
});

test('أ-3: نجح الحفظ وضاع الرد → الواجهة لا تُكرّر الحوالة، وتعرض حالة الخادم الحقيقية', async () => {
  await cpage.route('**/api/bookings/*/payment', async (route) => { await route.fetch(); await route.abort(); });  // يصل الخادم ثم يضيع الرد
  bk3 = await bookThroughUi(cpage, 'TX-LOSTREPLY');
  await cpage.unroute('**/api/bookings/*/payment');
  assert.ok(await cpage.evaluate(() => !!S.ord[0].pendingPayment), 'الواجهة تظن أن الحوالة لم تُسجَّل');
  assert.equal((await paymentsOf(bk3, customer.cookie)).length, 1, 'لكن الخادم حفظها');
  await cpage.evaluate((id) => retryPayment(id), bk3);
  await until(() => cpage.evaluate((id) => !S.ord.find((o) => o.id === id).pendingPayment, bk3), 8000, 'stale pending cleared from server truth');
  assert.equal((await paymentsOf(bk3, customer.cookie)).length, 1, 'لا حوالة ثانية');
  await cpage.reload();
  await loadCustomer(cpage);
  assert.ok(await cpage.evaluate((id) => S.ord.find((o) => o.id === id) && !S.ord.find((o) => o.id === id).pendingPayment, bk3), 'بعد التحديث لا حوالة معلّقة وهمية');
});

/* ================= ب) تغيير الحالة من واجهة المكتب ================= */

test('ب: المكتب المختص يرى الطلب في واجهته ويغيّر حالته بالأزرار، فتُحفظ وتبقى بعد التحديث ويراها العميل لحظياً', async () => {
  const { ctx: octx, page: op } = await openPage(officeA.cookie, '/apps/office/', { width: 1280, height: 800 });
  try {
    await op.waitForFunction((id) => typeof D !== 'undefined' && Array.isArray(D.ord) && D.ord.some((o) => o.id === id), bk1, { timeout: 15000 });
    await op.locator('button[onclick="go(\'orders\')"]').first().click();
    await op.locator(`[onclick="go('od','${bk1}')"]`).first().click();
    assert.ok((await op.locator('body').innerText()).includes(bk1));
    const before = (await server('/api/bookings/' + bk1, 'GET', undefined, officeA.cookie)).data.booking.status;
    assert.equal(before, 'pending');
    await op.locator(`button[onclick="ss('${bk1}',1)"]`).click();          // «قبول وبدء التنفيذ»
    await until(async () => (await server('/api/bookings/' + bk1, 'GET', undefined, officeA.cookie)).data.booking.status === 'in_progress', 10000, 'status saved on server');
    const events = (await server(`/api/bookings/${bk1}/events`, 'GET', undefined, officeA.cookie)).data.events;
    assert.ok(events.some((e) => e.old_status === 'pending' && e.new_status === 'in_progress' && e.actor_id === officeA.id), 'الحدث مسجَّل باسم المكتب');
    // العميل يرى التحديث عبر الآلية القائمة (SSE) دون استدعاء يدوي
    await until(() => cpage.evaluate((id) => { const x = S.ord.find((o) => o.id === id); return x && x.serverStatus === 'in_progress' && x.st === 1; }, bk1), 10000, 'customer live update');
    assert.ok((await server('/api/notifications', 'GET', undefined, customer.cookie)).data.notifications.some((n) => n.kind === 'booking_status' && n.data.bookingId === bk1 && n.data.status === 'in_progress'));
    // تحديث صفحة المكتب: الحالة باقية
    await op.reload();
    await op.waitForFunction((id) => typeof D !== 'undefined' && Array.isArray(D.ord) && D.ord.some((o) => o.id === id && o.st === 1 && o.serverStatus === 'in_progress'), bk1, { timeout: 15000 });
    await op.locator('button[onclick="go(\'orders\')"]').first().click();
    await op.locator(`[onclick="go('od','${bk1}')"]`).first().click();
    assert.equal(await op.locator(`button[onclick="ss('${bk1}',1)"]`).count(), 0, 'زر البدء اختفى لأن الطلب قيد التنفيذ فعلاً');
    assert.ok(await op.locator(`button[onclick="ss('${bk1}',2)"]`).count() >= 1, 'خيار الإنهاء متاح الآن');
    // العميل بعد التحديث والخروج والدخول
    await cpage.reload();
    await loadCustomer(cpage);
    assert.equal(await cpage.evaluate((id) => S.ord.find((o) => o.id === id).serverStatus, bk1), 'in_progress');
    // مكتب آخر لا يرى هذا الطلب
    assert.equal((await bookingsOf(officeB.cookie)).some((b) => b.public_id === bk1), false);
    assert.equal((await server(`/api/bookings/${bk1}/status`, 'PATCH', { status: 'completed' }, officeB.cookie)).status, 403);
  } finally { await octx.close(); }
});

test('ب-2: رفض الخادم لتغيير الحالة → لا نجاح كاذب ولا إبلاغ للعميل ولا تغيّر في الواجهة، والمحاولة التالية تُسجَّل مرة واحدة', async () => {
  const mk = await server('/api/bookings', 'POST', { serviceId: officeA.serviceId, serviceType: 'bus', title: 'رحلة فشل الحالة', passengerCount: 1, totalAmount: 500, currency: 'YER', details: {} }, customer.cookie);
  assert.equal(mk.status, 201, JSON.stringify(mk.data));
  const id = mk.data.booking.public_id;
  const { ctx: octx, page: op } = await openPage(officeA.cookie, '/apps/office/', { width: 1280, height: 800 });
  try {
    await op.waitForFunction((i) => typeof D !== 'undefined' && Array.isArray(D.ord) && D.ord.some((o) => o.id === i), id, { timeout: 15000 });
    await op.evaluate(() => { window.__toasts = []; new MutationObserver((ms) => ms.forEach((m) => m.addedNodes.forEach((n) => n.style && n.style.position === 'fixed' && window.__toasts.push(n.textContent)))).observe(document.body, { childList: true }); });
    await op.route('**/api/bookings/*/status', (route) => route.fulfill({ status: 500, contentType: 'application/json', body: JSON.stringify({ ok: false, error: 'تعذّر الحفظ (اختبار)' }) }));
    await op.locator('button[onclick="go(\'orders\')"]').first().click();
    await op.locator(`[onclick="go('od','${id}')"]`).first().click();
    await op.locator(`button[onclick="ss('${id}',1)"]`).click();
    await until(() => op.evaluate(() => window.__toasts.length > 0), 5000, 'toast shown');
    const toasts = await op.evaluate(() => window.__toasts);
    assert.ok(toasts.some((t) => t.includes('تعذّر الحفظ')), 'يظهر خطأ الخادم الحقيقي: ' + toasts);
    assert.ok(!toasts.some((t) => t.includes('تم تحديث الحالة')), 'لا رسالة نجاح كاذبة');
    await sleep(900);                                          // نافذة المزامنة المؤجَّلة في الواجهة
    assert.equal(await op.evaluate((i) => D.ord.find((o) => o.id === i).st, id), 0, 'الواجهة لم تغيّر الحالة');
    assert.equal((await server('/api/bookings/' + id, 'GET', undefined, officeA.cookie)).data.booking.status, 'pending');
    assert.equal((await server('/api/notifications', 'GET', undefined, customer.cookie)).data.notifications.some((n) => n.kind === 'booking_status' && n.data.bookingId === id), false, 'العميل لم يُبلَّغ بتغيير لم يحدث');
    // المحاولة التالية بعد عودة الخادم: تنجح وتُسجَّل مرة واحدة
    await op.unroute('**/api/bookings/*/status');
    await op.locator(`button[onclick="ss('${id}',1)"]`).click();
    await until(async () => (await server('/api/bookings/' + id, 'GET', undefined, officeA.cookie)).data.booking.status === 'in_progress', 10000, 'saved after retry');
    await sleep(900);
    const ev = (await server(`/api/bookings/${id}/events`, 'GET', undefined, officeA.cookie)).data.events.filter((e) => e.new_status === 'in_progress');
    assert.equal(ev.length, 1, 'حدث واحد فقط دون تكرار من المزامنة المؤجَّلة');
    assert.ok((await op.evaluate(() => window.__toasts)).some((t) => t.includes('تم تحديث الحالة')));
  } finally { await octx.close(); }
});

/* ================= ج) عرض الطلب في واجهة الإدارة ================= */

test('ج: الإدارة ترى الطلب في صفحة الطلبات بنفس بيانات الخادم، دون خلط مع مكتب أو عميل آخر', async () => {
  const bB = await server('/api/bookings', 'POST', { serviceId: officeB.serviceId, serviceType: 'bus', title: 'رحلة المكتب الآخر', passengerCount: 1, totalAmount: 500, currency: 'YER', details: {} }, customerB.cookie);
  assert.equal(bB.status, 201, JSON.stringify(bB.data));
  bkB = bB.data.booking.public_id;
  const { ctx: actx, page: ap } = await openPage(admin, '/apps/admin/', { width: 1280, height: 800 });
  try {
    await ap.waitForFunction(() => typeof D !== 'undefined' && Array.isArray(D.or) && D.or.length >= 4, null, { timeout: 15000 });
    await ap.evaluate(() => go('or'));
    const rowOf = async (id) => (await ap.evaluate((i) => { const r = [...document.querySelectorAll('tr[onclick]')].find((x) => x.innerText.includes(i)); return r ? r.innerText.replace(/\s+/g, ' ') : null; }, id));
    const api = (await server('/api/admin/bookings', 'GET', undefined, admin)).data.bookings;
    const a = api.find((b) => b.public_id === bk1), b = api.find((x) => x.public_id === bkB);
    assert.equal(a.status, 'in_progress');
    const rowA = await rowOf(bk1), rowB = await rowOf(bkB);
    assert.ok(rowA, 'الطلب ظاهر في جدول الإدارة');
    assert.ok(rowA.includes('عميل تجريبي') && rowA.includes('Test Office') && rowA.includes('قيد التنفيذ') && rowA.includes('مدفوع جزئياً') && rowA.includes('500'), 'صف الطلب: ' + rowA);
    assert.ok(!rowA.includes('Office B') && !rowA.includes('عميل آخر'), 'لا خلط مع المكتب/العميل الآخر');
    assert.ok(rowB && rowB.includes('Office B') && rowB.includes('عميل آخر') && rowB.includes('قيد المراجعة') && rowB.includes('غير مدفوع'), 'صف الطلب الآخر: ' + rowB);
    assert.ok(!rowB.includes('Test Office') && !rowB.includes('عميل تجريبي'));
    // مطابقة مع بيانات الخادم (المكتب والعميل والمبلغ)
    const rec = await ap.evaluate((id) => { const r = D.or.find((x) => x.serverId === id); return { of: r.of, cu: r.cu, tot: r.tot, st: r.serverStatus, pay: r.pay }; }, bk1);
    assert.deepEqual(rec, { of: a.office_id, cu: a.customer_id, tot: a.total_amount, st: a.status, pay: 'مدفوع جزئياً' });
    assert.equal(a.office_id, officeA.id);
    assert.equal(b.office_id, officeB.id);
    assert.notEqual(a.customer_id, b.customer_id);
    // فتح تفاصيل الطلب من الصف نفسه
    await ap.locator('tr[onclick]', { hasText: bk1 }).click();
    await until(() => ap.evaluate((id) => document.body.innerText.includes(id) && document.body.innerText.includes('عميل تجريبي'), bk1), 5000, 'detail');
    assert.ok(await ap.evaluate(() => [...document.querySelectorAll('button')].some((x) => /^ac\('or'/.test(x.getAttribute('onclick') || ''))), 'أزرار الإدارة ظاهرة للمدير');
  } finally { await actx.close(); }
  // التحقق من الحماية عبر الخادم: غير المدير لا يقرأ سجل الإدارة، والعميل الآخر لا يصل لطلب غيره
  for (const c of [customer.cookie, customerB.cookie, officeA.cookie, officeB.cookie]) assert.ok([401, 403].includes((await server('/api/admin/bookings', 'GET', undefined, c)).status));
  assert.equal((await server('/api/bookings/' + bk1, 'GET', undefined, customerB.cookie)).status, 403);
  assert.equal((await bookingsOf(customerB.cookie)).length, 1);
});

/* ================= د) الدورة كاملة بعد الخروج والدخول ================= */

test('د: بعد خروج العميل ودخوله يجد الطلب والحالة والدفع كما حفظها الخادم، وتبقى الحوالة غير المعلّقة بلا زر', async () => {
  await relogin();
  const view = await cpage.evaluate((ids) => ids.map((id) => { const x = S.ord.find((o) => o.id === id); return x ? { id, st: x.serverStatus, pay: x.paymentStatus, pending: !!x.pendingPayment } : null; }), [bk1, bk2, bk3]);
  assert.deepEqual(view, [
    { id: bk1, st: 'in_progress', pay: 'submitted', pending: false },
    { id: bk2, st: 'pending', pay: 'submitted', pending: false },
    { id: bk3, st: 'pending', pay: 'submitted', pending: false },
  ]);
  for (const id of [bk1, bk2, bk3]) assert.equal((await paymentsOf(id, customer.cookie)).length, 1);
});

test('لا أخطاء JavaScript في أي واجهة أثناء الدورة', () => {
  assert.deepEqual(ERRS, []);
});
