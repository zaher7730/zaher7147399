// اختبار متصفح حقيقي للوحة الإدارة: بيانات حية، محتوى المنصة، الباقات، التوثيق، الدعم، التقييمات، الربط، وإخفاء الصفحة عن غير المدير.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, PNG, b64, sleep } from '../helpers.mjs';

import { chromium } from 'playwright';
const ERRS = [];
let S, admin, office, customer, browser, page, bookingId;
const until = async (fn, ms = 7000) => { const end = Date.now() + ms; for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('timeout: ' + fn); await sleep(100); } };
const ev = (fn, arg) => page.evaluate(fn, arg);
const png = 'data:image/png;base64,' + b64(PNG);

test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
  const b = await S.request('/api/bookings', 'POST', { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details: {} }, customer.cookie);
  bookingId = b.data.booking.public_id;
  await S.request(`/api/bookings/${bookingId}/status`, 'PATCH', { status: 'completed' }, office.cookie);
  browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, serviceWorkers: 'block' });
  await ctx.addCookies([{ name: 'safarak_session', value: admin.split('=')[1], url: S.base }]);
  page = await ctx.newPage();
  page.on('pageerror', (e) => ERRS.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.goto(S.base + '/apps/admin/');
  await until(() => ev(() => typeof D !== 'undefined' && D.of && D.of.length >= 1 && D.integrations));
});
test.after(async () => { await browser?.close(); await S?.stop(); });

test('الإدارة لا تُخدم لغير المدير', async () => {
  for (const c of [undefined, customer.cookie, office.cookie]) {
    const r = await fetch(S.base + '/apps/admin/', { headers: c ? { cookie: c } : {}, redirect: 'manual' });
    assert.notEqual(r.status, 200, 'يجب ألا تظهر صفحة الإدارة');
  }
});

test('العملاء والمكاتب والطلبات والحوالات والتقييمات تُحمَّل من الخادم', async () => {
  assert.equal(await ev(() => D.cu.length), 1);
  assert.equal(await ev(() => D.or.length), 1);
  assert.equal(await ev(() => D.or[0].st), 'مكتمل');
  await S.request('/api/reviews', 'POST', { bookingId, rating: 5, comment: 'ممتاز' }, customer.cookie);
  await ev(() => SA_hydrateAdmin(true));
  assert.equal(await ev(() => D.rv.length), 1);
});

test('إخفاء تقييم من الإدارة ينعكس على الصفحة العامة', async () => {
  const id = await ev(() => D.rv[0].id);
  await ev((id) => { const i = E.rv.ac.findIndex((a) => a[2] === 'مخفي'); return ac('rv', id, i); }, id);
  await until(async () => (await S.request(`/api/public/offices/${office.id}/reviews`)).data.summary.count === 0);
});

test('محتوى المنصة (إعلان) يُحفظ في الخادم بصورته ويظهر للعامة', async () => {
  await ev((png) => { D.ads.push({ id: 1, h: 'إعلان اختبار', p: 'نص', im: png, tg: 'طيران', on: 1 }); sv(); }, png);
  await until(async () => (await S.request('/api/admin/docs?collection=ads', 'GET', undefined, admin)).data.docs.length === 1);
  const doc = (await S.request('/api/admin/docs?collection=ads', 'GET', undefined, admin)).data.docs[0];
  assert.ok(doc.data.im.startsWith('/assets/offers/'), 'الصورة أصل عام وليست base64');
  const pub = await S.request('/api/public/docs?collections=ads');
  assert.equal(pub.data.docs.ads[0].h, 'إعلان اختبار');
  await page.reload();
  await until(() => ev(() => D.ads.length === 1 && D.ads[0].h === 'إعلان اختبار'));
  await ev(() => { D.ads = []; sv(); });
  await until(async () => (await S.request('/api/admin/docs?collection=ads', 'GET', undefined, admin)).data.docs.length === 0);
});

test('الباقات: الإدارة تنشر، المكتب يطلب، الإدارة توافق وتفعّل الرصيد', async () => {
  await ev(() => SA_pushLive('pk', { n: 'باقة 5', sv: 'نقل دولي', qty: 5, price: 2500, cur: 'YER', on: 1 }));
  const pk = (await S.request('/api/packages', 'GET', undefined, office.cookie)).data.packages;
  assert.equal(pk.length, 1);
  await S.request('/api/office/package-purchases', 'POST', { packageId: pk[0].id }, office.cookie);
  await ev(() => SA_hydrateAdmin(true));
  assert.equal(await ev(() => D.pp.length), 1);
  assert.equal(await ev(() => D.pp[0].st), 'بانتظار المراجعة');
  const id = await ev(() => D.pp[0].id);
  for (const label of ['موافقة', 'تفعيل الرصيد']) await ev(([id, label]) => ac('pp', id, E.pp.ac.findIndex((a) => a[0] === label)), [id, label]);
  await until(async () => (await S.request('/api/office/package-purchases', 'GET', undefined, office.cookie)).data.quotas.some((q) => q.service_type === 'bus' && q.remaining === 5));
});

test('توثيق المكتب من لوحة الإدارة', async () => {
  const up = async (n) => (await S.request('/api/files', 'POST', { filename: n + '.png', mimeType: 'image/png', base64: b64(PNG) }, office.cookie)).data.file.id;
  await S.request('/api/office/verification', 'POST', { legalName: 'شركة', ownerName: 'مالك', ownerId: '123456', licenseNo: 'L', registrationNo: 'R', files: { licImg: await up('l'), crImg: await up('c') } }, office.cookie);
  await ev(() => SA_hydrateAdmin(true));
  assert.equal(await ev(() => D.ov.length), 1);
  assert.ok(await ev(() => D.ov[0].licImg.startsWith('/api/files/')));
  await ev(() => ac('ov', D.ov[0].id, E.ov.ac.findIndex((a) => a[0] === 'توثيق المكتب')));
  await until(async () => (await S.request('/api/public/offices')).data.offices[0].profile.verified === true);
});

test('الدعم: تذكرة من عميل، والإدارة ترد وتحلّها', async () => {
  const t = await S.request('/api/tickets', 'POST', { subject: 'مشكلة في الحجز', body: 'تفاصيل', kind: 'dispute', bookingId }, customer.cookie);
  await ev(() => SA_hydrateAdmin(true));
  assert.equal(await ev(() => D.tk.length), 1);
  assert.equal(await ev(() => D.tk[0].pr), 'عالية');
  await ev(() => { D.tk[0].res = 'تم التواصل مع المكتب'; return ac('tk', D.tk[0].id, E.tk.ac.findIndex((a) => a[0] === 'تم الحل')); });
  await until(async () => (await S.request('/api/tickets/' + t.data.ticket.id, 'GET', undefined, customer.cookie)).data.messages.some((m) => m.body === 'تم التواصل مع المكتب'));
  assert.equal((await S.request('/api/tickets/' + t.data.ticket.id, 'GET', undefined, customer.cookie)).data.ticket.status, 'resolved');
});

test('إيقاف عميل من الإدارة يمنعه من الدخول ويقطع جلسته', async () => {
  await ev(() => ac('cu', D.cu[0].id, E.cu.ac.findIndex((a) => /إيقاف|تعليق/.test(a[0])) >= 0 ? E.cu.ac.findIndex((a) => /إيقاف|تعليق/.test(a[0])) : 0));
  await until(async () => (await S.request('/api/bookings', 'GET', undefined, customer.cookie)).status === 401);
});

test('صفحة الربط الخارجي تعرض الخدمات الناقصة', async () => {
  await ev(() => go('int'));
  const txt = await ev(() => document.querySelector('#pg').innerText);
  assert.match(txt, /واتساب/);
  assert.match(txt, /WHATSAPP_ACCESS_TOKEN/);
});

test('لا أخطاء جافاسكربت في الصفحة طوال الاختبارات', () => assert.deepEqual(ERRS, []));
