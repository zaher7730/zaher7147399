// اختبار متصفح: لوحة الإدارة ترى المحادثة الحقيقية بين العميل والمكتب، وتغيير حالتها يُحفظ في الخادم ويمنع الرسائل.
import test from 'node:test';
import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { startServer, sleep } from '../helpers.mjs';

let S, browser, page, admin, office, customer, convId, ERRS = [];
const until = async (fn, ms = 8000) => { const end = Date.now() + ms; for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('timeout: ' + fn); await sleep(100); } };

test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000061', 'عميل المحادثة');
  const c = await S.request('/api/conversations', 'POST', { officeId: office.id }, customer.cookie);
  convId = c.data.conversation.id;
  await S.request(`/api/conversations/${convId}/messages`, 'POST', { body: 'سؤال من العميل للمكتب' }, customer.cookie);
  await S.request(`/api/conversations/${convId}/messages`, 'POST', { body: 'رد المكتب على العميل' }, office.cookie);
  browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, serviceWorkers: 'block' });
  await ctx.addCookies([{ name: 'safarak_session', value: admin.split('=')[1], url: S.base }]);
  page = await ctx.newPage();
  page.on('pageerror', (e) => ERRS.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.goto(S.base + '/apps/admin/');
  await until(() => page.evaluate(() => typeof D !== 'undefined' && Array.isArray(D.ch) && D.ch.length === 1));
});
test.after(async () => { await browser?.close(); await S?.stop(); });

test('الإدارة تحمّل المحادثة الحقيقية بنصها وأطرافها (لا بيانات وهمية)', async () => {
  const r = await page.evaluate(() => D.ch[0]);
  assert.equal(r.serverId, convId);
  assert.equal(r.st, 'مفتوحة');
  assert.match(r.m, /العميل: سؤال من العميل للمكتب/);
  assert.match(r.m, /المكتب: رد المكتب على العميل/);
});

test('صفحة المحادثات تعرضها، وتغيير الحالة إلى «مغلقة» يُحفظ في الخادم ويمنع الرسائل', async () => {
  await page.evaluate(() => go('ch'));
  await sleep(500);
  assert.match(await page.evaluate(() => document.body.innerText), /مفتوحة/);
  await page.evaluate(async () => { const r = D.ch[0]; r.st = 'مغلقة'; await SA_pushLive('ch', r); });
  const list = await S.request('/api/admin/conversations', 'GET', undefined, admin);
  assert.equal(list.data.conversations[0].status, 'closed');
  assert.equal((await S.request(`/api/conversations/${convId}/messages`, 'POST', { body: 'x' }, customer.cookie)).status, 409);
});

test('لا أخطاء جافاسكربت', () => assert.deepEqual(ERRS, []));
