// متصفح حقيقي: شاشات المراحل 7–10 في الإدارة (سجل عربي، نسخ احتياطي، حصص) والمكتب (تقييمات، سجل الطلب) والعميل (دعم، أجهزة، بيانات، دفع إلكتروني)
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { startServer, sleep } from '../helpers.mjs';

import { chromium } from 'playwright';
const SHOTS = process.env.SHOTS_DIR || '';
const ERRS = [];
let S, admin, office, customer, browser, bookingId;
const until = async (page, fn, ms = 8000) => { const end = Date.now() + ms; for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('timeout: ' + fn); await sleep(100); } };
const shot = async (page, name) => { if (SHOTS) { fs.mkdirSync(SHOTS, { recursive: true }); await page.screenshot({ path: `${SHOTS}/${name}.png` }); } };
const open = async (app, cookie, viewport, ready) => {
  const ctx = await browser.newContext({ viewport, serviceWorkers: 'block' });
  await ctx.addCookies([{ name: 'safarak_session', value: cookie.split('=')[1], url: S.base }]);
  const page = await ctx.newPage();
  page.on('pageerror', (e) => ERRS.push(app + ': ' + e.message));
  page.on('dialog', (d) => d.accept());
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.goto(S.base + '/apps/' + app + '/');
  const ev = (fn, arg) => page.evaluate(fn, arg);
  await until(page, () => ev(ready));
  return { page, ev, ctx };
};
const noOverflow = (ev) => ev(() => document.documentElement.scrollWidth <= window.innerWidth + 1);

test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
  const b = await S.request('/api/bookings', 'POST', { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details: {} }, customer.cookie);
  bookingId = b.data.booking.public_id;
  await S.request(`/api/bookings/${bookingId}/status`, 'PATCH', { status: 'in_progress' }, office.cookie);
  await S.request(`/api/bookings/${bookingId}/status`, 'PATCH', { status: 'completed' }, office.cookie);
  const rv = await S.request('/api/reviews', 'POST', { bookingId, rating: 5, comment: 'ممتاز جداً' }, customer.cookie);
  assert.equal(rv.status, 201, JSON.stringify(rv.data));
  browser = await chromium.launch();
});
test.after(async () => { await browser?.close(); await S?.stop(); });

test('الإدارة: سجل العمليات بالعربية + النسخ الاحتياطي + الحصص', async () => {
  const { page, ev } = await open('admin', admin, { width: 1280, height: 800 }, () => typeof D !== 'undefined' && D.of && D.of.length >= 1 && D.log && D.log.length > 0);
  // السجل
  await ev(() => go('log'));
  const rows = await ev(() => [...document.querySelectorAll('#pg tbody tr')].map((r) => r.innerText));
  assert.ok(rows.length >= 5);
  assert.ok(rows.every((t) => /[؀-ۿ]/.test(t)), 'كل صف فيه عربي');
  assert.ok(!rows.some((t) => /\b[a-z]+\.[a-z_]+\b/.test(t)), 'لا مفاتيح عمليات إنجليزية: ' + rows.find((t) => /\b[a-z]+\.[a-z_]+\b/.test(t)));
  assert.ok(rows.some((t) => t.includes('تغيير حالة حجز') && t.includes('مكتمل')));
  await shot(page, 'admin-log');
  // النسخ الاحتياطي
  await ev(() => go('bkp'));
  assert.ok(await ev(() => document.querySelector('#pg h1').textContent.includes('النسخ الاحتياطي')));
  await ev(() => SA_makeBackup());
  await until(page, () => ev(() => document.querySelectorAll('#pg tbody tr td[dir="ltr"]').length === 1));
  const bt = await ev(() => document.querySelector('#pg tbody tr').innerText);
  assert.match(bt, /safarak-.*\.sqlite/);
  assert.match(bt, /نعم/);
  await shot(page, 'admin-backups');
  // الحصص
  await ev(() => go('qt'));
  assert.ok(await ev(() => document.querySelector('#pg h1').textContent.includes('حصص المكاتب')));
  await ev(() => { document.querySelector('#qt_t').value = 'bus'; document.querySelector('#qt_n').value = '7'; SA_addQuota(); });
  await until(page, () => ev(() => [...document.querySelectorAll('#pg tbody tr')].some((r) => /النقل الدولي|نقل دولي/.test(r.innerText) && r.innerText.includes('7'))));
  await ev(() => SA_toggleEnforce());
  await until(page, () => ev(() => D.set.enforceQuota === true));
  assert.ok(await ev(() => document.querySelector('#pg').innerText.includes('مفعّل')));
  const sets = await S.request('/api/admin/settings', 'GET', undefined, admin);
  assert.equal(sets.data.settings.enforceQuota, true);
  await ev(() => SA_toggleEnforce());
  await shot(page, 'admin-quotas');
  // القائمة الجانبية تضم الصفحتين
  const side = await ev(() => document.querySelector('#sb').innerText);
  assert.ok(side.includes('النسخ الاحتياطي') && side.includes('حصص المكاتب'));
});

test('المكتب: رد على التقييم + سجل الطلب من الخادم', async () => {
  const { page, ev } = await open('office', office.cookie, { width: 1280, height: 800 }, () => typeof OK !== 'undefined' && OK === 1 && D.ord.length >= 1 && D.rvsLoaded === 1);
  await until(page, async () => (await ev(() => (document.querySelector('#sb') || {}).innerText || '')).includes('تقييمات العملاء'));
  await ev(() => go('rv'));
  const txt = await ev(() => document.querySelector('#pg').innerText);
  assert.ok(txt.includes('ممتاز جداً') && txt.includes('بانتظار ردك'));
  await shot(page, 'office-reviews');
  await ev(() => rvReply(D.rvs[0].id));
  await ev(() => { document.querySelector('#rv_t').value = 'شكراً لثقتك بنا'; rvReplySend(D.rvs[0].id); });
  await until(page, () => ev(() => D.rvs[0].officeReply === 'شكراً لثقتك بنا'));
  assert.ok((await ev(() => document.querySelector('#pg').innerText)).includes('شكراً لثقتك بنا'));
  const mine = await S.request('/api/reviews', 'GET', undefined, customer.cookie);
  assert.equal(mine.data.reviews[0].officeReply, 'شكراً لثقتك بنا');
  // سجل الطلب
  await ev(() => go('od', D.ord[0].id));
  await until(page, () => ev(() => D.ord[0].tlLoaded === 1));
  const log = await ev(() => [...document.querySelectorAll('#pg .card')].find((c) => c.querySelector('h3') && c.querySelector('h3').textContent === 'سجل الطلب').innerText);
  assert.match(log, /إنشاء الطلب/);
  assert.match(log, /تغيّرت الحالة من «قيد التنفيذ» إلى «مكتمل»/);
  assert.match(log, /تقييم العميل: 5/);
  assert.match(log, /ردّ المكتب/);
  await shot(page, 'office-order-log');
  assert.ok(await ev(() => typeof pdfO === 'function'));
});

for (const [name, vp] of [['mobile', { width: 390, height: 844 }], ['desktop', { width: 1280, height: 800 }]]) {
  test(`العميل (${name}): دعم، أجهزة، بياناتي، حذف الحساب، الدفع الإلكتروني`, async () => {
    const { page, ev, ctx } = await open('customer', customer.cookie, vp, () => typeof S !== 'undefined' && S.u.in === 1 && SA_tk.loaded === 1);
    // قائمة المزيد فيها التذاكر
    await ev(() => go('more'));
    assert.ok((await ev(() => document.querySelector('#m').innerText)).includes('تذاكر الدعم'));
    // تذكرة جديدة
    await ev(() => go('tickets'));
    if (name === 'mobile') assert.ok((await ev(() => document.querySelector('#m').innerText)).includes('لا توجد تذاكر بعد'));
    else assert.ok((await ev(() => document.querySelector('#m').innerText)).includes('استفسار عن الحجز'), 'تذاكر الجلسة السابقة تظهر');
    await ev(() => SA_newTicket());
    await ev((id) => { document.querySelector('#tk_s').value = 'استفسار عن الحجز'; document.querySelector('#tk_b').value = 'متى يتم تأكيد طلبي؟'; document.querySelector('#tk_o').value = id; }, bookingId);
    await shot(page, `customer-ticket-form-${name}`);
    await ev(() => SA_createTicket());
    await until(page, () => ev(() => S.scr === 'tkdet' && SA_tk.msgs.length === 1));
    assert.ok((await ev(() => document.querySelector('#m').innerText)).includes('متى يتم تأكيد طلبي؟'));
    // رد الإدارة يظهر للعميل
    const id = await ev(() => SA_tk.cur.id);
    await S.request(`/api/tickets/${id}/messages`, 'POST', { body: 'تم تأكيد طلبك' }, admin);
    await until(page, async () => { await ev((i) => SA_showTicket(i), id); return ev(() => document.querySelector('#m').innerText.includes('فريق الدعم')); });
    assert.ok((await ev(() => document.querySelector('#m').innerText)).includes('تم الرد عليك'));
    await ev(() => { document.querySelector('#tk_r').value = 'شكراً'; SA_replyTicket(); });
    await until(page, () => ev(() => SA_tk.msgs.length === 3));
    await shot(page, `customer-ticket-${name}`);
    assert.ok(await noOverflow(ev), 'لا تمرير أفقي في التذاكر');
    // أجهزتي
    await ev(() => go('settings'));
    const st = await ev(() => document.querySelector('#m').innerText);
    assert.ok(st.includes('أجهزتي المتصلة') && st.includes('تنزيل نسخة من بياناتي') && st.includes('طلب حذف حسابي'));
    await ev(() => go('devices'));
    await until(page, () => ev(() => SA_dv.loaded === 1 && document.querySelector('#m').innerText.includes('هذا الجهاز')));
    await shot(page, `customer-devices-${name}`);
    assert.ok(await noOverflow(ev), 'لا تمرير أفقي في الأجهزة');
    // جلسة ثانية ثم إنهاؤها من الواجهة
    const second = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
    await ev(() => { SA_dv.loaded = 0; SA_loadDevices(); });
    await until(page, () => ev(() => SA_dv.list.length >= 2));
    const other = await ev(() => SA_dv.list.find((s) => !s.current).id);
    await ev((i) => SA_revokeDevice(i), other);
    await until(page, () => ev((i) => !SA_dv.list.some((s) => s.id === i), other));
    assert.equal((await S.request('/api/me', 'GET', undefined, second.cookie)).status, 401, 'الجلسة المنتهية لم تعد صالحة');
    // تنزيل البيانات
    await ev(() => go('settings'));
    const dl = page.waitForEvent('download');
    await ev(() => SA_exportData());
    const d = await dl;
    assert.equal(d.suggestedFilename(), 'safarak-my-data.json');
    const exported = JSON.parse(fs.readFileSync(await d.path(), 'utf8'));
    assert.equal(exported.user.name, 'عميل تجريبي');
    // طلب الحذف (مرة واحدة فقط على كل التشغيل)
    if (name === 'mobile') {
      await ev(() => SA_requestDeletion());
      await until(page, () => ev(() => SA_deletionPending()));
      assert.ok((await ev(() => document.querySelector('#m').innerText)).includes('طلب حذف حسابي قيد المراجعة'));
    }
    await shot(page, `customer-settings-${name}`);
    // الدفع الإلكتروني: غير مفعّل افتراضياً فلا يظهر خياره ولا زره
    assert.equal(await ev(() => SA_online.on), false);
    assert.equal(await ev(() => payOpts()), '');
    assert.equal(await ev(() => onlinePayBox({ id: 'X', paymentStatus: 'pending', serverStatus: 'pending' })), '');
    assert.equal(await ev(() => { try { payT('e'); } catch (e) {} return S.pt || 'm'; }), 'm');
    // عند التفعيل يظهر الخيار والزر
    assert.ok(await ev(() => { SA_online.on = true; const a = payOpts().includes('دفع إلكتروني بالبطاقة'), b = onlinePayBox({ id: 'X', paymentStatus: 'pending', serverStatus: 'pending' }).includes('ادفع الآن'), c = onlinePayBox({ id: 'X', paymentStatus: 'confirmed', serverStatus: 'pending' }) === ''; SA_online.on = false; return a && b && c; }));
    await ctx.close();
  });
}

test('لا أخطاء جافاسكربت في أي تطبيق', () => {
  assert.deepEqual(ERRS, []);
});
