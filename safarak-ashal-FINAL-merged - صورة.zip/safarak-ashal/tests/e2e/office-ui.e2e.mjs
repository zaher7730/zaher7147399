// اختبار متصفح حقيقي للوحة المكتب مقابل الخادم: طلبات، محادثة لحظية، حفظ الملف والوثائق، التوثيق، الباقات، النافذة المنبثقة.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, PNG, b64, sleep } from '../helpers.mjs';

import { chromium } from 'playwright';
const ERRS = [];
let S, admin, office, customer, browser, page;
const until = async (fn, ms = 6000) => { const end = Date.now() + ms; for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('timeout: ' + fn); await sleep(100); } };
const ev = (fn, arg) => page.evaluate(fn, arg);
const waitBoot = () => until(() => ev(() => typeof OK !== 'undefined' && OK === 1 && window.__bootDone === 1), 15000);
const png = 'data:image/png;base64,' + b64(PNG);

test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
  await S.request('/api/bookings', 'POST', { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details: {} }, customer.cookie);
  browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, serviceWorkers: 'block' });
  await ctx.addCookies([{ name: 'safarak_session', value: office.cookie.split('=')[1], url: S.base }]);
  page = await ctx.newPage();
  page.on('pageerror', (e) => ERRS.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  // نعلّم انتهاء التهيئة فقط عند استدعاء go من boot.js نفسه (الاستدعاء الأخير للإقلاع)
  await page.addInitScript(() => {
    const t = setInterval(() => {
      if (typeof window.go !== 'function' || window.__goHooked) return;
      window.__goHooked = 1; clearInterval(t);
      const og = window.go;
      window.go = function (...a) { const r = og.apply(this, a); if (/boot\.js:24:/.test(new Error().stack)) window.__bootDone = 1; return r; };
    }, 0);
  });
  await page.goto(S.base + '/apps/office/');
  // انتظر اكتمال تهيئة الواجهة: الرئيسية تُرسم بعد انتهاء المزامنة، فلا يسبقها انتقال الاختبار
  await waitBoot();
});
test.after(async () => { await browser?.close(); await S?.stop(); });

test('الطلبات والخدمات ووسائل الدفع تُحمَّل من الخادم', async () => {
  assert.equal(await ev(() => D.ord.length), 1);
  assert.equal(await ev(() => D.ord[0].ph), '+967770000003');
  assert.equal(await ev(() => D.bk.length), 1);
  assert.ok(await ev(() => D.ofr.bus.length >= 1));
});

test('النافذة المنبثقة وزر القائمة يعملان (دالتان كانتا مفقودتين)', async () => {
  await ev(() => go('banks'));
  assert.equal(await ev(() => typeof mo + typeof tgs), 'functionfunction');
  await ev(() => mo('تجربة', '<p>نص</p>', 'cm()'));
  assert.ok(await ev(() => !!document.querySelector('#md .mc')));
  await ev(() => cm());
});

test('طلب جديد من عميل يصل لحظياً للمكتب', async () => {
  await S.request('/api/bookings', 'POST', { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 2, totalAmount: 1000, currency: 'YER', details: {} }, customer.cookie);
  await until(() => ev(() => D.ord.length === 2));
});

test('محادثة لحظية مع مرفق في الاتجاهين', async () => {
  const ph = '+967770000003';
  await ev(() => go('chats'));
  const conv = (await S.request('/api/conversations', 'POST', { officeId: office.id }, customer.cookie)).data.conversation;
  await S.request(`/api/conversations/${conv.id}/messages`, 'POST', { body: 'هل المقعد متاح؟' }, customer.cookie);
  await until(() => ev((p) => D.ch[p] && D.ch[p].un === 1, ph));
  await ev((p) => { F.ch = p; go(); }, ph);
  await until(() => ev((p) => D.ch[p].loaded && D.ch[p].m.some((m) => m.x === 'هل المقعد متاح؟'), ph));
  await until(async () => (await S.request('/api/messages/unread-count', 'GET', undefined, office.cookie)).data.count === 0);
  await ev(() => { $('#mi').value = 'نعم متاح'; sm(); });
  await until(() => ev((p) => D.ch[p].m.some((m) => m.me && m.id && m.x === 'نعم متاح'), ph));
  const msgs = (await S.request(`/api/conversations/${conv.id}/messages`, 'GET', undefined, customer.cookie)).data.messages;
  assert.ok(msgs.some((m) => m.body === 'نعم متاح'));
  await ev(async (a) => SA_officeSendFile(a.ph, 'عميل', { n: 'ticket.png', type: 'image/png', data: a.png }, 'تذكرة', null, ''), { ph, png });
  const after = (await S.request(`/api/conversations/${conv.id}/messages`, 'GET', undefined, customer.cookie)).data.messages;
  const f = after.find((m) => m.kind === 'image');
  assert.ok(f && f.fileName === 'ticket.png');
  assert.equal((await fetch(S.base + f.fileUrl, { headers: { cookie: customer.cookie } })).status, 200);
});

test('حفظ ملف المكتب: الاسم والمدينة وصورة الشعار والوثائق الخاصة', async () => {
  await ev((png) => { D.pf.name = 'مكتب النور'; D.pf.city = 'عدن'; D.pf.about = 'نبذة'; D.pf.logo = png; D.pf.licImg = png; D.pf.crImg = png; D.cfg.cancel = 'سياسة'; save(); }, png);
  await until(async () => (await S.request('/api/office/profile', 'GET', undefined, office.cookie)).data.profile?.displayName === 'مكتب النور');
  const prof = (await S.request('/api/office/profile', 'GET', undefined, office.cookie)).data.profile;
  assert.ok(prof.logo.startsWith('/assets/offers/'));
  const st = (await S.request('/api/state/office-data', 'GET', undefined, office.cookie)).data.value;
  assert.equal(st.cfg.cancel, 'سياسة');
  assert.ok(!JSON.stringify(st).includes('base64'), 'لا صور base64 داخل الحالة');
  assert.ok(st.pf.licImg.startsWith('/api/files/'));
  assert.equal(st.pf.pwh, undefined);
  // إعادة تحميل: البيانات تعود من الخادم
  await page.reload();
  await waitBoot();
  await until(() => ev(() => OK === 1 && D.pf.name === 'مكتب النور' && D.cfg.cancel === 'سياسة'));
  assert.ok(await ev(() => D.pf.licImg.startsWith('/api/files/')));
});

test('طلب التوثيق ثم اعتماد المدير يظهر في لوحة المكتب', async () => {
  await ev(() => { Object.assign(D.pf, { lname: 'شركة النور', cr: 'R-9', lic: 'L-9', owner: 'المالك', ownerId: '123456' }); });
  assert.equal(await ev(() => SA_submitVerification()), true);
  assert.equal((await S.request('/api/admin/office-verifications', 'GET', undefined, admin)).data.verifications[0].status, 'pending');
  await S.request(`/api/admin/office-verifications/${office.id}`, 'PATCH', { status: 'approved' }, admin);
  await page.reload();
  await waitBoot();
  await until(() => ev(() => OK === 1 && D.pf.ver === 2));
});

test('شراء عروض تطبيقنا: باقة الإدارة وطلب كمية مخصصة', async () => {
  const pk = await S.request('/api/admin/packages', 'POST', { title: 'باقة 10 رحلات', serviceType: 'bus', quantity: 10, price: 5000, currency: 'YER' }, admin);
  assert.equal(pk.status, 201, JSON.stringify(pk.data));
  await ev(() => { D.pk = null; go('pkg'); });
  await until(() => ev(() => D.pk && D.pk.loaded && D.pk.list.length === 1));
  await until(() => ev(() => /باقة 10 رحلات/.test(document.querySelector('#pg').innerText)));
  await ev((id) => pkReq(id), pk.data.package?.id ?? pk.data.id);
  await ev(() => { go('pkg'); mo('x', '<select id="pk_t"><option value="air">a</option></select><input id="pk_q" value="7"><input id="pk_n" value="ملاحظة">', ''); return pkCustomSend(); });
  await until(() => ev(() => D.pk.purchases.length === 2));
  const list = (await S.request('/api/admin/package-purchases', 'GET', undefined, admin)).data.purchases;
  assert.equal(list.length, 2);
  assert.ok(list.some((p) => p.custom_request === 1 && p.quantity === 7));
});

test('لا أخطاء جافاسكربت في الصفحة طوال الاختبارات', () => assert.deepEqual(ERRS, []));
