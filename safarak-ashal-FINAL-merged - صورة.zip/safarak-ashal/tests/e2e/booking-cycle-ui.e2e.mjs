// دورة الحجز الكاملة عبر الواجهات الحقيقية: العميل يختار الخدمة ويرفع السند PDF ويرسل الحجز،
// ثم المكتب يراجع الحوالة ويغيّر الحالة، ثم العميل يرى النتيجة ويقيّم، والإدارة ترى السجل.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, PNG, PDF, sleep } from '../helpers.mjs';

import { chromium } from 'playwright';

const until = async (fn, ms = 8000) => { const end = Date.now() + ms; for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('timeout'); await sleep(100); } };
let S, admin, office, customer, other, browser, ctx, page, bookingId, paymentId;
const ERRS = [];

test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  // خدمة حافلة تعمل كل يوم حتى تظهر للعميل
  const sync = await S.request('/api/office/services/sync', 'PUT', { services: [{ serviceType: 'bus', title: 'رحلة اختبار', details: { price: 500, currency: 'YER', from: 'عدن', to: 'المكلا', days: 'يومي', seats: 10 }, active: true }] }, office.cookie);
  assert.equal(sync.status, 200, JSON.stringify(sync.data));
  customer = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
  other = await S.otpLogin('customer', '770000005', 'عميل آخر');
  browser = await chromium.launch();
  ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: 'block' });
  await ctx.addCookies([{ name: 'safarak_session', value: customer.cookie.split('=')[1], url: S.base }]);
  page = await ctx.newPage();
  page.on('pageerror', (e) => ERRS.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.goto(S.base + '/apps/customer/');
  await page.waitForFunction(() => typeof S !== 'undefined' && S.u.in === 1 && typeof OFFS !== 'undefined' && OFFS.length >= 1, null, { timeout: 15000 });
  await page.evaluate((oid) => SA_loadPaymentMethods(oid), office.id);
  await page.waitForFunction(() => BANKS.length + PMS.length > 0, null, { timeout: 10000 });
});
test.after(async () => { await browser?.close(); await S?.stop(); });

const clickBtn = async (text) => { const ok = await page.evaluate((t) => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes(t)); if (!b) return false; b.click(); return true; }, text); if (!ok) throw new Error('button not found: ' + text); };
const clickOn = (onclick) => page.evaluate((o) => { const b = [...document.querySelectorAll('button')].find((x) => (x.getAttribute('onclick') || '') === o); if (!b) throw new Error('no button ' + o); b.click(); }, onclick);

async function fillBookingForm() {
  await page.evaluate(() => {
    for (const x of missing(fields(S.o))) {
      const [t, k] = x;
      if (t === 'c') S.v[k] = Math.max(1, +S.v[k] || 1);
      else if (t === 'tg') S.v[k] = x[4][0];
      else if (t === 'd') S.v[k] = '1990-01-01';
      else if (t === 'p') S.v[k] = '+967770000003';
      else if (t === 's') S.v[k] = x[4][0];
      else if (t === 'sd') S.v[k] = seatMap(S.o).filter((a) => a[1] > 0)[0][0];
      else if (t === 't') S.v[k] = 'تجربة ' + k;
    }
    S.v.a = Math.max(1, +S.v.a || 1);
    render();
  });
  await sleep(200);
  const fKeys = await page.evaluate(() => missing(fields(S.o)).filter((x) => x[0] === 'f').map((x) => x[1]));
  for (const k of fKeys) {
    await page.locator(`input[type=file][onchange*="S.fl['${k}']"]`).setInputFiles({ name: k + '.png', mimeType: 'image/png', buffer: PNG });
    await sleep(300);
  }
}

test('العميل يختار الخدمة من المكتب ويصل إلى شاشة الدفع', async () => {
  await page.evaluate((oid) => { const i = OFFS.findIndex((o) => o.id === oid); return oSvc(i, 'bus'); }, office.id);
  await sleep(300);
  assert.equal(await page.evaluate(() => S.o.serviceId), office.serviceId);
  await clickBtn('ابدأ الحجز الآن');
  await sleep(300);
  await fillBookingForm();
  assert.deepEqual(await page.evaluate(() => missing(fields(S.o)).map((x) => x[1])), []);
  await clickOn('toPay()');
  await sleep(300);
  assert.equal(await page.evaluate(() => S.scr), 'pay');
});

test('إرسال بلا سند يُمنع ولا يُنشأ حجز', async () => {
  await clickOn('pmBank(0)');
  await sleep(200);
  const total = await page.evaluate(() => total());
  await page.evaluate((t) => { document.querySelector('[data-k="tn"]').value = 'عميل تجريبي'; document.querySelector('[data-k="tr"]').value = 'TX-NONE'; }, total);
  await clickOn('send()');
  await sleep(1500);
  const list = (await S.request('/api/bookings', 'GET', undefined, customer.cookie)).data.bookings;
  assert.equal(list.length, 0);
});

test('السند PDF يُرفع ويُربط بالحوالة، وليس بصورة الهوية', async () => {
  await page.locator(`input[type=file][onchange*="S.fl['rc']"]`).setInputFiles({ name: 'receipt.pdf', mimeType: 'application/pdf', buffer: PDF });
  await until(() => page.evaluate(() => String(S.fu.rc || '').startsWith('data:application/pdf;base64,')));
  const total = await page.evaluate(() => total());
  await page.evaluate((t) => { document.querySelector('[data-k="tn"]').value = 'عميل تجريبي'; document.querySelector('[data-k="tr"]').value = 'TX-PDF'; }, total);
  await clickOn('send()');
  await until(() => page.evaluate(() => S.scr === 'done'));
  const list = (await S.request('/api/bookings', 'GET', undefined, customer.cookie)).data.bookings;
  assert.equal(list.length, 1);
  bookingId = list[0].public_id;
  assert.equal(list[0].payment_status, 'submitted');
  const pays = (await S.request(`/api/bookings/${bookingId}/payments`, 'GET', undefined, customer.cookie)).data.payments;
  assert.equal(pays.length, 1);
  paymentId = pays[0].id;
  const files = (await S.request('/api/files', 'GET', undefined, customer.cookie)).data.files;
  const receipt = files.find((f) => f.id === pays[0].receipt_file_id);
  assert.ok(receipt, 'payment must reference a stored receipt');
  assert.equal(receipt.mime_type, 'application/pdf');
  assert.equal(receipt.original_name, 'rc.pdf');
});

test('المكتب يرى الحوالة ويؤكدها، والعميل يرى الحالة ويُشعَر', async () => {
  const list = (await S.request('/api/office/payments', 'GET', undefined, office.cookie)).data.payments;
  assert.ok(list.some((p) => p.id === paymentId && p.original_name === 'rc.pdf'));
  // المكتب يؤكد الحوالة من واجهته الحقيقية
  const octx = await browser.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: 'block' });
  await octx.addCookies([{ name: 'safarak_session', value: office.cookie.split('=')[1], url: S.base }]);
  const op = await octx.newPage();
  const oerr = [];
  op.on('pageerror', (e) => oerr.push(e.message));
  await op.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await op.goto(S.base + '/apps/office/');
  await op.waitForFunction((pid) => typeof D !== 'undefined' && Array.isArray(D.rm) && D.rm.some((x) => x.serverId === pid), paymentId, { timeout: 15000 });
  const shown = await op.evaluate((pid) => { const r = D.rm.find((x) => x.serverId === pid); return { oid: r.oid, file: !!r.receiptFileId }; }, paymentId);
  assert.equal(shown.oid, bookingId);
  assert.equal(shown.file, true);
  await op.evaluate((pid) => { const r = D.rm.find((x) => x.serverId === pid); return rmc(r.id); }, paymentId);
  await until(async () => (await S.request('/api/office/payments', 'GET', undefined, office.cookie)).data.payments.find((p) => p.id === paymentId)?.status === 'confirmed');
  assert.deepEqual(oerr, []);
  await octx.close();
  const b = (await S.request('/api/bookings/' + bookingId, 'GET', undefined, customer.cookie)).data.booking;
  assert.equal(b.payment_status, 'confirmed');
  const n = (await S.request('/api/notifications', 'GET', undefined, customer.cookie)).data.notifications;
  assert.ok(n.some((x) => x.kind === 'payment_review'));
  await page.evaluate(() => SA_loadBookings());
  await until(() => page.evaluate((id) => S.ord.some((x) => x.id === id), bookingId));
});

test('المكتب ينهي الحجز، والعميل يقيّم، والإدارة ترى السجل', async () => {
  assert.equal((await S.request(`/api/bookings/${bookingId}/status`, 'PATCH', { status: 'completed' }, office.cookie)).status, 200);
  await page.evaluate(() => SA_loadBookings());
  await until(() => page.evaluate((id) => S.ord.some((x) => x.id === id && x.st === 2), bookingId));
  const r = await S.request('/api/reviews', 'POST', { bookingId, rating: 5, comment: 'ممتاز' }, customer.cookie);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal((await S.request('/api/reviews', 'POST', { bookingId, rating: 4 }, other.cookie)).status, 404);
  const ab = (await S.request('/api/admin/bookings', 'GET', undefined, admin)).data.bookings;
  assert.ok(ab.some((x) => x.public_id === bookingId && x.status === 'completed'));
});

test('بعد إعادة التحميل والخروج والدخول تبقى الحجوزات والحالة كما هي', async () => {
  await page.reload();
  await page.waitForFunction(() => typeof S !== 'undefined' && S.u.in === 1 && typeof SA_loadBookings === 'function', null, { timeout: 15000 });
  await page.evaluate(() => SA_loadBookings());
  await until(() => page.evaluate((id) => S.ord.some((x) => x.id === id && x.st === 2), bookingId));
  assert.equal((await S.request('/api/auth/logout', 'POST', {}, customer.cookie)).status, 200);
  const again = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
  customer = again;
  const b = (await S.request('/api/bookings', 'GET', undefined, again.cookie)).data.bookings.find((x) => x.public_id === bookingId);
  assert.ok(b, 'booking must persist after re-login');
  assert.equal(b.status, 'completed');
  assert.equal(b.payment_status, 'confirmed');
});

test('حماية الوصول: عميل آخر ومكتب آخر لا يصلان للسند ولا للحوالة', async () => {
  const files = (await S.request('/api/files', 'GET', undefined, customer.cookie)).data.files;
  const rc = files.find((f) => f.original_name === 'rc.pdf');
  assert.equal((await fetch(S.base + '/api/files/' + rc.id, { headers: { cookie: other.cookie } })).status, 403);
  assert.equal((await S.request(`/api/bookings/${bookingId}/payments`, 'GET', undefined, other.cookie)).status, 403);
});

test('فشل رفع السند: الحجز يُحفظ، ويظهر زر إعادة الإرسال، ونجاح الإعادة يسجّل الحوالة بالسند الصحيح', async () => {
  // جلسة العميل بعد تسجيل الخروج في الاختبار السابق
  await ctx.clearCookies();
  await ctx.addCookies([{ name: 'safarak_session', value: customer.cookie.split('=')[1], url: S.base }]);
  await page.reload();
  await page.waitForFunction(() => typeof S !== 'undefined' && S.u.in === 1 && typeof OFFS !== 'undefined' && OFFS.length >= 1, null, { timeout: 15000 });
  await page.evaluate((oid) => SA_loadPaymentMethods(oid), office.id);
  await page.waitForFunction(() => BANKS.length + PMS.length > 0, null, { timeout: 10000 });
  await page.evaluate((oid) => { const i = OFFS.findIndex((o) => o.id === oid); return oSvc(i, 'bus'); }, office.id);
  await sleep(300);
  await clickBtn('ابدأ الحجز الآن');
  await sleep(300);
  await fillBookingForm();
  await clickOn('toPay()');
  await sleep(300);
  await clickOn('pmBank(0)');
  await sleep(200);
  // اعتراض رفع السند فقط (الملف rc) لمحاكاة فشل الشبكة
  await page.route('**/api/files', async (route) => {
    if ((route.request().postData() || '').includes('"filename":"rc.')) return route.abort();
    return route.continue();
  });
  await page.locator(`input[type=file][onchange*="S.fl['rc']"]`).setInputFiles({ name: 'receipt.pdf', mimeType: 'application/pdf', buffer: PDF });
  await until(() => page.evaluate(() => String(S.fu.rc || '').startsWith('data:application/pdf;base64,')));
  const total = await page.evaluate(() => total());
  await page.evaluate((t) => { document.querySelector('[data-k="tn"]').value = 'عميل تجريبي'; document.querySelector('[data-k="tr"]').value = 'TX-RETRY'; }, total);
  await clickOn('send()');
  await until(() => page.evaluate(() => S.scr === 'done' && !!S.ord[0] && !!S.ord[0].pendingPayment));
  const pid = await page.evaluate(() => S.ord[0].id);
  const pending = (await S.request(`/api/bookings/${pid}`, 'GET', undefined, customer.cookie)).data.booking;
  assert.equal(pending.payment_status, 'pending', 'booking saved without payment');
  assert.equal((await S.request(`/api/bookings/${pid}/payments`, 'GET', undefined, customer.cookie)).data.payments.length, 0);
  // رفع السند يعود طبيعياً ثم إعادة الإرسال من الزر
  await page.unroute('**/api/files');
  assert.ok(await page.evaluate(() => !!document.querySelector('button[onclick^="retryPayment("]')), 'retry button visible');
  await page.evaluate((id) => retryPayment(id), pid);
  await until(async () => (await S.request(`/api/bookings/${pid}`, 'GET', undefined, customer.cookie)).data.booking.payment_status === 'submitted');
  const pays = (await S.request(`/api/bookings/${pid}/payments`, 'GET', undefined, customer.cookie)).data.payments;
  assert.equal(pays.length, 1);
  const files = (await S.request('/api/files', 'GET', undefined, customer.cookie)).data.files;
  const rc = files.find((f) => f.id === pays[0].receipt_file_id);
  assert.equal(rc.original_name, 'rc.pdf');
  assert.equal(rc.mime_type, 'application/pdf');
});

test('لا أخطاء JavaScript في الصفحة أثناء الدورة', () => {
  assert.deepEqual(ERRS, []);
});
