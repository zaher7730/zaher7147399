// اختبار متصفح حقيقي لواجهة العميل مقابل الخادم: محادثة ومرفق، لحظي، مفضلة، تقييم، إلغاء، ملف شخصي.
// التشغيل: npm run test:e2e  (يحتاج playwright مثبتاً عالمياً أو في devDependencies)
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, PNG, b64, sleep } from '../helpers.mjs';

import { chromium } from 'playwright';

const ERRS = [];
let S, admin, office, customer, browser, page, ctx;
const until = async (fn, ms = 6000) => { const end = Date.now() + ms; for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('timeout: ' + fn); await sleep(100); } };
const ev = (fn, arg) => page.evaluate(fn, arg);

test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
  browser = await chromium.launch();
  ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: 'block' });
  await ctx.addCookies([{ name: 'safarak_session', value: customer.cookie.split('=')[1], url: S.base }]);
  page = await ctx.newPage();
  page.on('pageerror', (e) => ERRS.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.goto(S.base + '/apps/customer/');
  await until(() => ev(() => typeof S !== 'undefined' && S.u.in === 1));
});
test.after(async () => { await browser?.close(); await S?.stop(); });

test('الجلسة قائمة والمكتب المنشور ظاهر', async () => {
  await until(() => ev(() => OFFS.length >= 1));
  assert.equal(await ev(() => S.u.name), 'عميل تجريبي');
});

let bookingId;
test('الحجز الحقيقي ثم إلغاؤه من الواجهة', async () => {
  const r = await S.request('/api/bookings', 'POST', { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details: {} }, customer.cookie);
  bookingId = r.data.booking.public_id;
  await ev(() => SA_loadBookings());
  await until(() => ev((id) => S.ord.some((x) => x.id === id), bookingId));
  await ev(() => cancelO(0));
  await until(() => ev(() => S.ord[0].st === 6));
  assert.equal((await S.request('/api/bookings/' + bookingId, 'GET', undefined, customer.cookie)).data.booking.status, 'cancelled');
});

test('محادثة: إرسال نص ومرفق صورة من الواجهة، واستلام رد المكتب لحظياً', async () => {
  await ev((oid) => { S.hist = []; S.cur = 'O' + OFFS.findIndex((o) => o.id === oid); go('chat'); }, office.id);
  await until(() => ev(() => { const c = Object.values(S.cv)[0]; return c && c.loaded; }));
  await ev(() => { $('#cm').value = 'السلام عليكم، هل المقعد متاح؟'; return sm(); });
  await until(() => ev(() => Object.values(S.cv)[0].msgs.some((m) => m.me && m.id)));
  const conv = (await S.request('/api/conversations', 'GET', undefined, office.cookie)).data.conversations[0];
  const msgs = (await S.request(`/api/conversations/${conv.id}/messages`, 'GET', undefined, office.cookie)).data.messages;
  assert.equal(msgs[0].body, 'السلام عليكم، هل المقعد متاح؟');
  // مرفق: صورة PNG
  await page.setInputFiles('body', []).catch(() => {});
  await ev(() => { const i = document.createElement('input'); i.type = 'file'; i.id = 'tst'; document.body.append(i); });
  await page.setInputFiles('#tst', { name: 'p.png', mimeType: 'image/png', buffer: PNG });
  await ev(() => att(document.getElementById('tst')));
  await until(() => ev(() => Object.values(S.cv)[0].msgs.some((m) => m.img)));
  const after = (await S.request(`/api/conversations/${conv.id}/messages`, 'GET', undefined, office.cookie)).data.messages;
  assert.ok(after.some((m) => m.kind === 'image' && m.fileName));
  // رد المكتب يصل بدون إعادة تحميل
  await S.request(`/api/conversations/${conv.id}/messages`, 'POST', { body: 'نعم متاح' }, office.cookie);
  await until(() => ev(() => Object.values(S.cv)[0].msgs.some((m) => !m.me && m.m === 'نعم متاح')));
  // الإشعار اللحظي وصل
  await until(() => ev(() => (S.nts || []).some((n) => n.kind === 'message')));
});

test('إعادة تحميل الصفحة تُبقي المحادثة (محفوظة في الخادم)', async () => {
  await page.reload();
  await until(() => ev(() => typeof S !== 'undefined' && S.u.in === 1 && Object.values(S.cv).length > 0));
  await ev(() => { S.cur = Object.values(S.cv)[0].id; go('chat'); });
  await until(() => ev(() => Object.values(S.cv)[0].msgs.length >= 3));
});

test('المفضلة: مكتب يُحفظ ويبقى بعد إعادة التحميل', async () => {
  await until(() => ev(() => OFFS.length > 0));
  await ev(() => tfo(0));
  await until(async () => (await S.request('/api/favorites', 'GET', undefined, customer.cookie)).data.favorites.length === 1);
  await page.reload();
  await until(() => ev(() => S.u.in === 1 && S.fo.length === 1));
});

test('التقييم يُقبل بعد اكتمال حجز فقط', async () => {
  await ev(() => addRv(0).catch?.(() => {}));
  const b2 = await S.request('/api/bookings', 'POST', { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details: {} }, customer.cookie);
  const id = b2.data.booking.public_id;
  await S.request(`/api/bookings/${id}/status`, 'PATCH', { status: 'completed' }, office.cookie);
  await ev(() => SA_loadBookings());
  await ev(() => SA_loadMyReviews());
  await until(() => ev((i) => S.ord.some((x) => x.id === i && x.st === 2), id));
  const ok = await ev(async (oid) => SA_submitReview(oid, 4, 'خدمة جيدة'), office.id);
  assert.equal(ok, true);
  const pub = await S.request(`/api/public/offices/${office.id}/reviews`);
  assert.equal(pub.data.summary.count, 1);
});

test('الملف الشخصي: حفظ الاسم والهوية ورفع صورة الهوية الخاصة', async () => {
  await ev(() => go('acct'));
  await ev(() => { S.u.name = 'عميل معدّل'; S.u.idt = 'جواز'; S.u.idn = 'A1234567'; });
  await ev(() => { const i = document.createElement('input'); i.type = 'file'; i.id = 'idf'; document.body.append(i); });
  await page.setInputFiles('#idf', { name: 'id.png', mimeType: 'image/png', buffer: PNG });
  await ev(() => { S.u.idiFile = document.getElementById('idf').files[0]; });
  assert.equal(await ev(() => SA_saveProfile()), true);
  const me = (await S.request('/api/me', 'GET', undefined, customer.cookie)).data;
  assert.equal(me.user.name, 'عميل معدّل');
  assert.equal(me.profile.idNumber, 'A1234567');
  assert.ok(me.profile.idFileId);
});

test('الخروج يمسح بيانات المستخدم من الذاكرة ويقطع الجلسة', async () => {
  await ev(() => logout());
  await until(() => ev(() => S.u.in === 0 && S.ord.length === 0 && Object.keys(S.cv).length === 0));
  assert.equal((await S.request('/api/bookings', 'GET', undefined, customer.cookie)).status, 401);
});

test('محتوى الإدارة: إعلان وخدمة مخفية وصفحة سياسة معدّلة تظهر في تطبيق العميل', async () => {
  const put = async (c, id, data) => { const r = await S.request(`/api/admin/docs/${c}/${id}`, 'PUT', { data, public: true }, admin); assert.equal(r.status, 200, JSON.stringify(r.data)); };
  await put('ads', '1', { id: 1, h: 'عرض الصيف', p: 'خصم خاص', im: '/shared/assets/brand/logo.png', tg: 'طيران', on: 1 });
  await put('sv', '1', { id: 1, n: 'تأجير السيارات', p: 'وصف جديد', on: 0 });
  await put('pg', '1', { id: 1, n: 'سياسة الخصوصية', body: 'نص سياسة جديد من الإدارة', upd: '2026-10-26' });
  await page.goto(S.base + '/apps/customer/');
  await until(() => ev(() => typeof S !== 'undefined' && S.u.in === 0 && window.SA_PAGES));
  // العميل خرج في الاختبار السابق: نحمّل المحتوى العام فقط
  await ev(() => SA_loadPublicDocs());
  assert.equal(await ev(() => ADS.length), 2);
  await ev(() => { S.u.in = 1; S.u.name = 'ع'; S.hist = []; go('home'); });
  const html = await ev(() => document.querySelector('.hm').innerHTML);
  assert.ok(html.includes('عرض الصيف'));
  assert.ok(!html.includes("go('cars')"), 'خدمة التأجير مخفية');
  await ev(() => go('policy'));
  assert.ok((await ev(() => document.body.innerText)).includes('نص سياسة جديد من الإدارة'));
});

test('تتبع الإدارة: مدن ومستندات مطلوبة، وبصمة تظهر تحت خدمات أخرى، وعملة الريال لا الدولار', async () => {
  const put = async (c, id, data) => { const r = await S.request(`/api/admin/docs/${c}/${id}`, 'PUT', { data, public: true }, admin); assert.equal(r.status, 200, JSON.stringify(r.data)); };
  await put('ct', '1', { id: 1, n: 'تعز', ty: 'داخلية', on: 1 });
  await put('ct', '2', { id: 2, n: 'عدن', ty: 'داخلية', on: 1 });
  await put('ct', '3', { id: 3, n: 'المكلا', ty: 'داخلية', on: 0 });
  await put('rq', '1', { id: 1, sv: 'نقل دولي', req: ['جواز سفر', 'كشف حساب بنكي'] });
  const sy = await S.request('/api/office/services/sync', 'PUT', { services: [
    { serviceType: 'bus', title: 'رحلة اختبار', active: true, details: { price: 500, currency: 'YER', from: 'عدن', to: 'المكلا', days: 'يومياً', seats: 10 } },
    { serviceType: 'visa', title: 'برنت بصمة', active: true, details: { svc: 'برنت بصمة', price: 50, currency: 'YER' } },
  ] }, office.cookie);
  assert.equal(sy.status, 200, JSON.stringify(sy.data));
  await page.goto(S.base + '/apps/customer/');
  await until(() => ev(() => typeof S !== 'undefined' && window.SA_PAGES && OFFS.length >= 1 && VISA.length >= 1 && VCT.length === 2));
  // المدن: المعطّلة في الإدارة لا تظهر، وشريط مدن التأشيرات هو مدن الإدارة المفعّلة
  assert.deepEqual(await ev(() => CT.bus), ['عدن']);
  assert.deepEqual(await ev(() => VCT), ['تعز', 'عدن']);
  // لا ترجع قائمة المدن الافتراضية إذا كانت كل المدن الداخلية التي أدارتها الإدارة معطّلة.
  assert.deepEqual(await ev(() => { SA_CITY_RULES['تعز'].on = false; SA_CITY_RULES['عدن'].on = false; SA_refreshCities(); return VCT; }), []);
  await ev(() => { SA_CITY_RULES['تعز'].on = true; SA_CITY_RULES['عدن'].on = true; SA_refreshCities(); });
  // عملة العرض تُقرأ من details.currency إذا لم يوجد cur على العرض نفسه.
  assert.equal(await ev(() => curOf({ details: { currency: 'SAR' } })), 'SAR');
  // صيغ «صورة شخصية» الشائعة تُطابق الحقل الموجود ولا تضيف رفعاً مكرراً.
  assert.ok(await ev(() => SA_DOC_ALIAS['صورة شخصية'].includes('صورتين شخصية')));
  // برنت بصمة: خدمة منشورة من مكتب تظهر في «خدمات أخرى» بسعر بالريال
  const visa = await ev(() => { OFFS.forEach((o) => { o.c = 'تعز'; }); S.F.visa = { c: 'تعز', x: 'برنت بصمة' }; return visaPage('visa', VISA, '', ''); });
  assert.ok(visa.includes('برنت بصمة') && visa.includes('YER50') && !visa.includes('$'), 'بطاقة البصمة بالريال');
  // المستندات: ما تطلبه الإدارة يُضاف حقل رفع إلزامياً دون تكرار حقل الجواز الموجود
  const f = await ev(() => { S.o = { k: 'bus', n: 'x', from: 'عدن', to: 'المكلا', pr: 1, tot: 5, left: 5, details: {} }; return fields(S.o); }).then((r) => r.filter((x) => x[0] == 'f').map((x) => x[2]));
  assert.equal(f.filter((l) => l.includes('كشف حساب')).length, 1);
  assert.equal(f.filter((l) => l == 'جواز سفر').length, 0);
  // خانة الحوالة: اسم المرسل أو رقم حسابه في نفس الخانة
  assert.ok(await ev(() => pay.toString().includes('اسم المرسل أو رقم حسابه') && send.toString().includes('اسم المرسل أو رقم حسابه')));
  await ev(() => { S.u.in = 1; S.u.name = 'ع'; S.F.bus = { f: 'عدن', t: 'المكلا' }; S.d.bus = 0; go('bus'); });
  await sleep(400);
  const bus = await ev(() => document.querySelector('#m').innerText);
  assert.ok(!bus.includes('$'), 'لا رمز دولار في بطاقات الرحلات');
});

test('لا أخطاء جافاسكربت في الصفحة طوال الاختبارات', () => assert.deepEqual(ERRS, []));
