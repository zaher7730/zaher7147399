// اختبار متصفح: حالة الرحلات بالوقت الحقيقي (غادرت/عدّاد)، الأيام المحددة، ومتاح/غير متاح للسيارات.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, sleep } from '../helpers.mjs';

import { chromium } from 'playwright';

const f12 = (d) => { let h = d.getHours(); const s = h >= 12 ? 'م' : 'ص'; h = h % 12 || 12; return `${h}:${String(d.getMinutes()).padStart(2, '0')} ${s}`; };
const f24 = (d) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
// الاختبار مستقل عن ساعة التشغيل: ساعة المتصفح مثبّتة على 12:00 ظهراً من اليوم، فيقع «قبل ساعتين» و«بعد 3 ساعات» دائماً داخل نفس اليوم

let S, browser, page, customer, other, ERRS = [];
const until = async (fn, ms = 6000) => { const end = Date.now() + ms; for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('timeout'); await sleep(100); } };
const toasts = () => page.evaluate(() => [...document.querySelectorAll('.toast')].map((e) => e.textContent).join('|'));
const open = async (k, f, t) => { await page.evaluate(([k, f, t]) => { S.F[k] = { f, t }; S.d[k] = 0; go(k); }, [k, f, t]); await sleep(400); };
const screenText = () => page.evaluate(() => document.querySelector('#m').innerText);

test.before(async () => {
  S = await startServer();
  const admin = await S.adminLogin();
  const office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000003', 'عميل');
  other = await S.otpLogin('customer', '770000005', 'عميل آخر');
  const now = new Date();
  now.setHours(12, 0, 0, 0);
  const past = new Date(now.getTime() - 2 * 3600e3), fut = new Date(now.getTime() + 3 * 3600e3 + 60e3);
  const tmr = new Date(now.getTime() + 86400e3);
  const iso = `${tmr.getFullYear()}-${String(tmr.getMonth() + 1).padStart(2, '0')}-${String(tmr.getDate()).padStart(2, '0')}`;
  const mk = (serviceType, title, details) => ({ serviceType, title, active: true, details: { days: 'يومياً', seats: 10, kind: 'عادي', ...details } });
  const sy = await S.request('/api/office/services/sync', 'PUT', { services: [
    mk('bus', 'باص ماضي', { from: 'عدن', to: 'المكلا', time: f12(past), price: 500 }),
    mk('bus', 'باص قادم', { from: 'عدن', to: 'المكلا', time: f24(fut), price: 400 }),
    mk('bus', 'باص غداً فقط', { from: 'عدن', to: 'المكلا', days: 'أيام محددة', date: iso, time: '8:00 ص', price: 300 }),
    mk('local', 'محلي ماضي', { from: 'عدن', to: 'المكلا', time: f12(past), price: 30000 }),
    mk('local', 'محلي قادم', { from: 'عدن', to: 'المكلا', time: f12(fut), price: 31000 }),
    mk('air', 'طيران ماضي', { from: 'عدن', to: 'القاهرة', time: f12(past), price: 300 }),
    mk('air', 'طيران قادم', { from: 'عدن', to: 'القاهرة', time: f12(fut), price: 310 }),
    mk('priv', 'خاص ماضي', { from: 'عدن', to: 'صلالة', time: f12(past), price: 900 }),
    mk('priv', 'خاص قادم', { from: 'عدن', to: 'صلالة', time: f12(fut), price: 950 }),
    mk('cars', 'كامري', { city: 'عدن', make: 'تويوتا', model: 'كامري', year: 2023, seats: 5, price: 100, dep: 0, currency: 'YER' }),
    mk('cars', 'برادو', { city: 'عدن', make: 'تويوتا', model: 'برادو', year: 2022, seats: 7, price: 140, dep: 0, currency: 'YER' }),
  ] }, office.cookie);
  assert.equal(sy.status, 200, JSON.stringify(sy.data));
  const prado = sy.data.services.find((x) => x.title === 'برادو');
  const b = await S.request('/api/bookings', 'POST', { serviceId: prado.id, serviceType: 'cars', title: 'برادو', passengerCount: 1, totalAmount: 140, currency: 'YER', details: { form: {} } }, other.cookie);
  assert.equal(b.status, 201, JSON.stringify(b.data));
  browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: 'block' });
  await ctx.clock.install({ time: now });
  await ctx.addCookies([{ name: 'safarak_session', value: customer.cookie.split('=')[1], url: S.base }]);
  page = await ctx.newPage();
  page.on('pageerror', (e) => ERRS.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.goto(S.base + '/apps/customer/');
  await until(() => page.evaluate(() => typeof S !== 'undefined' && S.u.in === 1 && OFFS.length >= 1));
});
test.after(async () => { await browser?.close(); await S?.stop(); });

for (const [k, f, t] of [['bus', 'عدن', 'المكلا'], ['local', 'عدن', 'المكلا'], ['air', 'عدن', 'القاهرة'], ['priv', 'عدن', 'صلالة']]) {
  test(`${k}: الماضية «غادرت» وتبقى ظاهرة ولا تُحجز، والقادمة بعدّاد حقيقي وتُحجز`, async () => {
    await open(k, f, t);
    const txt = await screenText();
    assert.equal((txt.match(/الرحلة غادرت/g) || []).length, 1);
    assert.match(txt, /بعد 3 ساعات/);
    await page.locator('.arCard button:has-text("ابدأ الحجز")').nth(0).click();
    await sleep(300);
    assert.equal(await page.evaluate(() => S.scr), k);
    assert.match(await toasts(), /الرحلة غادرت — اختر رحلة أخرى/);
    await open(k, f, t);
    await page.locator('.arCard button:has-text("ابدأ الحجز")').nth(1).click();
    await until(() => page.evaluate(() => S.scr === 'detail'));
  });
}

test('أيام الرحلة: «أيام محددة» بتاريخ تظهر في ذلك اليوم فقط (بلا ظهور عشوائي)', async () => {
  await open('bus', 'عدن', 'المكلا');
  const n = () => page.evaluate(() => document.querySelectorAll('.arCard').length);
  assert.equal(await n(), 2);
  await page.evaluate(() => { S.d.bus = 1; render(); });
  assert.equal(await n(), 3);
  await page.evaluate(() => { S.d.bus = 3; render(); });
  assert.equal(await n(), 2);
  await page.evaluate(() => { S.d.bus = 1; render(); });
  assert.doesNotMatch(await screenText(), /الرحلة غادرت/);
});

test('السيارات: متاح/غير متاح، والمحجوزة لا تُحجز، وتصفية المتاحة فقط', async () => {
  await page.evaluate(() => { S.F.cars = {}; go('cars'); });
  await sleep(400);
  const html = () => page.evaluate(() => document.querySelector('#m').innerHTML);
  let h = await html();
  assert.match(h, /class="crSt ok"/);
  assert.match(h, /class="crSt bad"/);
  const cards = page.locator('.crCard');
  const n = await cards.count();
  let reserved = -1, free = -1;
  for (let i = 0; i < n; i++) { const c = await cards.nth(i).innerHTML(); if (/crSt bad/.test(c)) reserved = i; if (/crSt ok/.test(c)) free = i; }
  await cards.nth(reserved).locator('.crBook').click();
  await sleep(300);
  assert.equal(await page.evaluate(() => S.scr), 'cars');
  assert.match(await toasts(), /غير متاحة/);
  await cards.nth(free).locator('.crBook').click();
  await until(() => page.evaluate(() => S.scr === 'detail'));
  await page.evaluate(() => { S.F.cars = { a: 'المتاحة فقط' }; go('cars'); });
  await sleep(300);
  h = await html();
  assert.doesNotMatch(h, /crSt bad/);
  assert.match(h, /crSt ok/);
});

test('لا أخطاء جافاسكربت', () => assert.deepEqual(ERRS, []));
