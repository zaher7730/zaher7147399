// يغطي: ملف .env وحمايته من التعطيل الصامت، تشغيل start-local.sh لأول مرة، ملفات PWA،
// منطق عامل الخدمة (sw.js) بمحاكاة بيئة عامل الخدمة، ومنع تعليق تفعيل إشعارات الجهاز.
import test, { mock } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import { startServer, sleep } from './helpers.mjs';
import { generateVapidKeys } from '../server/integrations/push.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (f) => fs.readFileSync(path.join(ROOT, f), 'utf8');

/* ---------- 1) ملف .env ---------- */

test('.env.example: كل قيمة نصية بلا تعليق داخلي، واسم المدير المحتوي مسافات بين تنصيص', () => {
  const lines = read('.env.example').split(/\r?\n/).filter((l) => l.trim() && !l.trimStart().startsWith('#'));
  for (const line of lines) {
    const i = line.indexOf('=');
    assert.ok(i > 0, 'سطر غير صالح: ' + line);
    const raw = line.slice(i + 1);
    assert.ok(!/\s#/.test(raw), 'تعليق داخل سطر القيمة (يُكسر في systemd/Docker): ' + line);
  }
  assert.match(read('.env.example'), /^ADMIN_NAME="مدير المنصة"$/m);
  assert.match(read('.env.example'), /^NODE_ENV=development$/m);
});

test('.env.example يحوي كل المفاتيح التي يقرؤها الخادم (بما فيها مفاتيح الإنتاج)', () => {
  const cfg = read('server/config/index.mjs') + read('server/security/crypto.mjs');
  const used = new Set([...cfg.matchAll(/\be\.([A-Z][A-Z0-9_]+)/g)].map((m) => m[1]));
  const example = new Set([...read('.env.example').matchAll(/^([A-Z][A-Z0-9_]+)=/gm)].map((m) => m[1]));
  const missing = [...used].filter((k) => !example.has(k) && k !== 'BACKUP_OFFSITE_NOTE');
  assert.deepEqual(missing, [], 'مفاتيح يقرؤها الخادم وغائبة عن .env.example');
  assert.ok(example.has('DATA_ENCRYPTION_KEY') && example.has('VAPID_PUBLIC_KEY') && example.has('VAPID_PRIVATE_KEY'));
});

test('محلل .env يقرأ ADMIN_NAME كاملاً ويُسقط التعليقات (مطابق لما يقرأه الخادم)', () => {
  const out = spawnSync(process.execPath, ['scripts/env-get.mjs', 'ADMIN_NAME'], { cwd: ROOT, encoding: 'utf8', env: { PATH: process.env.PATH, SAFARAK_ENV_FILE: path.join(ROOT, '.env.example') } });
  assert.equal(out.status, 0, out.stderr);
  assert.equal(out.stdout, 'مدير المنصة');
});

test('متغير البيئة الحقيقي له الأولوية على ملف .env', () => {
  const out = spawnSync(process.execPath, ['scripts/env-get.mjs', 'PORT'], { cwd: ROOT, encoding: 'utf8', env: { PATH: process.env.PATH, PORT: '9999', SAFARAK_ENV_FILE: path.join(ROOT, '.env.example') } });
  assert.equal(out.stdout, '9999');
});

test('NODE_ENV بقيمة غير معروفة (تعليق ملتصق) يرفض التشغيل بدلاً من تعطيل الإنتاج بصمت', () => {
  const out = spawnSync(process.execPath, ['--input-type=module', '-e', "import { loadConfig } from './server/config/index.mjs'; loadConfig(); console.log('LOADED');"], {
    cwd: ROOT, encoding: 'utf8', env: { PATH: process.env.PATH, SAFARAK_ENV_FILE: '', NODE_ENV: 'production            # تعليق' },
  });
  assert.notEqual(out.status, 0);
  assert.match(out.stderr, /NODE_ENV غير صالح/);
  assert.doesNotMatch(out.stdout, /LOADED/);
});

/* ---------- 2) التشغيل الأول عبر start-local.sh ---------- */

test('التشغيل الأول: نسخ .env.example وتعبئته ثم start-local.sh يعمل ويقبل دخول المدير', async (t) => {
  if (process.platform === 'win32') return t.skip('يُختبر على Linux/macOS؛ ملف .bat يُفحص بالقراءة فقط');
  const tmp = await mkdtemp(path.join(os.tmpdir(), 'safarak-launch-'));
  const port = 21000 + Math.floor(Math.random() * 20000);
  const set = (text, key, value) => {
    const re = new RegExp(`^${key}=.*$`, 'm');
    assert.match(text, re, 'المفتاح غير موجود في المثال: ' + key);
    return text.replace(re, `${key}=${value}`);
  };
  let env = read('.env.example');
  env = set(env, 'PORT', port);
  env = set(env, 'HOST', '127.0.0.1');
  env = set(env, 'DB_PATH', path.join(tmp, 'db.sqlite'));
  env = set(env, 'PRIVATE_UPLOADS_DIR', path.join(tmp, 'private'));
  env = set(env, 'PUBLIC_OFFER_UPLOADS_DIR', path.join(tmp, 'public'));
  env = set(env, 'BACKUP_DIR', path.join(tmp, 'backups'));
  env = set(env, 'ADMIN_PHONE', '770000001');
  env = set(env, 'ADMIN_PASSWORD', 'TestAdminPass!2026');
  env = set(env, 'OTP_PEPPER', 'test-only-pepper-which-is-long-enough');
  const envFile = path.join(tmp, '.env');
  fs.writeFileSync(envFile, env, 'utf8');

  const child = spawn('bash', ['scripts/start-local.sh'], {
    cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'],
    env: { PATH: process.env.PATH, HOME: process.env.HOME || tmp, SAFARAK_ENV_FILE: envFile },
  });
  let log = '';
  child.stdout.on('data', (b) => (log += b));
  child.stderr.on('data', (b) => (log += b));
  try {
    const base = `http://127.0.0.1:${port}`;
    const start = Date.now();
    for (;;) {
      if (child.exitCode !== null) throw new Error('start-local.sh توقف مبكراً:\n' + log);
      try { if ((await fetch(base + '/api/health')).ok) break; } catch { /* ينتظر */ }
      if (Date.now() - start > 20000) throw new Error('الخادم لم يعمل:\n' + log);
      await sleep(100);
    }
    const r = await fetch(base + '/api/auth/login', {
      method: 'POST', headers: { 'content-type': 'application/json', origin: base },
      body: JSON.stringify({ identifier: '770000001', password: 'TestAdminPass!2026' }),
    });
    assert.equal(r.status, 200, 'تسجيل دخول المدير يجب أن ينجح بعد التشغيل الأول');
    const data = await r.json();
    assert.equal(data.user.role, 'admin');
    assert.equal(data.user.name, 'مدير المنصة', 'ADMIN_NAME يجب أن يُقرأ كاملاً');
  } finally {
    child.kill('SIGTERM');
    await new Promise((res) => child.once('exit', res));
    await rm(tmp, { recursive: true, force: true });
  }
});

/* ---------- 3) ملفات PWA المقدَّمة من الخادم ---------- */

let S;
test.before(async () => { S = await startServer(); });
test.after(() => S.stop());

test('/sw.js يُقدَّم بنطاق / ولا يُخزَّن، وكذلك pwa.js والبيان', async () => {
  const sw = await S.request('/sw.js');
  assert.equal(sw.status, 200, 'sw.js يجب أن يوجد');
  assert.match(sw.headers.get('content-type'), /javascript/);
  assert.equal(sw.headers.get('service-worker-allowed'), '/');
  assert.match(sw.headers.get('cache-control'), /no-cache/);
  assert.equal((await S.request('/shared/pwa/pwa.js')).status, 200);
  for (const app of ['customer', 'office']) {
    const m = await S.request(`/apps/${app}/manifest.webmanifest`);
    assert.equal(m.status, 200, app + ' manifest');
    assert.equal(JSON.parse(m.data).dir, 'rtl');
    const page = await S.request(`/apps/${app}/`);
    assert.match(page.data, /\/shared\/pwa\/pwa\.js/, app + ' يحمّل pwa.js');
    assert.match(page.data, /manifest\.webmanifest/, app + ' يربط البيان');
  }
});

test('الإدارة لا تحمّل عامل الخدمة ولا تُخزَّن عبره', async () => {
  const admin = await S.request('/apps/admin/', 'GET', undefined, undefined, { redirect: 'manual' });
  assert.equal(admin.status, 302, 'لوحة الإدارة مقيّدة للمدير');
});

/* ---------- 4) منطق sw.js داخل بيئة عامل خدمة محاكاة ---------- */

function loadServiceWorker({ fetchImpl }) {
  const listeners = {};
  const shown = [];
  const opened = [];
  const stores = new Map();
  const clientsList = [];
  const self = {
    location: new URL('https://safarak.test/'),
    addEventListener(type, fn) { (listeners[type] ||= []).push(fn); },
    skipWaiting: async () => 'skipped',
    clients: {
      claim: async () => 'claimed',
      matchAll: async () => clientsList,
      openWindow: async (u) => { opened.push(u); return null; },
    },
    registration: { showNotification: async (title, opts) => { shown.push({ title, opts }); } },
  };
  const caches = {
    async keys() { return [...stores.keys()]; },
    async delete(name) { return stores.delete(name); },
    async open(name) {
      if (!stores.has(name)) stores.set(name, new Map());
      const m = stores.get(name);
      return {
        async put(req, res) { m.set(typeof req === 'string' ? req : req.url, res.clone()); },
        async match(req) { const k = typeof req === 'string' ? req : req.url; return m.has(k) ? m.get(k).clone() : undefined; },
      };
    },
  };
  const ctx = vm.createContext({ self, caches, fetch: fetchImpl, Response, URL, console });
  vm.runInContext(read('shared/pwa/sw.js'), ctx);
  const fire = (type, props = {}) => {
    const ev = { waitUntil(p) { ev.work = p; }, respondWith(p) { ev.response = p; }, ...props };
    for (const fn of listeners[type] || []) fn(ev);
    return ev;
  };
  return { fire, shown, opened, stores, clientsList };
}

const req = (url, method = 'GET') => new Request(url, { method });

test('sw.js: لا يعترض /api ولا الإدارة ولا الطلبات غير GET ولا النطاقات الخارجية', () => {
  const sw = loadServiceWorker({ fetchImpl: async () => new Response('x', { status: 200 }) });
  for (const [u, m] of [['https://safarak.test/api/me', 'GET'], ['https://safarak.test/apps/admin/', 'GET'], ['https://safarak.test/apps/customer/a.js', 'POST'], ['https://fonts.googleapis.com/x.css', 'GET'], ['https://safarak.test/preview/standalone.html', 'GET']]) {
    const ev = sw.fire('fetch', { request: req(u, m) });
    assert.equal(ev.response, undefined, 'لا يجب أن يعترض: ' + m + ' ' + u);
  }
});

test('sw.js: الشبكة أولاً ثم نسخة محفوظة عند انقطاع الاتصال', async () => {
  let online = true;
  const fetchImpl = async () => {
    if (!online) throw new TypeError('offline');
    return new Response('console.log(1)', { status: 200, headers: { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-cache' } });
  };
  const sw = loadServiceWorker({ fetchImpl });
  const first = sw.fire('fetch', { request: req('https://safarak.test/apps/customer/scripts/a.js') });
  const res = await first.response;
  assert.equal(await res.text(), 'console.log(1)');
  assert.equal(sw.stores.get('safarak-shell-v1').size, 1, 'حُفظت نسخة');
  online = false;
  const offline = await sw.fire('fetch', { request: req('https://safarak.test/apps/customer/scripts/a.js') }).response;
  assert.equal(await offline.text(), 'console.log(1)', 'تُعرض النسخة المحفوظة');
});

test('sw.js: بلا اتصال وبلا نسخة يعيد 503 بنص عربي بدل الانهيار', async () => {
  const sw = loadServiceWorker({ fetchImpl: async () => { throw new TypeError('offline'); } });
  const r = await sw.fire('fetch', { request: req('https://safarak.test/apps/office/x.html') }).response;
  assert.equal(r.status, 503);
  assert.match(await r.text(), /لا يوجد اتصال/);
});

test('sw.js: لا يحفظ استجابة no-store', async () => {
  const sw = loadServiceWorker({ fetchImpl: async () => new Response('secret', { status: 200, headers: { 'Cache-Control': 'no-store' } }) });
  await sw.fire('fetch', { request: req('https://safarak.test/shared/x.js') }).response;
  assert.equal(sw.stores.has('safarak-shell-v1') ? sw.stores.get('safarak-shell-v1').size : 0, 0);
});

test('sw.js: التفعيل يحذف الذاكرات القديمة لسفرك فقط', async () => {
  const sw = loadServiceWorker({ fetchImpl: async () => new Response('') });
  sw.stores.set('safarak-shell-v0', new Map());
  sw.stores.set('safarak-shell-v1', new Map());
  sw.stores.set('other-app-cache', new Map());
  await sw.fire('activate').work;
  assert.deepEqual([...sw.stores.keys()].sort(), ['other-app-cache', 'safarak-shell-v1']);
});

test('sw.js: نبضة الدفع تعرض عنواناً عاماً فقط دون كشف نص الإشعار (خصوصية شاشة القفل)', async () => {
  const fetchImpl = async (url) => {
    throw new Error('لا يجب جلب محتوى الإشعار من الشبكة عند النبضة: ' + url);
  };
  const sw = loadServiceWorker({ fetchImpl });
  await sw.fire('push').work;
  assert.equal(sw.shown.length, 1);
  assert.equal(sw.shown[0].title, 'سفرك أسهل');
  assert.ok(!String(sw.shown[0].opts.body).includes('تم تأكيد حجزك'), 'نص الإشعار الحقيقي لا يظهر على القفل');
  assert.equal(sw.shown[0].opts.tag, 'safarak-push');
  assert.equal(sw.shown[0].opts.data, undefined, 'لا رابط ثابت في النبضة؛ يُحدَّد التطبيق عند النقر');
});

test('sw.js: نبضة الدفع تعرض إشعاراً عاماً عند انقطاع الاتصال (حتى لا يلغيه المتصفح)', async () => {
  const sw = loadServiceWorker({ fetchImpl: async () => { throw new TypeError('offline'); } });
  await sw.fire('push').work;
  assert.equal(sw.shown.length, 1);
  assert.equal(sw.shown[0].title, 'سفرك أسهل');
});

test('sw.js: النقر على إشعار مستخدم المكتب يفتح تطبيق المكتب (وليس العميل)', async () => {
  const sw = loadServiceWorker({ fetchImpl: async () => new Response('') });
  const store = new Map(); sw.stores.set('safarak-meta', store);
  store.set('/__last_app', new Response('office'));
  await sw.fire('notificationclick', { notification: { close() {}, data: {} } }).work;
  assert.deepEqual(sw.opened, ['https://safarak.test/apps/office/']);
});

test('sw.js: النقر على الإشعار يفتح نافذة التطبيق أو يركّز نافذة مفتوحة', async () => {
  const sw = loadServiceWorker({ fetchImpl: async () => new Response('') });
  await sw.fire('notificationclick', { notification: { close() {}, data: { url: '/apps/customer/' } } }).work;
  assert.deepEqual(sw.opened, ['https://safarak.test/apps/customer/']);
  let focused = false;
  sw.clientsList.push({ url: 'https://safarak.test/apps/customer/', focus: async () => { focused = true; } });
  await sw.fire('notificationclick', { notification: { close() {}, data: {} } }).work;
  assert.equal(focused, true);
  assert.equal(sw.opened.length, 1, 'لا تُفتح نافذة ثانية إن وُجدت واحدة');
});

/* ---------- 5) تفعيل إشعارات الجهاز لا يتعلّق إلى الأبد ---------- */

function loadNotifications({ registration, ready, pushSubscribe, publicKey }) {
  const toasts = [];
  const sent = [];
  const ctx = vm.createContext({
    S: { u: { in: true } },
    toast: (m) => toasts.push(m),
    atob, Uint8Array, Promise, console,
    setTimeout: (f, ms) => globalThis.setTimeout(f, ms),
    clearTimeout: (t) => globalThis.clearTimeout(t),
    window: {
      PushManager: function () {},
      SA_API: {
        get: async () => ({ publicKey }),
        send: async (...args) => { sent.push(args); return {}; },
      },
    },
    Notification: { requestPermission: async () => 'granted' },
    navigator: {
      serviceWorker: {
        getRegistration: async () => registration,
        ready,
      },
    },
  });
  vm.runInContext(read('apps/customer/scripts/services/server-sync/notifications.js'), ctx);
  return { enable: () => ctx.SA_enablePush(), toasts, sent, ctx, pushSubscribe };
}

test('تفعيل الإشعارات بلا عامل خدمة مسجَّل: رسالة واضحة فوراً بدل التعليق', async () => {
  const n = loadNotifications({ registration: undefined, ready: new Promise(() => {}), publicKey: generateVapidKeys().publicKey });
  await n.enable();
  assert.equal(n.toasts.length, 1);
  assert.match(n.toasts[0], /غير مفعّلة/);
});

test('تفعيل الإشعارات مع عامل خدمة جاهز: يشترك ويرسل الاشتراك للخادم', async () => {
  const sub = { toJSON: () => ({ endpoint: 'https://push.example/abc', keys: { p256dh: 'a', auth: 'b' } }) };
  const reg = { pushManager: { getSubscription: async () => null, subscribe: async () => sub } };
  const n = loadNotifications({ registration: reg, ready: Promise.resolve(reg), publicKey: generateVapidKeys().publicKey });
  await n.enable();
  assert.equal(n.sent.length, 1);
  assert.equal(n.sent[0][0], 'POST');
  assert.equal(n.sent[0][1], '/api/push/subscribe');
  assert.equal(n.sent[0][2].endpoint, 'https://push.example/abc');
  assert.equal(n.toasts.at(-1), 'تم تفعيل إشعارات الجهاز');
});

test('تفعيل الإشعارات إذا لم يصبح العامل جاهزاً: تنتهي المهلة برسالة', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const reg = { pushManager: {} };
  const n = loadNotifications({ registration: reg, ready: new Promise(() => {}), publicKey: generateVapidKeys().publicKey });
  const pending = n.enable();
  await new Promise((r) => setImmediate(r)); // يُكمل الانتظار على getRegistration قبل إنشاء المؤقت
  t.mock.timers.tick(10000);
  await pending;
  assert.match(n.toasts.at(-1), /انتهت مهلة/);
  t.mock.timers.reset();
});
