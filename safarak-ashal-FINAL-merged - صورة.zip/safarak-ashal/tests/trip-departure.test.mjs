// منع حجز رحلة غادرت: قاعدة الخادم (توقيت المنصة + تاريخ الرحلة) تعمل حتى لو تجاوز أحدهم الواجهة.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, ymdLocal, localUtcOffset } from './helpers.mjs';
import { timeToMinutes, parseUtcOffset, departureMs, assertTripNotDeparted } from '../server/lib/trip-time.mjs';

test('وحدة: تحويل نص الوقت إلى دقائق مثل العميل تماماً', () => {
  assert.equal(timeToMinutes('08:00'), 480);
  assert.equal(timeToMinutes('8:30 م'), 20 * 60 + 30);
  assert.equal(timeToMinutes('12:15 ص'), 15);
  assert.equal(timeToMinutes('12:00 م'), 720);
  assert.equal(timeToMinutes('٠٩:٤٥'), 9 * 60 + 45);
  assert.equal(timeToMinutes('يومياً'), null);
  assert.equal(timeToMinutes(''), null);
});

test('وحدة: إزاحة توقيت المنصة ولحظة المغادرة', () => {
  assert.equal(parseUtcOffset('+03:00'), 180);
  assert.equal(parseUtcOffset('-05:30'), -330);
  assert.throws(() => parseUtcOffset('3'), /PLATFORM_UTC_OFFSET/);
  assert.throws(() => parseUtcOffset('+15:00'), /PLATFORM_UTC_OFFSET/);
  // 08:00 بتوقيت +03:00 = 05:00 UTC
  assert.equal(departureMs('2026-10-30', 480, 180), Date.UTC(2026, 9, 30, 5, 0));
  assert.equal(departureMs('2026-02-30', 480, 180), null);
  assert.equal(departureMs('30-10-2026', 480, 180), null);
});

test('وحدة: assertTripNotDeparted يرفض الماضي ويقبل المستقبل ولا يفحص ما لا وقت له', () => {
  const now = Date.UTC(2026, 9, 30, 6, 0); // 09:00 بتوقيت +03:00
  const o = { time: '08:00' };
  assert.throws(() => assertTripNotDeparted({ serviceType: 'bus', official: o, details: { departDate: '2026-10-30' } }, { now, offsetMin: 180 }), (e) => e.status === 409);
  assert.doesNotThrow(() => assertTripNotDeparted({ serviceType: 'bus', official: o, details: { departDate: '2026-10-31' } }, { now, offsetMin: 180 }));
  assert.doesNotThrow(() => assertTripNotDeparted({ serviceType: 'bus', official: { time: '10:00' }, details: { departDate: '2026-10-30' } }, { now, offsetMin: 180 }));
  assert.throws(() => assertTripNotDeparted({ serviceType: 'bus', official: o, details: {} }, { now, offsetMin: 180 }), (e) => e.status === 400);
  assert.throws(() => assertTripNotDeparted({ serviceType: 'bus', official: o, details: { departDate: '2030-01-01' } }, { now, offsetMin: 180 }), (e) => e.status === 400);
  assert.doesNotThrow(() => assertTripNotDeparted({ serviceType: 'cars', official: o, details: {} }, { now, offsetMin: 180 }));
  assert.doesNotThrow(() => assertTripNotDeparted({ serviceType: 'bus', official: { time: 'يومياً' }, details: {} }, { now, offsetMin: 180 }));
});

let S, admin, office, customer, serviceId;
test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000031', 'عميل المغادرة');
  // رحلة تنطلق بعد ساعتين من الآن بتوقيت الجهاز (الخادم مضبوط على نفس التوقيت في الاختبارات)
  const at = new Date(Date.now() + 2 * 3600000), pad = (n) => String(n).padStart(2, '0');
  const sync = await S.request('/api/office/services/sync', 'PUT', { services: [{ serviceType: 'bus', title: 'رحلة قادمة', details: { price: 500, currency: 'YER', from: 'عدن', to: 'المكلا', days: 'يومي', time: `${pad(at.getHours())}:${pad(at.getMinutes())}` }, active: true }] }, office.cookie);
  assert.equal(sync.status, 200, JSON.stringify(sync.data));
  serviceId = sync.data.services.find((x) => x.active === 1 && x.title === 'رحلة قادمة').id;
  S.future = { date: ymdLocal(at.getDate() === new Date().getDate() ? 0 : 1) };
});
test.after(async () => S && S.stop());

const body = (details) => ({ serviceId, serviceType: 'bus', title: 'رحلة قادمة', passengerCount: 1, totalAmount: 500, currency: 'YER', details });

test('الخادم يعمل بتوقيت الجهاز في الاختبارات', () => {
  assert.match(localUtcOffset(), /^[+-]\d{2}:\d{2}$/);
});

test('حجز بدون تاريخ الرحلة لعرض له وقت انطلاق → 400', async () => {
  const r = await S.request('/api/bookings', 'POST', body({ form: {} }), customer.cookie);
  assert.equal(r.status, 400, JSON.stringify(r.data));
});

test('حجز رحلة غادرت (تاريخ الأمس) → 409 برسالة الرحلة غادرت', async () => {
  const r = await S.request('/api/bookings', 'POST', body({ form: {}, departDate: ymdLocal(-1) }), customer.cookie);
  assert.equal(r.status, 409, JSON.stringify(r.data));
  assert.match(r.data.error || r.data.message || JSON.stringify(r.data), /غادرت/);
});

test('حجز الرحلة القادمة (بعد ساعتين) → 201', async () => {
  const r = await S.request('/api/bookings', 'POST', body({ form: {}, departDate: S.future.date }), customer.cookie);
  assert.equal(r.status, 201, JSON.stringify(r.data));
});

test('تاريخ غير صحيح → 400', async () => {
  const r = await S.request('/api/bookings', 'POST', body({ form: {}, departDate: '2026-13-45' }), customer.cookie);
  assert.equal(r.status, 400, JSON.stringify(r.data));
});
