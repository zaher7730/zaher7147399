// التحقق من ربط تشفير الملفات في كل مسارات الرفع: أي ملف خاص يُكتب على القرص مشفّراً، ويُقرأ سليماً عبر الواجهة.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startServer, PNG, PDF, b64 } from './helpers.mjs';

const MAGIC = Buffer.from('SAFv1ENC', 'utf8');
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let S, admin, customer, office, privateDir, publicDir;

test.before(async () => {
  S = await startServer();
  privateDir = path.join(path.dirname(S.dbPath), 'private');
  publicDir = path.join(path.dirname(S.dbPath), 'public');
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000003', 'عميل');
});
test.after(() => S.stop());

const rawFiles = (dir) => fs.readdirSync(dir).filter((f) => !f.startsWith('.')).map((f) => fs.readFileSync(path.join(dir, f)));
const download = async (url, cookie) => Buffer.from(await (await fetch(S.base + url, { headers: { cookie } })).arrayBuffer());

test('رفع /api/files (عميل ومكتب): الملف على القرص مشفّر ولا يحوي المحتوى الأصلي، ويُقرأ سليماً عبر الواجهة', async () => {
  const before = rawFiles(privateDir).length;
  const pdf = await S.request('/api/files', 'POST', { filename: 'receipt.pdf', mimeType: 'application/pdf', base64: b64(PDF) }, customer.cookie);
  const png = await S.request('/api/files', 'POST', { filename: 'id.png', mimeType: 'image/png', base64: b64(PNG) }, customer.cookie);
  const officePng = await S.request('/api/files', 'POST', { filename: 'lic.png', mimeType: 'image/png', base64: b64(PNG) }, office.cookie);
  for (const r of [pdf, png, officePng]) assert.equal(r.status, 201, JSON.stringify(r.data));

  const files = rawFiles(privateDir);
  assert.equal(files.length - before, 3, 'ثلاثة ملفات جديدة على القرص');
  for (const f of files) {
    assert.ok(f.subarray(0, MAGIC.length).equals(MAGIC), 'ملف خاص غير مشفّر على القرص');
    assert.ok(!f.includes(Buffer.from('Safarak receipt test')), 'محتوى PDF ظاهر على القرص');
    assert.ok(!f.includes(Buffer.from('IHDR')), 'محتوى PNG ظاهر على القرص');
  }
  assert.deepEqual(await download(pdf.data.file.downloadUrl, customer.cookie), PDF, 'الملف المنزَّل يطابق الأصل');
  assert.deepEqual(await download(png.data.file.downloadUrl, customer.cookie), PNG);
  assert.deepEqual(await download(officePng.data.file.downloadUrl, admin), PNG, 'المدير يقرأ وثيقة المكتب سليمة');
});

test('طلب انضمام مكتب (مسار عام): الوثائق تُحفظ مشفّرة ويقرأها المدير سليمة', async () => {
  const before = new Set(fs.readdirSync(privateDir));
  const dataUrl = 'data:image/png;base64,' + b64(PNG);
  const r = await S.request('/api/public/office-applications', 'POST', {
    officeName: 'مكتب الاختبار', ownerName: 'مالك الاختبار', phone: '771234567', address: 'عدن - كريتر',
    registrationNumber: 'R-100', licenseNumber: 'L-100', ownerIdNumber: '01234567', documents: { crImg: dataUrl, licImg: dataUrl },
  });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const added = fs.readdirSync(privateDir).filter((f) => !before.has(f) && !f.startsWith('.'));
  assert.equal(added.length, 2, 'وثيقتان جديدتان');
  for (const f of added) {
    const raw = fs.readFileSync(path.join(privateDir, f));
    assert.ok(raw.subarray(0, MAGIC.length).equals(MAGIC), 'وثيقة طلب الانضمام غير مشفّرة');
    assert.ok(!raw.includes(Buffer.from('IHDR')));
  }
  assert.deepEqual(await download(`/api/admin/office-applications/${r.data.application.id}/documents/crImg`, admin), PNG, 'المدير يقرأ الوثيقة سليمة');
});

test('صور العروض العامة عمداً غير مشفّرة (تُعرض للجميع)، ولا تدخل مجلد الملفات الخاصة', async () => {
  const before = rawFiles(privateDir).length;
  const r = await S.request('/api/office/assets', 'POST', { mimeType: 'image/png', base64: b64(PNG) }, office.cookie);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal(rawFiles(privateDir).length, before, 'صورة عامة لا تُكتب في المجلد الخاص');
  const pub = rawFiles(publicDir);
  assert.equal(pub.length, 1);
  assert.deepEqual(pub[0], PNG);
});

test('حارس ثابت: لا كتابة في مجلد الملفات الخاصة إلا عبر encryptBytes (يلتقط أي مسار رفع جديد)', () => {
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : e.name.endsWith('.mjs') ? [path.join(d, e.name)] : []));
  const offenders = [];
  for (const f of walk(path.join(ROOT, 'server'))) {
    if (/server[\\/]db[\\/](backup|restore)\.mjs$/.test(f)) continue; // النسخ والاستعادة تنسخ البايتات كما هي (مشفّرة أصلاً)
    fs.readFileSync(f, 'utf8').split('\n').forEach((line, i) => {
      if (/\b(writeFile|writeFileSync|appendFile|appendFileSync|createWriteStream|copyFile|copyFileSync|renameSync)\b/.test(line) && /privateUploads/.test(line) && !/encryptBytes\(/.test(line))
        offenders.push(`${path.relative(ROOT, f)}:${i + 1}`);
    });
  }
  assert.deepEqual(offenders, [], 'مسار يكتب ملفاً خاصاً بلا تشفير');
});
