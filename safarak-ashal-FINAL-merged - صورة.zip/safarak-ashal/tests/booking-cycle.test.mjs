// دورة الحجز الكاملة: عرض → حجز بسعر موثّق → سند → حوالة → تأكيد → حالة → فاتورة → إشعارات → تقييم.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, PNG, PDF, b64 } from './helpers.mjs';

let S, admin, office, customer, other;
test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = (await S.otpLogin('customer', '770000003', 'Test Customer')).cookie;
  other = (await S.otpLogin('customer', '770000005', 'Other Customer')).cookie;
});
test.after(() => S.stop());

let bookingId, paymentId, fileId;

test('الخدمة المنشورة ظاهرة للعموم بسعرها الرسمي', async () => {
  const r = await S.request('/api/public/services');
  assert.equal(r.status, 200);
  assert.equal(r.data.services.length, 1);
  assert.equal(r.data.services[0].details.price, 500);
  const pm = await S.request('/api/public/payment-methods?officeId=' + office.id);
  assert.ok(pm.data.methods.some((m) => m.id === office.methodId));
});

test('السعر مُتحقَّق منه على الخادم والعميل وحده ينشئ الحجز', async () => {
  const body = (amount) => ({ serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: amount, currency: 'YER', details: { form: {} } });
  assert.equal((await S.request('/api/bookings', 'POST', body(499), customer)).status, 409);
  assert.equal((await S.request('/api/bookings', 'POST', body(500), office.cookie)).status, 403);
  assert.equal((await S.request('/api/bookings', 'POST', body(500))).status, 401);
  const ok = await S.request('/api/bookings', 'POST', body(500), customer);
  assert.equal(ok.status, 201, JSON.stringify(ok.data));
  bookingId = ok.data.booking.public_id;
  assert.match(ok.data.booking.invoice_number, /^INV-\d+-000001$/);
  assert.equal(ok.data.booking.office_id, office.id);
});

test('المكتب يستلم إشعار الطلب الجديد', async () => {
  const n = await S.request('/api/notifications', 'GET', undefined, office.cookie);
  assert.equal(n.status, 200);
  assert.ok(n.data.notifications.some((x) => x.kind === 'booking_new' && x.data.bookingId === bookingId));
  assert.ok(n.data.unread >= 1);
});

test('عزل البيانات: عميل آخر لا يرى الحجز', async () => {
  assert.equal((await S.request('/api/bookings/' + bookingId, 'GET', undefined, other)).status, 403);
  const list = await S.request('/api/bookings', 'GET', undefined, other);
  assert.equal(list.data.bookings.length, 0);
  assert.equal((await S.request(`/api/bookings/${bookingId}/status`, 'PATCH', { status: 'completed' }, customer)).status, 403);
});

test('رفع السند وتسجيل الحوالة ثم تأكيد المكتب', async () => {
  const up = await S.request('/api/files', 'POST', { filename: 'receipt.pdf', mimeType: 'application/pdf', base64: b64(PDF), bookingId }, customer);
  assert.equal(up.status, 201, JSON.stringify(up.data));
  fileId = up.data.file.id;
  assert.equal((await S.request('/api/files', 'POST', { filename: 'x.exe', mimeType: 'application/x-msdownload', base64: b64(PDF), bookingId }, customer)).status, 400);
  assert.equal((await S.request('/api/files', 'POST', { filename: 'fake.pdf', mimeType: 'application/pdf', base64: b64(Buffer.from('not a pdf')) , bookingId }, customer)).status, 400);
  const pay = { amount: 500, reference: 'TX-1', sender: 'Test Customer', transferredAt: '2026-10-24', methodId: office.methodId, methodName: 'حساب الاختبار', currency: 'YER', receiptFileId: fileId };
  assert.equal((await S.request(`/api/bookings/${bookingId}/payment`, 'POST', { ...pay, sender: '' }, customer)).status, 400);
  assert.equal((await S.request(`/api/bookings/${bookingId}/payment`, 'POST', { ...pay, reference: '' }, customer)).status, 400);
  assert.equal((await S.request(`/api/bookings/${bookingId}/payment`, 'POST', pay, other)).status, 403);
  // العميل يرسل اسم المرسل ورقم الحوالة وصورتها فقط: المبلغ من الحجز نفسه والتاريخ من الخادم
  const { amount: _a, transferredAt: _d, ...slim } = pay;
  const r = await S.request(`/api/bookings/${bookingId}/payment`, 'POST', { ...slim, amount: 1 }, customer);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal(Number(r.data.payment.amount), 500);
  assert.ok(r.data.payment.transferred_at);
  paymentId = r.data.payment.id;
  assert.equal((await fetch(S.base + '/api/files/' + fileId, { headers: { cookie: office.cookie } })).status, 200);
  assert.equal((await fetch(S.base + '/api/files/' + fileId, { headers: { cookie: other } })).status, 403);
  assert.equal((await fetch(S.base + '/api/files/' + fileId)).status, 401);
  const list = await S.request('/api/office/payments', 'GET', undefined, office.cookie);
  assert.ok(list.data.payments.some((p) => p.id === paymentId));
  const conf = await S.request('/api/office/payments/' + paymentId, 'PATCH', { status: 'confirmed', note: 'تم' }, office.cookie);
  assert.equal(conf.status, 200);
  assert.equal((await S.request('/api/bookings/' + bookingId, 'GET', undefined, customer)).data.booking.payment_status, 'confirmed');
  const cn = await S.request('/api/notifications', 'GET', undefined, customer);
  assert.ok(cn.data.notifications.some((x) => x.kind === 'payment_review'));
});

test('المكتب يغيّر الحالة والعميل يُشعَر وتُسجَّل الأحداث', async () => {
  assert.equal((await S.request(`/api/bookings/${bookingId}/status`, 'PATCH', { status: 'bogus' }, office.cookie)).status, 400);
  assert.equal((await S.request(`/api/bookings/${bookingId}/status`, 'PATCH', { status: 'in_progress', note: 'بدأ' }, office.cookie)).status, 200);
  const done = await S.request(`/api/bookings/${bookingId}/status`, 'PATCH', { status: 'completed' }, office.cookie);
  assert.equal(done.data.booking.status, 'completed');
  const ev = await S.request(`/api/bookings/${bookingId}/events`, 'GET', undefined, customer);
  assert.ok(ev.data.events.length >= 3);
  const n = await S.request('/api/notifications', 'GET', undefined, customer);
  assert.ok(n.data.notifications.some((x) => x.kind === 'booking_status'));
  const read = await S.request('/api/notifications/read', 'POST', {}, customer);
  assert.equal(read.status, 200);
  assert.equal((await S.request('/api/notifications', 'GET', undefined, customer)).data.unread, 0);
});

test('التقييم بعد الاكتمال فقط ومرة واحدة، والمكتب يرد، والعموم يرونه', async () => {
  assert.equal((await S.request('/api/reviews', 'POST', { bookingId, rating: 0 }, customer)).status, 400);
  const r = await S.request('/api/reviews', 'POST', { bookingId, rating: 5, comment: 'خدمة ممتازة' }, customer);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal((await S.request('/api/reviews', 'POST', { bookingId, rating: 4 }, customer)).status, 409);
  assert.equal((await S.request('/api/reviews', 'POST', { bookingId, rating: 4 }, other)).status, 404);
  assert.equal((await S.request(`/api/reviews/${r.data.review.id}/reply`, 'POST', { reply: 'شكراً لك' }, office.cookie)).status, 200);
  const pub = await S.request(`/api/public/offices/${office.id}/reviews`);
  assert.equal(pub.data.summary.count, 1);
  assert.equal(pub.data.reviews[0].office_reply, 'شكراً لك');
  const offices = await S.request('/api/public/offices');
  assert.equal(offices.data.offices[0].rating.avg, 5);
});

test('الفاتورة تسلسلية لكل مكتب وتظهر للمكتب والإدارة', async () => {
  const second = await S.request('/api/bookings', 'POST', { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details: {} }, other);
  assert.match(second.data.booking.invoice_number, /000002$/);
  const inv = await S.request('/api/office/invoices', 'GET', undefined, office.cookie);
  assert.equal(inv.data.invoices.length, 2);
  assert.equal((await S.request('/api/admin/invoices', 'GET', undefined, admin)).data.invoices.length, 2);
});

test('إلغاء العميل وحماية الحالات النهائية', async () => {
  const b = await S.request('/api/bookings', 'POST', { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details: {} }, customer);
  const id = b.data.booking.public_id;
  assert.equal((await S.request(`/api/bookings/${id}/cancel`, 'POST', {}, other)).status, 403);
  assert.equal((await S.request(`/api/bookings/${id}/cancel`, 'POST', {}, customer)).data.booking.status, 'cancelled');
  assert.equal((await S.request(`/api/bookings/${id}/cancel`, 'POST', {}, customer)).status, 409);
  assert.equal((await S.request(`/api/bookings/${bookingId}/cancel`, 'POST', {}, customer)).status, 409);
});

test('الطلب اليدوي من المكتب ينشئ عميلاً ويصل إليه', async () => {
  const m = await S.request('/api/office/bookings', 'POST', { customerName: 'Manual Customer', customerPhone: '770000004', serviceType: 'bus', title: 'طلب مسجل من المكتب', passengerCount: 1, totalAmount: 500, currency: 'YER' }, office.cookie);
  assert.equal(m.status, 201, JSON.stringify(m.data));
  const mc = await S.otpLogin('customer', '770000004', 'Manual Customer');
  const list = await S.request('/api/bookings', 'GET', undefined, mc.cookie);
  assert.ok(list.data.bookings.some((b) => b.public_id === m.data.booking.public_id));
  assert.equal((await S.request('/api/office/bookings', 'POST', { customerName: 'X Y', customerPhone: '770000006', serviceType: 'hotel', title: 'لا عرض لها', totalAmount: 5 }, office.cookie)).status, 400);
});

test('الأمانات: حجز مباشر لنقطة مسجلة فقط', async () => {
  const pt = await S.request('/api/admin/points', 'POST', { name: 'نقطة الاختبار', city: 'عدن', address: 'عنوان الاختبار' }, admin);
  assert.equal(pt.status, 201);
  const ok = await S.request('/api/bookings', 'POST', { officeId: office.id, serviceType: 'pass', title: 'إرسال جواز', totalAmount: 0, details: { pointId: pt.data.point.id } }, customer);
  assert.equal(ok.status, 201, JSON.stringify(ok.data));
  assert.equal((await S.request('/api/bookings', 'POST', { officeId: office.id, serviceType: 'pass', title: 'x', totalAmount: 0, details: { pointId: 9999 } }, customer)).status, 400);
});

test('حصة المكتب: عند التفعيل لا يُقبل الحجز دون رصيد، وتُخصم بعد الشراء', async () => {
  assert.equal((await S.request('/api/admin/settings', 'PUT', { settings: { enforceQuota: true } }, admin)).status, 200);
  const body = { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details: {} };
  assert.equal((await S.request('/api/bookings', 'POST', body, customer)).status, 409);
  const req = await S.request('/api/office/package-purchases', 'POST', { serviceType: 'bus', quantity: 2 }, office.cookie);
  assert.equal(req.status, 201);
  const pid = req.data.purchase.id;
  assert.equal((await S.request('/api/admin/package-purchases/' + pid, 'PATCH', { status: 'fulfilled', totalPrice: 100 }, admin)).status, 200);
  assert.equal((await S.request('/api/admin/package-purchases/' + pid, 'PATCH', { status: 'fulfilled' }, admin)).status, 409);
  assert.equal((await S.request('/api/bookings', 'POST', body, customer)).status, 201);
  const q = await S.request('/api/office/package-purchases', 'GET', undefined, office.cookie);
  assert.equal(q.data.quotas.find((x) => x.service_type === 'bus').remaining, 1);
});
