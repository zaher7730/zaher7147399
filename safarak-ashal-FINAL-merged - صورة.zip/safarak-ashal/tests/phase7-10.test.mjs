// المراحل 7–10: سجل العمليات بالعربية، النسخ الاحتياطي بالملفات والاستعادة، رقم نسخة الحالة، حد المساحات،
// سجل الطلب من الخادم، رد المكتب على التقييم، جلسات الأجهزة، التصدير وطلب الحذف.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { startServer, PNG, b64 } from './helpers.mjs';
import { describeAudit, ACTION_AR } from '../server/lib/audit-labels.mjs';
import { verifyBackup } from '../server/db/backup.mjs';
import { restoreBackup } from '../server/db/restore.mjs';

let S, admin, office, customer;
const ARABIC = /[؀-ۿ]/;
test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
});
test.after(() => S.stop());

async function makeBooking(amount = 500) {
  const r = await S.request('/api/bookings', 'POST', { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: amount, currency: 'YER', details: { form: {} } }, customer.cookie);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  return r.data.booking;
}

test('سجل العمليات: كل وصف بالعربية ولا تظهر مفاتيح إنجليزية', async () => {
  const b = await makeBooking();
  await S.request(`/api/bookings/${b.public_id}/status`, 'PATCH', { status: 'in_progress' }, office.cookie);
  await S.request('/api/auth/login', 'POST', { identifier: '770000001', password: 'wrong-password' });
  const au = await S.request('/api/admin/audit?limit=200', 'GET', undefined, admin);
  assert.equal(au.status, 200);
  assert.ok(au.data.entries.length > 5);
  for (const e of au.data.entries) {
    assert.match(e.label, ARABIC, 'التسمية عربية: ' + e.action);
    if (e.entity) assert.match(e.entity, ARABIC);
    assert.ok(!/[a-z]{3,}\.[a-z]/i.test(e.label), 'لا مفتاح إنجليزي: ' + e.label);
  }
  const st = au.data.entries.find((e) => e.action === 'booking.status');
  assert.match(st.detail, /قيد التنفيذ/);
  assert.equal(describeAudit({ action: 'x.unknown', entity_type: '', entity_id: '', metadata_json: '{bad' }).label, 'عملية في النظام');
});

test('كل عملية يسجّلها الخادم لها وصف عربي', () => {
  const used = new Set();
  const walk = (d) => { for (const f of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, f.name); if (f.isDirectory()) walk(p); else if (p.endsWith('.mjs')) for (const m of fs.readFileSync(p, 'utf8').matchAll(/audit\(\s*[\w.?]+\s*,\s*'([\w.]+)'/g)) used.add(m[1]); } };
  walk(path.resolve(import.meta.dirname, '../server'));
  assert.ok(used.size > 30);
  const missing = [...used].filter((a) => !ACTION_AR[a]);
  assert.deepEqual(missing, []);
});

test('سجل الطلب من الخادم: حالات وحوالة وتقييم ورد المكتب', async () => {
  const b = await makeBooking();
  const up = await S.request('/api/files', 'POST', { filename: 'r.png', mimeType: 'image/png', base64: b64(PNG), bookingId: b.public_id }, customer.cookie);
  const pay = await S.request(`/api/bookings/${b.public_id}/payment`, 'POST', { reference: 'R-1', sender: 'عميل', methodId: office.methodId, methodName: 'حساب الاختبار', currency: 'YER', receiptFileId: up.data.file.id }, customer.cookie);
  assert.equal(pay.status, 201, JSON.stringify(pay.data));
  assert.equal((await S.request(`/api/bookings/${b.public_id}/status`, 'PATCH', { status: 'completed' }, office.cookie)).status, 200);
  const rv = await S.request('/api/reviews', 'POST', { bookingId: b.public_id, rating: 4, comment: 'خدمة جيدة' }, customer.cookie);
  assert.equal(rv.status, 201, JSON.stringify(rv.data));
  const rp = await S.request(`/api/reviews/${rv.data.review.id}/reply`, 'POST', { reply: 'شكراً لك' }, office.cookie);
  assert.equal(rp.status, 200);
  assert.equal(rp.data.review.officeReply, 'شكراً لك');
  const tl = await S.request(`/api/bookings/${b.public_id}/timeline`, 'GET', undefined, office.cookie);
  assert.equal(tl.status, 200);
  const texts = tl.data.timeline.map((x) => x.text).join('|');
  assert.match(texts, /إنشاء الطلب/);
  assert.match(texts, /تسجيل حوالة/);
  assert.match(texts, /مكتمل/);
  assert.match(texts, /تقييم العميل: 4/);
  assert.match(texts, /ردّ المكتب/);
  for (const x of tl.data.timeline) assert.match(x.text, ARABIC);
  const other = await S.otpLogin('customer', '770000009', 'غريب');
  assert.equal((await S.request(`/api/bookings/${b.public_id}/timeline`, 'GET', undefined, other.cookie)).status, 403);
  const au = await S.request('/api/admin/audit?limit=50&action=review.reply', 'GET', undefined, admin);
  assert.equal(au.data.entries[0].label, 'رد المكتب على تقييم');
  const off2 = await S.seedOffice(admin, { phone: '770000011', name: 'مكتب آخر' });
  const other2 = await S.request(`/api/reviews/${rv.data.review.id}/reply`, 'POST', { reply: 'x' }, off2.cookie);
  assert.ok([403, 404].includes(other2.status));
});

test('النسخ الاحتياطي يشمل الملفات ويُسرد، والاستعادة تعيد القاعدة والملفات', async () => {
  const f = await S.request('/api/files', 'POST', { filename: 'doc.png', mimeType: 'image/png', base64: b64(PNG) }, customer.cookie);
  assert.equal(f.status, 201);
  const asset = await S.request('/api/office/assets', 'POST', { filename: 'o.png', mimeType: 'image/png', base64: b64(PNG) }, office.cookie);
  assert.equal(asset.status, 201, JSON.stringify(asset.data));
  const bk = await S.request('/api/admin/backup', 'POST', {}, admin);
  assert.equal(bk.status, 200);
  assert.ok(bk.data.backup.includesFiles);
  assert.ok(bk.data.backup.fileCount >= 2);
  const ls = await S.request('/api/admin/backups', 'GET', undefined, admin);
  assert.equal(ls.status, 200);
  assert.equal(ls.data.backups[0].file, bk.data.file);
  assert.equal((await S.request('/api/admin/backups', 'GET', undefined, customer.cookie)).status, 403);
  // اختبار الاستعادة على نسخة مؤقتة من نفس البنية
  const cfgDirs = fs.readdirSync(os.tmpdir()).filter((d) => d.startsWith('safarak-test-')).map((d) => path.join(os.tmpdir(), d)).find((d) => fs.existsSync(path.join(d, 'backups', bk.data.file)));
  assert.ok(cfgDirs, 'مجلد الاختبار');
  const dbFile = path.join(cfgDirs, 'backups', bk.data.file);
  const v = verifyBackup(dbFile);
  assert.ok(v.ok, v.problems.join());
  const target = fs.mkdtempSync(path.join(os.tmpdir(), 'safarak-restore-'));
  const cfg = { dbPath: path.join(target, 'db.sqlite'), privateUploads: path.join(target, 'private'), publicOfferUploads: path.join(target, 'public') };
  fs.mkdirSync(cfg.privateUploads, { recursive: true });
  fs.writeFileSync(path.join(cfg.privateUploads, 'stale.bin'), 'stale');
  const r = restoreBackup(cfg, dbFile);
  assert.ok(r.files >= 2);
  assert.ok(fs.existsSync(path.join(cfg.privateUploads, f.data.file.id + '.bin')), 'الملف الخاص عاد');
  assert.ok(!fs.existsSync(path.join(cfg.privateUploads, 'stale.bin')), 'الملف القديم لم يختلط بالنسخة');
  assert.ok(fs.existsSync(path.join(cfg.privateUploads + '.before-restore', 'stale.bin')), 'القديم محفوظ جانباً');
  assert.equal(fs.readdirSync(cfg.publicOfferUploads).length >= 1, true);
  // تلف ملف داخل النسخة يمنع الاستعادة قبل أي تغيير
  const filesDir = dbFile.replace(/\.sqlite$/, '.files');
  const victim = path.join(filesDir, 'private', f.data.file.id + '.bin');
  fs.writeFileSync(victim, 'corrupted');
  assert.equal(verifyBackup(dbFile).ok, false);
  const target2 = fs.mkdtempSync(path.join(os.tmpdir(), 'safarak-restore-'));
  const cfg2 = { dbPath: path.join(target2, 'db.sqlite'), privateUploads: path.join(target2, 'private'), publicOfferUploads: path.join(target2, 'public') };
  assert.throws(() => restoreBackup(cfg2, dbFile), /غير سليمة/);
  assert.ok(!fs.existsSync(cfg2.dbPath), 'لم تُلمس القاعدة');
  fs.rmSync(target, { recursive: true, force: true });
  fs.rmSync(target2, { recursive: true, force: true });
});

test('منع الكتابة فوق الحالة بدون رقم نسخة + حد المساحات', async () => {
  const put = (ns, body) => S.request('/api/state/' + ns, 'PUT', body, customer.cookie);
  const a = await put('ns-a', { value: { x: 1 } });
  assert.equal(a.status, 200);
  const blind = await put('ns-a', { value: { x: 2 } });
  assert.equal(blind.status, 428, 'بلا رقم نسخة لا تُكتب فوق الموجود');
  assert.equal(blind.data.version, a.data.version);
  assert.equal((await put('ns-a', { value: { x: 3 }, version: 99 })).status, 409);
  assert.equal((await put('ns-a', { value: { x: 4 }, version: 'abc' })).status, 409);
  assert.equal((await put('ns-a', { value: { x: 5 }, version: a.data.version })).status, 200);
  const g = await S.request('/api/state/ns-a', 'GET', undefined, customer.cookie);
  assert.deepEqual(g.data.value, { x: 5 });
  // حد المساحات: 40 كحد أقصى
  const user = await S.otpLogin('customer', '770000020', 'مستخدم المساحات');
  for (let i = 0; i < 40; i++) assert.equal((await S.request('/api/state/n' + i, 'PUT', { value: i }, user.cookie)).status, 200, 'مساحة ' + i);
  const over = await S.request('/api/state/n40', 'PUT', { value: 1 }, user.cookie);
  assert.equal(over.status, 409);
  assert.match(over.data.error, /الحد الأقصى/);
  assert.equal((await S.request('/api/state/n0', 'PUT', { value: 'upd', version: 1 }, user.cookie)).status, 200, 'تعديل مساحة موجودة مسموح');
  await S.request('/api/state/n1', 'DELETE', undefined, user.cookie);
  assert.equal((await S.request('/api/state/n40', 'PUT', { value: 1 }, user.cookie)).status, 200, 'بعد الحذف تتوفر مساحة');
});

test('جلسات الأجهزة والتصدير وطلب الحذف تُسجَّل بالعربية', async () => {
  const c2 = await S.otpLogin('customer', '770000003', 'عميل تجريبي');
  const list = await S.request('/api/auth/sessions', 'GET', undefined, customer.cookie);
  assert.ok(list.data.sessions.length >= 2);
  assert.ok(list.data.sessions.some((s) => s.current));
  const other = list.data.sessions.find((s) => !s.current);
  assert.equal((await S.request('/api/auth/sessions/' + other.id, 'DELETE', undefined, customer.cookie)).data.revoked, 1);
  const rv = await S.request('/api/auth/sessions/revoke-others', 'POST', {}, customer.cookie);
  assert.equal(rv.status, 200);
  const ex = await S.request('/api/me/export', 'GET', undefined, customer.cookie);
  assert.equal(ex.status, 200);
  assert.equal(ex.data.user.name, 'عميل تجريبي');
  const del = await S.request('/api/me/delete-request', 'POST', {}, customer.cookie);
  assert.equal(del.status, 201);
  assert.equal((await S.request('/api/me/delete-request', 'POST', {}, customer.cookie)).status, 409);
  const tk = await S.request('/api/tickets', 'GET', undefined, customer.cookie);
  assert.ok(tk.data.tickets.some((t) => t.kind === 'data_deletion'));
  const au = await S.request('/api/admin/audit?limit=100', 'GET', undefined, admin);
  const labels = au.data.entries.map((e) => e.label);
  for (const l of ['إنهاء جلسة جهاز', 'إنهاء جلسات الأجهزة الأخرى', 'تصدير بيانات الحساب', 'طلب حذف الحساب والبيانات']) assert.ok(labels.includes(l), l);
  assert.equal(c2.user.id, customer.user.id);
});
