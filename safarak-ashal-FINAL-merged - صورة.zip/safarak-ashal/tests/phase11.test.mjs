// المرحلة 11: تشفير الملفات الخاصة على القرص، وسلامة التشفير، والتوافق مع الملفات القديمة.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { initCrypto, encryptBytes, decryptBytes } from '../server/security/crypto.mjs';

const cfg = (dataKey = '') => ({ production: false, security: { dataKey }, otp: { pepper: 'test-pepper' } });

test('تشفير الملف: البيانات الأصلية لا تظهر في الخرج، وتعود سليمة عند الفك', () => {
  initCrypto(cfg('a'.repeat(64)));
  const plain = Buffer.from('%PDF-1.4 بيانات سرية للعميل 1234567890');
  const enc = encryptBytes(plain);
  assert.ok(!enc.includes(plain), 'النص الأصلي ظاهر داخل الملف المشفّر');
  assert.ok(enc.length > plain.length);
  assert.deepEqual(decryptBytes(enc), plain);
});

test('كل تشفير يستخدم IV جديداً فالمخرجات مختلفة لنفس الإدخال', () => {
  initCrypto(cfg('b'.repeat(64)));
  const plain = Buffer.from('same content');
  assert.notEqual(encryptBytes(plain).toString('hex'), encryptBytes(plain).toString('hex'));
});

test('الملف المعدّل أو بمفتاح مختلف يُرفض ولا يُعاد كنص مقروء', () => {
  initCrypto(cfg('c'.repeat(64)));
  const enc = encryptBytes(Buffer.from('مستند مكتب'));
  const tampered = Buffer.from(enc);
  tampered[tampered.length - 1] ^= 0xff;
  assert.throws(() => decryptBytes(tampered));
  initCrypto(cfg('d'.repeat(64)));
  assert.throws(() => decryptBytes(enc));
  initCrypto(cfg('c'.repeat(64)));
});

test('الملفات القديمة غير المشفّرة تُقرأ كما هي (توافق مع ما قبل المرحلة 11)', () => {
  initCrypto(cfg('e'.repeat(64)));
  const legacy = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3]); // رأس JPEG
  assert.deepEqual(decryptBytes(legacy), legacy);
});
