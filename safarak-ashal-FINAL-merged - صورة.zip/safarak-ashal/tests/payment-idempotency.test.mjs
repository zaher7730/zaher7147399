// الحوالة المعلّقة وإعادة الإرسال: بيانات الحوالة محفوظة مع الحجز، وإعادة الإرسال لا تُنشئ سجلاً مكرراً،
// ولا تتعدّى على حجز أو سند لا يخص العميل.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, PDF, PNG, b64 } from './helpers.mjs';

let S, admin, office, customer, other;
test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = await S.seedOffice(admin);
  customer = (await S.otpLogin('customer', '770000003', 'Test Customer')).cookie;
  other = (await S.otpLogin('customer', '770000005', 'Other Customer')).cookie;
});
test.after(() => S.stop());

const newBooking = async (details = {}) => {
  const r = await S.request('/api/bookings', 'POST', { serviceId: office.serviceId, serviceType: 'bus', title: 'رحلة اختبار', passengerCount: 1, totalAmount: 500, currency: 'YER', details }, customer);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  return r.data.booking;
};
const upload = async (bookingId, filename = 'rc.pdf', mimeType = 'application/pdf', buf = PDF) => {
  const r = await S.request('/api/files', 'POST', { filename, mimeType, base64: b64(buf), bookingId }, customer);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  return r.data.file;
};
const payBody = (fileId, extra = {}) => ({ amount: 500, reference: 'TX-IDEM', sender: 'Test Customer', transferredAt: '2026-10-27', methodId: office.methodId, methodName: 'حساب الاختبار', currency: 'YER', receiptFileId: fileId, ...extra });

test('بيانات الحوالة المعلّقة تُحفظ مع الحجز وتُقرأ في جلسة جديدة', async () => {
  const details = { paymentSubmitted: true, payment: { methodId: office.methodId, methodName: 'حساب الاختبار' }, form: { tn: 'Test Customer', tr: 'TX-PENDING' } };
  const b = await newBooking(details);
  assert.equal(b.payment_status, 'pending');
  await S.request('/api/auth/logout', 'POST', {}, customer);
  const again = await S.otpLogin('customer', '770000003', 'Test Customer');
  customer = again.cookie;
  const got = (await S.request('/api/bookings/' + b.public_id, 'GET', undefined, customer)).data.booking;
  assert.equal(got.payment_status, 'pending');
  assert.deepEqual(got.details.payment, details.payment);
  assert.equal(got.details.paymentSubmitted, true);
  assert.deepEqual(got.details.form, details.form);
  assert.equal((await S.request(`/api/bookings/${b.public_id}/payments`, 'GET', undefined, customer)).data.payments.length, 0);
  // السند المرفوع قبل فشل تسجيل الحوالة يبقى مرتبطاً بالحجز الصحيح ويمكن العثور عليه من الخادم
  const f = await upload(b.public_id);
  const files = (await S.request('/api/files', 'GET', undefined, customer)).data.files;
  const mine = files.find((x) => x.id === f.id);
  assert.equal(mine.booking_id, got.id);
  assert.equal(mine.owner_id, got.customer_id);
  assert.equal(mine.original_name, 'rc.pdf');
});

test('إعادة إرسال نفس الحوالة لا تُنشئ سجلاً مكرراً ولا إشعاراً جديداً', async () => {
  const b = await newBooking({ paymentSubmitted: true });
  const f = await upload(b.public_id);
  const first = await S.request(`/api/bookings/${b.public_id}/payment`, 'POST', payBody(f.id), customer);
  assert.equal(first.status, 201, JSON.stringify(first.data));
  const notifCount = async () => (await S.request('/api/notifications', 'GET', undefined, office.cookie)).data.notifications.filter((n) => n.kind === 'payment_submitted' && n.data.bookingId === b.public_id).length;
  assert.equal(await notifCount(), 1);
  // إعادة بالسند نفسه (ضياع الرد بعد نجاح الحفظ)
  const retry = await S.request(`/api/bookings/${b.public_id}/payment`, 'POST', payBody(f.id), customer);
  assert.equal(retry.status, 200, JSON.stringify(retry.data));
  assert.equal(retry.data.duplicate, true);
  assert.equal(retry.data.payment.id, first.data.payment.id);
  // إعادة بسند مرفوع مرة ثانية لكن بنفس مرجع الحوالة
  const f2 = await upload(b.public_id, 'rc.pdf', 'application/pdf', PDF);
  const retry2 = await S.request(`/api/bookings/${b.public_id}/payment`, 'POST', payBody(f2.id), customer);
  assert.equal(retry2.status, 200);
  assert.equal(retry2.data.payment.id, first.data.payment.id);
  const pays = (await S.request(`/api/bookings/${b.public_id}/payments`, 'GET', undefined, customer)).data.payments;
  assert.equal(pays.length, 1);
  assert.equal(await notifCount(), 1);
  assert.equal((await S.request('/api/bookings/' + b.public_id, 'GET', undefined, customer)).data.booking.payment_status, 'submitted');
});

test('حوالة جديدة بمرجع وسند مختلفين تُسجَّل، والتكرار لا يتجاوز حدود المالك', async () => {
  const b = await newBooking({ paymentSubmitted: true });
  const f = await upload(b.public_id);
  assert.equal((await S.request(`/api/bookings/${b.public_id}/payment`, 'POST', payBody(f.id, { reference: 'TX-A' }), customer)).status, 201);
  const f2 = await upload(b.public_id, 'rc.png', 'image/png', PNG);
  const second = await S.request(`/api/bookings/${b.public_id}/payment`, 'POST', payBody(f2.id, { reference: 'TX-B' }), customer);
  assert.equal(second.status, 201, 'مرجع وسند جديدان = حوالة جديدة مشروعة');
  // عميل آخر لا يستطيع استخدام حجزه أو سنده، ولا يرى نتيجة التكرار
  assert.equal((await S.request(`/api/bookings/${b.public_id}/payment`, 'POST', payBody(f.id, { reference: 'TX-A' }), other)).status, 403);
  assert.equal((await S.request(`/api/bookings/${b.public_id}/payments`, 'GET', undefined, other)).status, 403);
  // السند يجب أن يتبع الحجز نفسه: سند حجز آخر لا يُقبل
  const b2 = await newBooking({ paymentSubmitted: true });
  const foreign = await upload(b.public_id, 'rc.pdf');
  const wrong = await S.request(`/api/bookings/${b2.public_id}/payment`, 'POST', payBody(foreign.id, { reference: 'TX-C' }), customer);
  assert.equal(wrong.status, 400);
  assert.equal((await S.request(`/api/bookings/${b2.public_id}/payments`, 'GET', undefined, customer)).data.payments.length, 0);
});
