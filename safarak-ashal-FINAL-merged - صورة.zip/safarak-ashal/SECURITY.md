# Security policy

Report vulnerabilities privately to the project owner (do not open a public issue).
Details of the protections and how to operate them: `docs/SECURITY_AR.md`.
Never commit `.env`, database files, uploads or keys — only `.env.example`.
