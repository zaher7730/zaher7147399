# الخدمات الخارجية — أين تُربط وكيف (سفرك أسهل)

> كل موضع في الكود يحتاج خدمة خارجية معلَّم بالتعليق `EXTERNAL-SERVICE[الاسم]` أو `EXTERNAL-SECRET[الاسم]`.
> للبحث عنها كلها: `grep -rn "EXTERNAL-" server/`. وحالة كل خدمة تظهر للمدير في لوحة الإدارة (واجهة `GET /api/admin/integrations`).
> **لا تضع أي مفتاح داخل المستودع.** المفاتيح تُوضع في متغيرات البيئة على الاستضافة فقط (القالب: `.env.example`).
> لتوليد الأسرار المحلية: `npm run keys` ثم انسخ الناتج إلى متغيرات البيئة على الاستضافة.

## 1. واتساب (إرسال رمز الدخول OTP) — الأهم
- **المطلوب:** حساب Meta for Developers + WhatsApp Business Cloud API + رقم مخصص + قالب رسالة مصادَق عليه (نوع Authentication).
- **الخطوات:** developers.facebook.com ← إنشاء تطبيق نوع Business ← إضافة منتج WhatsApp ← ربط/إضافة رقم ← إنشاء قالب «رمز تحقق» بالعربية وانتظار الموافقة ← إنشاء System User Token دائم.
- **المتغيرات:** `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_OTP_TEMPLATE`, `WHATSAPP_OTP_LANGUAGE=ar`.
- **الملف في الكود:** `server/integrations/whatsapp.mjs`.
- **للتجربة قبل الربط:** في وضع التطوير (`NODE_ENV=development`) يُطبع الرمز في سجل الخادم بالشكل `[OTP-DEV] phone=... code=....`. **في الإنتاج لا يعمل الدخول قبل ربط واتساب أو SMS.**

## 2. رسائل SMS (بديل/احتياط)
- **الخيار أ — Twilio:** `SMS_PROVIDER=twilio` + `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, و`TWILIO_FROM` أو `TWILIO_MESSAGING_SERVICE_SID`.
- **الخيار ب — بوابة محلية (HTTP):** `SMS_PROVIDER=http` + `SMS_HTTP_URL`, `SMS_HTTP_TOKEN` (يرسل الخادم POST بـ JSON فيه `to` و`message`).
- **قناة الإرسال:** `OTP_CHANNEL=auto|whatsapp|sms`. **الملف:** `server/integrations/sms.mjs`.

## 3. الدفع الإلكتروني (Stripe) — اختياري
- الحوالة اليدوية (رفع السند ثم تأكيد المكتب) تعمل بدونه بالكامل.
- **المطلوب:** حساب Stripe، `PAYMENT_PROVIDER=stripe`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, و`PUBLIC_BASE_URL` برابط موقعك الحقيقي.
- **Webhook:** في لوحة Stripe أضف نقطة `https://دومينك/api/payments/webhook/stripe` وفعّل الحدث `checkout.session.completed`.
- **الملف:** `server/integrations/stripe.mjs`. (تنبيه: توفر Stripe يعتمد على بلد الحساب؛ بدائل محلية تُضاف كمزوّد جديد في نفس المجلد.)

## 4. إشعارات الجهاز (Web Push)
- لا تحتاج حساب خارجي. تحتاج مفاتيح VAPID: `npm run keys` يولّدها ← `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT=mailto:بريدك`.
- تعمل على HTTPS فقط، وعلى آيفون تتطلب إضافة التطبيق للشاشة الرئيسية. **الملف:** `server/integrations/push.mjs`.

## 5. مفتاح تشفير البيانات الحساسة
- `DATA_ENCRYPTION_KEY` (64 حرف hex) يُشفّر رقم هوية العميل ورقم هوية مالك المكتب في القاعدة. **إلزامي في الإنتاج.**
- **احفظ نسخة منه خارج الخادم؛ لو ضاع لا يمكن قراءة تلك الحقول أبداً.** لا تغيّره بعد بدء التشغيل.

## 6. الاستضافة والدومين وHTTPS
- يحتاج الخادم Node 22+ وقرصاً **دائماً** (قاعدة SQLite والملفات الخاصة). المنصات التي تمسح القرص عند كل نشر لا تصلح دون Volume.
- **أسهل طريقة:** Docker (الملف `Dockerfile` و`compose.yaml` جاهزان) على VPS أو منصة تدعم Docker + Volume، وضع Cloudflare أو Nginx أمامه لـ HTTPS.
- متغيرات الإنتاج المهمة: `NODE_ENV=production`, `COOKIE_SECURE=true`, `TRUST_PROXY=true`, `PUBLIC_BASE_URL`, `OTP_PEPPER`, `DATA_ENCRYPTION_KEY`, `ADMIN_PHONE`, `ADMIN_PASSWORD`.
- **للتجربة مع الفريق بلا استضافة:** شغّل على جهازك `npm start` ثم افتح نفقاً (Cloudflare Tunnel أو ngrok) فيعطيك رابط HTTPS مؤقتاً يفتحه الأصدقاء على الجوال.

## 7. نسخ احتياطي خارج الخادم
- النسخ المحلي تلقائي (`BACKUP_EVERY_HOURS`, `BACKUP_KEEP`) في `BACKUP_DIR`.
- **انسخ مجلد النسخ دورياً إلى مكان آخر** (تخزين سحابي أو جهاز آخر). `npm run backup` ينسخ يدوياً، و`scripts/restore.mjs` للاسترجاع.
