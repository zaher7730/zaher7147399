# Contributing and safe updates

This repository is intentionally editable and versioned; it is not a closed or one-off build.

## Change rules
- Keep the original customer, office, and admin visual systems intact unless a requested design change is approved.
- Never add sample customers, offices, phone numbers, prices, bookings, payment receipts, or offers to production seeds. Empty states are preferred until real data is created by an authorized user.
- Put database schema changes in a new numbered SQL file under `server/db/migrations/`. Do not edit a migration already released; create the next migration instead.
- Put shared HTTP/API behavior in `server/` and `shared/`, not duplicated in each app.
- Never commit `.env`, SQLite runtime databases, uploaded documents, or secrets.
- Update tests and Arabic docs whenever a route, role, migration, or deployment requirement changes.
- Do not mark a feature production-ready until its server-side authorization, empty/error/loading states, integration test, and visual regression check are covered.

## Local checks

```sh
node --check server/index.mjs
node --check shared/scripts/api-bridge.js
npm test
npm run test:e2e   # اختبارات المتصفح (تحتاج Playwright: npm ci ثم npm run e2e:install)
npm run build:preview
npm run check:release
```

## Versioning
- Patch (`x.y.Z`): safe bug fix without schema/API contract changes.
- Minor (`x.Y.0`): backward-compatible feature or API addition.
- Major (`X.0.0`): documented breaking API/data contract change.
- Always create a new migration for schema changes and test both fresh installation and upgrade from the prior schema.
