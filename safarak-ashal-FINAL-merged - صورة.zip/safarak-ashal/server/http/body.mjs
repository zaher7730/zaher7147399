import { HttpError } from '../lib/errors.mjs';
export async function readRaw(req, maxBytes) {
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > maxBytes) throw new HttpError(413, 'حجم الطلب كبير');
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw new HttpError(413, 'حجم الطلب كبير');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}
export function parseJson(raw) {
  if (!raw) return {};
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' ? v : {};
  } catch {
    throw new HttpError(400, 'صيغة JSON غير صحيحة');
  }
}
