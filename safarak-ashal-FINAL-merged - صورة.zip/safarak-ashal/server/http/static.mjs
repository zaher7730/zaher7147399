import fs from 'node:fs';
import path from 'node:path';
import { SECURITY_HEADERS, buildCsp, hsts } from '../security/headers.mjs';

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
};
// preview/ ليس عاماً: ملف المعاينة يحمل كود لوحة الإدارة، فيُفتح محلياً من القرص فقط (انظر preview/README.txt)
const PUBLIC_ROOTS = new Set(['apps', 'shared']);

export function resolveStatic(root, urlPath) {
  let p;
  try { p = decodeURIComponent(urlPath.split('?')[0]); } catch { return null; }
  if (p.includes('\0')) return null;
  const parts = p.split('/').filter(Boolean);
  if (parts.some((x) => x.startsWith('.'))) return null; // لا ملفات مخفية؛ والجذور المسموحة محصورة في PUBLIC_ROOTS
  if (!PUBLIC_ROOTS.has(parts[0])) return null;
  const full = path.resolve(root, '.' + p);
  return full.startsWith(root + path.sep) ? full : null;
}

export function sendFile(file, req, res, extra = {}, cfg = null) {
  const ext = path.extname(file).toLowerCase();
  const isHtml = ext === '.html';
  const stat = fs.statSync(file);
  const etag = `W/"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
  if (req.headers['if-none-match'] === etag) { res.writeHead(304, { ETag: etag }); return res.end(); }
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Content-Length': stat.size,
    ETag: etag,
    ...SECURITY_HEADERS,
    ...(isHtml && cfg ? { 'Content-Security-Policy': buildCsp(cfg) } : {}),
    ...(cfg ? hsts(cfg) : {}),
    'Cache-Control': isHtml || ext === '.js' || ext === '.css' ? 'no-cache' : 'public, max-age=86400',
    ...extra,
  });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}
