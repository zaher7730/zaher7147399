// موجّه بسيط: مسارات بمعاملات :name، وصلاحيات حسب الدور.
export function createRouter() {
  const routes = [];
  const compile = (pattern) => {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:([A-Za-z]+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '$');
    return { re, keys };
  };
  const add = (method, pattern, opts, handler) => {
    if (typeof opts === 'function') { handler = opts; opts = {}; }
    routes.push({ method, pattern, ...compile(pattern), opts, handler });
  };
  return {
    get: (p, o, h) => add('GET', p, o, h),
    post: (p, o, h) => add('POST', p, o, h),
    put: (p, o, h) => add('PUT', p, o, h),
    patch: (p, o, h) => add('PATCH', p, o, h),
    delete: (p, o, h) => add('DELETE', p, o, h),
    match(method, path) {
      let pathMatched = false;
      for (const r of routes) {
        const m = r.re.exec(path);
        if (!m) continue;
        pathMatched = true;
        if (r.method !== method) continue;
        const params = {};
        r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
        return { route: r, params };
      }
      return { route: null, pathMatched };
    },
  };
}
