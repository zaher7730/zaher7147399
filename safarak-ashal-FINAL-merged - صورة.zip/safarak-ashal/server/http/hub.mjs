// قناة أحداث لحظية (Server-Sent Events): إشعارات ورسائل وتحديثات حالة تصل فور حدوثها.
export function createHub() {
  const clients = new Map(); // userId -> Set(res)
  return {
    subscribe(userId, res) {
      if (!clients.has(userId)) clients.set(userId, new Set());
      clients.get(userId).add(res);
      res.on('close', () => { clients.get(userId)?.delete(res); if (!clients.get(userId)?.size) clients.delete(userId); });
    },
    publish(userId, type, payload = {}) {
      const set = clients.get(userId);
      if (!set) return 0;
      const frame = `event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`;
      for (const res of set) { try { res.write(frame); } catch { /* الاتصال أُغلق */ } }
      return set.size;
    },
    heartbeat() { for (const set of clients.values()) for (const res of set) { try { res.write(': ping\n\n'); } catch { /* ignore */ } } },
    count: () => [...clients.values()].reduce((a, s) => a + s.size, 0),
  };
}
