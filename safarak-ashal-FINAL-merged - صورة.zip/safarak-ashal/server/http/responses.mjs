// أدوات الاستجابة.
import { SECURITY_HEADERS } from '../security/headers.mjs';
export { SECURITY_HEADERS };

export function sendJson(res, status, data, extra = {}) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...SECURITY_HEADERS,
    ...extra,
  });
  res.end(JSON.stringify(data));
}
export const sendFail = (res, status, error, extra = {}) => sendJson(res, status, { ok: false, error, ...extra });
