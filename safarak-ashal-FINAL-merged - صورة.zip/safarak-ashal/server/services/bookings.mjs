// منطق مشترك للحجوزات: الحالات، الإشعارات، الحصة، تحويل الصفوف.
import { transaction } from '../db/connection.mjs';
import { issueInvoice } from './invoices.mjs';

export const STATUS = ['pending', 'reviewing', 'in_progress', 'waiting_documents', 'waiting_payment', 'completed', 'rejected', 'cancelled'];
export const STATUS_AR = {
  pending: 'قيد المراجعة', reviewing: 'قيد المراجعة', in_progress: 'قيد التنفيذ', waiting_documents: 'بانتظار المستندات',
  waiting_payment: 'بانتظار الدفع', completed: 'مكتمل', rejected: 'مرفوض', cancelled: 'ملغي',
};

export const BOOKING_SELECT = `SELECT b.*,c.name AS customer_name,c.phone AS customer_phone,o.name AS office_user_name,o.office_name,i.number AS invoice_number
  FROM bookings b JOIN users c ON c.id=b.customer_id LEFT JOIN users o ON o.id=b.office_id LEFT JOIN invoices i ON i.booking_id=b.id`;

export const mapBooking = (r) => ({ ...r, details: JSON.parse(r.details_json || '{}') });

/** هل للعرض حجز نشط؟ (النشط = أي حالة غير مكتمل/مرفوض/ملغي) */
export function carReserved(db, serviceId) {
  return !!db.prepare("SELECT 1 FROM bookings WHERE service_id=? AND status NOT IN ('completed','rejected','cancelled') LIMIT 1").get(serviceId);
}

export function quotaEnforced(db) {
  const r = db.prepare("SELECT value_json FROM platform_settings WHERE setting_key='enforceQuota'").get();
  try { return r ? JSON.parse(r.value_json) === true : false; } catch { return false; }
}

/** ينشئ الحجز + حدثه الأول + الفاتورة + يخصم الحصة (إن فُعّلت) + يُشعر المكتب. */
export function insertBooking(app, { publicId, customerId, officeId, serviceType, serviceId = null, title, details, pax, amount, currency, status = 'pending', actorId, note = 'إنشاء الحجز' }) {
  const { db } = app;
  const row = transaction(db, () => {
    // سيارة واحدة = عميل واحد في كل مرة: ما دام حجز سابق لنفس العرض غير مكتمل/مرفوض/ملغي فهي غير متاحة
    if (serviceId && serviceType === 'cars' && carReserved(db, serviceId)) {
      const err = new Error('هذه السيارة محجوزة حالياً من عميل آخر'); err.status = 409; throw err;
    }
    if (officeId && quotaEnforced(db)) {
      const q = db.prepare('SELECT remaining FROM office_quotas WHERE office_id=? AND service_type=?').get(officeId, serviceType);
      if (!q || q.remaining < 1) { const err = new Error('لا يملك المكتب رصيداً كافياً لاستقبال هذا الطلب'); err.status = 409; throw err; }
      db.prepare("UPDATE office_quotas SET remaining=remaining-1,updated_at=datetime('now') WHERE office_id=? AND service_type=?").run(officeId, serviceType);
    }
    const r = db
      .prepare('INSERT INTO bookings(public_id,customer_id,office_id,service_type,service_id,title,details_json,passenger_count,total_amount,currency,status) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(publicId, customerId, officeId, serviceType, serviceId, title, JSON.stringify(details || {}), pax, amount, currency, status);
    const id = Number(r.lastInsertRowid);
    db.prepare('INSERT INTO booking_events(booking_id,actor_id,old_status,new_status,note) VALUES(?,?,?,?,?)').run(id, actorId, null, status, note);
    const b = db.prepare('SELECT * FROM bookings WHERE id=?').get(id);
    issueInvoice(db, b);
    return b;
  });
  if (officeId) {
    app.notify(officeId, { kind: 'booking_new', title: 'طلب جديد من عميل', body: title, data: { bookingId: publicId } });
    app.hub.publish(officeId, 'booking', { bookingId: publicId, event: 'created' });
  }
  return db.prepare(`${BOOKING_SELECT} WHERE b.id=?`).get(row.id);
}

export function changeStatus(app, booking, actor, status, note = '') {
  const { db } = app;
  const old = booking.status;
  db.prepare("UPDATE bookings SET status=?,updated_at=datetime('now') WHERE id=?").run(status, booking.id);
  db.prepare('INSERT INTO booking_events(booking_id,actor_id,old_status,new_status,note) VALUES(?,?,?,?,?)').run(booking.id, actor.id, old, status, note.slice(0, 1000));
  app.audit(actor, 'booking.status', 'booking', booking.public_id, { old, status });
  const label = STATUS_AR[status] || status;
  if (actor.id !== booking.customer_id)
    app.notify(booking.customer_id, { kind: 'booking_status', title: 'تحديث على طلبك', body: `${booking.title} — ${label}`, data: { bookingId: booking.public_id, status } });
  if (booking.office_id && actor.id !== booking.office_id)
    app.notify(booking.office_id, { kind: 'booking_status', title: 'تحديث على طلب', body: `${booking.title} — ${label}`, data: { bookingId: booking.public_id, status } });
  for (const uid of [booking.customer_id, booking.office_id]) if (uid) app.hub.publish(uid, 'booking', { bookingId: booking.public_id, event: 'status', status });
  return db.prepare(`${BOOKING_SELECT} WHERE b.id=?`).get(booking.id);
}
