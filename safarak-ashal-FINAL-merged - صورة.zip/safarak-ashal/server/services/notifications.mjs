// إنشاء إشعار محفوظ في قاعدة البيانات + دفعه فوراً للمستخدم إن كان متصلاً (SSE).
export function createNotifier(db, hub, onNew = () => {}) {
  const ins = db.prepare('INSERT INTO notifications(user_id,kind,title,body,data_json) VALUES(?,?,?,?,?)');
  const get = db.prepare('SELECT * FROM notifications WHERE id=?');
  return function notify(userId, { kind, title, body = '', data = {} }) {
    if (!userId) return null;
    const r = ins.run(userId, kind, title, body, JSON.stringify(data));
    const row = get.get(Number(r.lastInsertRowid));
    hub.publish(userId, 'notification', mapNotification(row));
    onNew(userId); // دفع إلى الجهاز إن كان مشتركاً (Web Push)
    return row;
  };
}
export const mapNotification = (r) => ({ id: r.id, kind: r.kind, title: r.title, body: r.body, data: JSON.parse(r.data_json || '{}'), read: !!r.read_at, createdAt: r.created_at });
