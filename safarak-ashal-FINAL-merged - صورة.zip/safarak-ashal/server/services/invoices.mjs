import { transaction } from '../db/connection.mjs';
// فاتورة بترقيم تسلسلي لكل مكتب: INV-<رقم المكتب>-<تسلسل 6 خانات>.
export function issueInvoice(db, booking) {
  if (!booking.office_id) return null;
  const existing = db.prepare('SELECT * FROM invoices WHERE booking_id=?').get(booking.id);
  if (existing) return existing;
  return transaction(db, () => {
    db.prepare('INSERT INTO invoice_counters(office_id,last_seq) VALUES(?,0) ON CONFLICT(office_id) DO NOTHING').run(booking.office_id);
    db.prepare('UPDATE invoice_counters SET last_seq=last_seq+1 WHERE office_id=?').run(booking.office_id);
    const seq = db.prepare('SELECT last_seq FROM invoice_counters WHERE office_id=?').get(booking.office_id).last_seq;
    const number = `INV-${booking.office_id}-${String(seq).padStart(6, '0')}`;
    db.prepare('INSERT INTO invoices(booking_id,office_id,seq,number) VALUES(?,?,?,?)').run(booking.id, booking.office_id, seq, number);
    return db.prepare('SELECT * FROM invoices WHERE booking_id=?').get(booking.id);
  });
}
