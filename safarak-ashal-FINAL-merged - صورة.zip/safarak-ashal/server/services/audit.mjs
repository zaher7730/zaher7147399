export function createAudit(db) {
  const stmt = db.prepare('INSERT INTO audit_log(actor_id,action,entity_type,entity_id,metadata_json) VALUES(?,?,?,?,?)');
  return (user, action, entityType, entityId, metadata = {}) =>
    stmt.run(user?.id || null, action, entityType, String(entityId ?? ''), JSON.stringify(metadata));
}
