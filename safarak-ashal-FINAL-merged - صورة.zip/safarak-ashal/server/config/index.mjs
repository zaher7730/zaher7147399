// الإعدادات المركزية: كل قيمة تُقرأ من متغيرات البيئة هنا فقط (لا قراءة process.env في بقية الملفات).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadDotEnv } from './env.mjs';
import { parseUtcOffset } from '../lib/trip-time.mjs';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const num = (v, d) => (v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : d);
const abs = (v, d) => path.resolve(ROOT, v || d);

export function loadConfig(overrides = {}) {
  loadDotEnv(ROOT);
  const e = { ...process.env, ...overrides };
  // قيمة غير معروفة (مثل «production   # تعليق») كانت تُعطّل وضع الإنتاج بصمت: نرفض التشغيل بدلاً من ذلك
  if (!['', 'development', 'production', 'test'].includes(e.NODE_ENV || '')) {
    throw new Error(`NODE_ENV غير صالح: "${e.NODE_ENV}". القيم المسموحة: development أو production أو test (احذف التعليقات من سطر NODE_ENV)`);
  }
  const production = e.NODE_ENV === 'production';
  const cfg = {
    root: ROOT,
    version: JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version,
    production,
    host: e.HOST || '127.0.0.1',
    port: num(e.PORT, 8000),
    dbPath: abs(e.DB_PATH, 'storage/database/safarak.sqlite'),
    privateUploads: abs(e.PRIVATE_UPLOADS_DIR, 'storage/private/uploads'),
    publicOfferUploads: abs(e.PUBLIC_OFFER_UPLOADS_DIR, 'storage/public/offers'),
    backupDir: abs(e.BACKUP_DIR, 'storage/backups'),
    backupEveryHours: num(e.BACKUP_EVERY_HOURS, production ? 6 : 0),
    backupKeep: num(e.BACKUP_KEEP, 14),
    sessionHours: num(e.SESSION_HOURS, 24),
    secureCookie: e.COOKIE_SECURE === 'true',
    trustProxy: e.TRUST_PROXY === 'true',
    maxBody: num(e.MAX_BODY_MB, 7) * 1024 * 1024,
    maxFile: num(e.MAX_FILE_MB, 5) * 1024 * 1024,
    allowedOrigins: String(e.ALLOWED_ORIGINS || '').split(',').map((x) => x.trim()).filter(Boolean),
    rateLimitPerMinute: num(e.RATE_LIMIT_PER_MINUTE, 600),
    // توقيت المنصة الذي تُفسَّر به أوقات الرحلات في العروض (اليمن +03:00)
    platformUtcOffsetMin: parseUtcOffset(e.PLATFORM_UTC_OFFSET || '+03:00'),
    otp: {
      ttlMs: 5 * 60 * 1000,
      pepper: e.OTP_PEPPER || (production ? '' : 'local-development-only-pepper'),
      channel: e.OTP_CHANNEL || 'auto', // auto | whatsapp | sms
    },
    whatsapp: {
      token: e.WHATSAPP_ACCESS_TOKEN || '',
      phoneNumberId: e.WHATSAPP_PHONE_NUMBER_ID || '',
      template: e.WHATSAPP_OTP_TEMPLATE || '',
      language: e.WHATSAPP_OTP_LANGUAGE || 'ar',
      graphVersion: e.WHATSAPP_GRAPH_VERSION || 'v22.0',
    },
    sms: {
      provider: e.SMS_PROVIDER || '', // twilio | http
      twilioSid: e.TWILIO_ACCOUNT_SID || '',
      twilioToken: e.TWILIO_AUTH_TOKEN || '',
      twilioFrom: e.TWILIO_FROM || '',
      twilioMessagingService: e.TWILIO_MESSAGING_SERVICE_SID || '',
      httpUrl: e.SMS_HTTP_URL || '',
      httpToken: e.SMS_HTTP_TOKEN || '',
    },
    payments: {
      provider: e.PAYMENT_PROVIDER || '', // stripe | (يُضاف لاحقاً)
      stripeSecret: e.STRIPE_SECRET_KEY || '',
      stripeWebhookSecret: e.STRIPE_WEBHOOK_SECRET || '',
      publicBaseUrl: e.PUBLIC_BASE_URL || '',
    },
    security: {
      dataKey: e.DATA_ENCRYPTION_KEY || '', // EXTERNAL-SECRET: يُولَّد بـ npm run keys
    },
    push: {
      publicKey: e.VAPID_PUBLIC_KEY || '',
      privateKey: e.VAPID_PRIVATE_KEY || '',
      subject: (e.VAPID_SUBJECT || '').trim(), // مطلوب مع المفاتيح: mailto:بريدك@نطاقك أو https://نطاقك
    },
    backupOffsiteHint: e.BACKUP_OFFSITE_NOTE || '',
    admin: {
      name: e.ADMIN_NAME || 'مدير المنصة',
      phone: (e.ADMIN_PHONE || '').trim(),
      email: e.ADMIN_EMAIL || null,
      password: e.ADMIN_PASSWORD || '',
    },
  };
  if (production && !cfg.otp.pepper) throw new Error('OTP_PEPPER is required in production');
  if (production && (cfg.push.publicKey || cfg.push.privateKey) && !/^(mailto:[^@\s]+@(?!example\.(com|org|net)$)[^@\s]+\.[^@\s]+|https:\/\/\S+)$/.test(cfg.push.subject)) {
    throw new Error('VAPID_SUBJECT مطلوب في الإنتاج بصيغة mailto:بريدك@نطاقك أو https://نطاقك (وليس example.com)');
  }
  return cfg;
}
