// تحميل ملف .env داخل الخادم نفسه (بدون bash ولا source) — يعمل بنفس الطريقة في Linux وWindows وDocker.
// القواعد: المتغير الموجود أصلاً في البيئة له الأولوية (لا يُكتب فوقه)، والتعليقات بعد القيمة تُحذف بمحلل Node.
// SAFARAK_ENV_FILE: مسار بديل للملف (للاختبارات)، وقيمته الفارغة تعطّل القراءة.
import fs from 'node:fs';
import path from 'node:path';

export function dotEnvPath(root) {
  const override = process.env.SAFARAK_ENV_FILE;
  if (override !== undefined) return override ? path.resolve(override) : '';
  return path.join(root, '.env');
}

export function loadDotEnv(root) {
  const file = dotEnvPath(root);
  if (!file || !fs.existsSync(file)) return false;
  process.loadEnvFile(file);
  return true;
}
