// تركيب التطبيق: يبني سياق الخدمات المشتركة ثم معالج HTTP (موجّه API + ملفات ثابتة + أمان).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import http from 'node:http';

import { openDatabase } from './db/connection.mjs';
import { migrate } from './db/migrate.mjs';
import { bootstrapAdmin } from './db/bootstrap.mjs';
import { scheduleBackups } from './db/backup.mjs';
import { createRouter } from './http/router.mjs';
import { createHub } from './http/hub.mjs';
import { readRaw, parseJson } from './http/body.mjs';
import { parseCookies, buildCookie } from './http/cookies.mjs';
import { sendJson, sendFail, SECURITY_HEADERS } from './http/responses.mjs';
import { resolveStatic, sendFile } from './http/static.mjs';
import { createLimiter } from './security/rate-limit.mjs';
import { createLockout } from './security/lockout.mjs';
import { createSessions } from './security/sessions.mjs';
import { createCsrfCheck } from './security/csrf.mjs';
import { initCrypto } from './security/crypto.mjs';
import { HttpError } from './lib/errors.mjs';
import { hashToken } from './security/index.mjs';
import { createAudit } from './services/audit.mjs';
import { createNotifier } from './services/notifications.mjs';
import { pushToUser } from './integrations/push.mjs';

import health from './routes/health.mjs';
import publicRoutes from './routes/public.mjs';
import auth from './routes/auth.mjs';
import files from './routes/files.mjs';
import bookings from './routes/bookings.mjs';
import payments from './routes/payments.mjs';
import office from './routes/office.mjs';
import officeApplications from './routes/office-applications.mjs';
import admin from './routes/admin.mjs';
import adminData from './routes/admin-data.mjs';
import messages from './routes/messages.mjs';
import reviews from './routes/reviews.mjs';
import notifications from './routes/notifications.mjs';
import favorites from './routes/favorites.mjs';
import profile from './routes/profile.mjs';
import state from './routes/state.mjs';
import packages from './routes/packages.mjs';
import tickets from './routes/tickets.mjs';
import events from './routes/events.mjs';
import verification from './routes/verification.mjs';

const SESSION_COOKIE = 'safarak_session';

export function createApp(cfg, { log = (...a) => console.log(...a) } = {}) {
  initCrypto(cfg);
  const db = openDatabase(cfg);
  migrate(db, log);
  bootstrapAdmin(db, cfg, log);
  const hub = createHub();
  const app = {
    cfg,
    db,
    hub,
    log,
    audit: createAudit(db),
    notify: null,
    limited: createLimiter(12, 60000),
    apiLimited: createLimiter(cfg.rateLimitPerMinute, 60000),
    lockout: createLockout(db),
    sessions: createSessions(db, cfg),
  };

  app.notify = createNotifier(db, hub, (uid) => { pushToUser(app, uid).catch(() => {}); });

  const router = createRouter();
  for (const mod of [
    health, publicRoutes, auth, officeApplications, files, bookings, payments, office, admin, adminData,
    messages, reviews, notifications, favorites, profile, state, packages, tickets, events, verification,
  ]) mod(router, app);

  const sessionUser = (req) => {
    const token = parseCookies(req)[SESSION_COOKIE];
    if (!token) return null;
    const u = db
      .prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1')
      .get(hashToken(token), Date.now()) || null;
    if (u) app.sessions.touch(token);
    return u;
  };
  app.sessionUser = sessionUser;
  app.sessionCookie = (token, maxAge) => buildCookie(SESSION_COOKIE, token, { maxAge, secure: cfg.secureCookie });
  app.sessionName = SESSION_COOKIE;

  const clientIp = (req) => (cfg.trustProxy ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() : '') || req.socket.remoteAddress || 'unknown';
  app.clientIp = clientIp;

  const sameOrigin = createCsrfCheck(cfg);

  async function handleApi(req, res, url, method, requestId) {
    const ip = clientIp(req);
    if (app.apiLimited('api:' + ip)) return sendFail(res, 429, 'طلبات كثيرة؛ حاول بعد قليل');
    if (!['GET', 'HEAD', 'OPTIONS'].includes(method) && !sameOrigin(req)) return sendFail(res, 403, 'مصدر الطلب غير مسموح');
    const { route, params, pathMatched } = router.match(method, url.pathname);
    if (!route) return sendFail(res, pathMatched ? 405 : 404, pathMatched ? 'الطريقة غير مدعومة' : 'واجهة API غير موجودة');
    const user = sessionUser(req);
    const opts = route.opts || {};
    if (!opts.public && !user) return sendFail(res, 401, 'يلزم تسجيل الدخول');
    if (opts.roles && !(user && opts.roles.includes(user.role))) return sendFail(res, 403, opts.forbidden || 'غير مصرح لهذا الحساب بهذه العملية');
    let rawCache;
    const ctx = {
      req, res, url, params, user, app, ip, requestId, method,
      query: url.searchParams,
      raw: async () => (rawCache ??= await readRaw(req, cfg.maxBody)),
      body: async () => parseJson(await ctx.raw()),
      json: (status, data, headers) => sendJson(res, status, data, headers),
      ok: (data = {}, status = 200, headers) => sendJson(res, status, { ok: true, ...data }, headers),
      fail: (status, message, extra) => sendFail(res, status, message, extra),
    };
    await route.handler(ctx);
    if (!res.writableEnded && !res.headersSent) sendFail(res, 500, 'لم تُرجع العملية استجابة');
  }

  async function handler(req, res) {
    const requestId = crypto.randomBytes(4).toString('hex');
    const started = Date.now();
    res.on('finish', () => {
      if (req.url.startsWith('/api/') || res.statusCode >= 500) {
        log(JSON.stringify({ t: new Date().toISOString(), id: requestId, m: req.method, u: req.url.split('?')[0], s: res.statusCode, ms: Date.now() - started }));
      }
    });
    try {
      const url = new URL(req.url, 'http://localhost');
      const p = url.pathname;
      const method = req.method || 'GET';
      if (method === 'OPTIONS') {
        const origin = req.headers.origin;
        const allowed = origin && (cfg.allowedOrigins.includes(origin));
        res.writeHead(204, {
          ...(allowed ? { 'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Credentials': 'true', Vary: 'Origin' } : {}),
          'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type',
        });
        return res.end();
      }
      if (p.startsWith('/api/')) return await handleApi(req, res, url, method, requestId);

      // صور العروض العامة
      const offerAsset = p.match(/^\/assets\/offers\/([0-9a-f-]{36})$/i);
      if (offerAsset && (method === 'GET' || method === 'HEAD')) {
        const asset = db.prepare('SELECT * FROM public_assets WHERE id=?').get(offerAsset[1]);
        const f = asset && path.join(cfg.publicOfferUploads, asset.stored_name);
        if (!asset || !fs.existsSync(f)) return sendFail(res, 404, 'الصورة غير موجودة');
        res.writeHead(200, { 'Content-Type': asset.mime_type, 'Content-Length': asset.size_bytes, ...SECURITY_HEADERS, 'Cache-Control': 'public, max-age=86400' });
        return method === 'HEAD' ? res.end() : fs.createReadStream(f).pipe(res);
      }

      // مسارات قديمة /apps/<app>/src/ تُحوَّل إلى المسار النظيف
      const legacy = p.match(/^\/apps\/(customer|office|admin)\/src\/?$/);
      if (legacy) { res.writeHead(301, { Location: `/apps/${legacy[1]}/${url.search}` }); return res.end(); }

      // لوحة الإدارة لا تُقدَّم لغير المدير (والتحقق الفعلي يتم أيضاً في كل API إداري)
      if (p === '/apps/admin' || p.startsWith('/apps/admin/')) {
        const visitor = sessionUser(req);
        if (!visitor || visitor.role !== 'admin') {
          res.writeHead(302, { Location: '/apps/customer/?access=admin', 'Cache-Control': 'no-store' });
          return res.end();
        }
      }
      // الجذر يحوَّل إلى تطبيق العميل (الصفحة تستخدم مسارات نسبية فلا تعمل من /). نحافظ على ?access=admin
      if (p === '/' && (method === 'GET' || method === 'HEAD')) { res.writeHead(302, { Location: '/apps/customer/' + url.search, 'Cache-Control': 'no-cache' }); return res.end(); }
      if (p === '/sw.js') return sendFile(path.join(cfg.root, 'shared/pwa/sw.js'), req, res, { 'Service-Worker-Allowed': '/', 'Cache-Control': 'no-cache' }, cfg);
      if (method !== 'GET' && method !== 'HEAD') return sendFail(res, 405, 'الطريقة غير مدعومة');
      const file = resolveStatic(cfg.root, p);
      if (!file) return sendFail(res, 404, 'غير موجود');
      let stat;
      try { stat = fs.statSync(file); } catch { return sendFail(res, 404, 'الملف غير موجود'); }
      if (stat.isDirectory()) {
        const index = path.join(file, 'index.html');
        if (!fs.existsSync(index)) return sendFail(res, 404, 'الصفحة غير موجودة');
        if (!p.endsWith('/')) { res.writeHead(301, { Location: p + '/' + url.search }); return res.end(); }
        return sendFile(index, req, res, {}, cfg);
      }
      return sendFile(file, req, res, {}, cfg);
    } catch (e) {
      if (e instanceof HttpError) return sendFail(res, e.status, e.message, e.extra || {});
      log(JSON.stringify({ t: new Date().toISOString(), id: requestId, level: 'error', msg: String(e?.stack || e).slice(0, 1500) }));
      if (!res.headersSent) return sendFail(res, 500, 'حدث خطأ داخلي');
      res.end();
    }
  }

  const server = http.createServer(handler);
  const heartbeat = setInterval(() => hub.heartbeat(), 25000);
  heartbeat.unref();
  const stopBackups = scheduleBackups(db, cfg, log);
  const cleanup = setInterval(() => {
    try {
      db.prepare('DELETE FROM sessions WHERE expires_at<?').run(Date.now());
      db.prepare('DELETE FROM otp_challenges WHERE expires_at<?').run(Date.now() - 3600 * 1000);
      app.lockout.sweep();
    } catch { /* ignore */ }
  }, 3600 * 1000);
  cleanup.unref();

  return {
    app, server, db,
    listen: () => new Promise((resolve) => server.listen(cfg.port, cfg.host, () => resolve(server))),
    close: () => new Promise((resolve) => { clearInterval(heartbeat); clearInterval(cleanup); stopBackups(); server.closeAllConnections?.(); server.close(() => { try { db.close(); } catch { /* ignore */ } resolve(); }); }),
  };
}
