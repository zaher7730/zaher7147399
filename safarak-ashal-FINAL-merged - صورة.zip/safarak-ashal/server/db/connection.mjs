import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

export function openDatabase(cfg) {
  for (const dir of [path.dirname(cfg.dbPath), cfg.privateUploads, cfg.publicOfferUploads, cfg.backupDir]) fs.mkdirSync(dir, { recursive: true });
  const db = new DatabaseSync(cfg.dbPath);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;');
  return db;
}

/** يشغّل fn داخل معاملة؛ يتراجع عند أي خطأ. */
const depth = new WeakMap();
export function transaction(db, fn) {
  if ((depth.get(db) || 0) > 0) return fn(); // معاملة متداخلة: تنضم للمعاملة الخارجية
  depth.set(db, 1);
  try { return runTransaction(db, fn); } finally { depth.set(db, 0); }
}
function runTransaction(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch { /* ignore */ }
    throw e;
  }
}
