CREATE TABLE IF NOT EXISTS service_points (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 city TEXT NOT NULL,
 address TEXT NOT NULL DEFAULT '',
 phone TEXT NOT NULL DEFAULT '',
 active INTEGER NOT NULL DEFAULT 1,
 created_by INTEGER REFERENCES users(id),
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS service_points_public_idx ON service_points(active, city, name);
