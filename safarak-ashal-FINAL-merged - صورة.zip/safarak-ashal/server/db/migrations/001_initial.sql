PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 phone TEXT NOT NULL UNIQUE,
 email TEXT UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('customer','office','admin')),
 office_name TEXT,
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 expires_at INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions(user_id);
CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at);
CREATE TABLE IF NOT EXISTS bookings (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 public_id TEXT NOT NULL UNIQUE,
 customer_id INTEGER NOT NULL REFERENCES users(id),
 office_id INTEGER REFERENCES users(id),
 service_type TEXT NOT NULL,
 title TEXT NOT NULL,
 details_json TEXT NOT NULL DEFAULT '{}',
 passenger_count INTEGER NOT NULL DEFAULT 1 CHECK(passenger_count > 0),
 total_amount REAL NOT NULL DEFAULT 0 CHECK(total_amount >= 0),
 currency TEXT NOT NULL DEFAULT 'YER',
 payment_status TEXT NOT NULL DEFAULT 'pending' CHECK(payment_status IN ('pending','submitted','confirmed','rejected','refunded')),
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','reviewing','in_progress','waiting_documents','waiting_payment','completed','rejected','cancelled')),
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS bookings_customer_idx ON bookings(customer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS bookings_office_idx ON bookings(office_id, created_at DESC);
CREATE TABLE IF NOT EXISTS booking_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 actor_id INTEGER NOT NULL REFERENCES users(id),
 old_status TEXT,
 new_status TEXT NOT NULL,
 note TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS office_services (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 office_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 service_type TEXT NOT NULL,
 title TEXT NOT NULL,
 details_json TEXT NOT NULL DEFAULT '{}',
 active INTEGER NOT NULL DEFAULT 1,
 updated_at TEXT NOT NULL DEFAULT (datetime('now')),
 UNIQUE(office_id, service_type, title)
);
CREATE TABLE IF NOT EXISTS audit_log (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 actor_id INTEGER REFERENCES users(id),
 action TEXT NOT NULL,
 entity_type TEXT NOT NULL,
 entity_id TEXT,
 metadata_json TEXT NOT NULL DEFAULT '{}',
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
