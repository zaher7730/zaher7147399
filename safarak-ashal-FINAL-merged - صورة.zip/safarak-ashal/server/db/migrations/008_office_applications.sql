PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS office_applications (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 office_name TEXT NOT NULL,
 owner_name TEXT NOT NULL,
 phone TEXT NOT NULL,
 address TEXT NOT NULL,
 registration_number TEXT NOT NULL,
 license_number TEXT NOT NULL DEFAULT '',
 owner_id_number TEXT NOT NULL,
 documents_json TEXT NOT NULL DEFAULT '{}',
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 review_note TEXT NOT NULL DEFAULT '',
 reviewed_by INTEGER REFERENCES users(id),
 reviewed_at TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS office_applications_status_idx ON office_applications(status, created_at DESC);
CREATE INDEX IF NOT EXISTS office_applications_phone_idx ON office_applications(phone);
