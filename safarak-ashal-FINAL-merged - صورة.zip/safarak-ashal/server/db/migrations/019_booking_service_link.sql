-- ربط الحجز بالعرض المنشور (office_services) لمعرفة السيارات المحجوزة (متاح / غير متاح).
-- SQLite لا تدعم ADD COLUMN مع REFERENCES بقيمة افتراضية غير NULL؛ العمود يقبل NULL (حجوزات الأمانات والطلبات اليدوية بلا عرض).
ALTER TABLE bookings ADD COLUMN service_id INTEGER REFERENCES office_services(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS bookings_service_idx ON bookings(service_id, status);
