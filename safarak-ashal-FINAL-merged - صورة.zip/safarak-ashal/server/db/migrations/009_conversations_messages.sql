-- المحادثات بين العميل والمكتب (مرتبطة اختيارياً بحجز) والرسائل والمرفقات.
CREATE TABLE IF NOT EXISTS conversations (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 office_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 booking_id INTEGER REFERENCES bookings(id) ON DELETE SET NULL,
 subject TEXT NOT NULL DEFAULT '',
 last_message_at TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS conversations_unique_idx ON conversations(customer_id, office_id, IFNULL(booking_id,0));
CREATE INDEX IF NOT EXISTS conversations_customer_idx ON conversations(customer_id, last_message_at DESC);
CREATE INDEX IF NOT EXISTS conversations_office_idx ON conversations(office_id, last_message_at DESC);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
 sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 kind TEXT NOT NULL DEFAULT 'text' CHECK(kind IN ('text','image','file','system')),
 body TEXT NOT NULL DEFAULT '',
 file_id TEXT REFERENCES stored_files(id) ON DELETE SET NULL,
 read_at TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS messages_conv_idx ON messages(conversation_id, id);
CREATE INDEX IF NOT EXISTS messages_unread_idx ON messages(conversation_id, read_at);
