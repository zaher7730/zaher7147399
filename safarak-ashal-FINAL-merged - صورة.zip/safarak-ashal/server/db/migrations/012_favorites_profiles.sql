-- المفضلة، وملفات العملاء، وملفات المكاتب العامة.
CREATE TABLE IF NOT EXISTS favorites (
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 kind TEXT NOT NULL CHECK(kind IN ('office','service')),
 ref_id INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 PRIMARY KEY(user_id, kind, ref_id)
);
CREATE TABLE IF NOT EXISTS customer_profiles (
 user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 id_type TEXT NOT NULL DEFAULT '',
 id_number TEXT NOT NULL DEFAULT '',
 id_file_id TEXT REFERENCES stored_files(id) ON DELETE SET NULL,
 city TEXT NOT NULL DEFAULT '',
 extra_json TEXT NOT NULL DEFAULT '{}',
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS office_profiles (
 office_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 display_name TEXT NOT NULL DEFAULT '',
 city TEXT NOT NULL DEFAULT '',
 address TEXT NOT NULL DEFAULT '',
 years INTEGER NOT NULL DEFAULT 0,
 phone TEXT NOT NULL DEFAULT '',
 whatsapp TEXT NOT NULL DEFAULT '',
 license_no TEXT NOT NULL DEFAULT '',
 registration_no TEXT NOT NULL DEFAULT '',
 about TEXT NOT NULL DEFAULT '',
 logo_asset_id TEXT REFERENCES public_assets(id) ON DELETE SET NULL,
 cover_asset_id TEXT REFERENCES public_assets(id) ON DELETE SET NULL,
 verified INTEGER NOT NULL DEFAULT 0,
 extra_json TEXT NOT NULL DEFAULT '{}',
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
