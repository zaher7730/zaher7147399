CREATE TABLE IF NOT EXISTS stored_files (
 id TEXT PRIMARY KEY,
 owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 booking_id INTEGER REFERENCES bookings(id) ON DELETE SET NULL,
 original_name TEXT NOT NULL,
 stored_name TEXT NOT NULL UNIQUE,
 mime_type TEXT NOT NULL,
 size_bytes INTEGER NOT NULL CHECK(size_bytes > 0),
 sha256 TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS stored_files_owner_idx ON stored_files(owner_id, created_at DESC);
CREATE INDEX IF NOT EXISTS stored_files_booking_idx ON stored_files(booking_id);
