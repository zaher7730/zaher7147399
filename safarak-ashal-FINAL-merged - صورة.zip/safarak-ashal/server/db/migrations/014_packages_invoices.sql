-- باقات «شراء عروض تطبيقنا» التي تعرضها الإدارة على المكاتب وطلبات الشراء ورصيد المكتب.
CREATE TABLE IF NOT EXISTS offer_packages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 service_type TEXT NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity > 0),
 price REAL NOT NULL CHECK(price >= 0),
 currency TEXT NOT NULL DEFAULT 'YER',
 active INTEGER NOT NULL DEFAULT 1,
 created_by INTEGER REFERENCES users(id),
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS package_purchases (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 office_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 package_id INTEGER REFERENCES offer_packages(id) ON DELETE SET NULL,
 service_type TEXT NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity > 0),
 total_price REAL NOT NULL DEFAULT 0 CHECK(total_price >= 0),
 currency TEXT NOT NULL DEFAULT 'YER',
 custom_request INTEGER NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'requested' CHECK(status IN ('requested','approved','paid','rejected','fulfilled')),
 note TEXT NOT NULL DEFAULT '',
 reviewed_by INTEGER REFERENCES users(id),
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS package_purchases_office_idx ON package_purchases(office_id, created_at DESC);
CREATE TABLE IF NOT EXISTS office_quotas (
 office_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 service_type TEXT NOT NULL,
 remaining INTEGER NOT NULL DEFAULT 0,
 updated_at TEXT NOT NULL DEFAULT (datetime('now')),
 PRIMARY KEY(office_id, service_type)
);
-- ترقيم فواتير تسلسلي لكل مكتب.
CREATE TABLE IF NOT EXISTS invoice_counters (
 office_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 last_seq INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS invoices (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 booking_id INTEGER NOT NULL UNIQUE REFERENCES bookings(id) ON DELETE CASCADE,
 office_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 seq INTEGER NOT NULL,
 number TEXT NOT NULL UNIQUE,
 issued_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS invoices_office_idx ON invoices(office_id, seq);
