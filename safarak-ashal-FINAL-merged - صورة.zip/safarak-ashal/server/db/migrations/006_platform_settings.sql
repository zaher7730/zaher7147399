CREATE TABLE IF NOT EXISTS platform_settings (
 setting_key TEXT PRIMARY KEY,
 value_json TEXT NOT NULL,
 updated_by INTEGER REFERENCES users(id),
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
