-- حفظ دائم لحالة كل واجهة لكل مستخدم (بديل localStorage) مع رقم نسخة لمنع الكتابة فوق تعديل أحدث.
CREATE TABLE IF NOT EXISTS user_state (
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 namespace TEXT NOT NULL,
 value_json TEXT NOT NULL,
 version INTEGER NOT NULL DEFAULT 1,
 updated_at TEXT NOT NULL DEFAULT (datetime('now')),
 PRIMARY KEY(user_id, namespace)
);
-- مجموعات بيانات المنصة التي تديرها الإدارة (إعلانات، مدن، صفحات، عمولات...) مع علم للنشر العام.
CREATE TABLE IF NOT EXISTS platform_docs (
 collection TEXT NOT NULL,
 doc_id TEXT NOT NULL,
 data_json TEXT NOT NULL,
 is_public INTEGER NOT NULL DEFAULT 0,
 updated_by INTEGER REFERENCES users(id),
 updated_at TEXT NOT NULL DEFAULT (datetime('now')),
 PRIMARY KEY(collection, doc_id)
);
CREATE INDEX IF NOT EXISTS platform_docs_public_idx ON platform_docs(is_public, collection);
