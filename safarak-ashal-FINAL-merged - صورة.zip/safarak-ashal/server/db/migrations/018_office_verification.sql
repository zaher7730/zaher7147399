-- توثيق المكتب: طلب من المكتب (وثائق خاصة) ثم مراجعة المدير. المكتب لا يستطيع توثيق نفسه.
CREATE TABLE IF NOT EXISTS office_verifications (
 office_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 legal_name TEXT NOT NULL DEFAULT '',
 owner_name TEXT NOT NULL DEFAULT '',
 owner_id_enc TEXT NOT NULL DEFAULT '',
 license_no TEXT NOT NULL DEFAULT '',
 registration_no TEXT NOT NULL DEFAULT '',
 tax_no TEXT NOT NULL DEFAULT '',
 issuer TEXT NOT NULL DEFAULT '',
 issued_at TEXT NOT NULL DEFAULT '',
 expires_at TEXT NOT NULL DEFAULT '',
 files_json TEXT NOT NULL DEFAULT '{}',
 note TEXT NOT NULL DEFAULT '',
 reviewed_by INTEGER REFERENCES users(id),
 reviewed_at TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
