-- محاولات الدفع عبر بوابة إلكترونية (يُفعَّل عند ضبط مزود الدفع) وأحداث الويب هوك للتدقيق.
CREATE TABLE IF NOT EXISTS payment_intents (
 id TEXT PRIMARY KEY,
 booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 provider TEXT NOT NULL,
 provider_ref TEXT,
 amount REAL NOT NULL,
 currency TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'created' CHECK(status IN ('created','pending','paid','failed','cancelled')),
 checkout_url TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS payment_intents_ref_idx ON payment_intents(provider, provider_ref);
CREATE TABLE IF NOT EXISTS webhook_events (
 id TEXT PRIMARY KEY,
 provider TEXT NOT NULL,
 type TEXT NOT NULL,
 payload_json TEXT NOT NULL,
 received_at TEXT NOT NULL DEFAULT (datetime('now'))
);
