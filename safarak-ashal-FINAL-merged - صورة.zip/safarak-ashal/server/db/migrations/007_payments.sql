CREATE TABLE IF NOT EXISTS payment_methods (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 owner_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
 type TEXT NOT NULL,
 name TEXT NOT NULL,
 account_no TEXT NOT NULL,
 holder TEXT NOT NULL DEFAULT '',
 currency TEXT NOT NULL DEFAULT 'YER',
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 updated_at TEXT NOT NULL DEFAULT (datetime('now')),
 UNIQUE(owner_id,type,name,account_no)
);
CREATE INDEX IF NOT EXISTS payment_methods_public_idx ON payment_methods(active, owner_id);
CREATE TABLE IF NOT EXISTS payment_submissions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 customer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 office_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 method_id INTEGER REFERENCES payment_methods(id) ON DELETE SET NULL,
 method_name TEXT NOT NULL,
 amount REAL NOT NULL CHECK(amount > 0),
 currency TEXT NOT NULL,
 reference TEXT NOT NULL,
 sender TEXT NOT NULL,
 transferred_at TEXT NOT NULL,
 receipt_file_id TEXT REFERENCES stored_files(id),
 status TEXT NOT NULL DEFAULT 'submitted' CHECK(status IN ('submitted','confirmed','rejected')),
 note TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS payment_submissions_office_idx ON payment_submissions(office_id,status,created_at DESC);
CREATE INDEX IF NOT EXISTS payment_submissions_booking_idx ON payment_submissions(booking_id,created_at DESC);
