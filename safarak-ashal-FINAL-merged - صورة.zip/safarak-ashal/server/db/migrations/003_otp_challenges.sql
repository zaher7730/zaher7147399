CREATE TABLE IF NOT EXISTS otp_challenges (
 id TEXT PRIMARY KEY,
 phone TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('customer','office','admin')),
 name TEXT NOT NULL DEFAULT '',
 code_hash TEXT NOT NULL,
 expires_at INTEGER NOT NULL,
 attempts INTEGER NOT NULL DEFAULT 0,
 consumed_at INTEGER,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS otp_phone_created_idx ON otp_challenges(phone, created_at DESC);
