-- حالة المحادثة من منظور الإدارة: مفتوحة / مُبلَّغ عنها / مغلقة (الإغلاق يمنع إرسال رسائل جديدة).
ALTER TABLE conversations ADD COLUMN admin_status TEXT NOT NULL DEFAULT 'open' CHECK (admin_status IN ('open','reported','closed'));
