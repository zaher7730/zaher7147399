-- تقييمات المكاتب من العملاء (تقييم واحد لكل عميل/مكتب/حجز) مع رد المكتب.
CREATE TABLE IF NOT EXISTS reviews (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 office_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 customer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 booking_id INTEGER REFERENCES bookings(id) ON DELETE SET NULL,
 rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
 comment TEXT NOT NULL DEFAULT '',
 office_reply TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'published' CHECK(status IN ('published','hidden')),
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS reviews_unique_idx ON reviews(office_id, customer_id, IFNULL(booking_id,0));
CREATE INDEX IF NOT EXISTS reviews_office_idx ON reviews(office_id, status, created_at DESC);
