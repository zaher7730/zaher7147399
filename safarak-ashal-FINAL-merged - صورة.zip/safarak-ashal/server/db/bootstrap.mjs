// إنشاء أول مدير من متغيرات البيئة فقط (لا توجد بيانات دخول افتراضية).
import { hashPassword, strongEnough } from '../security/index.mjs';
import { normalizePhone } from '../lib/phone.mjs';
export function bootstrapAdmin(db, cfg, log = () => {}) {
  if (!cfg.admin.phone || !cfg.admin.password) return false;
  if (!strongEnough(cfg.admin.password)) throw new Error('ADMIN_PASSWORD must be at least 10 characters and not digits only');
  if (db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get()) return false;
  db.prepare('INSERT INTO users(name,phone,email,password_hash,role) VALUES(?,?,?,?,?)').run(cfg.admin.name, normalizePhone(cfg.admin.phone), cfg.admin.email, hashPassword(cfg.admin.password), 'admin');
  log('Initial administrator created from environment configuration.');
  return true;
}
