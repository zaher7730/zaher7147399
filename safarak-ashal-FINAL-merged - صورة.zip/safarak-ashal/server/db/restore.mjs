// استعادة نسخة احتياطية: قاعدة البيانات + الملفات معاً. يتحقق من كل شيء قبل تغيير أي ملف حالي (أوقف الخادم أولاً).
import fs from 'node:fs';
import path from 'node:path';
import { filesDirOf, verifyBackup } from './backup.mjs';

export function restoreBackup(cfg, dbFile, log = () => {}) {
  const v = verifyBackup(dbFile);
  if (!v.ok) throw new Error('النسخة غير سليمة: ' + v.problems.join('، '));
  if (fs.existsSync(cfg.dbPath)) fs.copyFileSync(cfg.dbPath, cfg.dbPath + '.before-restore');
  for (const s of ['-wal', '-shm']) fs.rmSync(cfg.dbPath + s, { force: true });
  fs.copyFileSync(dbFile, cfg.dbPath);
  log(`database restored: ${cfg.dbPath}`);
  if (v.legacy) { log('نسخة قديمة بلا ملفات: لم تُغيَّر الملفات الحالية'); return { files: 0, legacy: true }; }
  const dir = filesDirOf(dbFile);
  let count = 0;
  for (const [area, target] of [['private', cfg.privateUploads], ['public', cfg.publicOfferUploads]]) {
    // الملفات الحالية تُحفظ جانباً (تُستبدل نسخة سابقة من «.before-restore») ثم تُعاد ملفات النسخة كما كانت
    if (fs.existsSync(target)) {
      fs.rmSync(target + '.before-restore', { recursive: true, force: true });
      fs.renameSync(target, target + '.before-restore');
    }
    fs.mkdirSync(target, { recursive: true });
    const from = path.join(dir, area);
    if (!fs.existsSync(from)) continue;
    for (const f of fs.readdirSync(from)) {
      fs.copyFileSync(path.join(from, f), path.join(target, f));
      fs.chmodSync(path.join(target, f), area === 'private' ? 0o600 : 0o644);
      count++;
    }
  }
  log(`files restored: ${count}`);
  return { files: count, legacy: false };
}
