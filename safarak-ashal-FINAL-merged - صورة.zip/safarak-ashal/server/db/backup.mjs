// نسخ احتياطي متّسق: قاعدة البيانات (VACUUM INTO) + الملفات الخاصة وصور العروض مع بيان (manifest) بتجزئة كل ملف.
// الشكل: safarak-<وقت>.sqlite  بجانب  safarak-<وقت>.files/{private,public,manifest.json}
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const DB_RE = /^safarak-(.+)\.sqlite$/;
const AREAS = (cfg) => [['private', cfg.privateUploads], ['public', cfg.publicOfferUploads]];

const sha256File = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
export const filesDirOf = (dbFile) => dbFile.replace(/\.sqlite$/, '.files');

/** يقرأ بيان النسخة ويتحقق أن كل ملف موجود وسليم. يرجع { ok, problems, manifest } */
export function verifyBackup(dbFile) {
  const dir = filesDirOf(dbFile), problems = [];
  if (!fs.existsSync(dbFile)) return { ok: false, problems: ['ملف قاعدة البيانات غير موجود'], manifest: null };
  if (!fs.existsSync(dir)) return { ok: true, legacy: true, problems: [], manifest: null };
  let manifest;
  try { manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8')); } catch { return { ok: false, problems: ['بيان النسخة تالف أو مفقود'], manifest: null }; }
  if (manifest.dbSha256 && sha256File(dbFile) !== manifest.dbSha256) problems.push('قاعدة البيانات لا تطابق بيان النسخة');
  for (const f of manifest.files || []) {
    const p = path.join(dir, f.area, f.name);
    if (!fs.existsSync(p)) problems.push(`ملف مفقود: ${f.area}/${f.name}`);
    else if (sha256File(p) !== f.sha256) problems.push(`ملف تالف: ${f.area}/${f.name}`);
  }
  return { ok: problems.length === 0, problems, manifest };
}

export function backupNow(db, cfg, log = () => {}) {
  fs.mkdirSync(cfg.backupDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const file = path.join(cfg.backupDir, `safarak-${stamp}.sqlite`);
  // القاعدة أولاً ثم الملفات: أي ملف رُفع بينهما يظهر زائداً في النسخة ولا ينقص منها ملف تشير إليه القاعدة
  db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
  fs.chmodSync(file, 0o600);
  const finalDir = filesDirOf(file), tmpDir = finalDir + '.partial';
  fs.rmSync(tmpDir, { recursive: true, force: true });
  fs.mkdirSync(tmpDir, { recursive: true, mode: 0o700 });
  const files = [];
  for (const [area, src] of AREAS(cfg)) {
    const dest = path.join(tmpDir, area);
    fs.mkdirSync(dest, { recursive: true, mode: 0o700 });
    if (!fs.existsSync(src)) continue;
    for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
      if (!ent.isFile()) continue;
      const from = path.join(src, ent.name), to = path.join(dest, ent.name);
      fs.copyFileSync(from, to);
      fs.chmodSync(to, 0o600);
      files.push({ area, name: ent.name, size: fs.statSync(to).size, sha256: sha256File(to) });
    }
  }
  fs.writeFileSync(path.join(tmpDir, 'manifest.json'), JSON.stringify({ version: 1, createdAt: new Date().toISOString(), db: path.basename(file), dbSha256: sha256File(file), files }, null, 1), { mode: 0o600 });
  fs.renameSync(tmpDir, finalDir);
  const all = fs.readdirSync(cfg.backupDir).filter((f) => DB_RE.test(f)).sort();
  for (const old of all.slice(0, Math.max(0, all.length - cfg.backupKeep))) {
    fs.rmSync(path.join(cfg.backupDir, old), { force: true });
    fs.rmSync(filesDirOf(path.join(cfg.backupDir, old)), { recursive: true, force: true });
  }
  log(`backup created: ${file} (+${files.length} files)`);
  return file;
}

/** قائمة النسخ الموجودة (الأحدث أولاً) */
export function listBackups(cfg) {
  if (!fs.existsSync(cfg.backupDir)) return [];
  return fs.readdirSync(cfg.backupDir).filter((f) => DB_RE.test(f)).sort().reverse().map((f) => {
    const full = path.join(cfg.backupDir, f), st = fs.statSync(full), dir = filesDirOf(full);
    let manifest = null;
    try { manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8')); } catch { /* نسخة قديمة بلا ملفات */ }
    const list = manifest?.files || [];
    return {
      file: f, createdAt: manifest?.createdAt || st.mtime.toISOString(), sizeBytes: st.size + list.reduce((a, x) => a + x.size, 0),
      includesFiles: !!manifest, fileCount: list.length,
    };
  });
}

export function scheduleBackups(db, cfg, log) {
  if (!cfg.backupEveryHours) return () => {};
  const t = setInterval(() => { try { backupNow(db, cfg, log); } catch (e) { log('backup failed: ' + e.message); } }, cfg.backupEveryHours * 3600 * 1000);
  t.unref();
  return () => clearInterval(t);
}
