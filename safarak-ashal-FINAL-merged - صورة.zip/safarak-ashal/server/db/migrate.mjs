// يطبّق ملفات SQL المرقّمة بالترتيب مرة واحدة لكل ملف (ويسجلها في schema_migrations).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { transaction } from './connection.mjs';

const DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'migrations');

export function migrate(db, log = () => {}) {
  db.exec("CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT (datetime('now')))");
  const done = new Set(db.prepare('SELECT name FROM schema_migrations').all().map((r) => r.name));
  const files = fs.readdirSync(DIR).filter((x) => /^\d+.*\.sql$/.test(x)).sort();
  let applied = 0;
  for (const name of files) {
    if (done.has(name)) continue;
    transaction(db, () => {
      db.exec(fs.readFileSync(path.join(DIR, name), 'utf8'));
      db.prepare('INSERT INTO schema_migrations(name) VALUES(?)').run(name);
    });
    log(`migration applied: ${name}`);
    applied++;
  }
  return applied;
}
