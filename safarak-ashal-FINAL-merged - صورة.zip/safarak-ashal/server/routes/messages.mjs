// المحادثات بين العميل والمكتب (مرتبطة اختيارياً بحجز) مع مرفقات وحالة قراءة ولحظية عبر SSE.
import { bad, conflict, forbidden, notFound } from '../lib/errors.mjs';

export default function register(router, app) {
  const { db, notify, hub, audit } = app;
  const PARTY = { roles: ['customer', 'office'], forbidden: 'المحادثات للعميل والمكتب فقط' };
  const ADMIN = { roles: ['admin'], forbidden: 'هذه العملية للمدير فقط' };
  const ADMIN_STATUS = ['open', 'reported', 'closed'];

  const fileStmt = db.prepare('SELECT original_name,mime_type,size_bytes FROM stored_files WHERE id=?');
  const mapMsg = (m) => {
    const f = m.file_id ? fileStmt.get(m.file_id) : null;
    return {
      id: m.id, conversationId: m.conversation_id, senderId: m.sender_id, kind: m.kind, body: m.body,
      fileId: m.file_id, fileUrl: m.file_id ? '/api/files/' + m.file_id : null,
      fileName: f?.original_name || null, fileType: f?.mime_type || null, fileSize: f?.size_bytes || null,
      readAt: m.read_at, createdAt: m.created_at,
    };
  };
  const mapConv = (c, me) => ({
    id: c.id, bookingId: c.booking_public_id || null, subject: c.subject, lastMessageAt: c.last_message_at, createdAt: c.created_at,
    customer: { id: c.customer_id, name: c.customer_name, phone: me === c.office_id ? c.customer_phone : undefined }, office: { id: c.office_id, name: c.office_display },
    unread: c.unread || 0, lastBody: c.last_body || '', status: c.admin_status || 'open', me,
  });

  const SEL = `SELECT c.*,cu.name AS customer_name,cu.phone AS customer_phone,COALESCE(ou.office_name,ou.name) AS office_display,b.public_id AS booking_public_id,
      (SELECT COUNT(*) FROM messages m WHERE m.conversation_id=c.id AND m.sender_id<>? AND m.read_at IS NULL) AS unread,
      (SELECT COALESCE(NULLIF(m.body,''),'📎 مرفق') FROM messages m WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_body
    FROM conversations c JOIN users cu ON cu.id=c.customer_id JOIN users ou ON ou.id=c.office_id LEFT JOIN bookings b ON b.id=c.booking_id`;

  const loadConv = (ctx) => {
    const c = db.prepare(`${SEL} WHERE c.id=?`).get(ctx.user.id, Number(ctx.params.id));
    if (!c) throw notFound('المحادثة غير موجودة');
    if (c.customer_id !== ctx.user.id && c.office_id !== ctx.user.id) throw forbidden('ليست من محادثاتك');
    return c;
  };

  router.get('/api/conversations', PARTY, (ctx) => {
    const col = ctx.user.role === 'office' ? 'c.office_id' : 'c.customer_id';
    const rows = db.prepare(`${SEL} WHERE ${col}=? ORDER BY COALESCE(c.last_message_at,c.created_at) DESC LIMIT 300`).all(ctx.user.id, ctx.user.id);
    ctx.ok({ conversations: rows.map((c) => mapConv(c, ctx.user.id)) });
  });

  // إنشاء أو فتح محادثة: العميل يحدد المكتب (أو الحجز)، والمكتب يحدد الحجز/العميل.
  router.post('/api/conversations', PARTY, async (ctx) => {
    const { user } = ctx;
    const b = await ctx.body();
    let customerId, officeId, bookingId = null;
    if (b.bookingId) {
      const bk = db.prepare('SELECT * FROM bookings WHERE public_id=?').get(String(b.bookingId));
      if (!bk || !bk.office_id) throw notFound('الحجز غير موجود أو غير مرتبط بمكتب');
      if (bk.customer_id !== user.id && bk.office_id !== user.id) throw forbidden('ليس حجزك');
      customerId = bk.customer_id; officeId = bk.office_id; // محادثة واحدة لكل (عميل، مكتب) مهما تعددت حجوزاتهما
    } else if (user.role === 'customer') {
      const o = db.prepare("SELECT id FROM users WHERE id=? AND role='office' AND active=1").get(Number(b.officeId));
      if (!o) throw bad('المكتب غير صالح');
      customerId = user.id; officeId = o.id;
    } else {
      const c = db.prepare("SELECT id FROM users WHERE id=? AND role='customer' AND active=1").get(Number(b.customerId));
      if (!c) throw bad('العميل غير صالح');
      customerId = c.id; officeId = user.id;
    }
    db.prepare('INSERT INTO conversations(customer_id,office_id,booking_id,subject) VALUES(?,?,?,?) ON CONFLICT DO NOTHING').run(customerId, officeId, bookingId, String(b.subject || '').slice(0, 200));
    const row = db.prepare('SELECT id FROM conversations WHERE customer_id=? AND office_id=? AND IFNULL(booking_id,0)=?').get(customerId, officeId, bookingId || 0);
    const c = db.prepare(`${SEL} WHERE c.id=?`).get(user.id, row.id);
    ctx.ok({ conversation: mapConv(c, user.id) }, 201);
  });

  router.get('/api/conversations/:id/messages', PARTY, (ctx) => {
    const c = loadConv(ctx);
    const after = Number(ctx.query.get('after') || 0);
    const rows = db.prepare('SELECT * FROM messages WHERE conversation_id=? AND id>? ORDER BY id LIMIT 500').all(c.id, after);
    ctx.ok({ conversation: mapConv(c, ctx.user.id), messages: rows.map(mapMsg) });
  });

  router.post('/api/conversations/:id/messages', PARTY, async (ctx) => {
    if (app.limited('msg:' + ctx.user.id, 60)) return ctx.fail(429, 'رسائل كثيرة؛ انتظر قليلاً');
    const c = loadConv(ctx);
    if (c.admin_status === 'closed') throw conflict('أُغلقت هذه المحادثة من الإدارة');
    const b = await ctx.body();
    const text = String(b.body || '').trim().slice(0, 4000);
    let fileId = null, kind = 'text';
    if (b.fileId) {
      const f = db.prepare('SELECT * FROM stored_files WHERE id=? AND owner_id=?').get(String(b.fileId), ctx.user.id);
      if (!f) throw bad('الملف غير موجود أو ليس لك');
      fileId = f.id; kind = f.mime_type.startsWith('image/') ? 'image' : 'file';
    }
    if (!text && !fileId) throw bad('اكتب رسالة أو أرفق ملفاً');
    const r = db.prepare('INSERT INTO messages(conversation_id,sender_id,kind,body,file_id) VALUES(?,?,?,?,?)').run(c.id, ctx.user.id, kind, text, fileId);
    db.prepare("UPDATE conversations SET last_message_at=datetime('now') WHERE id=?").run(c.id);
    const msg = mapMsg(db.prepare('SELECT * FROM messages WHERE id=?').get(Number(r.lastInsertRowid)));
    const other = ctx.user.id === c.customer_id ? c.office_id : c.customer_id;
    hub.publish(other, 'message', msg);
    hub.publish(ctx.user.id, 'message', msg);
    notify(other, { kind: 'message', title: ctx.user.id === c.customer_id ? `رسالة من ${c.customer_name}` : `رسالة من ${c.office_display}`, body: text || '📎 مرفق', data: { conversationId: c.id } });
    ctx.ok({ message: msg }, 201);
  });

  router.post('/api/conversations/:id/read', PARTY, (ctx) => {
    const c = loadConv(ctx);
    const r = db.prepare("UPDATE messages SET read_at=datetime('now') WHERE conversation_id=? AND sender_id<>? AND read_at IS NULL").run(c.id, ctx.user.id);
    const other = ctx.user.id === c.customer_id ? c.office_id : c.customer_id;
    if (r.changes) hub.publish(other, 'read', { conversationId: c.id });
    ctx.ok({ marked: Number(r.changes) });
  });

  router.get('/api/messages/unread-count', PARTY, (ctx) =>
    ctx.ok({ count: db.prepare('SELECT COUNT(*) AS n FROM messages m JOIN conversations c ON c.id=m.conversation_id WHERE (c.customer_id=? OR c.office_id=?) AND m.sender_id<>? AND m.read_at IS NULL').get(ctx.user.id, ctx.user.id, ctx.user.id).n }));

  // ---- مراقبة الإدارة للمحادثات بين العملاء والمكاتب ----
  // قراءة كل المحادثات مسموحة للمدير فقط، وكل اطلاع يُسجَّل في سجل التدقيق (مرة كل 10 دقائق لكل مدير لتفادي الإغراق).
  const viewLogged = new Map();
  const lastMsgs = db.prepare('SELECT m.id,m.sender_id,m.kind,m.body,m.file_id,m.created_at FROM messages m WHERE m.conversation_id=? ORDER BY m.id DESC LIMIT 60');
  const imgMsgs = db.prepare("SELECT file_id FROM messages WHERE conversation_id=? AND kind='image' AND file_id IS NOT NULL ORDER BY id DESC LIMIT 3");
  router.get('/api/admin/conversations', ADMIN, (ctx) => {
    const limit = Math.min(Math.max(Number(ctx.query.get('limit') || 100), 1), 300);
    const rows = db.prepare(`SELECT c.*,cu.name AS customer_name,COALESCE(ou.office_name,ou.name) AS office_display,b.public_id AS booking_public_id,
        (SELECT COUNT(*) FROM messages m WHERE m.conversation_id=c.id) AS msg_count,
        (SELECT COALESCE(NULLIF(m.body,''),'📎 مرفق') FROM messages m WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_body
      FROM conversations c JOIN users cu ON cu.id=c.customer_id JOIN users ou ON ou.id=c.office_id LEFT JOIN bookings b ON b.id=c.booking_id
      ORDER BY COALESCE(c.last_message_at,c.created_at) DESC LIMIT ?`).all(limit);
    const conversations = rows.map((c) => ({
      id: c.id, customerId: c.customer_id, customerName: c.customer_name, officeId: c.office_id, officeName: c.office_display,
      bookingId: c.booking_public_id || null, status: c.admin_status, messageCount: c.msg_count, lastBody: c.last_body || '', lastMessageAt: c.last_message_at || c.created_at,
      transcript: lastMsgs.all(c.id).reverse().map((m) => ({ at: m.created_at, from: m.sender_id === c.customer_id ? 'customer' : 'office', text: m.body || '', kind: m.kind, fileId: m.file_id })),
      images: imgMsgs.all(c.id).map((m) => m.file_id).reverse(),
    }));
    const now = Date.now();
    if (!viewLogged.has(ctx.user.id) || now - viewLogged.get(ctx.user.id) > 600000) {
      viewLogged.set(ctx.user.id, now);
      audit(ctx.user, 'conversation.admin_view', 'conversation', 'all', { count: conversations.length });
    }
    ctx.ok({ conversations });
  });

  router.patch('/api/admin/conversations/:id', ADMIN, async (ctx) => {
    const c = db.prepare('SELECT * FROM conversations WHERE id=?').get(Number(ctx.params.id));
    if (!c) throw notFound('المحادثة غير موجودة');
    const b = await ctx.body();
    const status = String(b.status || '');
    if (!ADMIN_STATUS.includes(status)) throw bad('حالة المحادثة غير صحيحة');
    if (status !== c.admin_status) {
      db.prepare('UPDATE conversations SET admin_status=? WHERE id=?').run(status, c.id);
      audit(ctx.user, 'conversation.admin_status', 'conversation', String(c.id), { old: c.admin_status, status });
      if (status === 'closed') for (const uid of [c.customer_id, c.office_id]) notify(uid, { kind: 'conversation_closed', title: 'أُغلقت محادثة من الإدارة', body: 'لا يمكن إرسال رسائل جديدة في هذه المحادثة', data: { conversationId: c.id } });
    }
    ctx.ok({ conversation: { id: c.id, status } });
  });
}
