// المفضلة: مكاتب وعروض يحفظها العميل (محفوظة في الخادم لتظهر على أي جهاز).
import { bad } from '../lib/errors.mjs';

export default function register(router, app) {
  const { db } = app;
  const list = (userId) => db.prepare('SELECT kind,ref_id,created_at FROM favorites WHERE user_id=? ORDER BY created_at DESC').all(userId).map((f) => ({ kind: f.kind, id: f.ref_id, createdAt: f.created_at }));

  router.get('/api/favorites', (ctx) => ctx.ok({ favorites: list(ctx.user.id) }));

  router.put('/api/favorites', async (ctx) => {
    const b = await ctx.body();
    const kind = String(b.kind || ''), id = Number(b.id);
    if (!['office', 'service'].includes(kind) || !Number.isInteger(id) || id <= 0) throw bad('عنصر المفضلة غير صالح');
    const exists = kind === 'office'
      ? db.prepare("SELECT id FROM users WHERE id=? AND role='office'").get(id)
      : db.prepare('SELECT id FROM office_services WHERE id=?').get(id);
    if (!exists) throw bad('العنصر غير موجود');
    if (b.on === false) db.prepare('DELETE FROM favorites WHERE user_id=? AND kind=? AND ref_id=?').run(ctx.user.id, kind, id);
    else db.prepare('INSERT OR IGNORE INTO favorites(user_id,kind,ref_id) VALUES(?,?,?)').run(ctx.user.id, kind, id);
    ctx.ok({ favorites: list(ctx.user.id) });
  });
}
