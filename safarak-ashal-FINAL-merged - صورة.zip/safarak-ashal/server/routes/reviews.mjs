// تقييمات المكاتب: العميل يقيّم بعد اكتمال حجزه، والمكتب يرد، والمدير يخفي/يظهر.
import { bad, conflict, forbidden, notFound } from '../lib/errors.mjs';

export default function register(router, app) {
  const { db, audit, notify } = app;
  const map = (r) => ({ id: r.id, officeId: r.office_id, customerId: r.customer_id, bookingId: r.booking_public_id || null, rating: r.rating, comment: r.comment, officeReply: r.office_reply, status: r.status, createdAt: r.created_at, customerName: r.customer_name, officeName: r.office_name });
  const SEL = `SELECT r.*,b.public_id AS booking_public_id,cu.name AS customer_name,COALESCE(ou.office_name,ou.name) AS office_name
    FROM reviews r JOIN users cu ON cu.id=r.customer_id JOIN users ou ON ou.id=r.office_id LEFT JOIN bookings b ON b.id=r.booking_id`;

  router.post('/api/reviews', { roles: ['customer'], forbidden: 'التقييم للعملاء فقط' }, async (ctx) => {
    const b = await ctx.body();
    const rating = Number(b.rating);
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw bad('التقييم من 1 إلى 5');
    const bk = db.prepare('SELECT * FROM bookings WHERE public_id=? AND customer_id=?').get(String(b.bookingId || ''), ctx.user.id);
    if (!bk || !bk.office_id) throw notFound('الحجز غير موجود');
    if (bk.status !== 'completed') throw conflict('يمكن تقييم المكتب بعد اكتمال الحجز فقط');
    if (db.prepare('SELECT id FROM reviews WHERE office_id=? AND customer_id=? AND booking_id=?').get(bk.office_id, ctx.user.id, bk.id)) throw conflict('قيّمت هذا الحجز مسبقاً');
    const r = db.prepare('INSERT INTO reviews(office_id,customer_id,booking_id,rating,comment) VALUES(?,?,?,?,?)').run(bk.office_id, ctx.user.id, bk.id, rating, String(b.comment || '').trim().slice(0, 2000));
    audit(ctx.user, 'review.create', 'review', r.lastInsertRowid, { rating });
    notify(bk.office_id, { kind: 'review', title: 'تقييم جديد على مكتبك', body: `${rating} ★`, data: { bookingId: bk.public_id } });
    ctx.ok({ review: map(db.prepare(`${SEL} WHERE r.id=?`).get(Number(r.lastInsertRowid))) }, 201);
  });

  // تقييماتي (عميل: ما كتبته، مكتب: ما وصلني، مدير: الكل)
  router.get('/api/reviews', (ctx) => {
    const u = ctx.user;
    const rows = u.role === 'customer' ? db.prepare(`${SEL} WHERE r.customer_id=? ORDER BY r.created_at DESC LIMIT 300`).all(u.id)
      : u.role === 'office' ? db.prepare(`${SEL} WHERE r.office_id=? ORDER BY r.created_at DESC LIMIT 300`).all(u.id)
      : db.prepare(`${SEL} ORDER BY r.created_at DESC LIMIT 500`).all();
    ctx.ok({ reviews: rows.map(map) });
  });

  router.post('/api/reviews/:id/reply', { roles: ['office'], forbidden: 'الرد للمكتب فقط' }, async (ctx) => {
    const r = db.prepare('SELECT * FROM reviews WHERE id=? AND office_id=?').get(Number(ctx.params.id), ctx.user.id);
    if (!r) throw notFound('التقييم غير موجود');
    const reply = String((await ctx.body()).reply || '').trim().slice(0, 2000);
    if (!reply) throw bad('اكتب الرد');
    db.prepare("UPDATE reviews SET office_reply=?,updated_at=datetime('now') WHERE id=?").run(reply, r.id);
    audit(ctx.user, 'review.reply', 'review', r.id);
    notify(r.customer_id, { kind: 'review_reply', title: 'ردّ المكتب على تقييمك', body: reply.slice(0, 120), data: {} });
    ctx.ok({ review: map(db.prepare(`${SEL} WHERE r.id=?`).get(r.id)) });
  });

  router.patch('/api/admin/reviews/:id', { roles: ['admin'], forbidden: 'هذه العملية للمدير فقط' }, async (ctx) => {
    const r = db.prepare('SELECT id FROM reviews WHERE id=?').get(Number(ctx.params.id));
    if (!r) throw notFound('التقييم غير موجود');
    const status = String((await ctx.body()).status || '');
    if (!['published', 'hidden'].includes(status)) throw bad('حالة غير صحيحة');
    db.prepare("UPDATE reviews SET status=?,updated_at=datetime('now') WHERE id=?").run(status, r.id);
    audit(ctx.user, 'review.moderate', 'review', r.id, { status });
    ctx.ok({ review: map(db.prepare(`${SEL} WHERE r.id=?`).get(r.id)) });
  });
}
