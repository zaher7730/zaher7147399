// حساب المستخدم: بياناته الأساسية، ملف العميل (هوية/مدينة)، تصدير بياناته، وطلب حذفها.
import { bad, conflict } from '../lib/errors.mjs';
import { normalizePhone } from '../lib/phone.mjs';
import { publicUser } from './auth.mjs';
import { encryptField, decryptField } from '../security/crypto.mjs';

export default function register(router, app) {
  const { db, audit, notify } = app;

  const mapCustomer = (r) => r && ({ idType: r.id_type, idNumber: decryptField(r.id_number), idFileId: r.id_file_id, idFileUrl: r.id_file_id ? '/api/files/' + r.id_file_id + '?inline=1' : null, city: r.city, extra: JSON.parse(r.extra_json || '{}'), updatedAt: r.updated_at });

  router.get('/api/me', (ctx) => {
    const profile = ctx.user.role === 'customer' ? mapCustomer(db.prepare('SELECT * FROM customer_profiles WHERE user_id=?').get(ctx.user.id)) : null;
    ctx.ok({ user: publicUser(ctx.user), profile });
  });

  router.patch('/api/me', async (ctx) => {
    const b = await ctx.body();
    const u = ctx.user;
    const name = b.name == null ? u.name : String(b.name).trim();
    const email = b.email === undefined ? u.email : String(b.email || '').trim() || null;
    if (name.length < 2 || name.length > 120) throw bad('الاسم غير صالح');
    if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw bad('البريد غير صالح');
    try { db.prepare('UPDATE users SET name=?,email=? WHERE id=?').run(name, email, u.id); }
    catch (e) { if (String(e.message).includes('UNIQUE')) throw conflict('البريد مستخدم'); throw e; }
    audit(u, 'me.update', 'user', u.id);
    ctx.ok({ user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(u.id)) });
  });

  router.put('/api/me/profile', { roles: ['customer'], forbidden: 'ملف العميل للعملاء فقط' }, async (ctx) => {
    const b = await ctx.body();
    const s = (k, n = 120) => String(b[k] ?? '').trim().slice(0, n);
    let idFileId = null;
    const old = db.prepare('SELECT * FROM customer_profiles WHERE user_id=?').get(ctx.user.id);
    if (b.idFileId === undefined) idFileId = old?.id_file_id ?? null;
    else if (b.idFileId) {
      const f = db.prepare('SELECT id FROM stored_files WHERE id=? AND owner_id=?').get(String(b.idFileId), ctx.user.id);
      if (!f) throw bad('ملف الهوية غير موجود');
      idFileId = f.id;
    }
    const extra = b.extra && typeof b.extra === 'object' ? JSON.stringify(b.extra).slice(0, 20000) : old?.extra_json || '{}';
    db.prepare(`INSERT INTO customer_profiles(user_id,id_type,id_number,id_file_id,city,extra_json,updated_at) VALUES(?,?,?,?,?,?,datetime('now'))
      ON CONFLICT(user_id) DO UPDATE SET id_type=excluded.id_type,id_number=excluded.id_number,id_file_id=excluded.id_file_id,city=excluded.city,extra_json=excluded.extra_json,updated_at=datetime('now')`)
      .run(ctx.user.id, s('idType', 40), encryptField(s('idNumber', 60)), idFileId, s('city', 80), extra);
    audit(ctx.user, 'customer.profile.update', 'user', ctx.user.id);
    ctx.ok({ profile: mapCustomer(db.prepare('SELECT * FROM customer_profiles WHERE user_id=?').get(ctx.user.id)) });
  });

  // تصدير كل بيانات المستخدم (حق الوصول للبيانات)
  router.get('/api/me/export', (ctx) => {
    const id = ctx.user.id, all = (sql, ...a) => db.prepare(sql).all(...a);
    const data = {
      exportedAt: new Date().toISOString(),
      user: publicUser(ctx.user),
      bookings: all('SELECT public_id,service_type,title,details_json,passenger_count,total_amount,currency,payment_status,status,created_at FROM bookings WHERE customer_id=? OR office_id=?', id, id),
      payments: all('SELECT booking_id,method_name,amount,currency,reference,sender,transferred_at,status,created_at FROM payment_submissions WHERE customer_id=? OR office_id=?', id, id),
      conversations: all('SELECT m.* FROM messages m JOIN conversations c ON c.id=m.conversation_id WHERE c.customer_id=? OR c.office_id=? ORDER BY m.id', id, id),
      reviews: all('SELECT * FROM reviews WHERE customer_id=? OR office_id=?', id, id),
      favorites: all('SELECT kind,ref_id FROM favorites WHERE user_id=?', id),
      notifications: all('SELECT kind,title,body,created_at FROM notifications WHERE user_id=?', id),
      state: all('SELECT namespace,value_json,version FROM user_state WHERE user_id=?', id),
    };
    audit(ctx.user, 'me.export', 'user', ctx.user.id);
    ctx.res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': 'attachment; filename="safarak-my-data.json"', 'Cache-Control': 'no-store' });
    ctx.res.end(JSON.stringify(data, null, 2));
  });

  // طلب حذف الحساب: تذكرة تراجعها الإدارة (لا حذف فوري لحماية سجلات الحجوزات والدفع)
  router.post('/api/me/delete-request', async (ctx) => {
    const exists = db.prepare("SELECT id FROM tickets WHERE user_id=? AND kind='data_deletion' AND status IN ('open','pending')").get(ctx.user.id);
    if (exists) throw conflict('لديك طلب حذف قيد المراجعة');
    const r = db.prepare("INSERT INTO tickets(user_id,kind,subject,priority) VALUES(?,'data_deletion','طلب حذف الحساب والبيانات','high')").run(ctx.user.id);
    audit(ctx.user, 'me.delete_request', 'ticket', r.lastInsertRowid);
    for (const a of db.prepare("SELECT id FROM users WHERE role='admin' AND active=1").all()) notify(a.id, { kind: 'ticket', title: 'طلب حذف حساب', body: ctx.user.name, data: { ticketId: Number(r.lastInsertRowid) } });
    ctx.ok({ ticketId: Number(r.lastInsertRowid) }, 201);
  });
}
