// الدعم والنزاعات: تذكرة مع محادثة داخلها، تُدار من الإدارة.
import { bad, forbidden, notFound } from '../lib/errors.mjs';

export default function register(router, app) {
  const { db, audit, notify, hub } = app;
  const SEL = 'SELECT t.*,u.name AS user_name,u.role AS user_role,b.public_id AS booking_public_id FROM tickets t JOIN users u ON u.id=t.user_id LEFT JOIN bookings b ON b.id=t.booking_id';
  const load = (ctx) => {
    const t = db.prepare(`${SEL} WHERE t.id=?`).get(Number(ctx.params.id));
    if (!t) throw notFound('التذكرة غير موجودة');
    if (ctx.user.role !== 'admin' && t.user_id !== ctx.user.id) throw forbidden('ليست تذكرتك');
    return t;
  };

  router.post('/api/tickets', async (ctx) => {
    const b = await ctx.body();
    const subject = String(b.subject || '').trim().slice(0, 200), text = String(b.body || '').trim().slice(0, 4000);
    const kind = ['support', 'dispute'].includes(b.kind) ? b.kind : 'support';
    if (subject.length < 3 || !text) throw bad('الموضوع والتفاصيل مطلوبان');
    let bookingId = null;
    if (b.bookingId) {
      const bk = db.prepare('SELECT * FROM bookings WHERE public_id=?').get(String(b.bookingId));
      if (!bk || (bk.customer_id !== ctx.user.id && bk.office_id !== ctx.user.id)) throw forbidden('هذا الحجز ليس لك');
      bookingId = bk.id;
    }
    const r = db.prepare('INSERT INTO tickets(user_id,booking_id,kind,subject,priority) VALUES(?,?,?,?,?)').run(ctx.user.id, bookingId, kind, subject, kind === 'dispute' ? 'high' : 'normal');
    const id = Number(r.lastInsertRowid);
    db.prepare('INSERT INTO ticket_messages(ticket_id,sender_id,body) VALUES(?,?,?)').run(id, ctx.user.id, text);
    audit(ctx.user, 'ticket.create', 'ticket', id, { kind });
    for (const a of db.prepare("SELECT id FROM users WHERE role='admin' AND active=1").all()) notify(a.id, { kind: 'ticket', title: kind === 'dispute' ? 'نزاع جديد' : 'تذكرة دعم جديدة', body: subject, data: { ticketId: id } });
    ctx.ok({ ticket: db.prepare(`${SEL} WHERE t.id=?`).get(id) }, 201);
  });

  router.get('/api/tickets', (ctx) => {
    const rows = ctx.user.role === 'admin'
      ? db.prepare(`${SEL} ORDER BY CASE t.status WHEN 'open' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END,t.updated_at DESC LIMIT 500`).all()
      : db.prepare(`${SEL} WHERE t.user_id=? ORDER BY t.updated_at DESC LIMIT 200`).all(ctx.user.id);
    ctx.ok({ tickets: rows });
  });

  router.get('/api/tickets/:id', (ctx) => {
    const t = load(ctx);
    ctx.ok({ ticket: t, messages: db.prepare('SELECT m.*,u.name AS sender_name,u.role AS sender_role FROM ticket_messages m JOIN users u ON u.id=m.sender_id WHERE m.ticket_id=? ORDER BY m.id').all(t.id) });
  });

  router.post('/api/tickets/:id/messages', async (ctx) => {
    const t = load(ctx);
    if (t.status === 'closed') throw bad('التذكرة مغلقة');
    const b = await ctx.body();
    const text = String(b.body || '').trim().slice(0, 4000);
    if (!text) throw bad('اكتب الرسالة');
    let fileId = null;
    if (b.fileId) { const f = db.prepare('SELECT id FROM stored_files WHERE id=? AND owner_id=?').get(String(b.fileId), ctx.user.id); if (!f) throw bad('الملف غير موجود'); fileId = f.id; }
    db.prepare('INSERT INTO ticket_messages(ticket_id,sender_id,body,file_id) VALUES(?,?,?,?)').run(t.id, ctx.user.id, text, fileId);
    const next = ctx.user.role === 'admin' ? 'pending' : 'open';
    db.prepare("UPDATE tickets SET status=?,updated_at=datetime('now') WHERE id=?").run(next, t.id);
    if (ctx.user.role === 'admin') notify(t.user_id, { kind: 'ticket_reply', title: 'ردّ الدعم على تذكرتك', body: text.slice(0, 120), data: { ticketId: t.id } });
    else for (const a of db.prepare("SELECT id FROM users WHERE role='admin' AND active=1").all()) hub.publish(a.id, 'ticket', { ticketId: t.id });
    ctx.ok({}, 201);
  });

  router.patch('/api/admin/tickets/:id', { roles: ['admin'], forbidden: 'هذه العملية للمدير فقط' }, async (ctx) => {
    const t = load(ctx);
    const b = await ctx.body();
    const status = b.status == null ? t.status : String(b.status), priority = b.priority == null ? t.priority : String(b.priority);
    if (!['open', 'pending', 'resolved', 'closed'].includes(status) || !['low', 'normal', 'high'].includes(priority)) throw bad('قيمة غير صحيحة');
    db.prepare("UPDATE tickets SET status=?,priority=?,updated_at=datetime('now') WHERE id=?").run(status, priority, t.id);
    audit(ctx.user, 'ticket.update', 'ticket', t.id, { status, priority });
    if (status !== t.status) notify(t.user_id, { kind: 'ticket_status', title: 'تحديث حالة تذكرتك', body: t.subject, data: { ticketId: t.id, status } });
    ctx.ok({ ticket: db.prepare(`${SEL} WHERE t.id=?`).get(t.id) });
  });
}
