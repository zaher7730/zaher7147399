// طلب انضمام مكتب: يُقدَّم علناً مع مستنداته (تُحفظ خاصة)، وتراجعه الإدارة (انظر admin.mjs).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { normalizePhone } from '../lib/phone.mjs';
import { matchesType, extFor, IMAGE_TYPES } from '../security/upload-guard.mjs';
import { sha256 } from '../security/index.mjs';
import { encryptField, encryptBytes } from '../security/crypto.mjs';
import { bad, conflict, HttpError } from '../lib/errors.mjs';

const DOC_KEYS = new Set(['crImg', 'licImg', 'idImg', 'cover', 'logo']);
const len = (s, min, max) => s.length >= min && s.length <= max;

export default function register(router, app) {
  const { db, cfg, audit } = app;

  router.post('/api/public/office-applications', { public: true }, async (ctx) => {
    if (app.limited('office-application:' + ctx.ip)) throw new HttpError(429, 'محاولات كثيرة لتقديم الطلب؛ حاول بعد دقيقة');
    const b = await ctx.body();
    const officeName = String(b.officeName || '').trim(), ownerName = String(b.ownerName || '').trim(), phone = normalizePhone(b.phone);
    const address = String(b.address || '').trim(), registrationNumber = String(b.registrationNumber || '').trim();
    const licenseNumber = String(b.licenseNumber || '').trim(), ownerIdNumber = String(b.ownerIdNumber || '').trim();
    if (!len(officeName, 2, 180) || !len(ownerName, 2, 180) || !phone || !len(phone, 10, 16) || !len(address, 5, 300) || !len(registrationNumber, 2, 100) || !len(ownerIdNumber, 3, 100))
      throw bad('أكمل بيانات المكتب والمالك والهاتف والعنوان والسجل والهوية بشكل صحيح');
    if (db.prepare('SELECT id FROM users WHERE phone=?').get(phone)) throw conflict('رقم الهاتف مسجل مسبقاً؛ تواصل مع الإدارة إذا كان الحساب لك');
    if (db.prepare("SELECT id FROM office_applications WHERE phone=? AND status='pending'").get(phone)) throw conflict('يوجد طلب انضمام قيد المراجعة لهذا الرقم');

    const supplied = b.documents && typeof b.documents === 'object' ? b.documents : {};
    const docs = {};
    let totalBytes = 0;
    const cleanup = () => { for (const d of Object.values(docs)) { try { fs.unlinkSync(path.join(cfg.privateUploads, d.storedName)); } catch { /* ignore */ } } };
    try {
      for (const [key, value] of Object.entries(supplied)) {
        if (!DOC_KEYS.has(key) || !value) continue;
        const m = String(value).match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/i);
        if (!m) throw bad('أحد مستندات المكتب ليس صورة JPG أو PNG أو WEBP صحيحة');
        const mimeType = m[1].toLowerCase(), bytes = Buffer.from(m[2], 'base64');
        totalBytes += bytes.length;
        if (!IMAGE_TYPES.includes(mimeType) || !matchesType(mimeType, bytes) || !bytes.length || bytes.length > 4 * 1024 * 1024 || totalBytes > 5 * 1024 * 1024)
          throw new HttpError(413, 'مجموع صور طلب المكتب يجب ألا يتجاوز 5 ميغابايت، وبصيغة صورة مدعومة');
        const storedName = crypto.randomUUID() + '.bin';
        fs.writeFileSync(path.join(cfg.privateUploads, storedName), encryptBytes(bytes), { flag: 'wx', mode: 0o600 });
        docs[key] = { storedName, originalName: `${key}.${extFor(mimeType)}`, mimeType, sizeBytes: bytes.length, sha256: sha256(bytes) };
      }
      const r = db
        .prepare('INSERT INTO office_applications(office_name,owner_name,phone,address,registration_number,license_number,owner_id_number,documents_json) VALUES(?,?,?,?,?,?,?,?)')
        .run(officeName, ownerName, phone, address, registrationNumber, licenseNumber, encryptField(ownerIdNumber), JSON.stringify(docs));
      audit(null, 'office_application.submit', 'office_application', r.lastInsertRowid, { phone, documentCount: Object.keys(docs).length });
      // إشعار كل المديرين بوجود طلب جديد
      for (const a of db.prepare("SELECT id FROM users WHERE role='admin' AND active=1").all())
        app.notify(a.id, { kind: 'office_application', title: 'طلب انضمام مكتب جديد', body: officeName, data: { applicationId: Number(r.lastInsertRowid) } });
      ctx.ok({ application: { id: Number(r.lastInsertRowid), status: 'pending', message: 'تم استلام طلب انضمام المكتب. لا يصبح الحساب نشطاً إلا بعد مراجعة الإدارة واعتماده.' } }, 201);
    } catch (e) { cleanup(); throw e; }
  });
}
