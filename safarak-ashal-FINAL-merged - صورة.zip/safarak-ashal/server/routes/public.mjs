// واجهات عامة لا تحتاج تسجيل دخول: العروض المنشورة، المكاتب، النقاط، وسائل الدفع، الإعدادات العامة.
import { PUBLIC_CONFIG_KEYS } from '../lib/settings.mjs';

export const officeRating = (db, officeId) =>
  db.prepare("SELECT COUNT(*) AS count, ROUND(AVG(rating),1) AS avg FROM reviews WHERE office_id=? AND status='published'").get(officeId);

export default function register(router, app) {
  const { db } = app;

  router.get('/api/public/services', { public: true }, ({ ok }) => {
    const rows = db
      .prepare(
        `SELECT s.id,s.office_id,s.service_type,s.title,s.details_json,s.updated_at,u.office_name,u.name AS office_user_name,
                CASE WHEN s.service_type='cars' AND EXISTS(SELECT 1 FROM bookings b WHERE b.service_id=s.id AND b.status NOT IN ('completed','rejected','cancelled')) THEN 1 ELSE 0 END AS reserved
         FROM office_services s JOIN users u ON u.id=s.office_id WHERE s.active=1 AND u.active=1 ORDER BY s.updated_at DESC,s.id DESC LIMIT 300`,
      )
      .all();
    ok({ services: rows.map((x) => ({ ...x, reserved: !!x.reserved, details: JSON.parse(x.details_json) })) });
  });

  router.get('/api/public/offices', { public: true }, ({ ok }) => {
    const rows = db
      .prepare(
        `SELECT u.id,u.name,u.phone,u.office_name,u.created_at,p.display_name,p.city,p.address,p.years,p.whatsapp,p.license_no,p.about,p.verified,
                p.logo_asset_id,p.cover_asset_id,p.extra_json,
                (SELECT COUNT(*) FROM reviews r WHERE r.office_id=u.id AND r.status='published') AS rating_count,
                (SELECT ROUND(AVG(rating),1) FROM reviews r WHERE r.office_id=u.id AND r.status='published') AS rating_avg
         FROM users u LEFT JOIN office_profiles p ON p.office_id=u.id WHERE u.role='office' AND u.active=1 ORDER BY u.office_name,u.name LIMIT 500`,
      )
      .all();
    ok({
      offices: rows.map((r) => ({
        id: r.id, name: r.name, phone: r.phone, office_name: r.office_name, created_at: r.created_at,
        profile: {
          displayName: r.display_name || r.office_name || r.name, city: r.city || '', address: r.address || '', years: r.years || 0,
          whatsapp: r.whatsapp || '', licenseNo: r.license_no || '', about: r.about || '', verified: !!r.verified,
          logo: r.logo_asset_id ? '/assets/offers/' + r.logo_asset_id : '', cover: r.cover_asset_id ? '/assets/offers/' + r.cover_asset_id : '',
          extra: JSON.parse(r.extra_json || '{}'),
        },
        rating: { count: r.rating_count || 0, avg: r.rating_avg ?? null },
      })),
    });
  });

  router.get('/api/public/offices/:id/reviews', { public: true }, ({ params, ok }) => {
    const id = Number(params.id);
    const rows = db
      .prepare(
        `SELECT r.id,r.rating,r.comment,r.office_reply,r.created_at,SUBSTR(u.name,1,INSTR(u.name||' ',' ')-1) AS customer_first_name
         FROM reviews r JOIN users u ON u.id=r.customer_id WHERE r.office_id=? AND r.status='published' ORDER BY r.created_at DESC LIMIT 200`,
      )
      .all(id);
    const dist = [0, 0, 0, 0, 0];
    for (const r of rows) dist[r.rating - 1]++;
    ok({ reviews: rows, summary: { ...officeRating(db, id), dist } });
  });

  router.get('/api/public/points', { public: true }, ({ ok }) =>
    ok({ points: db.prepare('SELECT id,name,city,address,phone FROM service_points WHERE active=1 ORDER BY city,name').all() }),
  );

  router.get('/api/public/payment-methods', { public: true }, ({ query, ok }) => {
    const officeId = Number(query.get('officeId') || 0);
    const cols = 'id,owner_id,type,name,account_no,holder,currency';
    const rows = officeId
      ? db.prepare(`SELECT ${cols} FROM payment_methods WHERE active=1 AND (owner_id=? OR owner_id IS NULL) ORDER BY CASE WHEN owner_id=? THEN 0 ELSE 1 END,id`).all(officeId, officeId)
      : db.prepare(`SELECT ${cols} FROM payment_methods WHERE active=1 AND owner_id IS NULL ORDER BY id`).all();
    ok({ methods: rows });
  });

  router.get('/api/public/config', { public: true }, ({ ok }) => {
    const out = {};
    for (const row of db.prepare('SELECT setting_key,value_json FROM platform_settings').all()) {
      if (PUBLIC_CONFIG_KEYS.has(row.setting_key)) { try { out[row.setting_key] = JSON.parse(row.value_json); } catch { /* skip */ } }
    }
    ok({ config: out });
  });

  // محتوى تديره الإدارة ويُعرض للجميع: إعلانات، مدن، صفحات وسياسات...
  router.get('/api/public/docs', { public: true }, ({ query, ok }) => {
    const wanted = String(query.get('collections') || '').split(',').map((x) => x.trim()).filter(Boolean);
    const rows = db.prepare('SELECT collection,doc_id,data_json FROM platform_docs WHERE is_public=1 ORDER BY collection,doc_id').all();
    const out = {};
    for (const r of rows) {
      if (wanted.length && !wanted.includes(r.collection)) continue;
      (out[r.collection] ||= []).push({ id: r.doc_id, ...JSON.parse(r.data_json) });
    }
    ok({ docs: out });
  });
}
