// بيانات الإدارة: محتوى المنصة (إعلانات، مدن، صفحات...)، إحصاءات، سجل التدقيق، نظرة على الحجوزات والمدفوعات، نسخ احتياطي.
import path from 'node:path';
import { HttpError, bad, notFound } from '../lib/errors.mjs';
import { backupNow, listBackups } from '../db/backup.mjs';
import { describeAudit } from '../lib/audit-labels.mjs';
import { BOOKING_SELECT, mapBooking } from '../services/bookings.mjs';

const ADMIN = { roles: ['admin'], forbidden: 'هذه العملية للمدير فقط' };
const COLLECTION = /^[a-z][a-z0-9_-]{1,40}$/i;
const DOC_ID = /^[A-Za-z0-9_.:-]{1,64}$/;

export default function register(router, app) {
  const { db, cfg, audit, notify } = app;

  // ---- مستندات المنصة ----
  router.get('/api/admin/docs', ADMIN, (ctx) => {
    const col = ctx.query.get('collection');
    const rows = col
      ? db.prepare('SELECT * FROM platform_docs WHERE collection=? ORDER BY doc_id').all(col)
      : db.prepare('SELECT * FROM platform_docs ORDER BY collection,doc_id').all();
    ctx.ok({ docs: rows.map((r) => ({ collection: r.collection, id: r.doc_id, data: JSON.parse(r.data_json), public: !!r.is_public, updatedAt: r.updated_at })) });
  });
  router.put('/api/admin/docs/:collection/:id', ADMIN, async (ctx) => {
    const { collection, id } = ctx.params;
    if (!COLLECTION.test(collection) || !DOC_ID.test(id)) throw bad('اسم المجموعة أو المعرّف غير صالح');
    const b = await ctx.body();
    const json = JSON.stringify(b.data ?? {});
    if (json.length > 500000) throw new HttpError(413, 'حجم المستند كبير');
    db.prepare("INSERT INTO platform_docs(collection,doc_id,data_json,is_public,updated_by,updated_at) VALUES(?,?,?,?,?,datetime('now')) ON CONFLICT(collection,doc_id) DO UPDATE SET data_json=excluded.data_json,is_public=excluded.is_public,updated_by=excluded.updated_by,updated_at=datetime('now')")
      .run(collection, id, json, b.public ? 1 : 0, ctx.user.id);
    audit(ctx.user, 'platform_doc.put', 'platform_doc', `${collection}/${id}`, { public: !!b.public });
    ctx.ok();
  });
  router.delete('/api/admin/docs/:collection/:id', ADMIN, (ctx) => {
    const r = db.prepare('DELETE FROM platform_docs WHERE collection=? AND doc_id=?').run(ctx.params.collection, ctx.params.id);
    if (!r.changes) throw notFound('المستند غير موجود');
    audit(ctx.user, 'platform_doc.delete', 'platform_doc', `${ctx.params.collection}/${ctx.params.id}`);
    ctx.ok();
  });

  // ---- إحصاءات لوحة الإدارة ----
  router.get('/api/admin/stats', ADMIN, (ctx) => {
    const n = (sql, ...a) => db.prepare(sql).get(...a);
    ctx.ok({
      users: db.prepare('SELECT role,COUNT(*) AS count,SUM(active) AS active FROM users GROUP BY role').all(),
      bookings: {
        byStatus: db.prepare('SELECT status,COUNT(*) AS count FROM bookings GROUP BY status').all(),
        byService: db.prepare('SELECT service_type,COUNT(*) AS count FROM bookings GROUP BY service_type ORDER BY count DESC').all(),
        last30: n("SELECT COUNT(*) AS n FROM bookings WHERE created_at>=datetime('now','-30 days')").n,
      },
      revenue: db.prepare("SELECT currency,ROUND(SUM(total_amount),2) AS total FROM bookings WHERE payment_status='confirmed' GROUP BY currency").all(),
      pending: {
        applications: n("SELECT COUNT(*) AS n FROM office_applications WHERE status='pending'").n,
        payments: n("SELECT COUNT(*) AS n FROM payment_submissions WHERE status='submitted'").n,
        packages: n("SELECT COUNT(*) AS n FROM package_purchases WHERE status='requested'").n,
        tickets: n("SELECT COUNT(*) AS n FROM tickets WHERE status IN ('open','pending')").n,
      },
      topOffices: db.prepare("SELECT u.id,COALESCE(u.office_name,u.name) AS name,COUNT(b.id) AS bookings,ROUND(SUM(b.total_amount),2) AS total FROM bookings b JOIN users u ON u.id=b.office_id GROUP BY u.id ORDER BY bookings DESC LIMIT 10").all(),
      online: app.hub.count(),
    });
  });

  router.get('/api/admin/bookings', ADMIN, (ctx) => {
    const status = ctx.query.get('status'), q = String(ctx.query.get('q') || '').trim();
    const where = [], args = [];
    if (status) { where.push('b.status=?'); args.push(status); }
    if (q) { where.push('(b.public_id LIKE ? OR b.title LIKE ? OR c.name LIKE ? OR c.phone LIKE ?)'); args.push(...Array(4).fill(`%${q}%`)); }
    const rows = db.prepare(`${BOOKING_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY b.created_at DESC LIMIT 500`).all(...args);
    ctx.ok({ bookings: rows.map(mapBooking) });
  });

  router.get('/api/admin/payments', ADMIN, (ctx) =>
    ctx.ok({ payments: db.prepare('SELECT p.*,b.public_id AS booking_public_id,b.title AS booking_title,c.name AS customer_name,COALESCE(o.office_name,o.name) AS office_name FROM payment_submissions p JOIN bookings b ON b.id=p.booking_id JOIN users c ON c.id=p.customer_id LEFT JOIN users o ON o.id=p.office_id ORDER BY p.created_at DESC LIMIT 500').all() }));

  router.get('/api/admin/invoices', ADMIN, (ctx) =>
    ctx.ok({ invoices: db.prepare('SELECT i.number,i.issued_at,b.public_id AS booking_id,b.title,b.total_amount,b.currency,b.payment_status,COALESCE(o.office_name,o.name) AS office_name,c.name AS customer_name FROM invoices i JOIN bookings b ON b.id=i.booking_id LEFT JOIN users o ON o.id=i.office_id JOIN users c ON c.id=b.customer_id ORDER BY i.id DESC LIMIT 1000').all() }));

  router.get('/api/admin/reviews', ADMIN, (ctx) =>
    ctx.ok({ reviews: db.prepare('SELECT r.*,cu.name AS customer_name,COALESCE(ou.office_name,ou.name) AS office_name FROM reviews r JOIN users cu ON cu.id=r.customer_id JOIN users ou ON ou.id=r.office_id ORDER BY r.created_at DESC LIMIT 500').all() }));

  router.get('/api/admin/audit', ADMIN, (ctx) => {
    const limit = Math.min(500, Number(ctx.query.get('limit') || 100)), action = ctx.query.get('action');
    const rows = action
      ? db.prepare('SELECT a.*,u.name AS actor_name FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id WHERE a.action LIKE ? ORDER BY a.id DESC LIMIT ?').all(action + '%', limit)
      : db.prepare('SELECT a.*,u.name AS actor_name FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT ?').all(limit);
    ctx.ok({ entries: rows.map((r) => ({ ...r, metadata: JSON.parse(r.metadata_json || '{}'), ...describeAudit(r) })) });
  });

  // إشعار عام من الإدارة لفئة (عملاء/مكاتب/الكل)
  router.post('/api/admin/broadcast', ADMIN, async (ctx) => {
    const b = await ctx.body();
    const title = String(b.title || '').trim().slice(0, 120), body = String(b.body || '').trim().slice(0, 500);
    const audience = String(b.audience || 'all');
    if (!title || !['all', 'customer', 'office'].includes(audience)) throw bad('العنوان والفئة مطلوبان');
    const users = audience === 'all' ? db.prepare("SELECT id FROM users WHERE active=1 AND role IN ('customer','office')").all() : db.prepare('SELECT id FROM users WHERE active=1 AND role=?').all(audience);
    for (const u of users) notify(u.id, { kind: 'announcement', title, body, data: {} });
    audit(ctx.user, 'admin.broadcast', 'notification', audience, { recipients: users.length });
    ctx.ok({ recipients: users.length });
  });

  router.get('/api/admin/backups', ADMIN, (ctx) => ctx.ok({ backups: listBackups(cfg), keep: cfg.backupKeep, everyHours: cfg.backupEveryHours, dir: path.basename(cfg.backupDir) }));

  router.post('/api/admin/backup', ADMIN, (ctx) => {
    const file = backupNow(db, cfg, app.log);
    const info = listBackups(cfg).find((b) => b.file === path.basename(file));
    audit(ctx.user, 'admin.backup', 'backup', path.basename(file), { count: info ? info.fileCount : 0 });
    ctx.ok({ file: path.basename(file), backup: info || null });
  });
}
