// الإشعارات داخل التطبيق + تسجيل أجهزة الإشعار الدفعي (Web Push — يحتاج مفاتيح VAPID لاحقاً).
import { bad } from '../lib/errors.mjs';
import { mapNotification } from '../services/notifications.mjs';

export default function register(router, app) {
  const { db } = app;

  router.get('/api/notifications', (ctx) => {
    const limit = Math.min(200, Number(ctx.query.get('limit') || 60));
    const rows = db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT ?').all(ctx.user.id, limit);
    const unread = db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE user_id=? AND read_at IS NULL').get(ctx.user.id).n;
    ctx.ok({ notifications: rows.map(mapNotification), unread });
  });

  router.post('/api/notifications/read', async (ctx) => {
    const b = await ctx.body();
    const ids = Array.isArray(b.ids) ? b.ids.map(Number).filter(Number.isInteger).slice(0, 500) : null;
    const r = ids
      ? db.prepare(`UPDATE notifications SET read_at=datetime('now') WHERE user_id=? AND read_at IS NULL AND id IN (${ids.map(() => '?').join(',') || 'NULL'})`).run(ctx.user.id, ...ids)
      : db.prepare("UPDATE notifications SET read_at=datetime('now') WHERE user_id=? AND read_at IS NULL").run(ctx.user.id);
    ctx.ok({ marked: Number(r.changes) });
  });

  router.delete('/api/notifications/:id', (ctx) => {
    db.prepare('DELETE FROM notifications WHERE id=? AND user_id=?').run(Number(ctx.params.id), ctx.user.id);
    ctx.ok();
  });

  // المفتاح العام فقط (آمن للنشر). فارغ = إشعارات الجهاز غير مفعّلة بعد على الخادم
  router.get('/api/push/public-key', (ctx) => ctx.ok({ publicKey: app.cfg.push.publicKey || null }));

  router.post('/api/push/subscribe', async (ctx) => {
    const b = await ctx.body();
    const endpoint = String(b.endpoint || '');
    if (!/^https:\/\//.test(endpoint) || endpoint.length > 1000) throw bad('اشتراك غير صالح');
    db.prepare('INSERT INTO push_subscriptions(user_id,endpoint,keys_json) VALUES(?,?,?) ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id,keys_json=excluded.keys_json')
      .run(ctx.user.id, endpoint, JSON.stringify(b.keys && typeof b.keys === 'object' ? b.keys : {}));
    ctx.ok();
  });
  router.delete('/api/push/subscribe', async (ctx) => {
    const b = await ctx.body();
    db.prepare('DELETE FROM push_subscriptions WHERE user_id=? AND endpoint=?').run(ctx.user.id, String(b.endpoint || ''));
    ctx.ok();
  });
}
