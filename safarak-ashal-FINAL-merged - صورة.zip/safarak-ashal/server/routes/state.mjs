// حفظ حالة الواجهة لكل مستخدم على الخادم (بديل localStorage) مع رقم نسخة لكشف التعارض بين الأجهزة.
import { bad, conflict, HttpError } from '../lib/errors.mjs';

const NS = /^[a-z0-9_.-]{1,48}$/i;
const MAX = 1024 * 1024;
export const MAX_NAMESPACES = 40; // أقصى عدد مساحات حفظ لكل مستخدم (يمنع تضخيم القاعدة)

export default function register(router, app) {
  const { db } = app;

  router.get('/api/state', (ctx) => {
    const rows = db.prepare('SELECT namespace,version,updated_at,LENGTH(value_json) AS size FROM user_state WHERE user_id=? ORDER BY namespace').all(ctx.user.id);
    ctx.ok({ namespaces: rows });
  });

  router.get('/api/state/:ns', (ctx) => {
    if (!NS.test(ctx.params.ns)) throw bad('اسم غير صالح');
    const r = db.prepare('SELECT value_json,version,updated_at FROM user_state WHERE user_id=? AND namespace=?').get(ctx.user.id, ctx.params.ns);
    ctx.ok(r ? { value: JSON.parse(r.value_json), version: r.version, updatedAt: r.updated_at } : { value: null, version: 0 });
  });

  router.put('/api/state/:ns', async (ctx) => {
    if (!NS.test(ctx.params.ns)) throw bad('اسم غير صالح');
    const b = await ctx.body();
    if (!('value' in b)) throw bad('القيمة مطلوبة');
    const json = JSON.stringify(b.value);
    if (json.length > MAX) throw new HttpError(413, 'حجم الحالة كبير');
    const cur = db.prepare('SELECT version FROM user_state WHERE user_id=? AND namespace=?').get(ctx.user.id, ctx.params.ns);
    const base = b.version == null ? null : Number(b.version);
    // الكتابة فوق بيانات موجودة تتطلب رقم النسخة التي بُني عليها التعديل؛ بدونه قد تُمحى تعديلات جهاز آخر
    if (cur && base === null) throw new HttpError(428, 'أرسل رقم النسخة الحالية لحفظ التعديل؛ حدّث البيانات ثم أعد المحاولة', { version: cur.version });
    if (cur && (!Number.isInteger(base) || base !== cur.version)) throw conflict('تم تحديث هذه البيانات من جهاز آخر', { version: cur.version });
    if (!cur && db.prepare('SELECT COUNT(*) AS n FROM user_state WHERE user_id=?').get(ctx.user.id).n >= MAX_NAMESPACES)
      throw conflict(`بلغت الحد الأقصى لمساحات الحفظ (${MAX_NAMESPACES}). احذف مساحة غير مستخدمة ثم أعد المحاولة`);
    const version = (cur?.version || 0) + 1;
    db.prepare("INSERT INTO user_state(user_id,namespace,value_json,version,updated_at) VALUES(?,?,?,?,datetime('now')) ON CONFLICT(user_id,namespace) DO UPDATE SET value_json=excluded.value_json,version=excluded.version,updated_at=datetime('now')")
      .run(ctx.user.id, ctx.params.ns, json, version);
    ctx.ok({ version });
  });

  router.delete('/api/state/:ns', (ctx) => {
    db.prepare('DELETE FROM user_state WHERE user_id=? AND namespace=?').run(ctx.user.id, ctx.params.ns);
    ctx.ok();
  });
}
