// الملفات: مستندات خاصة (بصلاحيات) وصور عروض عامة.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { FILE_TYPES, IMAGE_TYPES, matchesType, decodeBase64, safeFilename } from '../security/upload-guard.mjs';
import { sha256 } from '../security/index.mjs';
import { encryptBytes, readPrivateFile } from '../security/crypto.mjs';
import { bad, forbidden, notFound, HttpError } from '../lib/errors.mjs';

/** هل يحق للمستخدم قراءة الملف؟ المالك، المدير، المكتب/العميل صاحب الحجز، أو طرف في محادثة مرفق بها الملف. */
export function canReadFile(db, user, f) {
  if (user.role === 'admin' || f.owner_id === user.id) return true;
  if (f.booking_id) {
    const b = db.prepare('SELECT customer_id,office_id FROM bookings WHERE id=?').get(f.booking_id);
    if (b && ((user.role === 'office' && b.office_id === user.id) || (user.role === 'customer' && b.customer_id === user.id))) return true;
  }
  const c = db
    .prepare('SELECT c.customer_id,c.office_id FROM messages m JOIN conversations c ON c.id=m.conversation_id WHERE m.file_id=? LIMIT 1')
    .get(f.id);
  return !!c && (c.customer_id === user.id || c.office_id === user.id);
}

export default function register(router, app) {
  const { db, cfg, audit } = app;

  router.post('/api/office/assets', { roles: ['office', 'admin'], forbidden: 'رفع صور العروض متاح للمكتب أو المدير' }, async (ctx) => {
    const b = await ctx.body();
    const mimeType = String(b.mimeType || '').toLowerCase();
    if (!IMAGE_TYPES.includes(mimeType)) throw bad('صورة العرض يجب أن تكون JPG أو PNG أو WEBP');
    const bytes = decodeBase64(b.base64, cfg.maxFile);
    if (!bytes) throw new HttpError(413, 'حجم الصورة يتجاوز 5 ميغابايت أو غير صالح');
    if (!matchesType(mimeType, bytes)) throw bad('محتوى الصورة غير صالح أو يتجاوز الحد');
    const id = crypto.randomUUID(), storedName = id + '.img';
    fs.writeFileSync(path.join(cfg.publicOfferUploads, storedName), bytes, { flag: 'wx', mode: 0o644 });
    db.prepare('INSERT INTO public_assets(id,owner_id,stored_name,mime_type,size_bytes,sha256) VALUES(?,?,?,?,?,?)').run(id, ctx.user.id, storedName, mimeType, bytes.length, sha256(bytes));
    audit(ctx.user, 'offer_image.upload', 'public_asset', id, { mimeType, sizeBytes: bytes.length });
    ctx.ok({ asset: { id, url: '/assets/offers/' + id, mimeType, sizeBytes: bytes.length } }, 201);
  });

  router.post('/api/files', async (ctx) => {
    const { user } = ctx;
    const b = await ctx.body();
    const filename = safeFilename(b.filename), mimeType = String(b.mimeType || '').toLowerCase();
    if (!FILE_TYPES.has(mimeType)) throw bad('نوع الملف غير مسموح؛ الأنواع المدعومة صور JPG/PNG/WEBP وPDF');
    const bytes = decodeBase64(b.base64, cfg.maxFile);
    if (!bytes) throw new HttpError(413, 'حجم الملف غير صالح أو يتجاوز 5 ميغابايت');
    if (!matchesType(mimeType, bytes)) throw bad('محتوى الملف لا يطابق نوعه المعلن');
    let bookingId = null;
    if (b.bookingId) {
      const bk = db.prepare('SELECT * FROM bookings WHERE public_id=?').get(String(b.bookingId));
      if (!bk) throw notFound('الحجز المرتبط غير موجود');
      if (!(user.role === 'admin' || bk.customer_id === user.id || (user.role === 'office' && bk.office_id === user.id))) throw forbidden('لا تملك صلاحية إرفاق ملف بهذا الحجز');
      bookingId = bk.id;
    }
    const id = crypto.randomUUID(), storedName = id + '.bin';
    fs.writeFileSync(path.join(cfg.privateUploads, storedName), encryptBytes(bytes), { flag: 'wx', mode: 0o600 });
    const hash = sha256(bytes);
    db.prepare('INSERT INTO stored_files(id,owner_id,booking_id,original_name,stored_name,mime_type,size_bytes,sha256) VALUES(?,?,?,?,?,?,?,?)').run(id, user.id, bookingId, filename, storedName, mimeType, bytes.length, hash);
    audit(user, 'file.upload', 'file', id, { mimeType, sizeBytes: bytes.length });
    ctx.ok({ file: { id, filename, mimeType, sizeBytes: bytes.length, sha256: hash, downloadUrl: '/api/files/' + id } }, 201);
  });

  router.get('/api/files/:id', (ctx) => {
    const f = db.prepare('SELECT * FROM stored_files WHERE id=?').get(ctx.params.id);
    if (!f) throw notFound('الملف غير موجود');
    if (!canReadFile(db, ctx.user, f)) throw forbidden('لا تملك صلاحية قراءة هذا الملف');
    const fp = path.join(cfg.privateUploads, f.stored_name);
    if (!fs.existsSync(fp)) throw notFound('محتوى الملف غير موجود');
    const inline = ctx.query.get('inline') === '1' && f.mime_type.startsWith('image/');
    const data = readPrivateFile(fp); // فكّ التشفير قبل أي ترويسة حتى لا يُرسل رد نصف فارغ عند فشل الفك
    ctx.res.writeHead(200, {
      'Content-Type': f.mime_type,
      'Content-Length': data.length,
      'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(f.original_name)}`,
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'private, no-store',
    });
    ctx.res.end(data);
  });

  router.delete('/api/files/:id', (ctx) => {
    const f = db.prepare('SELECT * FROM stored_files WHERE id=?').get(ctx.params.id);
    if (!f) throw notFound('الملف غير موجود');
    if (!(ctx.user.role === 'admin' || f.owner_id === ctx.user.id)) throw forbidden('حذف الملف متاح لصاحبه أو المدير');
    try { fs.unlinkSync(path.join(cfg.privateUploads, f.stored_name)); } catch { /* ignore */ }
    db.prepare('DELETE FROM stored_files WHERE id=?').run(f.id);
    audit(ctx.user, 'file.delete', 'file', f.id);
    ctx.ok();
  });

  router.get('/api/files', (ctx) => {
    const { user } = ctx;
    const cols = 'f.id,f.owner_id,f.booking_id,f.original_name,f.mime_type,f.size_bytes,f.sha256,f.created_at';
    const rows =
      user.role === 'admin'
        ? db.prepare(`SELECT ${cols} FROM stored_files f ORDER BY f.created_at DESC LIMIT 500`).all()
        : user.role === 'office'
          ? db.prepare(`SELECT DISTINCT ${cols} FROM stored_files f LEFT JOIN bookings b ON b.id=f.booking_id WHERE f.owner_id=? OR b.office_id=? ORDER BY f.created_at DESC LIMIT 500`).all(user.id, user.id)
          : db.prepare(`SELECT DISTINCT ${cols} FROM stored_files f LEFT JOIN bookings b ON b.id=f.booking_id WHERE f.owner_id=? OR b.customer_id=? ORDER BY f.created_at DESC LIMIT 500`).all(user.id, user.id);
    ctx.ok({ files: rows.map((f) => ({ ...f, downloadUrl: '/api/files/' + f.id })) });
  });
}
