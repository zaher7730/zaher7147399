// واجهات الإدارة: كل مسار هنا يتطلب دور admin على الخادم (لا يكفي إخفاء الواجهة).
import { readPrivateFile } from '../security/crypto.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { transaction } from '../db/connection.mjs';
import { randomSecretHash, hashPassword } from '../security/index.mjs';
import { normalizePhone, validPhone } from '../lib/phone.mjs';
import { ADMIN_SETTING_KEYS } from '../lib/settings.mjs';
import { HttpError, bad, conflict, notFound } from '../lib/errors.mjs';
import { publicUser } from './auth.mjs';
import { decryptField } from '../security/crypto.mjs';
import { integrationStatus } from '../integrations/registry.mjs';
import { priceOf, validPrice, mapService } from './office.mjs';

const ADMIN = { roles: ['admin'], forbidden: 'هذه العملية للمدير فقط' };
const isUnique = (e) => String(e.message).includes('UNIQUE');

export default function register(router, app) {
  const { db, audit, notify } = app;

  // ---- إنشاء مكتب مباشرة ----
  router.post('/api/admin/offices', ADMIN, async (ctx) => {
    const b = await ctx.body();
    const name = String(b.name || '').trim(), phone = normalizePhone(b.phone), password = String(b.password || '');
    if (name.length < 2 || !validPhone(phone)) throw bad('اسم المكتب ورقم الهاتف بصيغة دولية مطلوبان');
    try {
      const r = db.prepare('INSERT INTO users(name,phone,email,password_hash,role,office_name) VALUES(?,?,?,?,?,?)')
        .run(name, phone, b.email || null, password.length >= 10 ? hashPassword(password) : randomSecretHash(), 'office', String(b.officeName || name).trim());
      const office = db.prepare('SELECT id,name,phone,email,role,office_name FROM users WHERE id=?').get(Number(r.lastInsertRowid));
      audit(ctx.user, 'office.create', 'user', office.id);
      ctx.ok({ office }, 201);
    } catch (e) { if (isUnique(e)) throw conflict('رقم الجوال أو البريد مستخدم'); throw e; }
  });

  // ---- حالة الخدمات الخارجية (بلا أي أسرار) ----
  router.get('/api/admin/integrations', ADMIN, (ctx) => ctx.ok({ integrations: integrationStatus(app.cfg) }));

  // ---- الإعدادات ----
  router.get('/api/admin/settings', ADMIN, (ctx) => {
    const settings = {};
    for (const row of db.prepare('SELECT setting_key,value_json FROM platform_settings').all()) { try { settings[row.setting_key] = JSON.parse(row.value_json); } catch { /* skip */ } }
    ctx.ok({ settings });
  });
  router.put('/api/admin/settings', ADMIN, async (ctx) => {
    const b = await ctx.body();
    const entries = Object.entries(b.settings && typeof b.settings === 'object' ? b.settings : {}).filter(([k]) => ADMIN_SETTING_KEYS.has(k));
    if (entries.length > 50) throw new HttpError(413, 'عدد الإعدادات كبير');
    transaction(db, () => {
      const up = db.prepare("INSERT INTO platform_settings(setting_key,value_json,updated_by,updated_at) VALUES(?,?,?,datetime('now')) ON CONFLICT(setting_key) DO UPDATE SET value_json=excluded.value_json,updated_by=excluded.updated_by,updated_at=datetime('now')");
      for (const [key, value] of entries) {
        if (typeof value === 'string' && value.length > 10000) throw bad('قيمة الإعداد طويلة جداً');
        up.run(key, JSON.stringify(value), ctx.user.id);
      }
    });
    audit(ctx.user, 'platform.settings.update', 'platform_settings', 'all', { keys: entries.map((x) => x[0]) });
    ctx.ok({ count: entries.length });
  });

  // ---- نقاط الخدمة ----
  router.get('/api/admin/points', ADMIN, (ctx) => ctx.ok({ points: db.prepare('SELECT * FROM service_points ORDER BY city,name,id').all() }));
  router.post('/api/admin/points', ADMIN, async (ctx) => {
    const b = await ctx.body();
    const name = String(b.name || '').trim(), city = String(b.city || '').trim(), address = String(b.address || '').trim(), phone = String(b.phone || '').trim();
    if (name.length < 2 || city.length < 2 || address.length < 3) throw bad('اسم النقطة والمدينة والعنوان مطلوبة');
    const r = db.prepare('INSERT INTO service_points(name,city,address,phone,active,created_by) VALUES(?,?,?,?,?,?)').run(name, city, address, phone, b.active === false ? 0 : 1, ctx.user.id);
    audit(ctx.user, 'service_point.create', 'service_point', r.lastInsertRowid);
    ctx.ok({ point: db.prepare('SELECT * FROM service_points WHERE id=?').get(Number(r.lastInsertRowid)) }, 201);
  });
  router.patch('/api/admin/points/:id', ADMIN, async (ctx) => {
    const old = db.prepare('SELECT * FROM service_points WHERE id=?').get(Number(ctx.params.id));
    if (!old) throw notFound('نقطة الخدمة غير موجودة');
    const b = await ctx.body();
    const pick = (k, cur) => (b[k] == null ? cur : String(b[k]).trim());
    const name = pick('name', old.name), city = pick('city', old.city), address = pick('address', old.address), phone = pick('phone', old.phone);
    const active = b.active === undefined ? old.active : b.active ? 1 : 0;
    if (name.length < 2 || city.length < 2 || address.length < 3) throw bad('اسم النقطة والمدينة والعنوان مطلوبة');
    db.prepare("UPDATE service_points SET name=?,city=?,address=?,phone=?,active=?,updated_at=datetime('now') WHERE id=?").run(name, city, address, phone, active, old.id);
    audit(ctx.user, 'service_point.update', 'service_point', old.id, { active });
    ctx.ok({ point: db.prepare('SELECT * FROM service_points WHERE id=?').get(old.id) });
  });
  router.delete('/api/admin/points/:id', ADMIN, (ctx) => {
    const old = db.prepare('SELECT id FROM service_points WHERE id=?').get(Number(ctx.params.id));
    if (!old) throw notFound('نقطة الخدمة غير موجودة');
    db.prepare('DELETE FROM service_points WHERE id=?').run(old.id);
    audit(ctx.user, 'service_point.delete', 'service_point', old.id);
    ctx.ok();
  });

  // ---- طلبات انضمام المكاتب ----
  const mapApp = (a) => ({
    id: a.id, office_name: a.office_name, owner_name: a.owner_name, phone: a.phone, address: a.address, registration_number: a.registration_number,
    license_number: a.license_number, owner_id_number: decryptField(a.owner_id_number), status: a.status, review_note: a.review_note, created_at: a.created_at,
    documents: Object.fromEntries(Object.entries(JSON.parse(a.documents_json || '{}')).map(([key, d]) => [key, { url: `/api/admin/office-applications/${a.id}/documents/${key}`, mimeType: d.mimeType, sizeBytes: d.sizeBytes, sha256: d.sha256 }])),
  });
  router.get('/api/admin/office-applications', { ...ADMIN, forbidden: 'طلبات انضمام المكاتب متاحة للمدير فقط' }, (ctx) => {
    const status = ctx.query.get('status');
    const rows = status && ['pending', 'approved', 'rejected'].includes(status)
      ? db.prepare('SELECT * FROM office_applications WHERE status=? ORDER BY created_at DESC LIMIT 500').all(status)
      : db.prepare("SELECT * FROM office_applications WHERE status='pending' ORDER BY created_at ASC LIMIT 500").all();
    ctx.ok({ applications: rows.map(mapApp) });
  });
  router.get('/api/admin/office-applications/:id/documents/:key', ADMIN, (ctx) => {
    if (!/^(crImg|licImg|idImg|cover|logo)$/.test(ctx.params.key)) throw notFound('الوثيقة غير موجودة');
    const a = db.prepare('SELECT documents_json FROM office_applications WHERE id=?').get(Number(ctx.params.id));
    if (!a) throw notFound('طلب المكتب غير موجود');
    const doc = JSON.parse(a.documents_json || '{}')[ctx.params.key];
    if (!doc) throw notFound('الوثيقة غير موجودة');
    const fp = path.join(app.cfg.privateUploads, doc.storedName);
    if (!fs.existsSync(fp)) throw notFound('ملف الوثيقة غير موجود');
    const data = readPrivateFile(fp);
    ctx.res.writeHead(200, { 'Content-Type': doc.mimeType, 'Content-Length': data.length, 'Content-Disposition': `inline; filename*=UTF-8''${encodeURIComponent(doc.originalName)}`, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'private, no-store' });
    ctx.res.end(data);
  });
  router.patch('/api/admin/office-applications/:id', { ...ADMIN, forbidden: 'اعتماد طلب المكتب متاح للمدير فقط' }, async (ctx) => {
    const id = Number(ctx.params.id);
    const a = db.prepare('SELECT * FROM office_applications WHERE id=?').get(id);
    if (!a) throw notFound('طلب المكتب غير موجود');
    if (a.status !== 'pending') throw conflict('تمت مراجعة هذا الطلب سابقاً');
    const b = await ctx.body();
    const status = String(b.status || ''), note = String(b.note || '').trim().slice(0, 1000);
    if (!['approved', 'rejected'].includes(status)) throw bad('اختر اعتماد الطلب أو رفضه');
    let officeId = null;
    transaction(db, () => {
      if (status === 'approved') {
        const prior = db.prepare('SELECT * FROM users WHERE phone=?').get(a.phone);
        if (prior && prior.role !== 'office') throw conflict('رقم الهاتف مستخدم لحساب آخر ولا يمكن إنشاء حساب مكتب به');
        if (prior) { officeId = prior.id; db.prepare("UPDATE users SET name=?,office_name=?,active=1 WHERE id=? AND role='office'").run(a.owner_name, a.office_name, prior.id); }
        else officeId = Number(db.prepare('INSERT INTO users(name,phone,password_hash,role,office_name,active) VALUES(?,?,?,?,?,1)').run(a.owner_name, a.phone, randomSecretHash(), 'office', a.office_name).lastInsertRowid);
        db.prepare("INSERT INTO office_profiles(office_id,display_name,address,phone,license_no,registration_no,updated_at) VALUES(?,?,?,?,?,?,datetime('now')) ON CONFLICT(office_id) DO NOTHING")
          .run(officeId, a.office_name, a.address, a.phone, a.license_number, a.registration_number);
      }
      db.prepare("UPDATE office_applications SET status=?,review_note=?,reviewed_by=?,reviewed_at=datetime('now'),updated_at=datetime('now') WHERE id=?").run(status, note, ctx.user.id, id);
    });
    audit(ctx.user, 'office_application.review', 'office_application', id, { status, officeId });
    if (officeId) notify(officeId, { kind: 'office_approved', title: 'تم اعتماد مكتبك', body: 'مرحباً بك في سفرك أسهل؛ أكمل بيانات مكتبك وانشر عروضك.', data: {} });
    ctx.ok({ status, officeId, message: status === 'approved' ? 'تم اعتماد المكتب وإنشاء حسابه؛ يستطيع الدخول برقم الهاتف ورمز واتساب.' : 'تم رفض طلب المكتب وتسجيل سبب القرار.' });
  });

  // ---- المستخدمون ----
  router.get('/api/admin/users', ADMIN, (ctx) => {
    const role = ctx.query.get('role');
    const rows = role
      ? db.prepare('SELECT id,name,phone,email,role,office_name,active,created_at FROM users WHERE role=? ORDER BY id DESC LIMIT 1000').all(role)
      : db.prepare('SELECT id,name,phone,email,role,office_name,active,created_at FROM users ORDER BY id DESC LIMIT 1000').all();
    ctx.ok({ users: rows });
  });
  router.patch('/api/admin/users/:id', ADMIN, async (ctx) => {
    const target = db.prepare('SELECT * FROM users WHERE id=?').get(Number(ctx.params.id));
    if (!target) throw notFound('الحساب غير موجود');
    const b = await ctx.body();
    const name = b.name == null ? target.name : String(b.name).trim();
    const phone = b.phone == null ? target.phone : normalizePhone(b.phone);
    const email = b.email === undefined ? target.email : String(b.email || '').trim() || null;
    const officeName = b.officeName === undefined ? target.office_name : String(b.officeName || '').trim() || name;
    const active = b.active === undefined ? target.active : b.active ? 1 : 0;
    if (name.length < 2 || !validPhone(phone)) throw bad('الاسم أو رقم الهاتف غير صالح');
    if (target.id === ctx.user.id && !active) throw conflict('لا يمكنك تعطيل حسابك');
    try { db.prepare('UPDATE users SET name=?,phone=?,email=?,office_name=?,active=? WHERE id=?').run(name, phone, email, officeName, active, target.id); }
    catch (e) { if (isUnique(e)) throw conflict('رقم الهاتف أو البريد مستخدم'); throw e; }
    if (!active) db.prepare('DELETE FROM sessions WHERE user_id=?').run(target.id);
    audit(ctx.user, 'admin.user.update', 'user', target.id, { role: target.role, active });
    ctx.ok({ user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(target.id)) });
  });

  // ---- عروض المكاتب (إدارة وتدقيق) ----
  router.get('/api/admin/services', ADMIN, (ctx) =>
    ctx.ok({ services: db.prepare('SELECT s.*,u.office_name FROM office_services s JOIN users u ON u.id=s.office_id ORDER BY s.updated_at DESC LIMIT 1000').all().map(mapService) }));
  router.post('/api/admin/services', ADMIN, async (ctx) => {
    const b = await ctx.body();
    const officeId = Number(b.officeId), serviceType = String(b.serviceType || '').trim(), title = String(b.title || '').trim();
    const details = b.details && typeof b.details === 'object' ? b.details : {};
    if (!db.prepare("SELECT id FROM users WHERE id=? AND role='office' AND active=1").get(officeId)) throw bad('اختر مكتباً نشطاً صحيحاً');
    if (!serviceType || !title || title.length > 250) throw bad('نوع الخدمة وعنوانها مطلوبان');
    const price = priceOf(details);
    if (!validPrice(price)) throw bad('السعر غير صالح');
    if (b.active && price === null) throw bad('لا يمكن نشر عرض قبل إدخال سعره الرسمي');
    try {
      const r = db.prepare("INSERT INTO office_services(office_id,service_type,title,details_json,active,updated_at) VALUES(?,?,?,?,?,datetime('now'))").run(officeId, serviceType, title, JSON.stringify(details), b.active ? 1 : 0);
      audit(ctx.user, 'admin.service.create', 'office_service', r.lastInsertRowid, { officeId, serviceType, active: !!b.active });
      ctx.ok({ service: mapService(db.prepare('SELECT * FROM office_services WHERE id=?').get(Number(r.lastInsertRowid))) }, 201);
    } catch (e) { if (isUnique(e)) throw conflict('هذا المكتب لديه عرض بالعنوان نفسه'); throw e; }
  });
  router.patch('/api/admin/services/:id', ADMIN, async (ctx) => {
    const id = Number(ctx.params.id);
    const old = db.prepare('SELECT * FROM office_services WHERE id=?').get(id);
    if (!old) throw notFound('العرض غير موجود');
    const b = await ctx.body();
    const title = b.title == null ? old.title : String(b.title).trim();
    const details = b.details && typeof b.details === 'object' ? b.details : JSON.parse(old.details_json);
    const active = b.active === undefined ? old.active : b.active ? 1 : 0;
    if (!title || title.length > 250) throw bad('عنوان العرض غير صالح');
    const price = priceOf(details);
    if (active && price === null) throw bad('لا يمكن نشر عرض قبل إدخال سعره الرسمي');
    if (!validPrice(price)) throw bad('السعر غير صالح');
    try { db.prepare("UPDATE office_services SET title=?,details_json=?,active=?,updated_at=datetime('now') WHERE id=?").run(title, JSON.stringify(details), active, id); }
    catch (e) { if (isUnique(e)) throw conflict('يوجد عرض بالعنوان نفسه لدى المكتب'); throw e; }
    audit(ctx.user, 'admin.service.review', 'office_service', id, { active });
    ctx.ok({ service: mapService(db.prepare('SELECT * FROM office_services WHERE id=?').get(id)) });
  });

  // ---- حسابات الدفع (عامة للمنصة أو لمكتب معيّن) ----
  router.get('/api/admin/payment-methods', ADMIN, (ctx) =>
    ctx.ok({ methods: db.prepare('SELECT p.*,u.office_name,u.name AS office_user_name FROM payment_methods p LEFT JOIN users u ON u.id=p.owner_id ORDER BY p.id DESC').all() }));
  const cleanMethod = (b, old = {}) => {
    const ownerId = b.ownerId === undefined ? old.owner_id ?? null : b.ownerId == null || b.ownerId === '' || Number(b.ownerId) === 0 ? null : Number(b.ownerId);
    const f = (k, cur, n = 200) => (b[k] == null ? cur : String(b[k]).trim().slice(0, n));
    const m = {
      ownerId, type: f('type', old.type || ''), name: f('name', old.name || ''), account: f('accountNo', old.account_no || ''),
      holder: f('holder', old.holder || ''), currency: f('currency', old.currency || 'YER', 8) || 'YER',
      active: b.active === undefined ? (old.active ?? 1) : b.active ? 1 : 0,
    };
    if (ownerId !== null && !db.prepare("SELECT id FROM users WHERE id=? AND role='office'").get(ownerId)) throw bad('المكتب المحدد غير صالح');
    if (!m.type || !m.name || !m.account) throw bad('نوع وسيلة الدفع والاسم ورقم الحساب مطلوبة');
    return m;
  };
  router.post('/api/admin/payment-methods', ADMIN, async (ctx) => {
    const m = cleanMethod(await ctx.body());
    try {
      const r = db.prepare('INSERT INTO payment_methods(owner_id,type,name,account_no,holder,currency,active) VALUES(?,?,?,?,?,?,?)').run(m.ownerId, m.type, m.name, m.account, m.holder, m.currency, m.active);
      audit(ctx.user, 'payment_method.create', 'payment_method', r.lastInsertRowid, { ownerId: m.ownerId, type: m.type });
      ctx.ok({ method: db.prepare('SELECT * FROM payment_methods WHERE id=?').get(Number(r.lastInsertRowid)) }, 201);
    } catch (e) { if (isUnique(e)) throw conflict('وسيلة الدفع موجودة مسبقاً'); throw e; }
  });
  router.patch('/api/admin/payment-methods/:id', ADMIN, async (ctx) => {
    const old = db.prepare('SELECT * FROM payment_methods WHERE id=?').get(Number(ctx.params.id));
    if (!old) throw notFound('وسيلة الدفع غير موجودة');
    const m = cleanMethod(await ctx.body(), old);
    try { db.prepare("UPDATE payment_methods SET owner_id=?,type=?,name=?,account_no=?,holder=?,currency=?,active=?,updated_at=datetime('now') WHERE id=?").run(m.ownerId, m.type, m.name, m.account, m.holder, m.currency, m.active, old.id); }
    catch (e) { if (isUnique(e)) throw conflict('وسيلة الدفع موجودة مسبقاً'); throw e; }
    audit(ctx.user, 'payment_method.update', 'payment_method', old.id, { ownerId: m.ownerId, active: m.active });
    ctx.ok({ method: db.prepare('SELECT * FROM payment_methods WHERE id=?').get(old.id) });
  });
  router.delete('/api/admin/payment-methods/:id', ADMIN, (ctx) => {
    const old = db.prepare('SELECT id FROM payment_methods WHERE id=?').get(Number(ctx.params.id));
    if (!old) throw notFound('وسيلة الدفع غير موجودة');
    db.prepare('DELETE FROM payment_methods WHERE id=?').run(old.id);
    audit(ctx.user, 'payment_method.delete', 'payment_method', old.id);
    ctx.ok();
  });
}
