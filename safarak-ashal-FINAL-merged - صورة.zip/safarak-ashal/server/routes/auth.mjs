// تسجيل الدخول: رمز OTP (العميل/المكتب/المدير) + كلمة مرور (المدير) + جلسات بكوكي HttpOnly.
const OTP_MAX_ATTEMPTS = 3; // عدد المحاولات الخاطئة لكل رمز قبل إبطاله (الرمز 4 خانات)
// حد على مستوى الرقم: إذا تجاوز مجموع المحاولات في 30 دقيقة 9 يُحجب الرقم 30 دقيقة (يمنع تجاوز الحد بطلب رموز جديدة)
const OTP_PHONE_GUESS_LIMIT = 9;
function phoneGuessesBlocked(db, phone) {
  return db.prepare("SELECT COALESCE(SUM(attempts),0) AS n FROM otp_challenges WHERE phone=? AND created_at >= datetime('now','-30 minutes')").get(phone).n >= OTP_PHONE_GUESS_LIMIT;
}
import crypto from 'node:crypto';
import { hashToken, hashPassword, verifyPassword, timingSafe } from '../security/index.mjs';
import { normalizePhone, phoneMatches, validPhone } from '../lib/phone.mjs';
import { deliverOtp } from '../integrations/otp.mjs';
import { bad, conflict, forbidden, HttpError } from '../lib/errors.mjs';

export const publicUser = (u) => u && { id: u.id, name: u.name, phone: u.phone, email: u.email, role: u.role, officeName: u.office_name || null };

export default function register(router, app) {
  const { db, cfg, audit } = app;

  function createSession(ctx, user) {
    const token = app.sessions.create(user.id, ctx.req, ctx.ip);
    ctx.res.setHeader('Set-Cookie', app.sessionCookie(token, cfg.sessionHours * 3600));
  }
  const currentToken = (req) => /safarak_session=([^;]+)/.exec(req.headers.cookie || '')?.[1];
  const findByPhone = (phone) => {
    let u = db.prepare('SELECT * FROM users WHERE phone=? AND active=1').get(phone);
    if (!u) u = db.prepare('SELECT * FROM users WHERE active=1').all().find((x) => phoneMatches(x.phone, phone));
    return u;
  };

  router.post('/api/auth/request-otp', { public: true }, async (ctx) => {
    if (app.limited('otp-ip:' + ctx.ip)) throw new HttpError(429, 'محاولات كثيرة لإرسال الرموز؛ حاول بعد دقيقة');
    const b = await ctx.body();
    const phone = normalizePhone(b.phone), role = String(b.role || 'customer'), name = String(b.name || '').trim();
    if (!validPhone(phone)) throw bad('رقم الهاتف غير صالح');
    if (!['customer', 'office', 'admin'].includes(role)) throw bad('نوع الحساب غير صالح');
    if (role === 'customer' && name.length < 2) throw bad('أدخل الاسم الكامل');
    const existing = findByPhone(phone);
    if (role !== 'customer' && (!existing || existing.role !== role)) throw forbidden('هذا الرقم غير مسجل لحساب مخوّل لهذا القسم. اطلب من الإدارة إنشاء حساب المكتب أو المدير.');
    if (role === 'customer' && existing && existing.role !== 'customer') throw forbidden('هذا الرقم مستخدم لحساب آخر؛ اختر القسم الصحيح.');
    if (phoneGuessesBlocked(db, phone)) throw new HttpError(429, 'محاولات خاطئة كثيرة لهذا الرقم؛ انتظر 30 دقيقة ثم حاول مرة أخرى.');
    const recent = db.prepare("SELECT COUNT(*) AS n FROM otp_challenges WHERE phone=? AND created_at >= datetime('now','-10 minutes')").get(phone).n;
    if (recent >= 5) throw new HttpError(429, 'تجاوزت عدد الرموز المسموح به لهذا الرقم؛ انتظر 10 دقائق.');
    const id = crypto.randomUUID(), code = String(crypto.randomInt(0, 10000)).padStart(4, '0');
    db.prepare('INSERT INTO otp_challenges(id,phone,role,name,code_hash,expires_at) VALUES(?,?,?,?,?,?)').run(id, phone, role, name, hashToken(`${id}:${code}:${cfg.otp.pepper}`), Date.now() + cfg.otp.ttlMs);
    try { await deliverOtp(cfg, phone, code); } catch (e) { db.prepare('DELETE FROM otp_challenges WHERE id=?').run(id); throw e; }
    // الرمز الأحدث فقط يبقى صالحاً: أي رمز سابق لنفس الرقم يُبطَل فوراً
    db.prepare('UPDATE otp_challenges SET consumed_at=? WHERE phone=? AND consumed_at IS NULL AND id<>?').run(Date.now(), phone, id);
    ctx.ok({ challengeId: id, expiresInSeconds: 300, message: cfg.production ? 'تم إرسال رمز التحقق.' : 'تم إنشاء رمز تحقق للتطوير؛ راجع نافذة تشغيل الخادم لإدخال الرمز.' });
  });

  router.post('/api/auth/verify-otp', { public: true }, async (ctx) => {
    if (app.limited('otp-verify:' + ctx.ip)) throw new HttpError(429, 'محاولات كثيرة؛ حاول بعد دقيقة');
    const b = await ctx.body();
    const id = String(b.challengeId || ''), code = String(b.code || '').replace(/\D/g, '');
    if (!/^[0-9a-f-]{36}$/i.test(id) || !/^\d{4}$/.test(code)) throw bad('رمز التحقق غير صحيح');
    const ch = db.prepare('SELECT * FROM otp_challenges WHERE id=?').get(id);
    if (ch && phoneGuessesBlocked(db, ch.phone)) throw new HttpError(429, 'محاولات خاطئة كثيرة لهذا الرقم؛ انتظر 30 دقيقة ثم حاول مرة أخرى.');
    if (!ch || ch.consumed_at || ch.expires_at < Date.now() || ch.attempts >= OTP_MAX_ATTEMPTS) throw bad('انتهت صلاحية الرمز أو تم تجاوز عدد المحاولات؛ اطلب رمزاً جديداً');
    db.prepare('UPDATE otp_challenges SET attempts=attempts+1 WHERE id=?').run(id);
    if (!timingSafe(hashToken(`${id}:${code}:${cfg.otp.pepper}`), ch.code_hash)) throw new HttpError(401, 'رمز التحقق غير صحيح');
    db.prepare('UPDATE otp_challenges SET consumed_at=? WHERE id=?').run(Date.now(), id);
    let u = findByPhone(ch.phone);
    if (!u && ch.role === 'customer') {
      try {
        const r = db.prepare('INSERT INTO users(name,phone,password_hash,role) VALUES(?,?,?,?)').run(ch.name, ch.phone, hashPassword(crypto.randomBytes(32).toString('hex')), 'customer');
        u = db.prepare('SELECT * FROM users WHERE id=?').get(Number(r.lastInsertRowid));
      } catch (e) {
        if (String(e.message).includes('UNIQUE')) throw conflict('هذا الرقم مسجل بالفعل؛ أعد طلب الرمز');
        throw e;
      }
    }
    if (!u || u.role !== ch.role) throw forbidden('الحساب غير مخوّل لهذا القسم');
    if (ch.role === 'customer' && ch.name && u.name !== ch.name) {
      db.prepare('UPDATE users SET name=? WHERE id=?').run(ch.name, u.id);
      u = db.prepare('SELECT * FROM users WHERE id=?').get(u.id);
    }
    createSession(ctx, u);
    audit(u, 'user.otp_login', 'user', u.id, { role: u.role });
    ctx.ok({ user: publicUser(u) });
  });

  // الدخول بكلمة المرور مخصص للمدير فقط؛ العميل والمكتب يدخلان برمز OTP. مع قفل بعد 5 محاولات فاشلة.
  router.post('/api/auth/login', { public: true }, async (ctx) => {
    if (app.limited('login:' + ctx.ip)) throw new HttpError(429, 'محاولات كثيرة، حاول بعد دقيقة');
    const b = await ctx.body();
    const raw = String(b.identifier || b.phone || '').trim(), password = String(b.password || '');
    const identifier = /^[+\d\s()-]+$/.test(raw) ? normalizePhone(raw) : raw;
    const key = 'login:' + identifier.toLowerCase();
    const wait = app.lockout.lockedFor(key);
    if (wait) throw new HttpError(429, `الحساب مقفل مؤقتاً بسبب محاولات فاشلة؛ حاول بعد ${Math.ceil(wait / 60)} دقيقة`);
    const u = db.prepare("SELECT * FROM users WHERE (phone=? OR email=?) AND active=1 AND role='admin'").get(identifier, identifier);
    if (!u || !verifyPassword(password, u.password_hash)) {
      const r = app.lockout.fail(key);
      audit(null, 'auth.login_failed', 'user', identifier, { ip: ctx.ip, locked: r.locked });
      throw new HttpError(401, 'بيانات الدخول غير صحيحة');
    }
    app.lockout.clear(key);
    createSession(ctx, u);
    audit(u, 'user.login', 'user', u.id, { ip: ctx.ip });
    ctx.ok({ user: publicUser(u) });
  });

  router.get('/api/auth/me', { public: true }, (ctx) => (ctx.user ? ctx.ok({ user: publicUser(ctx.user) }) : ctx.fail(401, 'يلزم تسجيل الدخول')));

  router.post('/api/auth/logout', { public: true }, (ctx) => {
    const token = currentToken(ctx.req);
    if (token) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(hashToken(token));
    ctx.ok({}, 200, { 'Set-Cookie': app.sessionCookie('', 0) });
  });

  // أجهزتي: عرض الجلسات النشطة وإنهاء أي جلسة (حماية عند فقدان جهاز)
  router.get('/api/auth/sessions', (ctx) => ctx.ok({ sessions: app.sessions.list(ctx.user.id, currentToken(ctx.req)) }));
  router.delete('/api/auth/sessions/:id', (ctx) => {
    const revoked = app.sessions.revoke(ctx.user.id, ctx.params.id);
    if (revoked) audit(ctx.user, 'session.revoke', 'session', ctx.params.id);
    ctx.ok({ revoked });
  });
  router.post('/api/auth/sessions/revoke-others', (ctx) => {
    const revoked = app.sessions.revokeOthers(ctx.user.id, currentToken(ctx.req));
    audit(ctx.user, 'session.revoke_others', 'session', ctx.user.id, { count: revoked });
    ctx.ok({ revoked });
  });
}
