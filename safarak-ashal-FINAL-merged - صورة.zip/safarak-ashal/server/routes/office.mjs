// واجهات المكتب: خدماته المنشورة، طلبات يدوية، ملف المكتب العام، عملاؤه، فواتيره، ملخصاته.
import { transaction } from '../db/connection.mjs';
import { randomSecretHash, publicId } from '../security/index.mjs';
import { normalizePhone, validPhone } from '../lib/phone.mjs';
import { HttpError, bad, conflict, notFound } from '../lib/errors.mjs';
import { STATUS, BOOKING_SELECT, mapBooking, insertBooking } from '../services/bookings.mjs';

const OFFICE_ONLY = { roles: ['office'], forbidden: 'هذه العملية للمكتب فقط' };
const OFFICE_OR_ADMIN = { roles: ['office', 'admin'], forbidden: 'هذه الصفحة للمكتب أو المدير' };

export const priceOf = (details) => (details?.price == null || details.price === '' ? null : Number(details.price));
export const validPrice = (p) => p === null || (Number.isFinite(p) && p >= 0 && p <= 1e9);
export const mapService = (x) => ({ ...x, details: JSON.parse(x.details_json || '{}') });

export default function register(router, app) {
  const { db, audit } = app;

  // ---- الخدمات ----
  router.get('/api/office/services', OFFICE_OR_ADMIN, (ctx) => {
    const rows = ctx.user.role === 'admin'
      ? db.prepare('SELECT * FROM office_services ORDER BY office_id,id').all()
      : db.prepare('SELECT * FROM office_services WHERE office_id=? ORDER BY id').all(ctx.user.id);
    ctx.ok({ services: rows.map(mapService) });
  });

  router.put('/api/office/services/sync', OFFICE_ONLY, async (ctx) => {
    const b = await ctx.body();
    const items = Array.isArray(b.services) ? b.services : [];
    if (items.length > 200) throw new HttpError(413, 'عدد الخدمات كبير جداً');
    const clean = items.map((x) => {
      const serviceType = String(x.serviceType || '').trim(), title = String(x.title || '').trim();
      const details = x.details && typeof x.details === 'object' ? x.details : {};
      if (!serviceType || !title || serviceType.length > 100 || title.length > 250) throw bad('كل خدمة تحتاج نوعاً وعنواناً صحيحين');
      const price = priceOf(details), active = x.active === false ? 0 : 1;
      if (!validPrice(price)) throw bad('سعر إحدى الخدمات غير صالح');
      if (active && price === null) throw bad('لا يمكن نشر عرض قبل إدخال سعره الرسمي؛ أدخل 0 فقط إذا كانت الخدمة مجانية');
      return { serviceType, title, details, active };
    });
    transaction(db, () => {
      db.prepare("UPDATE office_services SET active=0,updated_at=datetime('now') WHERE office_id=?").run(ctx.user.id);
      const up = db.prepare("INSERT INTO office_services(office_id,service_type,title,details_json,active,updated_at) VALUES(?,?,?,?,?,datetime('now')) ON CONFLICT(office_id,service_type,title) DO UPDATE SET details_json=excluded.details_json,active=excluded.active,updated_at=datetime('now')");
      for (const x of clean) up.run(ctx.user.id, x.serviceType, x.title, JSON.stringify(x.details), x.active);
    });
    audit(ctx.user, 'office_service.sync', 'office_services', ctx.user.id, { count: clean.length });
    const rows = db.prepare('SELECT * FROM office_services WHERE office_id=? ORDER BY id').all(ctx.user.id);
    ctx.ok({ count: clean.length, services: rows.map(mapService) });
  });

  router.post('/api/office/services', OFFICE_ONLY, async (ctx) => {
    const b = await ctx.body();
    const serviceType = String(b.serviceType || '').trim(), title = String(b.title || '').trim();
    if (!serviceType || !title || serviceType.length > 100 || title.length > 250) throw bad('نوع الخدمة والعنوان مطلوبان');
    const details = b.details && typeof b.details === 'object' ? b.details : {};
    const price = priceOf(details);
    if (!validPrice(price)) throw bad('السعر غير صالح');
    const active = b.active === false ? 0 : 1;
    if (active && price === null) throw bad('لا يمكن نشر عرض قبل إدخال سعره الرسمي');
    try {
      const r = db.prepare("INSERT INTO office_services(office_id,service_type,title,details_json,active,updated_at) VALUES(?,?,?,?,?,datetime('now'))").run(ctx.user.id, serviceType, title, JSON.stringify(details), active);
      audit(ctx.user, 'office_service.create', 'office_service', r.lastInsertRowid);
      ctx.ok({ service: mapService(db.prepare('SELECT * FROM office_services WHERE id=?').get(Number(r.lastInsertRowid))) }, 201);
    } catch (e) { if (String(e.message).includes('UNIQUE')) throw conflict('لديك عرض بالعنوان نفسه'); throw e; }
  });

  router.delete('/api/office/services/:id', OFFICE_ONLY, (ctx) => {
    const old = db.prepare('SELECT id FROM office_services WHERE id=? AND office_id=?').get(Number(ctx.params.id), ctx.user.id);
    if (!old) throw notFound('العرض غير موجود');
    db.prepare("UPDATE office_services SET active=0,updated_at=datetime('now') WHERE id=?").run(old.id);
    audit(ctx.user, 'office_service.deactivate', 'office_service', old.id);
    ctx.ok();
  });

  // ---- طلب يدوي ينشئه المكتب لعميل ----
  router.post('/api/office/bookings', { ...OFFICE_ONLY, forbidden: 'إنشاء الطلب اليدوي متاح للمكتب فقط' }, async (ctx) => {
    const { user } = ctx;
    const b = await ctx.body();
    const name = String(b.customerName || '').trim(), phone = normalizePhone(b.customerPhone);
    const service = String(b.serviceType || '').trim(), title = String(b.title || '').trim();
    const pax = Number(b.passengerCount || 1), amount = Number(b.totalAmount || 0);
    if (name.length < 2 || !validPhone(phone) || !service || title.length < 2 || title.length > 250 || !Number.isInteger(pax) || pax < 1 || pax > 30 || !Number.isFinite(amount) || amount < 0 || amount > 1e9)
      throw bad('بيانات الطلب اليدوي غير صحيحة');
    const offered = db.prepare('SELECT id FROM office_services WHERE office_id=? AND service_type=? AND active=1 ORDER BY id DESC LIMIT 1').get(user.id, service);
    if (!offered) throw bad('لا يمكن تسجيل طلب لهذه الخدمة قبل نشر عرض حقيقي لها من حساب المكتب');
    let customer = db.prepare('SELECT * FROM users WHERE phone=?').get(phone);
    if (customer && customer.role !== 'customer') throw conflict('رقم الهاتف مستخدم لحساب غير عميل');
    if (!customer) {
      const r = db.prepare('INSERT INTO users(name,phone,password_hash,role,active) VALUES(?,?,?,?,1)').run(name, phone, randomSecretHash(), 'customer');
      customer = db.prepare('SELECT * FROM users WHERE id=?').get(Number(r.lastInsertRowid));
      audit(user, 'office.customer.create', 'user', customer.id, { source: 'manual_booking' });
    }
    const status = STATUS.includes(String(b.status)) ? String(b.status) : 'pending';
    const details = { ...(b.details && typeof b.details === 'object' ? b.details : {}), serviceId: offered.id, officeManual: true, customerName: name, customerPhone: phone };
    let booking;
    try {
      booking = insertBooking(app, { publicId: publicId(), customerId: customer.id, officeId: user.id, serviceType: service, title, details, pax, amount, currency: String(b.currency || 'YER').slice(0, 8), status, actorId: user.id, note: 'أنشأ المكتب الطلب يدوياً' });
    } catch (e) { if (e.status === 409) throw conflict(e.message); throw e; }
    audit(user, 'office.booking.create', 'booking', booking.public_id, { customerId: customer.id });
    app.notify(customer.id, { kind: 'booking_new', title: 'سُجّل لك طلب جديد', body: title, data: { bookingId: booking.public_id } });
    ctx.ok({ booking: mapBooking(booking), customer: { id: customer.id, name: customer.name, phone: customer.phone } }, 201);
  });

  // ---- ملخصات ولوحة المكتب ----
  router.get('/api/office/summary', OFFICE_OR_ADMIN, (ctx) => {
    const q = ctx.user.role === 'admin'
      ? db.prepare('SELECT status,COUNT(*) AS count FROM bookings GROUP BY status').all()
      : db.prepare('SELECT status,COUNT(*) AS count FROM bookings WHERE office_id=? GROUP BY status').all(ctx.user.id);
    ctx.ok({ counts: q });
  });

  router.get('/api/office/dashboard', OFFICE_ONLY, (ctx) => {
    const id = ctx.user.id;
    const one = (sql, ...a) => db.prepare(sql).get(...a);
    ctx.ok({
      bookings: one('SELECT COUNT(*) AS total, SUM(status IN (\'pending\',\'reviewing\')) AS open, SUM(status=\'completed\') AS completed FROM bookings WHERE office_id=?', id),
      revenue: db.prepare("SELECT currency,ROUND(SUM(total_amount),2) AS total FROM bookings WHERE office_id=? AND payment_status='confirmed' GROUP BY currency").all(id),
      pendingPayments: one("SELECT COUNT(*) AS n FROM payment_submissions WHERE office_id=? AND status='submitted'", id).n,
      unreadMessages: one('SELECT COUNT(*) AS n FROM messages m JOIN conversations c ON c.id=m.conversation_id WHERE c.office_id=? AND m.sender_id<>? AND m.read_at IS NULL', id, id).n,
      rating: one("SELECT COUNT(*) AS count, ROUND(AVG(rating),1) AS avg FROM reviews WHERE office_id=? AND status='published'", id),
      quotas: db.prepare('SELECT service_type,remaining FROM office_quotas WHERE office_id=?').all(id),
    });
  });

  router.get('/api/office/customers', OFFICE_ONLY, (ctx) => {
    const rows = db.prepare(`SELECT c.id,c.name,c.phone,COUNT(b.id) AS bookings,ROUND(SUM(b.total_amount),2) AS total,MAX(b.created_at) AS last_booking_at
      FROM bookings b JOIN users c ON c.id=b.customer_id WHERE b.office_id=? GROUP BY c.id ORDER BY last_booking_at DESC LIMIT 1000`).all(ctx.user.id);
    ctx.ok({ customers: rows });
  });

  router.get('/api/office/invoices', OFFICE_ONLY, (ctx) => {
    const rows = db.prepare(`SELECT i.number,i.seq,i.issued_at,b.public_id AS booking_id,b.title,b.total_amount,b.currency,b.payment_status,c.name AS customer_name
      FROM invoices i JOIN bookings b ON b.id=i.booking_id JOIN users c ON c.id=b.customer_id WHERE i.office_id=? ORDER BY i.seq DESC LIMIT 1000`).all(ctx.user.id);
    ctx.ok({ invoices: rows });
  });

  // ---- ملف المكتب العام (الاسم، الموقع، الصورة، الترخيص...) ----
  const mapProfile = (r) => r && ({
    displayName: r.display_name, city: r.city, address: r.address, years: r.years, phone: r.phone, whatsapp: r.whatsapp,
    licenseNo: r.license_no, registrationNo: r.registration_no, about: r.about, verified: !!r.verified,
    logo: r.logo_asset_id ? '/assets/offers/' + r.logo_asset_id : '', cover: r.cover_asset_id ? '/assets/offers/' + r.cover_asset_id : '',
    logoAssetId: r.logo_asset_id, coverAssetId: r.cover_asset_id, extra: JSON.parse(r.extra_json || '{}'), updatedAt: r.updated_at,
  });
  router.get('/api/office/profile', OFFICE_ONLY, (ctx) =>
    ctx.ok({ profile: mapProfile(db.prepare('SELECT * FROM office_profiles WHERE office_id=?').get(ctx.user.id)) || null }));

  router.put('/api/office/profile', OFFICE_ONLY, async (ctx) => {
    const b = await ctx.body();
    const s = (k, n = 200) => String(b[k] ?? '').trim().slice(0, n);
    const owned = (id) => {
      if (!id) return null;
      const a = db.prepare('SELECT id FROM public_assets WHERE id=? AND owner_id=?').get(String(id), ctx.user.id);
      if (!a) throw bad('صورة غير تابعة لحسابك');
      return a.id;
    };
    const years = Math.max(0, Math.min(100, Number(b.years) || 0));
    const extra = b.extra && typeof b.extra === 'object' ? JSON.stringify(b.extra).slice(0, 20000) : '{}';
    const old = db.prepare('SELECT * FROM office_profiles WHERE office_id=?').get(ctx.user.id);
    const logo = b.logoAssetId === undefined ? old?.logo_asset_id ?? null : owned(b.logoAssetId);
    const cover = b.coverAssetId === undefined ? old?.cover_asset_id ?? null : owned(b.coverAssetId);
    db.prepare(`INSERT INTO office_profiles(office_id,display_name,city,address,years,phone,whatsapp,license_no,registration_no,about,logo_asset_id,cover_asset_id,extra_json,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))
      ON CONFLICT(office_id) DO UPDATE SET display_name=excluded.display_name,city=excluded.city,address=excluded.address,years=excluded.years,phone=excluded.phone,whatsapp=excluded.whatsapp,
      license_no=excluded.license_no,registration_no=excluded.registration_no,about=excluded.about,logo_asset_id=excluded.logo_asset_id,cover_asset_id=excluded.cover_asset_id,extra_json=excluded.extra_json,updated_at=datetime('now')`)
      .run(ctx.user.id, s('displayName'), s('city', 80), s('address', 300), years, s('phone', 30), s('whatsapp', 30), s('licenseNo', 80), s('registrationNo', 80), s('about', 2000), logo, cover, extra);
    if (s('displayName')) db.prepare('UPDATE users SET office_name=? WHERE id=?').run(s('displayName'), ctx.user.id);
    audit(ctx.user, 'office.profile.update', 'office_profile', ctx.user.id);
    ctx.ok({ profile: mapProfile(db.prepare('SELECT * FROM office_profiles WHERE office_id=?').get(ctx.user.id)) });
  });

  // الطلبات الخاصة بالمكتب مع العميل والفاتورة (بديل الاعتماد على الذاكرة المحلية)
  router.get('/api/office/bookings', OFFICE_ONLY, (ctx) => {
    const status = ctx.query.get('status');
    const rows = status
      ? db.prepare(`${BOOKING_SELECT} WHERE b.office_id=? AND b.status=? ORDER BY b.created_at DESC LIMIT 1000`).all(ctx.user.id, status)
      : db.prepare(`${BOOKING_SELECT} WHERE b.office_id=? ORDER BY b.created_at DESC LIMIT 1000`).all(ctx.user.id);
    ctx.ok({ bookings: rows.map(mapBooking) });
  });
}
