// «شراء عروض تطبيقنا»: باقات تعرضها الإدارة على المكاتب + طلب كمية مخصصة + رصيد المكتب.
import { transaction } from '../db/connection.mjs';
import { bad, conflict, notFound } from '../lib/errors.mjs';

const ADMIN = { roles: ['admin'], forbidden: 'هذه العملية للمدير فقط' };
const OFFICE = { roles: ['office'], forbidden: 'هذه العملية للمكتب فقط' };

export default function register(router, app) {
  const { db, audit, notify } = app;
  const pkg = (id) => db.prepare('SELECT * FROM offer_packages WHERE id=?').get(id);
  const purchases = (where, ...a) => db.prepare(`SELECT p.*,u.office_name,u.name AS office_user_name,k.title AS package_title FROM package_purchases p JOIN users u ON u.id=p.office_id LEFT JOIN offer_packages k ON k.id=p.package_id ${where} ORDER BY p.created_at DESC LIMIT 500`).all(...a);

  // ---- الإدارة تدير الباقات ----
  const cleanPkg = (b, old = {}) => {
    const title = String(b.title ?? old.title ?? '').trim(), serviceType = String(b.serviceType ?? old.service_type ?? '').trim();
    const quantity = Number(b.quantity ?? old.quantity), price = Number(b.price ?? old.price);
    if (!title || title.length > 160 || !serviceType || !Number.isInteger(quantity) || quantity < 1 || quantity > 1e6 || !Number.isFinite(price) || price < 0 || price > 1e9) throw bad('بيانات الباقة غير صحيحة');
    return { title, serviceType, quantity, price, description: String(b.description ?? old.description ?? '').trim().slice(0, 1000), currency: String(b.currency ?? old.currency ?? 'YER').slice(0, 8), active: b.active === undefined ? (old.active ?? 1) : b.active ? 1 : 0 };
  };
  router.post('/api/admin/packages', ADMIN, async (ctx) => {
    const p = cleanPkg(await ctx.body());
    const r = db.prepare('INSERT INTO offer_packages(title,description,service_type,quantity,price,currency,active,created_by) VALUES(?,?,?,?,?,?,?,?)').run(p.title, p.description, p.serviceType, p.quantity, p.price, p.currency, p.active, ctx.user.id);
    audit(ctx.user, 'package.create', 'offer_package', r.lastInsertRowid);
    ctx.ok({ package: pkg(Number(r.lastInsertRowid)) }, 201);
  });
  router.patch('/api/admin/packages/:id', ADMIN, async (ctx) => {
    const old = pkg(Number(ctx.params.id));
    if (!old) throw notFound('الباقة غير موجودة');
    const p = cleanPkg(await ctx.body(), old);
    db.prepare('UPDATE offer_packages SET title=?,description=?,service_type=?,quantity=?,price=?,currency=?,active=? WHERE id=?').run(p.title, p.description, p.serviceType, p.quantity, p.price, p.currency, p.active, old.id);
    audit(ctx.user, 'package.update', 'offer_package', old.id);
    ctx.ok({ package: pkg(old.id) });
  });
  router.delete('/api/admin/packages/:id', ADMIN, (ctx) => {
    const old = pkg(Number(ctx.params.id));
    if (!old) throw notFound('الباقة غير موجودة');
    db.prepare('UPDATE offer_packages SET active=0 WHERE id=?').run(old.id);
    audit(ctx.user, 'package.deactivate', 'offer_package', old.id);
    ctx.ok();
  });

  // ---- المكتب: يعرض الباقات ويطلب الشراء ----
  router.get('/api/packages', { roles: ['office', 'admin'], forbidden: 'الباقات للمكاتب والإدارة' }, (ctx) =>
    ctx.ok({ packages: ctx.user.role === 'admin' ? db.prepare('SELECT * FROM offer_packages ORDER BY id DESC').all() : db.prepare('SELECT * FROM offer_packages WHERE active=1 ORDER BY price').all() }));

  router.post('/api/office/package-purchases', OFFICE, async (ctx) => {
    const b = await ctx.body();
    let row;
    if (b.packageId) {
      const p = pkg(Number(b.packageId));
      if (!p || !p.active) throw notFound('الباقة غير متاحة');
      row = { packageId: p.id, serviceType: p.service_type, quantity: p.quantity, total: p.price, currency: p.currency, custom: 0 };
    } else {
      const serviceType = String(b.serviceType || '').trim(), quantity = Number(b.quantity);
      if (!serviceType || !Number.isInteger(quantity) || quantity < 1 || quantity > 1e5) throw bad('حدّد نوع الخدمة وكمية صحيحة');
      row = { packageId: null, serviceType, quantity, total: 0, currency: 'YER', custom: 1 };
    }
    const r = db.prepare('INSERT INTO package_purchases(office_id,package_id,service_type,quantity,total_price,currency,custom_request,note) VALUES(?,?,?,?,?,?,?,?)')
      .run(ctx.user.id, row.packageId, row.serviceType, row.quantity, row.total, row.currency, row.custom, String(b.note || '').slice(0, 500));
    audit(ctx.user, 'package.purchase_request', 'package_purchase', r.lastInsertRowid, row);
    for (const a of db.prepare("SELECT id FROM users WHERE role='admin' AND active=1").all())
      notify(a.id, { kind: 'package_request', title: row.custom ? 'طلب كمية مخصصة من مكتب' : 'طلب شراء باقة', body: `${ctx.user.office_name || ctx.user.name} — ${row.quantity} × ${row.serviceType}`, data: { purchaseId: Number(r.lastInsertRowid) } });
    ctx.ok({ purchase: db.prepare('SELECT * FROM package_purchases WHERE id=?').get(Number(r.lastInsertRowid)) }, 201);
  });

  router.get('/api/office/package-purchases', OFFICE, (ctx) =>
    ctx.ok({ purchases: purchases('WHERE p.office_id=?', ctx.user.id), quotas: db.prepare('SELECT service_type,remaining FROM office_quotas WHERE office_id=?').all(ctx.user.id) }));

  // ---- الإدارة تراجع الطلبات: السعر المخصص + الاعتماد + تفعيل الرصيد ----
  router.get('/api/admin/package-purchases', ADMIN, (ctx) => ctx.ok({ purchases: purchases('') }));

  router.patch('/api/admin/package-purchases/:id', ADMIN, async (ctx) => {
    const old = db.prepare('SELECT * FROM package_purchases WHERE id=?').get(Number(ctx.params.id));
    if (!old) throw notFound('الطلب غير موجود');
    const b = await ctx.body();
    const status = b.status == null ? old.status : String(b.status);
    if (!['requested', 'approved', 'paid', 'rejected', 'fulfilled'].includes(status)) throw bad('حالة غير صحيحة');
    if (old.status === 'fulfilled') throw conflict('تم تفعيل الرصيد لهذا الطلب مسبقاً');
    const price = b.totalPrice == null ? old.total_price : Number(b.totalPrice);
    if (!Number.isFinite(price) || price < 0) throw bad('السعر غير صالح');
    transaction(db, () => {
      db.prepare("UPDATE package_purchases SET status=?,total_price=?,note=?,reviewed_by=?,updated_at=datetime('now') WHERE id=?").run(status, price, String(b.note ?? old.note).slice(0, 500), ctx.user.id, old.id);
      if (status === 'fulfilled')
        db.prepare("INSERT INTO office_quotas(office_id,service_type,remaining) VALUES(?,?,?) ON CONFLICT(office_id,service_type) DO UPDATE SET remaining=remaining+excluded.remaining,updated_at=datetime('now')").run(old.office_id, old.service_type, old.quantity);
    });
    audit(ctx.user, 'package.purchase_review', 'package_purchase', old.id, { status, price });
    notify(old.office_id, { kind: 'package_status', title: status === 'fulfilled' ? 'تم تفعيل رصيد عروضك' : 'تحديث على طلب الباقة', body: `${old.quantity} × ${old.service_type} — ${status}`, data: { purchaseId: old.id } });
    ctx.ok({ purchase: db.prepare('SELECT * FROM package_purchases WHERE id=?').get(old.id) });
  });

  router.get('/api/admin/quotas', ADMIN, (ctx) =>
    ctx.ok({ quotas: db.prepare('SELECT q.*,u.office_name FROM office_quotas q JOIN users u ON u.id=q.office_id ORDER BY q.office_id').all() }));
  router.put('/api/admin/quotas', ADMIN, async (ctx) => {
    const b = await ctx.body();
    const officeId = Number(b.officeId), serviceType = String(b.serviceType || '').trim(), remaining = Number(b.remaining);
    if (!db.prepare("SELECT id FROM users WHERE id=? AND role='office'").get(officeId) || !serviceType || !Number.isInteger(remaining) || remaining < 0) throw bad('بيانات الرصيد غير صحيحة');
    db.prepare("INSERT INTO office_quotas(office_id,service_type,remaining) VALUES(?,?,?) ON CONFLICT(office_id,service_type) DO UPDATE SET remaining=excluded.remaining,updated_at=datetime('now')").run(officeId, serviceType, remaining);
    audit(ctx.user, 'quota.set', 'office_quota', officeId, { serviceType, remaining });
    ctx.ok();
  });
}
