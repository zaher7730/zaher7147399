import { otpChannels } from '../integrations/otp.mjs';
import { paymentsReady } from '../integrations/stripe.mjs';

export default function register(router, app) {
  router.get('/api/health', { public: true }, ({ ok }) => {
    let database = 'sqlite';
    try { app.db.prepare('SELECT 1').get(); } catch { database = 'error'; }
    ok({
      service: 'safarak-ashal-api',
      version: app.cfg.version,
      database,
      time: new Date().toISOString(),
      features: { otp: otpChannels(app.cfg), onlinePayments: paymentsReady(app.cfg), realtime: true },
    });
  });
}
