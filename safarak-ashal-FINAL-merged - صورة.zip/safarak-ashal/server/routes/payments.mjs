// المدفوعات: حوالة العميل + سند، مراجعة المكتب، حسابات الدفع، ودفع إلكتروني اختياري (Stripe).
import crypto from 'node:crypto';
import { HttpError, bad, conflict, forbidden, notFound } from '../lib/errors.mjs';
import { transaction } from '../db/connection.mjs';
import { createCheckout, paymentsReady, verifyStripeSignature } from '../integrations/stripe.mjs';

export default function register(router, app) {
  const { db, audit, notify, hub } = app;

  const submission = (id) => db.prepare('SELECT * FROM payment_submissions WHERE id=?').get(id);

  function notifyPayment(booking, kind, title, body) {
    for (const uid of [booking.customer_id, booking.office_id]) {
      if (!uid) continue;
      notify(uid, { kind, title, body, data: { bookingId: booking.public_id } });
      hub.publish(uid, 'booking', { bookingId: booking.public_id, event: 'payment' });
    }
  }

  router.get('/api/payments/config', { public: true }, (ctx) => ctx.ok({ online: paymentsReady(app.cfg), provider: paymentsReady(app.cfg) ? app.cfg.payments.provider : null }));

  // 1) العميل يسجّل حوالته
  router.post('/api/bookings/:id/payment', { roles: ['customer'], forbidden: 'تسجيل الحوالة متاح للعميل صاحب الحجز فقط' }, async (ctx) => {
    const { user } = ctx;
    const booking = db.prepare('SELECT * FROM bookings WHERE public_id=?').get(ctx.params.id);
    if (!booking) throw notFound('الحجز غير موجود');
    if (booking.customer_id !== user.id) throw forbidden('لا تملك هذا الحجز');
    if (['cancelled', 'rejected'].includes(booking.status)) throw conflict('لا يمكن الدفع لحجز ملغي أو مرفوض');
    const b = await ctx.body();
    // العميل يرسل اسم المرسل (أو رقم حسابه في نفس الخانة) ورقم الحوالة وصورتها فقط؛ المبلغ هو إجمالي الحجز نفسه ووقت التحويل هو وقت استلام الخادم
    const amount = Number(booking.total_amount), reference = String(b.reference || '').trim(), sender = String(b.sender || '').trim();
    const methodName = String(b.methodName || '').trim(), receiptId = String(b.receiptFileId || ''), transferredAt = new Date().toISOString();
    if (!Number.isFinite(amount) || amount <= 0 || !reference || !sender || !methodName || !receiptId)
      throw bad('اسم المرسل أو رقم حسابه ورقم الحوالة ووسيلة الدفع وصورة الحوالة مطلوبة');
    const file = db.prepare('SELECT * FROM stored_files WHERE id=? AND owner_id=? AND booking_id=?').get(receiptId, user.id, booking.id);
    if (!file) throw bad('سند التحويل غير مرفق بالحجز الصحيح');
    // إعادة الإرسال آمنة: نفس السند أو نفس مرجع الحوالة على نفس الحجز لا يُنشئ سجلاً ثانياً (ضغطتان، أو ضياع الرد بعد نجاح الحفظ)
    const dup = db.prepare("SELECT * FROM payment_submissions WHERE booking_id=? AND customer_id=? AND status IN ('submitted','confirmed') AND (receipt_file_id=? OR reference=?) ORDER BY id LIMIT 1").get(booking.id, user.id, file.id, reference.slice(0, 120));
    if (dup) return ctx.ok({ payment: dup, duplicate: true });
    let pm;
    if (b.methodId) {
      pm = db.prepare('SELECT * FROM payment_methods WHERE id=? AND active=1 AND (owner_id=? OR owner_id IS NULL)').get(Number(b.methodId), booking.office_id);
      if (!pm) throw bad('وسيلة الدفع غير فعالة أو لا تخص المكتب');
      if (pm.name !== methodName) throw bad('اسم وسيلة الدفع لا يطابق الحساب المختار');
    } else {
      pm = db.prepare('SELECT * FROM payment_methods WHERE active=1 AND name=? AND (owner_id=? OR owner_id IS NULL) ORDER BY CASE WHEN owner_id=? THEN 0 ELSE 1 END LIMIT 1').get(methodName, booking.office_id, booking.office_id);
      if (!pm) throw bad('وسيلة الدفع غير موجودة لدى المكتب');
    }
    const r = db.prepare("INSERT INTO payment_submissions(booking_id,customer_id,office_id,method_id,method_name,amount,currency,reference,sender,transferred_at,receipt_file_id,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,'submitted')")
      .run(booking.id, user.id, booking.office_id, pm.id, methodName, amount, String(b.currency || booking.currency).slice(0, 8), reference.slice(0, 120), sender.slice(0, 120), transferredAt.slice(0, 40), file.id);
    db.prepare("UPDATE bookings SET payment_status='submitted',updated_at=datetime('now') WHERE id=?").run(booking.id);
    audit(user, 'payment.submit', 'payment_submission', r.lastInsertRowid, { bookingId: booking.public_id, amount });
    if (booking.office_id) notify(booking.office_id, { kind: 'payment_submitted', title: 'حوالة جديدة بانتظار المراجعة', body: `${booking.title} — ${amount} ${booking.currency}`, data: { bookingId: booking.public_id } });
    hub.publish(booking.office_id, 'booking', { bookingId: booking.public_id, event: 'payment' });
    ctx.ok({ payment: submission(Number(r.lastInsertRowid)) }, 201);
  });

  // حوالات العميل لحجز معيّن
  router.get('/api/bookings/:id/payments', (ctx) => {
    const u = ctx.user;
    const booking = db.prepare('SELECT * FROM bookings WHERE public_id=?').get(ctx.params.id);
    if (!booking) throw notFound('الحجز غير موجود');
    if (!(u.role === 'admin' || booking.customer_id === u.id || booking.office_id === u.id)) throw forbidden('لا تملك هذا الحجز');
    ctx.ok({ payments: db.prepare('SELECT * FROM payment_submissions WHERE booking_id=? ORDER BY id DESC').all(booking.id) });
  });

  // 2) المكتب يسجّل دفعة يدوياً (استلمها خارج التطبيق)
  router.post('/api/office/payments/manual', { roles: ['office'], forbidden: 'هذه العملية للمكتب فقط' }, async (ctx) => {
    const { user } = ctx;
    const b = await ctx.body();
    const booking = db.prepare('SELECT * FROM bookings WHERE public_id=? AND office_id=?').get(String(b.bookingId || ''), user.id);
    if (!booking) throw notFound('الحجز غير موجود في مكتبك');
    const amount = Number(b.amount), reference = String(b.reference || '').trim(), sender = String(b.sender || '').trim();
    const methodName = String(b.methodName || '').trim(), transferredAt = String(b.transferredAt || '').trim();
    if (!Number.isFinite(amount) || amount <= 0 || !reference || !sender || !methodName || !transferredAt) throw bad('أكمل المبلغ ووسيلة الدفع والمرجع واسم المحوّل والتاريخ');
    const pm = db.prepare('SELECT * FROM payment_methods WHERE active=1 AND owner_id=? AND name=?').get(user.id, methodName);
    if (!pm) throw bad('وسيلة الدفع غير موجودة في حسابات مكتبك');
    let receiptFileId = null;
    if (b.receiptFileId) {
      const f = db.prepare('SELECT id FROM stored_files WHERE id=? AND owner_id=? AND booking_id=?').get(String(b.receiptFileId), user.id, booking.id);
      if (!f) throw bad('المرفق لا يتبع هذا الحجز');
      receiptFileId = f.id;
    }
    const r = db.prepare("INSERT INTO payment_submissions(booking_id,customer_id,office_id,method_id,method_name,amount,currency,reference,sender,transferred_at,receipt_file_id,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,'submitted')")
      .run(booking.id, booking.customer_id, user.id, pm.id, methodName, amount, pm.currency || booking.currency, reference.slice(0, 120), sender.slice(0, 120), transferredAt.slice(0, 40), receiptFileId);
    db.prepare("UPDATE bookings SET payment_status='submitted',updated_at=datetime('now') WHERE id=?").run(booking.id);
    audit(user, 'payment.manual_submit', 'payment_submission', r.lastInsertRowid, { bookingId: booking.public_id, amount });
    ctx.ok({ payment: submission(Number(r.lastInsertRowid)) }, 201);
  });

  // 3) المكتب يرى حوالاته
  router.get('/api/office/payments', { roles: ['office'], forbidden: 'هذه العملية للمكتب فقط' }, (ctx) => {
    const rows = db.prepare('SELECT p.*,b.public_id AS booking_public_id,b.title AS booking_title,c.name AS customer_name,c.phone AS customer_phone,f.original_name,f.mime_type FROM payment_submissions p JOIN bookings b ON b.id=p.booking_id JOIN users c ON c.id=p.customer_id LEFT JOIN stored_files f ON f.id=p.receipt_file_id WHERE p.office_id=? ORDER BY p.created_at DESC').all(ctx.user.id);
    ctx.ok({ payments: rows });
  });

  // 4) المكتب يؤكد/يرفض الحوالة
  router.patch('/api/office/payments/:id', { roles: ['office'], forbidden: 'هذه العملية للمكتب فقط' }, async (ctx) => {
    const old = db.prepare('SELECT * FROM payment_submissions WHERE id=? AND office_id=?').get(Number(ctx.params.id), ctx.user.id);
    if (!old) throw notFound('الحوالة غير موجودة');
    const b = await ctx.body();
    const status = String(b.status || '');
    if (!['confirmed', 'rejected'].includes(status)) throw bad('حالة الحوالة غير صحيحة');
    const note = String(b.note || '').slice(0, 1000);
    const booking = transaction(db, () => {
      db.prepare("UPDATE payment_submissions SET status=?,note=?,updated_at=datetime('now') WHERE id=?").run(status, note, old.id);
      db.prepare("UPDATE bookings SET payment_status=?,updated_at=datetime('now') WHERE id=?").run(status, old.booking_id);
      return db.prepare('SELECT * FROM bookings WHERE id=?').get(old.booking_id);
    });
    audit(ctx.user, 'payment.review', 'payment_submission', old.id, { status });
    notifyPayment(booking, 'payment_review', status === 'confirmed' ? 'تم تأكيد دفعتك' : 'تم رفض الحوالة', `${booking.title}${note ? ' — ' + note : ''}`);
    ctx.ok({ payment: submission(old.id) });
  });

  // حسابات دفع المكتب (يديرها المكتب بنفسه)
  router.get('/api/office/payment-methods', { roles: ['office'], forbidden: 'هذه العملية للمكتب فقط' }, (ctx) =>
    ctx.ok({ methods: db.prepare('SELECT * FROM payment_methods WHERE owner_id=? ORDER BY id').all(ctx.user.id) }));

  router.put('/api/office/payment-methods/sync', { roles: ['office'], forbidden: 'هذه العملية للمكتب فقط' }, async (ctx) => {
    const b = await ctx.body();
    const items = Array.isArray(b.methods) ? b.methods : [];
    if (items.length > 100) throw new HttpError(413, 'عدد الحسابات كبير');
    const clean = items.map((x) => ({
      type: String(x.type || '').trim(), name: String(x.name || '').trim(), account: String(x.accountNo || '').trim(),
      holder: String(x.holder || '').trim(), currency: String(x.currency || 'YER').trim().slice(0, 8), active: x.active ? 1 : 0,
    }));
    if (clean.some((x) => !x.type || !x.name || !x.account)) throw bad('كل وسيلة دفع تحتاج النوع والاسم ورقم الحساب');
    transaction(db, () => {
      db.prepare("UPDATE payment_methods SET active=0,updated_at=datetime('now') WHERE owner_id=?").run(ctx.user.id);
      const up = db.prepare("INSERT INTO payment_methods(owner_id,type,name,account_no,holder,currency,active,updated_at) VALUES(?,?,?,?,?,?,?,datetime('now')) ON CONFLICT(owner_id,type,name,account_no) DO UPDATE SET holder=excluded.holder,currency=excluded.currency,active=excluded.active,updated_at=datetime('now')");
      for (const x of clean) up.run(ctx.user.id, x.type, x.name, x.account, x.holder, x.currency, x.active);
    });
    audit(ctx.user, 'office.payment_methods.sync', 'payment_method', ctx.user.id, { count: clean.length });
    ctx.ok({ count: clean.length, methods: db.prepare('SELECT * FROM payment_methods WHERE owner_id=? ORDER BY id').all(ctx.user.id) });
  });

  // ---- الدفع الإلكتروني (اختياري: يعمل عند ضبط المفاتيح) ----
  router.post('/api/bookings/:id/checkout', { roles: ['customer'], forbidden: 'الدفع للعميل صاحب الحجز فقط' }, async (ctx) => {
    const booking = db.prepare('SELECT * FROM bookings WHERE public_id=? AND customer_id=?').get(ctx.params.id, ctx.user.id);
    if (!booking) throw notFound('الحجز غير موجود');
    if (booking.payment_status === 'confirmed') throw conflict('هذا الحجز مدفوع مسبقاً');
    if (!(booking.total_amount > 0)) throw bad('لا يوجد مبلغ مستحق');
    const intentId = crypto.randomUUID();
    const { providerRef, url } = await createCheckout(app.cfg, { intentId, booking, amount: booking.total_amount, currency: booking.currency });
    db.prepare("INSERT INTO payment_intents(id,booking_id,provider,provider_ref,amount,currency,status,checkout_url) VALUES(?,?,?,?,?,?,'pending',?)")
      .run(intentId, booking.id, app.cfg.payments.provider, providerRef, booking.total_amount, booking.currency, url);
    audit(ctx.user, 'payment.checkout', 'payment_intent', intentId, { bookingId: booking.public_id });
    ctx.ok({ checkoutUrl: url, intentId }, 201);
  });

  router.post('/api/payments/webhook/stripe', { public: true }, async (ctx) => {
    const raw = await ctx.raw();
    if (!verifyStripeSignature(app.cfg, raw, ctx.req.headers['stripe-signature'])) throw forbidden('توقيع غير صالح');
    let evt;
    try { evt = JSON.parse(raw); } catch { throw bad('حمولة غير صالحة'); }
    const dup = db.prepare('SELECT id FROM webhook_events WHERE id=?').get(String(evt.id));
    if (dup) return ctx.ok({ duplicate: true });
    db.prepare('INSERT INTO webhook_events(id,provider,type,payload_json) VALUES(?,?,?,?)').run(String(evt.id), 'stripe', String(evt.type), raw.slice(0, 200000));
    const obj = evt.data?.object || {};
    const intentId = obj.metadata?.intent_id || obj.client_reference_id;
    const intent = intentId && db.prepare('SELECT * FROM payment_intents WHERE id=?').get(intentId);
    if (intent && evt.type === 'checkout.session.completed' && obj.payment_status === 'paid') {
      db.prepare("UPDATE payment_intents SET status='paid',updated_at=datetime('now') WHERE id=?").run(intent.id);
      db.prepare("UPDATE bookings SET payment_status='confirmed',updated_at=datetime('now') WHERE id=?").run(intent.booking_id);
      const booking = db.prepare('SELECT * FROM bookings WHERE id=?').get(intent.booking_id);
      notifyPayment(booking, 'payment_review', 'تم استلام الدفع الإلكتروني', booking.title);
    } else if (intent && (evt.type === 'checkout.session.expired' || evt.type === 'payment_intent.payment_failed')) {
      db.prepare("UPDATE payment_intents SET status='failed',updated_at=datetime('now') WHERE id=?").run(intent.id);
    }
    ctx.ok({ received: true });
  });
}
