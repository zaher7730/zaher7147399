// توثيق المكاتب: المكتب يرسل وثائقه (ملفات خاصة)، والمدير وحده يعتمد أو يرفض. الرقم الوطني للمالك مشفّر.
import { bad, notFound, conflict } from '../lib/errors.mjs';
import { encryptField, decryptField } from '../security/crypto.mjs';

const KEYS = ['licImg', 'crImg', 'idImg', 'taxImg'];

export default function register(router, app) {
  const { db, audit, notify } = app;
  const OFFICE = { roles: ['office'], forbidden: 'هذه العملية للمكتب فقط' };
  const ADMIN = { roles: ['admin'], forbidden: 'هذه العملية للمدير فقط' };

  const map = (r, withSecret) => r && ({
    officeId: r.office_id, officeName: r.office_name || undefined, status: r.status, legalName: r.legal_name, ownerName: r.owner_name,
    ownerId: withSecret ? decryptField(r.owner_id_enc) : undefined, licenseNo: r.license_no, registrationNo: r.registration_no, taxNo: r.tax_no,
    issuer: r.issuer, issuedAt: r.issued_at, expiresAt: r.expires_at, files: JSON.parse(r.files_json || '{}'), note: r.note, reviewedAt: r.reviewed_at, createdAt: r.created_at, updatedAt: r.updated_at,
  });

  router.get('/api/office/verification', OFFICE, (ctx) =>
    ctx.ok({ verification: map(db.prepare('SELECT * FROM office_verifications WHERE office_id=?').get(ctx.user.id), true) || null }));

  router.post('/api/office/verification', OFFICE, async (ctx) => {
    const b = await ctx.body();
    const s = (k, n = 120) => String(b[k] ?? '').trim().slice(0, n);
    if (!s('legalName') || !s('licenseNo') || !s('registrationNo') || !s('ownerName')) throw bad('أكمل الاسم القانوني والترخيص والسجل واسم المالك');
    const files = {};
    for (const k of KEYS) {
      const id = b.files?.[k];
      if (!id) continue;
      const f = db.prepare('SELECT id FROM stored_files WHERE id=? AND owner_id=?').get(String(id), ctx.user.id);
      if (!f) throw bad('ملف غير تابع لحسابك: ' + k);
      files[k] = f.id;
    }
    if (!files.licImg || !files.crImg) throw bad('ارفع صورتي الترخيص والسجل التجاري');
    const old = db.prepare('SELECT status FROM office_verifications WHERE office_id=?').get(ctx.user.id);
    if (old?.status === 'approved') throw conflict('المكتب موثّق بالفعل');
    db.prepare(`INSERT INTO office_verifications(office_id,status,legal_name,owner_name,owner_id_enc,license_no,registration_no,tax_no,issuer,issued_at,expires_at,files_json,note,updated_at)
      VALUES(?,'pending',?,?,?,?,?,?,?,?,?,?,'',datetime('now'))
      ON CONFLICT(office_id) DO UPDATE SET status='pending',legal_name=excluded.legal_name,owner_name=excluded.owner_name,owner_id_enc=excluded.owner_id_enc,license_no=excluded.license_no,
      registration_no=excluded.registration_no,tax_no=excluded.tax_no,issuer=excluded.issuer,issued_at=excluded.issued_at,expires_at=excluded.expires_at,files_json=excluded.files_json,note='',updated_at=datetime('now')`)
      .run(ctx.user.id, s('legalName'), s('ownerName'), encryptField(s('ownerId', 60)), s('licenseNo', 80), s('registrationNo', 80), s('taxNo', 80), s('issuer'), s('issuedAt', 20), s('expiresAt', 20), JSON.stringify(files));
    audit(ctx.user, 'office.verification.submit', 'user', ctx.user.id);
    for (const a of db.prepare("SELECT id FROM users WHERE role='admin' AND active=1").all())
      notify(a.id, { kind: 'verification_request', title: 'طلب توثيق مكتب جديد', body: s('legalName'), data: { officeId: ctx.user.id } });
    ctx.ok({ verification: map(db.prepare('SELECT * FROM office_verifications WHERE office_id=?').get(ctx.user.id), true) }, 201);
  });

  router.get('/api/admin/office-verifications', ADMIN, (ctx) => {
    const rows = db.prepare(`SELECT v.*,COALESCE(u.office_name,u.name) AS office_name FROM office_verifications v JOIN users u ON u.id=v.office_id ORDER BY (v.status='pending') DESC, v.updated_at DESC LIMIT 500`).all();
    ctx.ok({ verifications: rows.map((r) => map(r, true)) });
  });

  router.patch('/api/admin/office-verifications/:officeId', ADMIN, async (ctx) => {
    const id = Number(ctx.params.officeId);
    const v = db.prepare('SELECT * FROM office_verifications WHERE office_id=?').get(id);
    if (!v) throw notFound('لا يوجد طلب توثيق لهذا المكتب');
    const b = await ctx.body();
    const status = String(b.status || '');
    if (!['approved', 'rejected', 'pending'].includes(status)) throw bad('حالة غير صحيحة');
    const note = String(b.note || '').trim().slice(0, 500);
    if (status === 'rejected' && !note) throw bad('اكتب سبب الرفض');
    db.prepare("UPDATE office_verifications SET status=?,note=?,reviewed_by=?,reviewed_at=datetime('now'),updated_at=datetime('now') WHERE office_id=?").run(status, note, ctx.user.id, id);
    db.prepare('INSERT INTO office_profiles(office_id,verified) VALUES(?,?) ON CONFLICT(office_id) DO UPDATE SET verified=excluded.verified').run(id, status === 'approved' ? 1 : 0);
    audit(ctx.user, 'office.verification.review', 'user', id, { status });
    notify(id, { kind: 'verification', title: status === 'approved' ? 'تم توثيق مكتبك ✓' : status === 'rejected' ? 'تعذّر توثيق مكتبك' : 'طلب التوثيق قيد المراجعة', body: note, data: { status } });
    ctx.ok({ verification: map(db.prepare('SELECT * FROM office_verifications WHERE office_id=?').get(id), true) });
  });
}
