// الحجوزات: إنشاء من العميل، قراءة حسب الدور، تغيير الحالة من المكتب/المدير، إلغاء من العميل.
import { publicId } from '../security/index.mjs';
import { bad, conflict, forbidden, notFound } from '../lib/errors.mjs';
import { assertTripNotDeparted } from '../lib/trip-time.mjs';
import { STATUS, STATUS_AR, BOOKING_SELECT, mapBooking, insertBooking, changeStatus } from '../services/bookings.mjs';

export default function register(router, app) {
  const { db, audit } = app;

  const loadBooking = (ctx) => {
    const booking = db.prepare('SELECT * FROM bookings WHERE public_id=?').get(ctx.params.id);
    if (!booking) throw notFound('الحجز غير موجود');
    const u = ctx.user;
    const ok = u.role === 'admin' || (u.role === 'customer' && booking.customer_id === u.id) || (u.role === 'office' && booking.office_id === u.id);
    if (!ok) throw forbidden('ليس لديك صلاحية لهذا الحجز');
    return booking;
  };

  router.post('/api/bookings', { roles: ['customer'], forbidden: 'إنشاء الحجز متاح لحساب العميل فقط' }, async (ctx) => {
    const { user } = ctx;
    const b = await ctx.body();
    const service = String(b.serviceType || '').trim(), title = String(b.title || '').trim();
    const pax = Number(b.passengerCount || 1), amount = Number(b.totalAmount || 0);
    if (!service || !title || service.length > 100 || title.length > 250 || !Number.isInteger(pax) || pax < 1 || pax > 30 || !Number.isFinite(amount) || amount < 0 || amount > 1e9)
      throw bad('تفاصيل الحجز غير صحيحة');
    let officeId = null;
    if (b.serviceId) {
      const s = db.prepare('SELECT s.id,s.office_id,s.service_type,s.title,s.details_json FROM office_services s JOIN users u ON u.id=s.office_id WHERE s.id=? AND s.active=1 AND u.active=1').get(Number(b.serviceId));
      if (!s) throw bad('الخدمة المحددة غير متاحة');
      if (service !== s.service_type) throw bad('نوع الخدمة لا يطابق العرض المنشور');
      const official = JSON.parse(s.details_json || '{}');
      const basePrice = official.price == null || official.price === '' ? null : Number(official.price);
      if (basePrice === null || !Number.isFinite(basePrice) || basePrice < 0) throw bad('العرض لا يحتوي سعراً رسمياً صالحاً؛ تواصل مع المكتب');
      assertTripNotDeparted({ serviceType: service, official, details: b.details }, { offsetMin: app.cfg.platformUtcOffsetMin });
      let expected = basePrice * pax;
      if (service === 'air' && b.details?.form && ['ذهاب وإياب', 'ذهاب وعودة'].includes(b.details.form.tt)) expected *= 2;
      if (b.details?.form?.fc === 'حجز كامل' && official.fullVehiclePrice != null) expected = Number(official.fullVehiclePrice);
      if (service === 'cars') expected = basePrice * pax + Number(official.dep || 0);
      if (Math.abs(amount - expected) > 0.01) throw conflict('تغير السعر الرسمي أو حساب الإجمالي؛ حدّث العرض وأعد المحاولة', { expectedAmount: expected, currency: official.currency || b.currency || 'YER' });
      officeId = s.office_id;
    } else if (b.officeId) {
      const office = db.prepare("SELECT id FROM users WHERE id=? AND role='office' AND active=1").get(Number(b.officeId));
      if (!office) throw bad('المكتب المحدد غير صالح');
      const point = db.prepare('SELECT id FROM service_points WHERE id=? AND active=1').get(Number(b.details?.pointId || 0));
      if (service !== 'pass' || amount !== 0 || !point) throw bad('الطلب المباشر مسموح فقط لخدمة الأمانات المسجلة؛ اختر نقطة حقيقية');
      officeId = office.id;
    } else if (b.officeName) throw bad('يجب اختيار عرض منشور أو مكتب ونقطة خدمة مسجلة');

    let booking;
    try {
      booking = insertBooking(app, { publicId: publicId(), customerId: user.id, officeId, serviceType: service, serviceId: b.serviceId ? Number(b.serviceId) : null, title, details: b.details, pax, amount, currency: String(b.currency || 'YER').slice(0, 8), actorId: user.id });
    } catch (e) { if (e.status === 409) throw conflict(e.message); throw e; }
    audit(user, 'booking.create', 'booking', booking.public_id);
    ctx.ok({ booking }, 201);
  });

  router.get('/api/bookings', (ctx) => {
    const { user } = ctx;
    const sel = BOOKING_SELECT;
    const rows =
      user.role === 'customer' ? db.prepare(sel + ' WHERE b.customer_id=? ORDER BY b.created_at DESC').all(user.id)
      : user.role === 'office' ? db.prepare(sel + ' WHERE b.office_id=? ORDER BY b.created_at DESC').all(user.id)
      : db.prepare(sel + ' ORDER BY b.created_at DESC LIMIT 500').all();
    ctx.ok({ bookings: rows.map(mapBooking) });
  });

  router.get('/api/bookings/:id', (ctx) => {
    const booking = loadBooking(ctx);
    ctx.ok({ booking: mapBooking(db.prepare(`${BOOKING_SELECT} WHERE b.id=?`).get(booking.id)) });
  });

  router.get('/api/bookings/:id/events', (ctx) => {
    const booking = loadBooking(ctx);
    ctx.ok({ events: db.prepare('SELECT e.*,u.name AS actor_name FROM booking_events e JOIN users u ON u.id=e.actor_id WHERE e.booking_id=? ORDER BY e.id').all(booking.id) });
  });

  // سجل الطلب الكامل بالعربية: تغييرات الحالة + الحوالات + التقييم ورد المكتب، مرتّبة زمنياً من الخادم
  router.get('/api/bookings/:id/timeline', (ctx) => {
    const booking = loadBooking(ctx), items = [];
    const ar = (s) => STATUS_AR[s] || s;
    for (const e of db.prepare('SELECT e.*,u.name AS actor_name,u.role AS actor_role FROM booking_events e JOIN users u ON u.id=e.actor_id WHERE e.booking_id=? ORDER BY e.id').all(booking.id))
      items.push({ id: 'e' + e.id, at: e.created_at, kind: 'status', text: e.old_status ? `تغيّرت الحالة من «${ar(e.old_status)}» إلى «${ar(e.new_status)}»` : `إنشاء الطلب بحالة «${ar(e.new_status)}»`, note: e.note || '', actor: e.actor_name, actorRole: e.actor_role });
    const PAY = { submitted: 'بانتظار التأكيد', confirmed: 'مؤكدة', rejected: 'مرفوضة' };
    for (const p of db.prepare('SELECT * FROM payment_submissions WHERE booking_id=? ORDER BY id').all(booking.id)) {
      items.push({ id: 'p' + p.id, at: p.created_at, kind: 'payment', text: `تسجيل حوالة بمبلغ ${p.amount} ${p.currency} عبر ${p.method_name}`, note: '', actor: p.sender, actorRole: 'customer' });
      if (p.status !== 'submitted') items.push({ id: 'pr' + p.id, at: p.updated_at, kind: 'payment', text: `الحوالة ${PAY[p.status]}`, note: p.note || '', actor: '', actorRole: 'office' });
    }
    for (const r of db.prepare('SELECT * FROM reviews WHERE booking_id=? ORDER BY id').all(booking.id)) {
      items.push({ id: 'r' + r.id, at: r.created_at, kind: 'review', text: `تقييم العميل: ${r.rating} من 5`, note: r.comment || '', actor: '', actorRole: 'customer' });
      if (r.office_reply) items.push({ id: 'rr' + r.id, at: r.updated_at, kind: 'review', text: 'ردّ المكتب على التقييم', note: r.office_reply, actor: '', actorRole: 'office' });
    }
    items.sort((a, b) => (a.at === b.at ? String(a.id).localeCompare(String(b.id)) : a.at < b.at ? -1 : 1));
    ctx.ok({ timeline: items });
  });

  router.patch('/api/bookings/:id/status', { roles: ['office', 'admin'], forbidden: 'تغيير حالة الحجز متاح للمكتب المسؤول أو المدير' }, async (ctx) => {
    const booking = loadBooking(ctx);
    const b = await ctx.body();
    const status = String(b.status || '');
    if (!STATUS.includes(status)) throw bad('حالة الحجز غير صحيحة');
    if (ctx.user.role === 'office' && booking.office_id !== ctx.user.id) throw forbidden('لا يمكنك إدارة حجوزات مكتب آخر');
    ctx.ok({ booking: changeStatus(app, booking, ctx.user, status, String(b.note || '')) });
  });

  // إلغاء العميل لطلبه قبل اكتماله
  router.post('/api/bookings/:id/cancel', { roles: ['customer'] }, async (ctx) => {
    const booking = loadBooking(ctx);
    if (['completed', 'cancelled', 'rejected'].includes(booking.status)) throw conflict('لا يمكن إلغاء طلب في هذه الحالة');
    const b = await ctx.body();
    ctx.ok({ booking: changeStatus(app, booking, ctx.user, 'cancelled', String(b.note || 'ألغاه العميل')) });
  });
}
