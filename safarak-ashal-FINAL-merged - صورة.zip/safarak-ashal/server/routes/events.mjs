// قناة الأحداث اللحظية (SSE): إشعارات، رسائل، تغيّر حالة حجز، تأكيد دفع.
export default function register(router, app) {
  router.get('/api/events', (ctx) => {
    const { res, user } = ctx;
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-store, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.write(`retry: 4000\nevent: ready\ndata: ${JSON.stringify({ userId: user.id, role: user.role })}\n\n`);
    app.hub.subscribe(user.id, res);
  });
}
