// رموز الجلسات والمعرّفات: التجزئة بـ SHA-256 والمقارنة الآمنة زمنياً.
import crypto from 'node:crypto';

export const hashToken = (token) => crypto.createHash('sha256').update(token).digest('hex');
export const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');
export const timingSafe = (a, b) => {
  try {
    const x = Buffer.from(String(a));
    const y = Buffer.from(String(b));
    return x.length === y.length && crypto.timingSafeEqual(x, y);
  } catch {
    return false;
  }
};
export const uuid = () => crypto.randomUUID();
export const publicId = (prefix = 'SA') => `${prefix}-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
export const newSessionToken = () => crypto.randomBytes(32).toString('base64url');
