// محدّد معدل بسيط في الذاكرة (نافذة 60 ثانية).
export function createLimiter(max = 12, windowMs = 60000) {
  const hits = new Map();
  let lastSweep = Date.now();
  return (key, limit = max) => {
    const now = Date.now();
    if (now - lastSweep > windowMs * 5) {
      for (const [k, v] of hits) if (now > v.until) hits.delete(k);
      lastSweep = now;
    }
    const v = hits.get(key) || { n: 0, until: now + windowMs };
    if (now > v.until) { v.n = 0; v.until = now + windowMs; }
    v.n++;
    hits.set(key, v);
    return v.n > limit;
  };
}
