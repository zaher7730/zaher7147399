// التحقق من محتوى الملفات المرفوعة (التوقيع الحقيقي للملف لا الامتداد المعلن فقط).
export const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
export const FILE_TYPES = new Set([...IMAGE_TYPES, 'application/pdf']);
const eq = (buf, bytes, at = 0) => bytes.every((b, i) => buf[at + i] === b);
export function matchesType(mimeType, bytes) {
  if (mimeType === 'image/jpeg') return eq(bytes, [0xff, 0xd8, 0xff]);
  if (mimeType === 'image/png') return eq(bytes, [137, 80, 78, 71, 13, 10, 26, 10]);
  if (mimeType === 'image/webp') return bytes.subarray(0, 4).toString() === 'RIFF' && bytes.subarray(8, 12).toString() === 'WEBP';
  if (mimeType === 'application/pdf') return bytes.subarray(0, 5).toString() === '%PDF-';
  return false;
}
export const extFor = (m) => ({ 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'application/pdf': 'pdf' })[m] || 'bin';
export function decodeBase64(encoded, maxBytes) {
  const raw = String(encoded || '').replace(/^data:[^,]+,/, '');
  if (!raw || raw.length > Math.ceil((maxBytes * 4) / 3) + 32) return null;
  const bytes = Buffer.from(raw, 'base64');
  return bytes.length && bytes.length <= maxBytes ? bytes : null;
}
export const safeFilename = (name) =>
  String(name || 'document').replace(/\\/g, '/').split('/').pop().replace(/[\x00-\x1f\x7f]/g, '').slice(0, 180) || 'document';
