// ترويسات الأمان: CSP وHSTS ومنع التضمين وتسريب المرجع.
// ملاحظة معروفة: الواجهات الأصلية تستخدم معالجات inline (onclick=...) فنحتاج 'unsafe-inline' للسكربت؛ إزالتها تتطلب إعادة كتابة المعالجات (مرحلة لاحقة).
// المتبقي من التخفيف: لا iframes ولا object ولا workers من مصادر خارجية، ولا تحميل سكربتات من نطاقات خارجية.
export const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'SAMEORIGIN',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(self), microphone=(), geolocation=(self), payment=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
};
export const hsts = (cfg) => (cfg.secureCookie ? { 'Strict-Transport-Security': 'max-age=31536000; includeSubDomains' } : {});
export const buildCsp = (cfg) =>
  [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com data:",
    "img-src 'self' data: blob:",
    "connect-src 'self'",
    "worker-src 'self'",
    "manifest-src 'self'",
    "object-src 'none'",
    "frame-src 'none'",
    "child-src 'none'",
    "frame-ancestors 'self'",
    "base-uri 'self'",
    "form-action 'self'",
    ...(cfg.secureCookie ? ['upgrade-insecure-requests'] : []),
  ].join('; ');
