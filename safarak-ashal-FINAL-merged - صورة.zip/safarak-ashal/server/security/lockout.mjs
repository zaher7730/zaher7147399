// منع التخمين: بعد عدة محاولات فاشلة يُقفل المفتاح (هاتف/IP) مؤقتاً، ويُسجَّل في التدقيق.
const MAX_FAILS = 5;
const LOCK_MS = 15 * 60 * 1000;
const WINDOW_MS = 30 * 60 * 1000;

export function createLockout(db) {
  const get = db.prepare('SELECT * FROM login_attempts WHERE attempt_key=?');
  return {
    /** يرجع الثواني المتبقية للقفل أو 0 */
    lockedFor(key) {
      const r = get.get(key);
      return r && r.locked_until > Date.now() ? Math.ceil((r.locked_until - Date.now()) / 1000) : 0;
    },
    fail(key) {
      const r = get.get(key), now = Date.now();
      const fails = r && now - r.updated_at < WINDOW_MS ? r.fails + 1 : 1;
      const lockedUntil = fails >= MAX_FAILS ? now + LOCK_MS : 0;
      db.prepare('INSERT INTO login_attempts(attempt_key,fails,locked_until,updated_at) VALUES(?,?,?,?) ON CONFLICT(attempt_key) DO UPDATE SET fails=excluded.fails,locked_until=excluded.locked_until,updated_at=excluded.updated_at')
        .run(key, fails, lockedUntil, now);
      return { fails, locked: lockedUntil > 0 };
    },
    clear(key) { db.prepare('DELETE FROM login_attempts WHERE attempt_key=?').run(key); },
    sweep() { db.prepare('DELETE FROM login_attempts WHERE updated_at<?').run(Date.now() - WINDOW_MS - LOCK_MS); },
  };
}
