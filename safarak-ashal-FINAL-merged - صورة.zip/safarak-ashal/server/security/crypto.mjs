// تشفير الحقول الحساسة داخل قاعدة البيانات (رقم الهوية/الجواز...) بـ AES-256-GCM.
// EXTERNAL-SECRET[DATA_ENCRYPTION_KEY]: مفتاح 32 بايت (hex 64 حرفاً) يُولَّد بـ `npm run keys` ويُحفظ في بيئة التشغيل فقط — لا في المستودع ولا في القاعدة.
// فقدان المفتاح = فقدان قراءة هذه الحقول؛ احتفظ بنسخة منه في مدير أسرار.
import crypto from 'node:crypto';
import fs from 'node:fs';

const PREFIX = 'enc:v1:';
let key = null;

export function initCrypto(cfg) {
  const raw = cfg.security.dataKey;
  if (raw) {
    key = /^[0-9a-f]{64}$/i.test(raw) ? Buffer.from(raw, 'hex') : crypto.createHash('sha256').update(raw).digest();
  } else if (!cfg.production) {
    key = crypto.createHash('sha256').update('dev-only-data-key:' + cfg.otp.pepper).digest(); // للتطوير فقط
  } else {
    throw new Error('DATA_ENCRYPTION_KEY is required in production (run: npm run keys)');
  }
}

export function encryptField(plain) {
  if (plain == null || plain === '') return '';
  if (!key) throw new Error('crypto not initialised');
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return PREFIX + Buffer.concat([iv, c.getAuthTag(), enc]).toString('base64url');
}

export function decryptField(stored) {
  if (!stored) return '';
  const s = String(stored);
  if (!s.startsWith(PREFIX)) return s; // قيم قديمة غير مشفّرة
  const buf = Buffer.from(s.slice(PREFIX.length), 'base64url');
  const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12));
  d.setAuthTag(buf.subarray(12, 28));
  return Buffer.concat([d.update(buf.subarray(28)), d.final()]).toString('utf8');
}

/** إخفاء جزئي للعرض: ****1234 */
export const maskField = (plain) => { const s = String(plain || ''); return s.length <= 4 ? '****' : '****' + s.slice(-4); };

// تشفير ملفات المستندات الخاصة على القرص (AES-256-GCM بنفس المفتاح).
// الصيغة: ترويسة 8 بايت + IV (12) + وسم المصادقة (16) + البيانات المشفّرة.
// الملفات القديمة غير المشفّرة (بلا ترويسة) تُقرأ كما هي، ويُعاد تشفيرها عند أول تحديث.
const FILE_MAGIC = Buffer.from('SAFv1ENC', 'utf8');

export function encryptBytes(buf) {
  if (!key) throw new Error('crypto not initialised');
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([c.update(buf), c.final()]);
  return Buffer.concat([FILE_MAGIC, iv, c.getAuthTag(), enc]);
}

export function decryptBytes(buf) {
  if (buf.length < FILE_MAGIC.length || !buf.subarray(0, FILE_MAGIC.length).equals(FILE_MAGIC)) return buf; // ملف قديم بلا تشفير
  if (!key) throw new Error('crypto not initialised');
  if (buf.length < 36) throw new Error('encrypted file is truncated');
  const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(8, 20));
  d.setAuthTag(buf.subarray(20, 36));
  return Buffer.concat([d.update(buf.subarray(36)), d.final()]);
}

/** قراءة ملف خاص من القرص وفكّ تشفيره (يرمي خطأ إن كان المفتاح غير مطابق أو الملف تالفاً). */
export const readPrivateFile = (fp) => decryptBytes(fs.readFileSync(fp));
