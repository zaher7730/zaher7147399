// حماية CSRF: الكوكي SameSite=Strict + فحص الأصل وترويسة Fetch-Metadata لكل طلب يغيّر البيانات.
export function createCsrfCheck(cfg) {
  return function allowed(req) {
    const site = req.headers['sec-fetch-site'];
    if (site === 'cross-site') return false;
    const origin = req.headers.origin;
    if (!origin) return true;
    try { if (new URL(origin).host === req.headers.host) return true; } catch { return false; }
    return cfg.allowedOrigins.includes(origin);
  };
}
