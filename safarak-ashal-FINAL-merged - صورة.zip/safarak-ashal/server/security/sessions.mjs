// الجلسات: رمز عشوائي (يُخزَّن مجزّأً فقط)، حدّ أقصى لعدد الأجهزة، وإمكانية إنهاء جلسة بعينها.
import { hashToken, newSessionToken } from './tokens.mjs';

const MAX_SESSIONS = 8;

export function createSessions(db, cfg) {
  return {
    create(userId, req, ip) {
      const token = newSessionToken();
      const expires = Date.now() + cfg.sessionHours * 3600 * 1000;
      db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at,ip,user_agent,last_seen) VALUES(?,?,?,?,?,?)')
        .run(hashToken(token), userId, expires, String(ip || '').slice(0, 64), String(req.headers['user-agent'] || '').slice(0, 200), Date.now());
      const old = db.prepare('SELECT token_hash FROM sessions WHERE user_id=? ORDER BY created_at DESC, rowid DESC LIMIT -1 OFFSET ?').all(userId, MAX_SESSIONS);
      for (const o of old) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(o.token_hash);
      return token;
    },
    list: (userId, currentToken) => db.prepare('SELECT token_hash,ip,user_agent,created_at,last_seen FROM sessions WHERE user_id=? AND expires_at>? ORDER BY last_seen DESC').all(userId, Date.now())
      .map((s) => ({ id: s.token_hash.slice(0, 16), ip: s.ip, userAgent: s.user_agent, createdAt: s.created_at, lastSeen: s.last_seen, current: !!currentToken && s.token_hash === hashToken(currentToken) })),
    revoke: (userId, idPrefix) => db.prepare('DELETE FROM sessions WHERE user_id=? AND substr(token_hash,1,16)=?').run(userId, String(idPrefix)).changes,
    revokeOthers: (userId, currentToken) => db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash<>?').run(userId, hashToken(currentToken)).changes,
    touch: (token) => db.prepare('UPDATE sessions SET last_seen=? WHERE token_hash=? AND last_seen<?').run(Date.now(), hashToken(token), Date.now() - 60000),
  };
}
