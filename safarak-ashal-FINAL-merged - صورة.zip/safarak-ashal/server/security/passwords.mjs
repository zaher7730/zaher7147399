// كلمات المرور: scrypt مع ملح عشوائي لكل كلمة (لا تُخزَّن كلمة المرور أبداً بشكل مقروء).
import crypto from 'node:crypto';
import { timingSafe } from './tokens.mjs';

export const scrypt = (password, salt) => crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
export const hashPassword = (password) => {
  const salt = crypto.randomBytes(16).toString('hex');
  return `${salt}:${scrypt(password, salt)}`;
};
export const randomSecretHash = () => hashPassword(crypto.randomBytes(48).toString('base64url'));
export const verifyPassword = (password, stored) => {
  const [salt, hash] = String(stored || '').split(':');
  return !!salt && !!hash && timingSafe(scrypt(password, salt), hash);
};
/** سياسة كلمة مرور المدير: 10 أحرف فأكثر وليست رقماً فقط. */
export const strongEnough = (p) => typeof p === 'string' && p.length >= 10 && !/^\d+$/.test(p);
