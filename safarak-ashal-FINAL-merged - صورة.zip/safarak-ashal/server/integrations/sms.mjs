// EXTERNAL-SERVICE[SMS]: رسائل نصية عبر Twilio أو بوابة HTTP عامة (احتياط للواتساب).
// يحتاج: SMS_PROVIDER=twilio + TWILIO_* أو SMS_PROVIDER=http + SMS_HTTP_URL. الخطوات: docs/EXTERNAL_SERVICES_AR.md (القسم 2).
import { HttpError } from '../lib/errors.mjs';

export const smsReady = (cfg) => !!((cfg.sms.provider === 'twilio' && cfg.sms.twilioSid && cfg.sms.twilioToken && (cfg.sms.twilioFrom || cfg.sms.twilioMessagingService)) || (cfg.sms.provider === 'http' && cfg.sms.httpUrl));

export async function viaTwilio(cfg, phone, code) {
  const s = cfg.sms;
  const form = new URLSearchParams({ To: phone, Body: `رمز التحقق الخاص بك في سفرك أسهل: ${code}` });
  if (s.twilioMessagingService) form.set('MessagingServiceSid', s.twilioMessagingService);
  else form.set('From', s.twilioFrom);
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${s.twilioSid}/Messages.json`, {
    method: 'POST',
    headers: { Authorization: 'Basic ' + Buffer.from(`${s.twilioSid}:${s.twilioToken}`).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form,
  });
  if (!response.ok) {
    console.error('Twilio SMS error:', response.status, (await response.text().catch(() => '')).slice(0, 300));
    throw new HttpError(502, 'تعذر إرسال الرمز عبر الرسائل النصية. تحقق من إعدادات المزود.');
  }
}
export async function viaHttpGateway(cfg, phone, code) {
  const s = cfg.sms;
  const response = await fetch(s.httpUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(s.httpToken ? { Authorization: `Bearer ${s.httpToken}` } : {}) },
    body: JSON.stringify({ to: phone, message: `رمز التحقق الخاص بك في سفرك أسهل: ${code}`, code }),
  });
  if (!response.ok) throw new HttpError(502, 'تعذر إرسال الرمز عبر بوابة الرسائل.');
}

