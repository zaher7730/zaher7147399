// EXTERNAL-SERVICE[STRIPE]: بوابة الدفع الإلكتروني. المزوّد الجاهز Stripe (يحتاج مفاتيح من صاحب المشروع).
// الخطوات: docs/EXTERNAL_SERVICES_AR.md (القسم 3). الحوالة اليدوية + السند تعمل دائماً دون هذه البوابة.
// الدفع اليدوي (حوالة + سند) يعمل دائماً دون هذه البوابة.
import crypto from 'node:crypto';
import { HttpError } from '../lib/errors.mjs';

export const paymentsReady = (cfg) => cfg.payments.provider === 'stripe' && !!cfg.payments.stripeSecret;

export async function createCheckout(cfg, { intentId, booking, amount, currency }) {
  if (!paymentsReady(cfg)) throw new HttpError(501, 'الدفع الإلكتروني غير مفعّل بعد؛ استخدم الحوالة المصرفية ورفع السند.');
  const base = cfg.payments.publicBaseUrl || '';
  const form = new URLSearchParams({
    mode: 'payment',
    'line_items[0][quantity]': '1',
    'line_items[0][price_data][currency]': String(currency).toLowerCase(),
    'line_items[0][price_data][unit_amount]': String(Math.round(amount * 100)),
    'line_items[0][price_data][product_data][name]': booking.title,
    success_url: `${base}/apps/customer/?pay=success&booking=${booking.public_id}`,
    cancel_url: `${base}/apps/customer/?pay=cancel&booking=${booking.public_id}`,
    client_reference_id: intentId,
    'metadata[intent_id]': intentId,
    'metadata[booking]': booking.public_id,
  });
  const r = await fetch('https://api.stripe.com/v1/checkout/sessions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${cfg.payments.stripeSecret}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form,
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    console.error('Stripe error', r.status, JSON.stringify(data).slice(0, 300));
    throw new HttpError(502, 'تعذر إنشاء جلسة الدفع.');
  }
  return { providerRef: data.id, url: data.url };
}

/** التحقق من توقيع ويب هوك Stripe (HMAC-SHA256 على `${t}.${payload}`). */
export function verifyStripeSignature(cfg, rawBody, header) {
  const secret = cfg.payments.stripeWebhookSecret;
  if (!secret || !header) return false;
  const parts = Object.fromEntries(String(header).split(',').map((p) => p.split('=')));
  if (!parts.t || !parts.v1) return false;
  if (Math.abs(Date.now() / 1000 - Number(parts.t)) > 300) return false;
  const expected = crypto.createHmac('sha256', secret).update(`${parts.t}.${rawBody}`).digest('hex');
  try { return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(parts.v1)); } catch { return false; }
}
