// EXTERNAL-SERVICE[WHATSAPP]: واتساب Cloud API (Meta) — إرسال رمز التحقق. يحتاج: WHATSAPP_ACCESS_TOKEN, WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_OTP_TEMPLATE.
// خطوات الربط الكاملة: docs/EXTERNAL_SERVICES_AR.md (القسم 1).
import { HttpError } from '../lib/errors.mjs';

export const whatsappReady = (cfg) => !!(cfg.whatsapp.token && cfg.whatsapp.phoneNumberId && cfg.whatsapp.template);

export async function viaWhatsApp(cfg, phone, code) {
  const w = cfg.whatsapp;
  const response = await fetch(`https://graph.facebook.com/${w.graphVersion}/${w.phoneNumberId}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${w.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      to: phone.replace(/[^0-9]/g, ''),
      type: 'template',
      template: { name: w.template, language: { code: w.language }, components: [{ type: 'body', parameters: [{ type: 'text', text: code }] }] },
    }),
  });
  if (!response.ok) {
    const detail = await response.text().catch(() => '');
    console.error('WhatsApp OTP provider error:', response.status, detail.slice(0, 400));
    throw new HttpError(502, 'تعذر إرسال رمز التحقق عبر واتساب. تحقق من إعدادات مزود الرسائل.');
  }
}
