// EXTERNAL-SERVICE[WEB_PUSH]: إشعارات الدفع إلى المتصفح/الجوال (Web Push + VAPID). لا تحتاج حساباً خارجياً؛ فقط مفاتيح تولّدها بـ `npm run keys`.
// يحتاج: VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY (PKCS8 base64url), VAPID_SUBJECT (mailto:you@example.com).
// نرسل «نبضة» بلا حمولة؛ عامل الخدمة (shared/pwa/sw.js) يجلب نص الإشعار من /api/notifications بعد وصولها.
import crypto from 'node:crypto';

export const pushReady = (cfg) => !!(cfg.push.publicKey && cfg.push.privateKey && cfg.push.subject);

const b64u = (buf) => Buffer.from(buf).toString('base64url');
function vapidJwt(cfg, audience) {
  const header = b64u(JSON.stringify({ typ: 'JWT', alg: 'ES256' }));
  const body = b64u(JSON.stringify({ aud: audience, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: cfg.push.subject }));
  const key = crypto.createPrivateKey({ key: Buffer.from(cfg.push.privateKey, 'base64url'), format: 'der', type: 'pkcs8' });
  const sig = crypto.sign('sha256', Buffer.from(`${header}.${body}`), { key, dsaEncoding: 'ieee-p1363' });
  return `${header}.${body}.${b64u(sig)}`;
}

export function generateVapidKeys() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const pub = publicKey.export({ format: 'der', type: 'spki' }).subarray(-65); // النقطة غير المضغوطة 65 بايت
  return { publicKey: b64u(pub), privateKey: b64u(privateKey.export({ format: 'der', type: 'pkcs8' })) };
}

/** يرسل نبضة لكل اشتراكات المستخدم ويحذف المنتهي منها. لا يرمي أخطاء (best effort). */
export async function pushToUser(app, userId) {
  const { cfg, db } = app;
  if (!pushReady(cfg)) return 0;
  const subs = db.prepare('SELECT id,endpoint FROM push_subscriptions WHERE user_id=?').all(userId);
  let sent = 0;
  await Promise.all(subs.map(async (s) => {
    try {
      const url = new URL(s.endpoint);
      const jwt = vapidJwt(cfg, url.origin);
      const r = await fetch(s.endpoint, { method: 'POST', headers: { Authorization: `vapid t=${jwt}, k=${cfg.push.publicKey}`, TTL: '3600', Urgency: 'normal', 'Content-Length': '0' }, signal: AbortSignal.timeout(8000) });
      if (r.status === 404 || r.status === 410) db.prepare('DELETE FROM push_subscriptions WHERE id=?').run(s.id);
      else if (r.ok) sent++;
    } catch { /* الشبكة غير متاحة: نتجاهل */ }
  }));
  return sent;
}
