// موزّع رموز التحقق: يختار القناة المتاحة (واتساب ثم SMS) وفي التطوير يطبع الرمز في السجل فقط.
import { HttpError } from '../lib/errors.mjs';
import { whatsappReady, viaWhatsApp } from './whatsapp.mjs';
import { smsReady, viaTwilio, viaHttpGateway } from './sms.mjs';

export function otpChannels(cfg) {
  return { whatsapp: whatsappReady(cfg), sms: smsReady(cfg), dev: !cfg.production };
}

export async function deliverOtp(cfg, phone, code) {
  const want = cfg.otp.channel;
  if ((want === 'auto' || want === 'whatsapp') && whatsappReady(cfg)) return viaWhatsApp(cfg, phone, code);
  if ((want === 'auto' || want === 'sms') && smsReady(cfg)) return cfg.sms.provider === 'twilio' ? viaTwilio(cfg, phone, code) : viaHttpGateway(cfg, phone, code);
  // EXTERNAL-SERVICE[OTP]: في الإنتاج لا يعمل الدخول قبل ربط واتساب أو SMS.
  if (cfg.production) throw new HttpError(503, 'لم يتم إعداد مزود إرسال رمز التحقق. أضف إعدادات WhatsApp Cloud API أو مزود SMS قبل تفعيل الدخول في الإنتاج.');
  console.info(`[OTP-DEV] phone=${phone} code=${code} expires_in=300s`);
}
