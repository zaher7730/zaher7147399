// سجل الخدمات الخارجية: يُظهر للمدير (ولملف الشرح) ما هو مربوط وما هو ناقص، دون كشف أي سرّ.
import { whatsappReady } from './whatsapp.mjs';
import { smsReady } from './sms.mjs';
import { paymentsReady } from './stripe.mjs';
import { pushReady } from './push.mjs';

export function integrationStatus(cfg) {
  return [
    { id: 'whatsapp', name: 'واتساب Cloud API', purpose: 'إرسال رمز الدخول (OTP) وإشعارات الحجز', required: 'production', ready: whatsappReady(cfg), env: ['WHATSAPP_ACCESS_TOKEN', 'WHATSAPP_PHONE_NUMBER_ID', 'WHATSAPP_OTP_TEMPLATE'], guide: 'EXTERNAL_SERVICES_AR.md#1' },
    { id: 'sms', name: 'رسائل SMS (Twilio / بوابة HTTP)', purpose: 'بديل أو احتياط لرمز الدخول', required: 'optional', ready: !!smsReady(cfg), env: ['SMS_PROVIDER', 'TWILIO_ACCOUNT_SID', 'TWILIO_AUTH_TOKEN', 'TWILIO_FROM'], guide: 'EXTERNAL_SERVICES_AR.md#2' },
    { id: 'stripe', name: 'الدفع الإلكتروني (Stripe)', purpose: 'دفع بالبطاقة؛ الحوالة اليدوية تعمل دونه', required: 'optional', ready: paymentsReady(cfg), env: ['PAYMENT_PROVIDER', 'STRIPE_SECRET_KEY', 'STRIPE_WEBHOOK_SECRET', 'PUBLIC_BASE_URL'], guide: 'EXTERNAL_SERVICES_AR.md#3' },
    { id: 'web-push', name: 'إشعارات الدفع (Web Push)', purpose: 'تنبيه الجوال/المتصفح حتى والتطبيق مغلق', required: 'optional', ready: pushReady(cfg), env: ['VAPID_PUBLIC_KEY', 'VAPID_PRIVATE_KEY', 'VAPID_SUBJECT'], guide: 'EXTERNAL_SERVICES_AR.md#4' },
    { id: 'data-key', name: 'مفتاح تشفير الحقول الحساسة', purpose: 'تشفير أرقام الهويات في القاعدة', required: 'production', ready: !!cfg.security.dataKey, env: ['DATA_ENCRYPTION_KEY'], guide: 'EXTERNAL_SERVICES_AR.md#5' },
    { id: 'https', name: 'نطاق + شهادة HTTPS', purpose: 'تشفير الاتصال (إلزامي للإنتاج)', required: 'production', ready: !!cfg.secureCookie && !!cfg.payments.publicBaseUrl, env: ['COOKIE_SECURE', 'PUBLIC_BASE_URL', 'TRUST_PROXY'], guide: 'EXTERNAL_SERVICES_AR.md#6' },
    { id: 'offsite-backup', name: 'نسخ احتياطي خارج الخادم', purpose: 'حماية البيانات من فقدان القرص', required: 'production', ready: !!cfg.backupOffsiteHint, env: ['BACKUP_OFFSITE_NOTE'], guide: 'EXTERNAL_SERVICES_AR.md#7' },
  ];
}
