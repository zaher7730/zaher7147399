// نقطة تشغيل الخادم: node server/index.mjs
import { loadConfig } from './config/index.mjs';
import { createApp } from './app.mjs';

const cfg = loadConfig();
const instance = createApp(cfg);
await instance.listen();
console.log(`Safarak Ashal v${cfg.version} running: http://${cfg.host}:${cfg.port}\nDatabase: ${cfg.dbPath}`);

let closing = false;
for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, async () => {
    if (closing) return;
    closing = true;
    console.log(`${sig} received, shutting down...`);
    await instance.close();
    process.exit(0);
  });
}
