/* عميل الواجهة البرمجية المشترك: يغلّف كل نقاط الخادم. لا يضيف أي عنصر مرئي. */
(() => {
  'use strict';
  const request = async (url, options = {}) => {
    const hasBody = options.body !== undefined && options.body !== null;
    const headers = { ...(hasBody && typeof options.body === 'string' ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) };
    let response;
    try {
      response = await fetch(url, { credentials: 'same-origin', cache: 'no-store', ...options, headers });
    } catch (e) {
      throw Object.assign(new Error('تعذّر الاتصال بالخادم؛ تحقق من الإنترنت'), { status: 0, offline: true });
    }
    const data = await response.json().catch(() => ({ ok: false, error: 'استجابة غير مفهومة من الخادم' }));
    if (!response.ok) {
      const err = Object.assign(new Error(data.error || `HTTP ${response.status}`), { status: response.status, data });
      if (response.status === 401 && typeof window.SA_ON_UNAUTHORIZED === 'function') window.SA_ON_UNAUTHORIZED(err, url);
      throw err;
    }
    return data;
  };
  const json = (body) => JSON.stringify(body ?? {});
  const id = encodeURIComponent;
  const get = (url) => request(url);
  const send = (method, url, body) => request(url, { method, body: json(body) });
  const qs = (o) => { const p = new URLSearchParams(); Object.entries(o || {}).forEach(([k, v]) => v !== undefined && v !== null && v !== '' && p.set(k, v)); const s = p.toString(); return s ? '?' + s : ''; };

  const api = {
    request, get, send,
    // ---- الحساب والدخول ----
    health: () => get('/api/health'),
    me: () => get('/api/auth/me'),
    requestOtp: (p) => send('POST', '/api/auth/request-otp', p),
    verifyOtp: (p) => send('POST', '/api/auth/verify-otp', p),
    login: (p) => send('POST', '/api/auth/login', p),
    logout: () => send('POST', '/api/auth/logout', {}),
    account: () => get('/api/me'),
    updateAccount: (p) => send('PATCH', '/api/me', p),
    saveCustomerProfile: (p) => send('PUT', '/api/me/profile', p),
    exportMyData: () => get('/api/me/export'),
    requestAccountDeletion: () => send('POST', '/api/me/delete-request', {}),
    // ---- بيانات عامة ----
    services: () => get('/api/public/services'),
    offices: () => get('/api/public/offices'),
    officeReviews: (officeId) => get(`/api/public/offices/${id(officeId)}/reviews`),
    points: () => get('/api/public/points'),
    publicConfig: () => get('/api/public/config'),
    publicDocs: (collections) => get('/api/public/docs' + qs({ collections: [].concat(collections || []).join(',') })),
    paymentMethods: (officeId) => get('/api/public/payment-methods' + qs({ officeId })),
    paymentsConfig: () => get('/api/payments/config'),
    applyOffice: (p) => send('POST', '/api/public/office-applications', p),
    // ---- الحجوزات ----
    bookings: () => get('/api/bookings'),
    booking: (bid) => get(`/api/bookings/${id(bid)}`),
    bookingEvents: (bid) => get(`/api/bookings/${id(bid)}/events`),
    bookingPayments: (bid) => get(`/api/bookings/${id(bid)}/payments`),
    createBooking: (p) => send('POST', '/api/bookings', p),
    cancelBooking: (bid, note) => send('POST', `/api/bookings/${id(bid)}/cancel`, { note }),
    updateBookingStatus: (bid, p) => send('PATCH', `/api/bookings/${id(bid)}/status`, p),
    checkout: (bid) => send('POST', `/api/bookings/${id(bid)}/checkout`, {}),
    // ---- المدفوعات ----
    submitPayment: (bid, p) => send('POST', `/api/bookings/${id(bid)}/payment`, p),
    officePayments: () => get('/api/office/payments'),
    createOfficePayment: (p) => send('POST', '/api/office/payments/manual', p),
    reviewOfficePayment: (pid, p) => send('PATCH', `/api/office/payments/${id(pid)}`, p),
    officePaymentMethods: () => get('/api/office/payment-methods'),
    syncOfficePaymentMethods: (methods) => send('PUT', '/api/office/payment-methods/sync', { methods }),
    // ---- المكتب ----
    officeServices: () => get('/api/office/services'),
    publishService: (p) => send('POST', '/api/office/services', p),
    syncOfficeServices: (services) => send('PUT', '/api/office/services/sync', { services }),
    deleteOfficeService: (sid) => request(`/api/office/services/${id(sid)}`, { method: 'DELETE' }),
    createOfficeBooking: (p) => send('POST', '/api/office/bookings', p),
    officeBookings: (status) => get('/api/office/bookings' + qs({ status })),
    officeSummary: () => get('/api/office/summary'),
    officeDashboard: () => get('/api/office/dashboard'),
    officeCustomers: () => get('/api/office/customers'),
    officeInvoices: () => get('/api/office/invoices'),
    officeProfile: () => get('/api/office/profile'),
    saveOfficeProfile: (p) => send('PUT', '/api/office/profile', p),
    officeVerification: () => get('/api/office/verification'),
    submitOfficeVerification: (p) => send('POST', '/api/office/verification', p),
    adminOfficeVerifications: () => get('/api/admin/office-verifications'),
    reviewOfficeVerification: (oid, p) => send('PATCH', `/api/admin/office-verifications/${id(oid)}`, p),
    uploadOfferAsset: (p) => send('POST', '/api/office/assets', p),
    // ---- الباقات ----
    packages: () => get('/api/packages'),
    requestPackage: (p) => send('POST', '/api/office/package-purchases', p),
    officePackagePurchases: () => get('/api/office/package-purchases'),
    // ---- المحادثات ----
    conversations: () => get('/api/conversations'),
    openConversation: (p) => send('POST', '/api/conversations', p),
    messages: (cid, after) => get(`/api/conversations/${id(cid)}/messages` + qs({ after })),
    sendMessage: (cid, p) => send('POST', `/api/conversations/${id(cid)}/messages`, p),
    markRead: (cid) => send('POST', `/api/conversations/${id(cid)}/read`, {}),
    unreadMessages: () => get('/api/messages/unread-count'),
    // ---- تقييمات ومفضلة وإشعارات ----
    reviews: () => get('/api/reviews'),
    createReview: (p) => send('POST', '/api/reviews', p),
    replyReview: (rid, reply) => send('POST', `/api/reviews/${id(rid)}/reply`, { reply }),
    favorites: () => get('/api/favorites'),
    setFavorite: (kind, fid, on = true) => send('PUT', '/api/favorites', { kind, id: fid, on }),
    notifications: (limit) => get('/api/notifications' + qs({ limit })),
    markNotificationsRead: (ids) => send('POST', '/api/notifications/read', ids ? { ids } : {}),
    deleteNotification: (nid) => request(`/api/notifications/${id(nid)}`, { method: 'DELETE' }),
    pushSubscribe: (p) => send('POST', '/api/push/subscribe', p),
    // ---- حالة الواجهة المحفوظة على الخادم ----
    getState: (ns) => get(`/api/state/${id(ns)}`),
    putState: (ns, value, version) => send('PUT', `/api/state/${id(ns)}`, { value, version }),
    // ---- دعم ----
    tickets: () => get('/api/tickets'),
    ticket: (tid) => get(`/api/tickets/${id(tid)}`),
    createTicket: (p) => send('POST', '/api/tickets', p),
    ticketMessage: (tid, p) => send('POST', `/api/tickets/${id(tid)}/messages`, p),
    // ---- الملفات ----
    files: () => get('/api/files'),
    uploadFile: (p) => send('POST', '/api/files', p),
    deleteFile: (fid) => request(`/api/files/${id(fid)}`, { method: 'DELETE' }),
    fileUrl: (fid, inline) => `/api/files/${id(fid)}${inline ? '?inline=1' : ''}`,
    // ---- الإدارة ----
    adminStats: () => get('/api/admin/stats'),
    adminIntegrations: () => get('/api/admin/integrations'),
    adminBookings: (p) => get('/api/admin/bookings' + qs(p)),
    adminPayments: () => get('/api/admin/payments'),
    adminInvoices: () => get('/api/admin/invoices'),
    adminReviews: () => get('/api/admin/reviews'),
  adminConversations: () => get('/api/admin/conversations'),
  adminConversationUpdate: (cid, p) => send('PATCH', `/api/admin/conversations/${id(cid)}`, p),
    moderateReview: (rid, status) => send('PATCH', `/api/admin/reviews/${id(rid)}`, { status }),
    adminAudit: (p) => get('/api/admin/audit' + qs(p)),
    adminBroadcast: (p) => send('POST', '/api/admin/broadcast', p),
    adminBackup: () => send('POST', '/api/admin/backup', {}),
    adminDocs: (collection) => get('/api/admin/docs' + qs({ collection })),
    putAdminDoc: (collection, did, data, isPublic) => send('PUT', `/api/admin/docs/${id(collection)}/${id(did)}`, { data, public: !!isPublic }),
    deleteAdminDoc: (collection, did) => request(`/api/admin/docs/${id(collection)}/${id(did)}`, { method: 'DELETE' }),
    adminOffices: (p) => send('POST', '/api/admin/offices', p),
    adminOfficeApplications: (status) => get('/api/admin/office-applications' + qs({ status })),
    reviewOfficeApplication: (aid, p) => send('PATCH', `/api/admin/office-applications/${id(aid)}`, p),
    adminUsers: (role) => get('/api/admin/users' + qs({ role })),
    updateAdminUser: (uid, p) => send('PATCH', `/api/admin/users/${id(uid)}`, p),
    adminPaymentMethods: () => get('/api/admin/payment-methods'),
    createAdminPaymentMethod: (p) => send('POST', '/api/admin/payment-methods', p),
    updateAdminPaymentMethod: (pid, p) => send('PATCH', `/api/admin/payment-methods/${id(pid)}`, p),
    deleteAdminPaymentMethod: (pid) => request(`/api/admin/payment-methods/${id(pid)}`, { method: 'DELETE' }),
    adminSettings: () => get('/api/admin/settings'),
    saveAdminSettings: (settings) => send('PUT', '/api/admin/settings', { settings }),
    adminPoints: () => get('/api/admin/points'),
    createAdminPoint: (p) => send('POST', '/api/admin/points', p),
    updateAdminPoint: (pid, p) => send('PATCH', `/api/admin/points/${id(pid)}`, p),
    deleteAdminPoint: (pid) => request(`/api/admin/points/${id(pid)}`, { method: 'DELETE' }),
    adminServices: () => get('/api/admin/services'),
    createAdminService: (p) => send('POST', '/api/admin/services', p),
    updateAdminService: (sid, p) => send('PATCH', `/api/admin/services/${id(sid)}`, p),
    adminPackages: () => get('/api/packages'),
    createAdminPackage: (p) => send('POST', '/api/admin/packages', p),
    updateAdminPackage: (pid, p) => send('PATCH', `/api/admin/packages/${id(pid)}`, p),
    deleteAdminPackage: (pid) => request(`/api/admin/packages/${id(pid)}`, { method: 'DELETE' }),
    adminPackagePurchases: () => get('/api/admin/package-purchases'),
    reviewPackagePurchase: (pid, p) => send('PATCH', `/api/admin/package-purchases/${id(pid)}`, p),
    adminQuotas: () => get('/api/admin/quotas'),
    setQuota: (p) => send('PUT', '/api/admin/quotas', p),
    adminTicketUpdate: (tid, p) => send('PATCH', `/api/admin/tickets/${id(tid)}`, p),
    adminBackups: () => get('/api/admin/backups'),
    // ---- أجهزتي (الجلسات النشطة) ----
    sessions: () => get('/api/auth/sessions'),
    revokeSession: (sid) => request(`/api/auth/sessions/${id(sid)}`, { method: 'DELETE' }),
    revokeOtherSessions: () => send('POST', '/api/auth/sessions/revoke-others', {}),
    // ---- سجل الطلب الكامل من الخادم ----
    bookingTimeline: (bid) => get(`/api/bookings/${id(bid)}/timeline`),
  };
  window.SA_API = Object.freeze(api);
})();
