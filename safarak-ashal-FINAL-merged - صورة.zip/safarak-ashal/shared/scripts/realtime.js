/* قناة الأحداث اللحظية (SSE): SA_RT.on('notification'|'message'|'booking'|'read'|'ticket', fn) */
(() => {
  'use strict';
  const handlers = {};
  let es = null, stopped = true, retry = 0, timer = null;
  const emit = (type, data) => (handlers[type] || []).forEach((fn) => { try { fn(data); } catch (e) { console.warn('SA_RT handler', e); } });
  function connect() {
    if (stopped || !window.EventSource) return;
    es = new EventSource('/api/events');
    ['ready', 'notification', 'message', 'booking', 'read', 'ticket'].forEach((t) =>
      es.addEventListener(t, (e) => { retry = 0; let d = {}; try { d = JSON.parse(e.data || '{}'); } catch { /* ignore */ } emit(t, d); }));
    es.onerror = () => {
      if (es) es.close();
      es = null;
      if (stopped) return;
      retry = Math.min(retry + 1, 6);
      timer = setTimeout(connect, 1000 * 2 ** retry); // تراجع أسّي حتى ~64ث
    };
  }
  window.SA_RT = {
    on(type, fn) { (handlers[type] ||= []).push(fn); return () => { handlers[type] = handlers[type].filter((f) => f !== fn); }; },
    start() { if (!stopped) return; stopped = false; connect(); },
    stop() { stopped = true; clearTimeout(timer); if (es) es.close(); es = null; },
  };
  // عند عودة الاتصال بالإنترنت أو ظهور التبويب نعيد الاتصال فوراً إن انقطع
  const wake = () => { if (!stopped && !es) { clearTimeout(timer); connect(); } };
  addEventListener('online', wake);
  document.addEventListener('visibilitychange', () => document.visibilityState === 'visible' && wake());
})();
