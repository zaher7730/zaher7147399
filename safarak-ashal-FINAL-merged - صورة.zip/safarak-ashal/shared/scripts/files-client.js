/* رفع الملفات والصور: تصغير الصور في المتصفح ثم إرسالها base64 إلى الخادم. */
(() => {
  'use strict';
  const readAsDataURL = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onerror = () => rej(new Error('تعذّرت قراءة الملف')); r.onload = () => res(r.result); r.readAsDataURL(f); });
  const loadImage = (src) => new Promise((res, rej) => { const im = new Image(); im.onerror = () => rej(new Error('صورة غير صالحة')); im.onload = () => res(im); im.src = src; });
  /** يحوّل ملفاً إلى {filename,mimeType,base64}؛ الصور تُصغَّر إلى maxDim وتُضغط JPEG. */
  async function prepare(file, { maxDim = 1800, quality = 0.88 } = {}) {
    const url = await readAsDataURL(file);
    if (/^image\/(jpeg|png|webp)$/.test(file.type) && file.size > 350000) {
      try {
        const im = await loadImage(url);
        const k = Math.min(1, maxDim / Math.max(im.width, im.height));
        const c = document.createElement('canvas');
        c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        const out = c.toDataURL('image/jpeg', quality);
        return { filename: file.name.replace(/\.\w+$/, '') + '.jpg', mimeType: 'image/jpeg', base64: out.split(',')[1], dataUrl: out };
      } catch { /* نرسل الأصل */ }
    }
    return { filename: file.name, mimeType: file.type || 'application/octet-stream', base64: url.split(',')[1], dataUrl: url };
  }
  window.SA_FILES = {
    prepare,
    async upload(file, opts = {}) {
      const p = await prepare(file, opts);
      const r = await window.SA_API.uploadFile({ filename: p.filename, mimeType: p.mimeType, base64: p.base64, bookingId: opts.bookingId });
      return { ...r.file, dataUrl: p.dataUrl };
    },
    async uploadOfferAsset(file) {
      const p = await prepare(file, { maxDim: 1600 });
      const r = await window.SA_API.uploadOfferAsset({ filename: p.filename, mimeType: p.mimeType, base64: p.base64 });
      return { ...r.asset, dataUrl: p.dataUrl };
    },
    readAsDataURL,
  };
})();
