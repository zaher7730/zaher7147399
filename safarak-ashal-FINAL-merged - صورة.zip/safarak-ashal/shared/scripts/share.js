/* مشاركة ونسخ وحفظ: SA_SHARE.share({title,text,url}) / copy(text) / download(filename, text|blob) */
(() => {
  'use strict';
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); return true; } catch { /* احتياط */ }
    const t = document.createElement('textarea');
    t.value = text; t.style.cssText = 'position:fixed;opacity:0'; document.body.append(t); t.select();
    let ok = false; try { ok = document.execCommand('copy'); } catch { /* ignore */ }
    t.remove(); return ok;
  }
  async function share({ title, text, url }) {
    const data = { title, text, url: url || location.href };
    if (navigator.share) { try { await navigator.share(data); return 'shared'; } catch (e) { if (e && e.name === 'AbortError') return 'cancelled'; } }
    return (await copy([text, data.url].filter(Boolean).join('\n'))) ? 'copied' : 'failed';
  }
  function download(filename, content, type = 'text/plain;charset=utf-8') {
    const blob = content instanceof Blob ? content : new Blob([content], { type });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = filename; document.body.append(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }
  window.SA_SHARE = { share, copy, download };
})();
