/* تسجيل عامل الخدمة /sw.js. يعمل فقط في سياق آمن (HTTPS أو localhost)، وفشله لا يؤثر على عمل التطبيق. */
(() => {
  'use strict';
  if (!('serviceWorker' in navigator) || !window.isSecureContext) return;
  // نتذكر أي تطبيق فتح المستخدم (عميل/مكتب) كي يفتح الإشعار التطبيق الصحيح
  const app = location.pathname.indexOf('/apps/office') === 0 ? 'office' : 'customer';
  if ('caches' in window) caches.open('safarak-meta').then((c) => c.put('/__last_app', new Response(app))).catch(() => {});
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js', { scope: '/' })
      .catch((e) => console.warn('تعذّر تسجيل عامل الخدمة:', e && e.message));
  });
})();
