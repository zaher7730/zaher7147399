/* عامل الخدمة لسفرك أسهل (يُقدَّم من الجذر /sw.js بنطاق كامل /).
   1) التخزين المؤقت: الواجهات (apps/customer و apps/office و shared) تُجلب من الشبكة أولاً، وتُحفظ نسخة منها،
      فإن انقطع الاتصال تُعرض آخر نسخة محفوظة. لا يخزّن أي استجابة فيها no-store.
   2) لا يتدخل أبداً في: /api/ (الجلسات والبيانات وSSE)، ولوحة الإدارة /apps/admin، والمعاينة /preview، والطلبات غير GET، والنطاقات الخارجية.
   3) إشعارات الجهاز: الخادم يرسل «نبضة» بلا نص، ويعرض العامل عنواناً عاماً لا يكشف المحتوى. ويجدد الاشتراك عند pushsubscriptionchange.
*/
const CACHE = 'safarak-shell-v1';
const SKIP_PREFIXES = ['/api/', '/apps/admin', '/preview/', '/sw.js'];
const CACHE_PREFIXES = ['/apps/customer/', '/apps/office/', '/shared/'];
const ICON = '/shared/assets/brand/icon-192.png';
// آخر تطبيق فتحه المستخدم على هذا الجهاز (تكتبه pwa.js) ليفتح الإشعار تطبيقه: العميل أو المكتب
const APP_MEMORY = 'safarak-meta';
const LAST_APP_KEY = '/__last_app';
async function lastAppPath() {
  try {
    const hit = await (await caches.open(APP_MEMORY)).match(LAST_APP_KEY);
    return (hit && (await hit.text()).trim()) === 'office' ? '/apps/office/' : '/apps/customer/';
  } catch { return '/apps/customer/'; }
}

function isCacheable(url) {
  return url.pathname === '/' || CACHE_PREFIXES.some((p) => url.pathname.startsWith(p));
}

self.addEventListener('install', (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k.startsWith('safarak-shell-') && k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

async function networkFirst(request, url) {
  const cache = await caches.open(CACHE);
  try {
    const response = await fetch(request);
    const cacheControl = response.headers.get('Cache-Control') || '';
    const storable = response.ok && !['opaque', 'opaqueredirect', 'error'].includes(response.type);
    if (storable && isCacheable(url) && !cacheControl.includes('no-store')) {
      // ينتظر الحفظ قبل الرد حتى لا يُوقَف العامل قبل اكتمال الكتابة
      await cache.put(request, response.clone()).catch(() => {});
    }
    return response;
  } catch (err) {
    const cached = await cache.match(request);
    if (cached) return cached;
    return new Response('لا يوجد اتصال بالإنترنت، وهذه الصفحة غير محفوظة على الجهاز بعد.', {
      status: 503,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (SKIP_PREFIXES.some((p) => url.pathname.startsWith(p))) return;
  if (!isCacheable(url) && request.mode !== 'navigate') return;
  event.respondWith(networkFirst(request, url));
});

// الخصوصية: نص الإشعار لا يُعرض على شاشة القفل ولا يُجلب من الشبكة؛ يظهر عنوان عام فقط،
// وعند فتح التطبيق تُعرض الإشعارات الحقيقية من داخل التطبيق بعد تسجيل الدخول.
self.addEventListener('push', (event) => {
  event.waitUntil(self.registration.showNotification('سفرك أسهل', {
    body: 'لديك تحديث جديد، افتح التطبيق لعرضه.',
    tag: 'safarak-push',
    icon: ICON,
    badge: ICON,
    lang: 'ar',
    dir: 'rtl',
  }));
});

// تجديد الاشتراك عندما يلغيه المتصفح أو ينتهي (يحدث دورياً على الجوال): نعيد الاشتراك بالمفتاح العام
// ونرسل الاشتراك الجديد للخادم، وإلا تتوقف الإشعارات بصمت.
function b64uToBytes(value) {
  const pad = '='.repeat((4 - (value.length % 4)) % 4);
  const base64 = (value + pad).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i += 1) out[i] = raw.charCodeAt(i);
  return out;
}

self.addEventListener('pushsubscriptionchange', (event) => {
  event.waitUntil((async () => {
    const keyResponse = await fetch('/api/push/public-key', { credentials: 'same-origin', cache: 'no-store' });
    if (!keyResponse.ok) return;
    const { publicKey } = await keyResponse.json();
    if (!publicKey) return;
    const subscription = await self.registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: b64uToBytes(publicKey),
    });
    await fetch('/api/push/subscribe', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(subscription.toJSON()),
    });
  })().catch(() => { /* لا جلسة أو لا اتصال: يُعاد المحاولة مع فتح التطبيق */ }));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil((async () => {
    const target = new URL((event.notification.data && event.notification.data.url) || (await lastAppPath()), self.location.origin).href;
    const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of windows) {
      if (new URL(client.url).origin === self.location.origin && 'focus' in client) return client.focus();
    }
    return self.clients.openWindow(target);
  })());
});
