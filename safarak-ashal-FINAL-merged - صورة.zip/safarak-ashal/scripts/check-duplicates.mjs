// يفحص التكرار والكود الميت في الواجهات (كلها سكربتات كلاسيكية بنطاق عام مشترك):
//  1) اسم دالة/ثابت معرَّف على مستوى الملف أكثر من مرة داخل التطبيق الواحد (يُخفي أحدهما الآخر ويُفسد المشروع بصمت) → فشل
//  2) ملفان (js/css/mjs) بمحتوى متطابق تماماً → فشل
//  3) دالة معرَّفة ولا يشير إليها أي ملف أو HTML (كود ميت) → فشل، إلا ما في قائمة الاستثناءات المعللة
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const walk = (d, out = []) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) { if (!['node_modules', '.git', 'originals', 'preview', 'dist', 'storage', 'backups'].includes(e.name)) walk(p, out); } else out.push(p); } return out; };
const rel = (p) => path.relative(root, p).split(path.sep).join('/');
let failed = false;
const fail = (m) => { failed = true; console.error('✖ ' + m); };

// ---- 1) تعريفات مكررة داخل كل تطبيق (مع shared لأن الجميع يحمّله) ----
const DECL = /^(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)\s*\(|^(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=/;
function declsOf(files) {
  const map = new Map();
  for (const f of files) {
    fs.readFileSync(f, 'utf8').split('\n').forEach((line, i) => {
      const m = DECL.exec(line); if (!m) return;
      const n = m[1] || m[2];
      (map.get(n) || map.set(n, []).get(n)).push(`${rel(f)}:${i + 1}`);
    });
  }
  return map;
}
const sharedJs = walk(path.join(root, 'shared')).filter((f) => f.endsWith('.js'));
const reportedAll = [];
for (const app of ['customer', 'office', 'admin']) {
  const appJs = walk(path.join(root, 'apps', app)).filter((f) => f.endsWith('.js'));
  const decls = declsOf([...sharedJs, ...appJs]);
  for (const [n, where] of decls) if (where.length > 1) fail(`[${app}] "${n}" معرَّف ${where.length} مرات: ${where.join(' | ')}`);
  reportedAll.push([app, appJs, decls]);
}

// ---- 2) ملفات متطابقة ----
const seen = new Map();
for (const f of walk(root).filter((f) => /\.(js|mjs|css)$/.test(f))) {
  const buf = fs.readFileSync(f); if (buf.length < 200) continue;
  const h = crypto.createHash('sha256').update(buf).digest('hex');
  if (seen.has(h)) fail(`ملفان متطابقان: ${seen.get(h)} و ${rel(f)}`); else seen.set(h, rel(f));
}

// ---- 3) كود ميت: دالة لا يستدعيها أحد ----
const ALLOW = new Set(JSON.parse(fs.readFileSync(path.join(root, 'scripts', 'dead-code-allowlist.json'), 'utf8')).names);
const corpus = (files) => files.map((f) => fs.readFileSync(f, 'utf8')).join('\n');
for (const [app, appJs, decls] of reportedAll) {
  const text = corpus([...sharedJs, ...appJs, path.join(root, 'apps', app, 'index.html'), path.join(root, 'server', 'app.mjs')]);
  for (const [n, where] of decls) {
    if (!where[0].includes('/scripts/') && !where[0].startsWith('shared/')) continue;
    if (!/^function|^async function/.test(fs.readFileSync(path.join(root, where[0].split(':')[0]), 'utf8').split('\n')[Number(where[0].split(':')[1]) - 1])) continue;
    const uses = text.split(new RegExp('(?<![\\w$])' + n.replace(/\$/g, '\\$') + '(?![\\w$])')).length - 1;
    if (uses <= 1 && !ALLOW.has(n)) fail(`[${app}] كود ميت؟ الدالة "${n}" لا يشير إليها أحد (${where[0]}). احذفها أو أضفها إلى scripts/dead-code-allowlist.json مع السبب`);
  }
}
if (failed) { console.error('\nفحص التكرار/الكود الميت: فشل'); process.exit(1); }
console.log('فحص التكرار/الكود الميت نجح: لا تعريف مكرر، لا ملف متطابق، لا دالة ميتة.');
