/* فحص بنية الإصدار: ملفات أساسية، ترتيب تحميل الواجهات، ملفات الأمان، عدم وجود أسرار، ومعاينة مستقلة سليمة. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import os from 'node:os';
import { spawnSync } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');
const exists = (f) => fs.existsSync(path.join(root, f));

const must = [
  ['server/index.mjs', 'createApp'],
  ['server/app.mjs', 'verification'],
  ['server/db/migrations/001_initial.sql', 'CREATE TABLE'],
  ['server/db/migrations/018_office_verification.sql', 'office_verifications'],
  ['shared/scripts/api-bridge.js', 'requestOtp'],
  ['shared/assets/brand/logo.png', null],
  ['.github/workflows/ci.yml', 'npm test'],
  ['shared/styles/trip-page.css', '.dpInfo'],
  ['.env.example', 'ADMIN_PHONE'],
  ['.gitignore', '.env'],
  ['shared/pwa/sw.js', 'self.addEventListener'],
  ['shared/pwa/pwa.js', 'serviceWorker'],
  ['server/config/env.mjs', 'loadEnvFile'],
  ['scripts/env-get.mjs', 'loadDotEnv'],
  ['scripts/start-local.sh', 'env-get.mjs'],
  ['Dockerfile', null],
  ['compose.yaml', null],
  ['docs/EXTERNAL_SERVICES_AR.md', null],
  ['docs/EXPLANATION_AR.md', null],
  ['SECURITY.md', null],
];
for (const [f, needle] of must) {
  if (!exists(f)) {
    errors.push(`ملف ناقص: ${f}`);
    continue;
  }
  if (needle && !read(f).includes(needle)) errors.push(`محتوى متوقع غير موجود في ${f}: ${needle}`);
}

/* كل سكربت/ستايل مذكور في index.html موجود فعلاً */
for (const role of ['customer', 'office', 'admin']) {
  const idx = `apps/${role}/index.html`;
  if (!exists(idx)) {
    errors.push(`ناقص ${idx}`);
    continue;
  }
  const html = read(idx);
  for (const m of html.matchAll(/(?:src|href)=["']([^"']+\.(?:js|css))["']/g)) {
    const ref = m[1];
    if (/^https?:/.test(ref)) continue;
    const file = ref.startsWith('/') ? ref.slice(1) : `apps/${role}/${ref}`;
    if (!exists(file)) errors.push(`${idx} يشير إلى ملف غير موجود: ${ref}`);
  }
  const refs = [...html.matchAll(/src=["']([^"']+\.js)["']/g)].map((x) => x[1]);
  if (new Set(refs).size !== refs.length) errors.push(`${idx}: سكربت مكرر`);
}

/* لا أسرار ولا بيانات حقيقية في المستودع */
const banned = [/BEGIN (RSA |EC )?PRIVATE KEY/, /AKIA[0-9A-Z]{16}/, /sk_live_[0-9a-zA-Z]+/];
const walk = (dir) =>
  fs.readdirSync(path.join(root, dir), { withFileTypes: true }).flatMap((e) => {
    const rel = path.join(dir, e.name);
    if (e.isDirectory()) return ['node_modules', '.git', 'storage', 'originals'].includes(e.name) ? [] : walk(rel);
    return /\.(js|mjs|json|md|html|css|yml|yaml|sql|sh|bat)$/.test(e.name) || e.name === '.env.example' ? [rel] : [];
  });
for (const f of walk('.')) {
  if (f === 'preview/standalone.html') continue;
  const t = read(f);
  for (const re of banned) if (re.test(t)) errors.push(`سر محتمل في ${f}`);
}
if (exists('.env')) errors.push('ملف .env موجود داخل المشروع — لا يجب رفعه');
if (/safarak_admin_pass|Dev-Only-Pass/.test(read('.env.example'))) errors.push('.env.example يحوي كلمة مرور فعلية');

/* الإدارة غير ظاهرة في تطبيق العميل */
const customerFiles = walk('apps/customer').map((f) => read(f)).join('\n');
if (/href=["'][^"']*apps\/admin/i.test(customerFiles)) errors.push('رابط إدارة ظاهر في تطبيق العميل');

/* .env.example: لا تعليق داخل سطر القيمة، والقيم المحتوية مسافات مُنصّصة */
for (const line of read('.env.example').split(/\r?\n/)) {
  if (!line.trim() || line.trimStart().startsWith('#') || !line.includes('=')) continue;
  const raw = line.slice(line.indexOf('=') + 1);
  if (/\s#/.test(raw)) errors.push(`.env.example: تعليق داخل سطر القيمة: ${line}`);
  if (/\s/.test(raw.trim()) && !/^".*"$/.test(raw.trim())) errors.push(`.env.example: قيمة بمسافات دون تنصيص: ${line}`);
}

/* عامل الخدمة وإشعار الجهاز: تسجيل sw.js وpwa.js في صفحات العميل والمكتب فقط */
for (const role of ['customer', 'office']) {
  const html = read(`apps/${role}/index.html`);
  if (!html.includes('/shared/pwa/pwa.js')) errors.push(`apps/${role}/index.html لا يحمّل pwa.js`);
  if (!exists(`apps/${role}/manifest.webmanifest`)) errors.push(`ناقص manifest.webmanifest لتطبيق ${role}`);
}
if (/serviceWorker\.register|pwa\.js/.test(read('apps/admin/index.html'))) errors.push('لوحة الإدارة لا يجب أن تسجّل عامل الخدمة');

/* المعاينة المستقلة */
if (!exists('preview/standalone.html')) errors.push('preview/standalone.html غير موجود — شغّل npm run build:preview');
else {
  const preview = read('preview/standalone.html');
  try {
    const match = preview.match(/<script id="embedded-pages" type="application\/json">([\s\S]*?)<\/script>/);
    if (!match) throw new Error('JSON المضمَّن مفقود');
    const pages = JSON.parse(match[1]);
    for (const role of ['admin', 'office', 'customer']) {
      if (!pages[role]) throw new Error(`واجهة ${role} غير مضمَّنة`);
      if (!pages[role].includes('SAFARAK_PREVIEW_MODE=true')) throw new Error(`وضع المعاينة غير مفعّل في ${role}`);
      for (const s of pages[role].matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)) new vm.Script(s[1], { filename: `preview:${role}` });
    }
    if (preview.indexOf('openRole(\'admin\')') < 0) throw new Error('المعاينة لا تبدأ بلوحة الإدارة');
    if (!preview.includes('لا تثبت أن الربط يعمل')) throw new Error('عبارة التنبيه (لا تثبت الاتصال بقاعدة البيانات) مفقودة');
    // الملف المرفق يجب أن يطابق تماماً ما يبنيه الكود الحالي (لا نسخة قديمة)
    const tmp = path.join(os.tmpdir(), `safarak-preview-${process.pid}.html`);
    const r = spawnSync(process.execPath, [path.join(root, 'scripts', 'build-standalone-preview.mjs')], { env: { ...process.env, PREVIEW_OUT: tmp }, encoding: 'utf8' });
    if (r.status !== 0) throw new Error('تعذّر بناء المعاينة للمقارنة: ' + (r.stderr || r.stdout));
    const fresh = fs.readFileSync(tmp, 'utf8');
    fs.rmSync(tmp, { force: true });
    if (fresh !== preview) throw new Error('preview/standalone.html قديم ولا يطابق الكود الحالي — شغّل npm run build:preview');
  } catch (e) {
    errors.push(`فحص المعاينة فشل: ${e.message}`);
  }
}

if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(1);
}
console.log(`فحص الإصدار نجح (${must.length} ملف أساسي + ترتيب الواجهات + الأسرار + المعاينة المستقلة).`);
