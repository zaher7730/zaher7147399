// نسخة احتياطية يدوية متّسقة (قاعدة البيانات + الملفات): npm run backup
import { loadConfig } from '../server/config/index.mjs';
import { openDatabase } from '../server/db/connection.mjs';
import { backupNow } from '../server/db/backup.mjs';
const cfg = loadConfig();
const db = openDatabase(cfg);
console.log('Backup written to', backupNow(db, cfg, console.log));
db.close();
