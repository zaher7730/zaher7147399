// يطبع قيمة متغير واحد من البيئة أو من ملف .env (بنفس محلل الخادم). الاستعمال: node scripts/env-get.mjs KEY
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadDotEnv } from '../server/config/env.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const key = process.argv[2] || '';
if (!/^[A-Z][A-Z0-9_]*$/.test(key)) {
  process.stderr.write('usage: node scripts/env-get.mjs KEY\n');
  process.exit(2);
}
loadDotEnv(ROOT);
process.stdout.write(process.env[key] ?? '');
