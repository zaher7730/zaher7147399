/* يبني preview/standalone.html: ملف واحد يحوي واجهات العميل والمكتب والإدارة (تبدأ بالإدارة)
   مع مبدّل بينها. معاينة بصرية فقط: لا خادم، لا قاعدة بيانات، ولا يثبت اتصالاً بها. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ROLES = ['admin', 'office', 'customer'];
/* نص التنبيه الوحيد للمعاينة: يُستعمل في الشريط العلوي وفي preview/README.txt، ونفس الصياغة في README.md وdocs/STATUS_AR.md (check-release يتحقق من وجود عبارة «لا تثبت أن الربط يعمل») */
const PREVIEW_NOTE = 'لا تتصل بالخادم ولا بقاعدة البيانات — لا تثبت أن الربط يعمل';
const TITLES = { admin: 'لوحة الإدارة', office: 'لوحة المكتب', customer: 'تطبيق العميل' };
const MIME = { ttf: 'font/ttf', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', svg: 'image/svg+xml', gif: 'image/gif', ico: 'image/x-icon' };
const SERVER_ONLY = /\/shared\/scripts\/(api-bridge|realtime|files-client)\.js$/;
const dataCache = new Map();
const ASSET_RE = /(["'(])((?:\.{0,2}\/)?[\w\-./]+\.(?:png|jpe?g|webp|svg|gif|ico|ttf))(?=["')?#])/g;

function toDataUri(file) {
  if (!dataCache.has(file)) {
    const ext = path.extname(file).slice(1).toLowerCase();
    dataCache.set(file, `data:${MIME[ext]};base64,${fs.readFileSync(file).toString('base64')}`);
  }
  return dataCache.get(file);
}
function resolveAsset(ref, appDir, baseDir) {
  const tries = ref.startsWith('/') ? [path.join(ROOT, ref)] : [path.join(baseDir, ref), path.join(appDir, ref)];
  return tries.find((f) => fs.existsSync(f) && fs.statSync(f).isFile());
}
function inlineAssets(text, appDir, baseDir) {
  return text.replace(ASSET_RE, (m, q, ref) => {
    const f = resolveAsset(ref, appDir, baseDir);
    return f ? q + toDataUri(f) : m;
  });
}
const readFrom = (appDir, ref) => fs.readFileSync(ref.startsWith('/') ? path.join(ROOT, ref) : path.join(appDir, ref), 'utf8');

function buildApp(role) {
  const appDir = path.join(ROOT, 'apps', role);
  let html = fs.readFileSync(path.join(appDir, 'index.html'), 'utf8');
  html = html.replace(/<link\s+[^>]*rel=["']stylesheet["'][^>]*href=["']([^"']+)["'][^>]*>/gi, (m, href) => {
    if (/^https?:/.test(href)) return '';
    const file = href.startsWith('/') ? path.join(ROOT, href) : path.join(appDir, href);
    return `<style>\n${inlineAssets(fs.readFileSync(file, 'utf8'), appDir, path.dirname(file))}\n</style>`;
  });
  html = html.replace(/<script\s+[^>]*src=["']([^"']+)["'][^>]*><\/script>/gi, (m, src) => {
    if (SERVER_ONLY.test(src) || /^https?:/.test(src)) return '';
    return `<script>\n${inlineAssets(readFrom(appDir, src), appDir, appDir).replace(/<\/script/gi, '<\\/script')}\n</script>`;
  });
  html = inlineAssets(html, appDir, appDir);
  html = html.replace(/<link\s+[^>]*rel=["'](?:manifest|icon)["'][^>]*>/gi, '');
  const guard = `<script>window.SAFARAK_PREVIEW_MODE=true;window.SAFARAK_PREVIEW_ROLE=${JSON.stringify(role)};</script>`;
  html = html.replace('</head>', () => guard + '</head>');
  if (/(src|href)=["'](?!data:|https?:|#|javascript:)[^"']*\.(js|css)["']/.test(html)) throw new Error(`بقي ملف خارجي غير مضمَّن في ${role}`);
  return html;
}

const pages = Object.fromEntries(ROLES.map((r) => [r, buildApp(r)]));
const json = JSON.stringify(pages).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
const buttons = ROLES.map((r, i) => `<button type="button" data-role="${r}"${i === 0 ? ' class="on"' : ''}>${TITLES[r]}</button>`).join('');

const wrapper = `<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0b1f4d"><title>سفرك أسهل — معاينة الواجهات</title>
<style>
html,body{margin:0;height:100%;overflow:hidden;background:#fff;font-family:Tahoma,Arial,sans-serif}
#bar{position:fixed;z-index:9;top:0;left:0;right:0;height:38px;display:flex;align-items:center;gap:6px;padding:0 10px;background:#0b1f4d;color:#fff;direction:rtl}
#bar b{font-size:12px;color:#e7b83f;margin-inline-end:6px}
#bar button{font-family:inherit;cursor:pointer;border:1px solid #e7b83f66;background:transparent;color:#fff;border-radius:8px;padding:5px 11px;font-size:12px}
#bar button.on{background:linear-gradient(135deg,#e7b83f,#c9951d);color:#17213a;font-weight:800}
#bar small{margin-inline-start:auto;font-size:10px;color:#ffffffaa}
#appframe{position:fixed;top:38px;left:0;width:100%;height:calc(100% - 38px);border:0;background:#fff}
</style></head><body>
<div id="bar"><b>معاينة بصرية</b>${buttons}<small>${PREVIEW_NOTE}</small></div>
<iframe id="appframe" title="معاينة"></iframe>
<script id="embedded-pages" type="application/json">${json}</script>
<script>
const pages=JSON.parse(document.getElementById('embedded-pages').textContent),frame=document.getElementById('appframe');
function openRole(r){if(!Object.prototype.hasOwnProperty.call(pages,r))return;frame.srcdoc=pages[r];document.querySelectorAll('#bar button').forEach(b=>b.classList.toggle('on',b.dataset.role===r))}
document.querySelectorAll('#bar button').forEach(b=>b.addEventListener('click',()=>openRole(b.dataset.role)));
openRole('admin');
</script></body></html>`;

// PREVIEW_OUT: مسار بديل للناتج (يستعمله check-release لمقارنة الملف المرفق بما يبنيه الكود الحالي دون لمس الملف المرفق)
const customOut = process.env.PREVIEW_OUT;
const out = customOut || path.join(ROOT, 'preview', 'standalone.html');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, wrapper, 'utf8');
if (!customOut) fs.writeFileSync(
  path.join(ROOT, 'preview', 'README.txt'),
  `معاينة سفرك أسهل — ملف مستقل (يُبنى بالأمر: npm run build:preview)\n\nيبدأ بلوحة الإدارة، ومن الشريط العلوي تبدّل بين الإدارة والمكتب والعميل.\nمعاينة بصرية فقط: ${PREVIEW_NOTE}.\nللاختبار الحقيقي شغّل الخادم وفق README.md.\n`,
  'utf8',
);
console.log(`Built ${customOut ? out : path.relative(ROOT, out)} (${(fs.statSync(out).size / 1e6).toFixed(2)} MB)`);
