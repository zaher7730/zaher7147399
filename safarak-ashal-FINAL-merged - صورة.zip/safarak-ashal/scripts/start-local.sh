#!/usr/bin/env bash
# تشغيل محلي: يقرأ .env عبر محلل Node نفسه (لا source ولا bash)، ويطلب بيانات المدير فقط إن كانت غير موجودة.
set -euo pipefail
cd "$(dirname "$0")/.."

get() { node scripts/env-get.mjs "$1"; }

if [[ -z "${ADMIN_PHONE:-}" ]]; then ADMIN_PHONE="$(get ADMIN_PHONE)"; fi
if [[ -z "$ADMIN_PHONE" ]]; then read -r -p 'رقم هاتف المدير: ' ADMIN_PHONE; fi
export ADMIN_PHONE

if [[ -z "${ADMIN_PASSWORD:-}" ]]; then ADMIN_PASSWORD="$(get ADMIN_PASSWORD)"; fi
if [[ -z "$ADMIN_PASSWORD" ]]; then read -r -s -p 'كلمة مرور المدير (10+ أحرف): ' ADMIN_PASSWORD; echo; fi
export ADMIN_PASSWORD

if [[ -z "${PORT:-}" ]]; then PORT="$(get PORT)"; fi
export PORT="${PORT:-8000}"
echo "افتح: http://127.0.0.1:${PORT}/"
exec node --no-warnings server/index.mjs
