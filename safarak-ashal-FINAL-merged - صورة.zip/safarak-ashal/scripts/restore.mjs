// استعادة قاعدة البيانات والملفات من نسخة: node scripts/restore.mjs <ملف النسخة .sqlite>   (أوقف الخادم أولاً)
// الملفات تُستعاد تلقائياً من المجلد المجاور «.files» إن وُجد، والحالية تُحفظ بجانبها باسم «.before-restore».
import fs from 'node:fs';
import { loadConfig } from '../server/config/index.mjs';
import { restoreBackup } from '../server/db/restore.mjs';
const file = process.argv[2];
if (!file || !fs.existsSync(file)) { console.error('usage: node scripts/restore.mjs <backup.sqlite>'); process.exit(1); }
try {
  const r = restoreBackup(loadConfig(), file, console.log);
  console.log(r.legacy ? 'تمت استعادة قاعدة البيانات فقط (نسخة قديمة بلا ملفات).' : `تمت استعادة قاعدة البيانات و${r.files} ملفاً.`);
} catch (e) { console.error('فشلت الاستعادة:', e.message); process.exit(1); }
