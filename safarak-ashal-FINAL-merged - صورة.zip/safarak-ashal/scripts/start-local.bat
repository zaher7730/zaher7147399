@echo off
chcp 65001 >nul
cd /d "%~dp0.."
if "%ADMIN_PHONE%"=="" for /f "usebackq delims=" %%A in (`node scripts\env-get.mjs ADMIN_PHONE`) do set "ADMIN_PHONE=%%A"
if "%ADMIN_PHONE%"=="" set /p ADMIN_PHONE=رقم هاتف المدير: 
if "%ADMIN_PASSWORD%"=="" for /f "usebackq delims=" %%A in (`node scripts\env-get.mjs ADMIN_PASSWORD`) do set "ADMIN_PASSWORD=%%A"
if "%ADMIN_PASSWORD%"=="" set /p ADMIN_PASSWORD=كلمة مرور المدير (10+ أحرف): 
if "%PORT%"=="" for /f "usebackq delims=" %%A in (`node scripts\env-get.mjs PORT`) do set "PORT=%%A"
if "%PORT%"=="" set PORT=8000
echo افتح: http://127.0.0.1:%PORT%/
node --no-warnings server\index.mjs
