// يولّد الأسرار اللازمة للتشغيل الحقيقي: node scripts/generate-keys.mjs  (أو npm run keys)
// انسخ الناتج إلى بيئة التشغيل (.env على الخادم أو متغيرات المنصة) — لا ترفعه إلى المستودع.
import crypto from 'node:crypto';
import { generateVapidKeys } from '../server/integrations/push.mjs';
const vapid = generateVapidKeys();
console.log(`# ---- أسرار مولَّدة ${new Date().toISOString()} (احفظها في مدير أسرار، لا في المستودع) ----
OTP_PEPPER=${crypto.randomBytes(32).toString('hex')}
DATA_ENCRYPTION_KEY=${crypto.randomBytes(32).toString('hex')}
VAPID_PUBLIC_KEY=${vapid.publicKey}
VAPID_PRIVATE_KEY=${vapid.privateKey}
VAPID_SUBJECT=mailto:admin@your-domain.example`);
