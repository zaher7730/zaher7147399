// يتأكد أن كل دالة/ثابت معرّف في ملفات المرجع الأصلية الثلاثة ما زال معرّفاً في apps/ (يمنع ضياع أكواد عند إعادة التنظيم).
// الأسماء المسموح فقدها عمداً (بيانات تجريبية حُذفت) في قائمة INTENTIONAL.
import fs from 'node:fs';
import path from 'node:path';
const ROOT = path.resolve(new URL('..', import.meta.url).pathname);
const REF = { customer: 'safarak-ashal-audited (4).html', office: 'safarak-office-panel-v12_20_5.html', admin: 'safarak-admin-panel (9).html' };
const INTENTIONAL = new Set(['CRA', 'GP', 'OFR', 'RP', 'RV0', 'RGB', 'GG', 'NMD', 'NX', 'OS', 'base', 'dvs', 'fr', 'nd', 'oi', 'sm', 'sum', 'kk', 'of', 'reply', 'nid', 'date', 'dv', 'last', 'ni', 'v', 'saveOC', 'officeEditor', 'officePanel', 'officeEditorBody', 'readEditor', 'saveOfficeCfg', 'resetOfficeCfg', 'previewOfficeCfg']);
const walk = (d, o = []) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); fs.statSync(p).isDirectory() ? walk(p, o) : /\.(js|html)$/.test(f) && o.push(p); } return o; };
let bad = 0;
for (const [app, file] of Object.entries(REF)) {
  const ref = fs.readFileSync(path.join(ROOT, 'originals/reference', file), 'utf8');
  const src = walk(path.join(ROOT, 'apps', app)).map((p) => fs.readFileSync(p, 'utf8')).join('\n');
  const names = new Set([...ref.matchAll(/\bfunction\s+([A-Za-z_$][\w$]*)\s*\(/g)].map((m) => m[1]));
  const lost = [...names].filter((n) => !INTENTIONAL.has(n) && !new RegExp(`function\\s+${n.replace(/\$/g, '\\$')}\\b`).test(src) && !new RegExp(`(?:const|let|var)\\s+${n.replace(/\$/g, '\\$')}\\b|[,\\s]${n.replace(/\$/g, '\\$')}\\s*=`).test(src));
  console.log(`${app}: ${names.size} دالة في الأصل، المفقود: ${lost.length ? lost.join(' ') : 'لا شيء'}`);
  bad += lost.length;
}
process.exit(bad ? 1 : 0);
