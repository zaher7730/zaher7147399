// إنشاء أول مدير من متغيرات البيئة فقط (لا توجد بيانات دخول افتراضية).
import { hashPassword, strongEnough } from '../security/index.mjs';
import { normalizePhone } from '../lib/phone.mjs';
import { randomBytes } from 'node:crypto';
export function bootstrapAdmin(db, cfg, log = () => {}) {
  if (!cfg.admin.phone || !cfg.admin.password) return false;
  if (!strongEnough(cfg.admin.password)) throw new Error('ADMIN_PASSWORD must be at least 10 characters and not digits only');
  if (db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get()) return false;
  db.prepare('INSERT INTO users(name,phone,email,password_hash,role) VALUES(?,?,?,?,?)').run(cfg.admin.name, normalizePhone(cfg.admin.phone), cfg.admin.email, hashPassword(cfg.admin.password), 'admin');
  log('Initial administrator created from environment configuration.');
  return true;
}

// وضع التجربة فقط: ثلاثة حسابات جاهزة (عميل/مكتب/مدير) لتجربة التصميم والترابط برموز ثابتة. لا يعمل خارج DEMO_MODE=true.
export const DEMO_CODES = { customer: '1111', office: '2222', admin: '3333' };
export const DEMO_ACCOUNTS = [
  { role: 'customer', phone: '+967770000001', name: 'عميل تجريبي' },
  { role: 'office', phone: '+967770000002', name: 'مكتب تجريبي', office: 'مكتب التجربة للسفر' },
  { role: 'admin', phone: '+967770000003', name: 'مدير تجريبي' },
];
export function bootstrapDemoUsers(db, cfg, log = () => {}) {
  if (!cfg.demo || cfg.production) return false;
  const ins = db.prepare('INSERT INTO users(name,phone,password_hash,role,office_name) VALUES(?,?,?,?,?)');
  for (const a of DEMO_ACCOUNTS) {
    if (db.prepare('SELECT id FROM users WHERE phone=?').get(a.phone)) continue;
    ins.run(a.name, a.phone, hashPassword(randomBytes(32).toString('hex')), a.role, a.office || null);
  }
  log('DEMO MODE: عميل 1111 | مكتب 2222 | إدارة 3333 — للتجربة المحلية فقط، لا تستعمله على الإنترنت.');
  return true;
}
