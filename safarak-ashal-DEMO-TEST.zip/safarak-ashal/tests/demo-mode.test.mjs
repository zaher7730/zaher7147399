// وضع التجربة: رموز ثابتة للعميل/المكتب/الإدارة، ومرفوض في الإنتاج، ومغلق افتراضياً.
import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { startServer } from './helpers.mjs';

const login = async (S, role, phone, code, name = 'تجربة') => {
  const rq = await S.request('/api/auth/request-otp', 'POST', { role, phone, name });
  assert.equal(rq.status, 200, JSON.stringify(rq.data));
  return S.request('/api/auth/verify-otp', 'POST', { challengeId: rq.data.challengeId, code });
};

test('وضع التجربة: 1111 عميل و2222 مكتب و3333 إدارة، وأي رقم يعمل', async () => {
  const S = await startServer({ DEMO_MODE: 'true' });
  try {
    const c = await login(S, 'customer', '771234567', '1111');
    assert.equal(c.status, 200); assert.equal(c.data.user.role, 'customer');
    const o = await login(S, 'office', '700000000', '2222');
    assert.equal(o.status, 200); assert.equal(o.data.user.role, 'office');
    const a = await login(S, 'admin', '700000000', '3333');
    assert.equal(a.status, 200); assert.equal(a.data.user.role, 'admin');
    const wrong = await login(S, 'admin', '700000000', '1111');
    assert.equal(wrong.status, 401);
  } finally { await S.stop(); }
});

test('بدون DEMO_MODE لا يوجد أي رمز ثابت (الرمز عشوائي)', async () => {
  const S = await startServer();
  try {
    const rq = await S.request('/api/auth/request-otp', 'POST', { role: 'customer', phone: '771234567', name: 'عميل' });
    assert.equal(rq.status, 200);
    const r = await S.request('/api/auth/verify-otp', 'POST', { challengeId: rq.data.challengeId, code: '1111' });
    assert.ok([200, 401].includes(r.status));
    const adm = await S.request('/api/auth/request-otp', 'POST', { role: 'admin', phone: '700000000' });
    assert.equal(adm.status, 403);
  } finally { await S.stop(); }
});

test('DEMO_MODE مرفوض مع NODE_ENV=production', () => {
  const r = spawnSync(process.execPath, ['--no-warnings', 'server/index.mjs'], {
    cwd: new URL('..', import.meta.url).pathname, encoding: 'utf8', timeout: 8000,
    env: { ...process.env, NODE_ENV: 'production', DEMO_MODE: 'true', SAFARAK_ENV_FILE: '', OTP_PEPPER: 'x'.repeat(40), PORT: '0' },
  });
  assert.notEqual(r.status, 0);
  assert.match(r.stderr, /DEMO_MODE/);
});

test('صفحة الدخول الموحدة: الجذر يفتحها، والدخول منها يعطي جلسة تفهمها التطبيقات', async () => {
  const S = await startServer({ DEMO_MODE: 'true' });
  try {
    const page = await S.request('/');
    assert.equal(page.status, 200);
    assert.match(page.data, /تسجيل الدخول/);
    assert.match(page.data, /data-role="customer"/);
    assert.match(page.data, /data-role="office"/);
    const o = await login(S, 'office', '700000000', '2222');
    const me = await S.request('/api/auth/me', 'GET', undefined, o.cookie);
    assert.equal(me.data.user.role, 'office');
    assert.equal((await S.request('/apps/admin/', 'GET', undefined, o.cookie, { redirect: 'manual' })).status, 302);
    const a = await login(S, 'admin', '700000000', '3333');
    assert.equal((await S.request('/apps/admin/index.html', 'GET', undefined, a.cookie, { redirect: 'manual' })).status, 200);
  } finally { await S.stop(); }
});
