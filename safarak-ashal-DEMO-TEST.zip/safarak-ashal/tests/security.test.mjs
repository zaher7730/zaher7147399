// الأمان: إخفاء الإدارة، حماية الأدوار، الترويسات، حماية الملفات الخاصة، CSRF.
import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';

let S, admin, customer, office;
test.before(async () => {
  S = await startServer();
  admin = await S.adminLogin();
  office = (await S.seedOffice(admin)).cookie;
  customer = (await S.otpLogin('customer', '770000003', 'Test Customer')).cookie;
});
test.after(() => S.stop());

test('الصفحات الثلاث تُقدَّم من مسارات نظيفة وللإدارة شروط', async () => {
  const home = await S.request('/');
  assert.equal(home.status, 200);
  for (const app of ['customer', 'office']) {
    const r = await S.request(`/apps/${app}/`);
    assert.equal(r.status, 200, app);
    assert.match(r.data, /scripts\//);
  }
  const hidden = await S.request('/apps/admin/', 'GET', undefined, undefined, { redirect: 'manual' });
  assert.equal(hidden.status, 302);
  assert.match(hidden.headers.get('location'), /access=admin/);
  for (const c of [customer, office]) {
    const r = await S.request('/apps/admin/', 'GET', undefined, c, { redirect: 'manual' });
    assert.equal(r.status, 302, 'غير المدير لا يرى لوحة الإدارة');
  }
  assert.equal((await S.request('/apps/admin/', 'GET', undefined, admin)).status, 200);
  assert.equal((await S.request('/apps/admin/scripts/core/render-router.js', 'GET', undefined, undefined, { redirect: 'manual' })).status, 302);
});

test('كل مسارات /api/admin ترفض الزائر والعميل والمكتب', async () => {
  const paths = ['/api/admin/users', '/api/admin/settings', '/api/admin/stats', '/api/admin/audit', '/api/admin/payments', '/api/admin/bookings', '/api/admin/docs', '/api/admin/packages', '/api/admin/office-applications', '/api/admin/payment-methods', '/api/admin/points', '/api/admin/quotas', '/api/admin/package-purchases'];
  for (const p of paths) {
    const anon = await S.request(p);
    assert.ok([401, 404, 405].includes(anon.status), p + ' anon ' + anon.status);
    if (anon.status === 404 || anon.status === 405) continue;
    assert.equal(anon.status, 401, p);
    assert.equal((await S.request(p, 'GET', undefined, customer)).status, 403, p + ' customer');
    assert.equal((await S.request(p, 'GET', undefined, office)).status, 403, p + ' office');
  }
  assert.equal((await S.request('/api/admin/stats', 'GET', undefined, admin)).status, 200);
});

test('ترويسات الأمان وعدم كشف الملفات الخاصة والقاعدة', async () => {
  const r = await S.request('/api/health');
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  for (const p of ['/storage/database/test.sqlite', '/storage/private/uploads/x.bin', '/server/index.mjs', '/.env', '/package.json', '/tests/helpers.mjs', '/originals/reference/x.html', '/../etc/passwd', '/%2e%2e/etc/passwd']) {
    const x = await S.request(p, 'GET', undefined, undefined, { redirect: 'manual' });
    assert.notEqual(x.status, 200, p);
  }
});

test('رفض الطلبات العابرة للأصل (CSRF) وكوكي الجلسة HttpOnly', async () => {
  const bad = await S.request('/api/auth/logout', 'POST', {}, customer, { headers: { origin: 'https://evil.example' } });
  assert.equal(bad.status, 403);
  const login = await fetch(S.base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ identifier: '770000001', password: 'TestAdminPass!2026' }) });
  const sc = login.headers.get('set-cookie');
  assert.match(sc, /HttpOnly/i);
  assert.match(sc, /SameSite=Strict/i);
});

test('كلمة مرور خاطئة ومحاولات OTP الخاطئة تُرفض', async () => {
  assert.equal((await S.request('/api/auth/login', 'POST', { identifier: '770000001', password: 'wrong' })).status, 401);
  const rq = await S.request('/api/auth/request-otp', 'POST', { role: 'customer', phone: '770000099', name: 'Nobody' });
  assert.equal(rq.status, 200);
  const wrong = await S.request('/api/auth/verify-otp', 'POST', { challengeId: rq.data.challengeId, code: String((Number(await S.otpCode('770000099')) + 1) % 10000).padStart(4, '0') });
  assert.ok([400, 401].includes(wrong.status));
  assert.equal((await S.request('/api/auth/request-otp', 'POST', { role: 'admin', phone: '770000098' })).status, 403);
  assert.equal((await S.request('/api/auth/request-otp', 'POST', { role: 'office', phone: '770000097' })).status, 403);
});

test('كل ملف سكربت/ستايل/صورة تشير إليه الواجهات الثلاث يُحمَّل بنوعه الصحيح', async () => {
  for (const app of ['customer', 'office', 'admin']) {
    const html = (await S.request(`/apps/${app}/`, 'GET', undefined, app === 'admin' ? admin : undefined)).data;
    const refs = [...html.matchAll(/(?:src|href)="([^"#]+\.(?:js|css|png|webmanifest))"/g)].map((m) => m[1]).filter((u) => !/^https?:/.test(u));
    assert.ok(refs.length > 5, app + ' refs');
    for (const ref of refs) {
      const url = ref.startsWith('/') ? ref : `/apps/${app}/${ref}`;
      const r = await fetch(S.base + url, { headers: app === 'admin' ? { cookie: admin } : {} });
      assert.equal(r.status, 200, url);
      const type = r.headers.get('content-type');
      if (url.endsWith('.js')) assert.match(type, /javascript/, url);
      if (url.endsWith('.css')) assert.match(type, /css/, url);
      await r.arrayBuffer();
    }
  }
});

test('قفل الدخول بعد 5 محاولات فاشلة، والتسجيل بكلمة مرور معطّل، والدخول بكلمة المرور للمدير فقط', async () => {
  for (let i = 0; i < 5; i++) assert.equal((await S.request('/api/auth/login', 'POST', { identifier: '770000444', password: 'nope-' + i })).status, 401);
  const locked = await S.request('/api/auth/login', 'POST', { identifier: '770000444', password: 'TestAdminPass!2026' });
  assert.equal(locked.status, 429, 'يُرفض أثناء القفل مهما كانت كلمة المرور');
  assert.equal((await S.request('/api/auth/register', 'POST', { name: 'x y', phone: '770000555', password: 'password-12345' })).status, 404);
  assert.equal((await S.request('/api/auth/login', 'POST', { identifier: '+967770000003', password: 'whatever-12345' })).status, 401, 'العميل لا يدخل بكلمة مرور');
});

test('أجهزتي: عرض الجلسات وإنهاء الأخرى', async () => {
  const c2 = (await S.otpLogin('customer', '770000003', 'Test Customer')).cookie;
  const list = await S.request('/api/auth/sessions', 'GET', undefined, c2);
  assert.ok(list.data.sessions.length >= 2);
  assert.equal(list.data.sessions.filter((s) => s.current).length, 1);
  assert.equal((await S.request('/api/auth/sessions/revoke-others', 'POST', {}, c2)).status, 200);
  assert.equal((await S.request('/api/auth/me', 'GET', undefined, customer)).status, 401, 'الجلسة الأخرى أُنهيت');
  assert.equal((await S.request('/api/auth/me', 'GET', undefined, c2)).status, 200);
  customer = c2;
});

test('الهوية مشفّرة في القاعدة وتُقرأ مفكوكة لصاحبها فقط', async () => {
  const put = await S.request('/api/me/profile', 'PUT', { idType: 'جواز', idNumber: 'P-9988776', city: 'عدن' }, customer);
  assert.equal(put.status, 200, JSON.stringify(put.data));
  assert.equal(put.data.profile.idNumber, 'P-9988776');
  const { DatabaseSync } = await import('node:sqlite');
  const row = new DatabaseSync(S.dbPath).prepare('SELECT id_number FROM customer_profiles').get();
  assert.match(row.id_number, /^enc:v1:/);
  assert.ok(!row.id_number.includes('9988776'));
});

test('حالة الخدمات الخارجية للمدير فقط وبلا أسرار', async () => {
  assert.equal((await S.request('/api/admin/integrations', 'GET', undefined, customer)).status, 403);
  const r = await S.request('/api/admin/integrations', 'GET', undefined, admin);
  assert.equal(r.status, 200);
  assert.ok(r.data.integrations.length >= 6);
  assert.doesNotMatch(JSON.stringify(r.data), /TestAdminPass|whsec_|sk_live/);
});

test('الجذر / يحوَّل لصفحة الدخول الموحدة مع حفظ ?access=admin، والمعاينة غير عامة', async () => {
  const root = await S.request('/', 'GET', undefined, undefined, { redirect: 'manual' });
  assert.equal(root.status, 302);
  assert.equal(root.headers.get('location'), '/apps/login/');
  const adm = await S.request('/?access=admin', 'GET', undefined, undefined, { redirect: 'manual' });
  assert.equal(adm.status, 302);
  assert.equal(adm.headers.get('location'), '/apps/login/?access=admin');
  // بعد التحويل تُحمَّل ملفات الواجهة من مسارها الصحيح (سبب الصفحة البيضاء القديمة)
  const page = await S.request('/');
  assert.equal(page.status, 200);
  assert.equal((await S.request('/styles/base/base.css')).status, 404, 'لا إعادة كتابة داخلية للجذر');
  assert.equal((await S.request('/apps/customer/styles/base/base.css')).status, 200);
  assert.equal((await S.request('/apps/login/login.js')).status, 200);
  // المعاينة المستقلة تحمل كود الإدارة: لا تُقدَّم من الخادم
  assert.equal((await S.request('/preview/standalone.html')).status, 404);
  assert.equal((await S.request('/preview/README.txt')).status, 404);
});
