/* صفحة الدخول الموحدة: تختار عميل أو مكتب (أو إدارة) ثم رمز التحقق، وتحوّلك للتطبيق المناسب.
   لا تضيف منطق دخول جديداً: تستعمل نفس مسارات الخادم /api/auth/* ونفس الجلسة التي تفهمها التطبيقات الثلاثة. */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const HOME = { customer: '/apps/customer/', office: '/apps/office/', admin: '/apps/admin/' };
  const LABEL = { customer: 'عميل', office: 'مكتب', admin: 'مدير' };
  let role = 'customer', challengeId = '', busy = false;

  const post = async (url, body) => {
    const r = await fetch(url, { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || 'تعذّر إتمام الطلب');
    return d;
  };
  const msg = (t, ok) => { const m = $('msg'); m.textContent = t || ''; m.hidden = !t; m.className = 'msg' + (ok ? ' ok' : ''); };
  const setBusy = (v) => { busy = v; $('sendBtn').disabled = $('verifyBtn').disabled = v; };

  function setRole(r) {
    role = r; challengeId = '';
    document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('on', b.dataset.role === r));
    $('nameWrap').hidden = r !== 'customer';
    $('step1').hidden = false; $('step2').hidden = true; $('code').value = ''; msg('');
    $('tabs').hidden = r === 'admin';
    $('adminLink').textContent = r === 'admin' ? 'رجوع' : 'دخول الإدارة';
    $('sub').textContent = r === 'admin' ? 'دخول الإدارة' : 'اختر نوع حسابك ثم سجّل الدخول';
  }

  document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => setRole(b.dataset.role)));
  $('adminLink').addEventListener('click', () => setRole(role === 'admin' ? 'customer' : 'admin'));
  $('backBtn').addEventListener('click', () => { $('step1').hidden = false; $('step2').hidden = true; msg(''); });

  $('sendBtn').addEventListener('click', async () => {
    if (busy) return;
    msg(''); setBusy(true);
    try {
      const d = await post('/api/auth/request-otp', { role, phone: $('phone').value.trim(), name: $('name').value.trim() });
      challengeId = d.challengeId;
      $('step1').hidden = true; $('step2').hidden = false; $('code').focus();
      msg(d.message || 'تم إرسال رمز التحقق', true);
    } catch (e) { msg(e.message); }
    setBusy(false);
  });

  $('verifyBtn').addEventListener('click', async () => {
    if (busy) return;
    msg(''); setBusy(true);
    try {
      const d = await post('/api/auth/verify-otp', { challengeId, code: $('code').value.trim() });
      location.href = HOME[d.user.role] || HOME.customer;
      return;
    } catch (e) { msg(e.message); }
    setBusy(false);
  });
  $('code').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('verifyBtn').click(); });
  $('phone').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('sendBtn').click(); });

  // إن كانت هناك جلسة سابقة: اعرض متابعة أو تسجيل الخروج (دون تحويل تلقائي حتى يمكنك الدخول بحساب آخر)
  fetch('/api/auth/me', { credentials: 'same-origin', cache: 'no-store' })
    .then((r) => (r.ok ? r.json() : null))
    .then((d) => {
      if (!d || !d.user) return;
      $('alreadyText').textContent = `أنت مسجّل الدخول كـ ${LABEL[d.user.role] || ''}: ${d.user.name || ''}`;
      $('already').hidden = false;
      $('goBtn').addEventListener('click', () => { location.href = HOME[d.user.role] || HOME.customer; });
      $('outBtn').addEventListener('click', async () => { await post('/api/auth/logout', {}).catch(() => {}); location.reload(); });
    })
    .catch(() => {});

  if (new URLSearchParams(location.search).get('access') === 'admin') setRole('admin');
})();
