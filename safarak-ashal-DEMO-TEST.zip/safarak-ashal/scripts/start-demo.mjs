// تشغيل وضع التجربة: node scripts/start-demo.mjs  (أو npm run demo)
// رموز الدخول: عميل 1111 — مكتب 2222 — إدارة 3333. قاعدة بيانات منفصلة (storage/database/demo.sqlite) ولا تلمس البيانات الحقيقية.
process.env.DEMO_MODE = 'true';
process.env.NODE_ENV = 'development';
process.env.DB_PATH ||= 'storage/database/demo.sqlite';
process.env.HOST ||= '127.0.0.1';
await import('../server/index.mjs');
